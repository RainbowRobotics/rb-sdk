#pragma once

#include "base.hpp"
#include "common_struct_generated.h"
#include "func_box_generated.h"
#include "func_config_generated.h"
#include "func_maint_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "rb_sdk_api.hpp"
#include "state_core_generated.h"

class RB_SDK_API RBManipulateMaintenanceSDK : public RBBaseSDK {
 public:
  RBManipulateMaintenanceSDK() {}

  static std::string type_name() { return "RBManipulateMaintenanceSDK"; }

  /**
   * @brief Requests the cobot to log/broadcast a joint board's info.
   *
   * This does not return the joint info through the SDK call itself — the
   * robot only reports success/failure here. The actual info is logged and
   * broadcast as a general message on the robot side (visible on the
   * teach-pendant/UI, not returned to this caller). Also powers the robot
   * on if it isn't already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         joint info payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_infos(const std::string& robot_model, int board_no,
                                           FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's brake state.
   *
   * If @p brake_optioin is 1 (Open, Hard) or 2 (Weak), this powers the
   * robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to control. A negative value
   *        applies to every joint board.
   * @param brake_optioin Brake option: 0 (Close), 1 (Open, Hard), 2 (Weak),
   *        or 3 (Close only). (Parameter name matches the underlying wire
   *        field's spelling, including its typo.)
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_brake(const std::string& robot_model, int board_no, int brake_optioin,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to zero a joint board's encoder.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to zero. A negative value applies
   *        to every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_encoder_zero(const std::string& robot_model, int board_no,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to run a joint board's current-sensor calibration procedure.
   *
   * This is a multi-stage physical calibration, not an instant reset:
   * cycles the brake and runs DQ-axis alignment (3 tries), DQ save (2
   * tries), and current nulling (2 tries), with real delays between steps.
   * Takes on the order of several seconds per joint. Powers the robot on
   * first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to calibrate. A negative value
   *        applies to every joint board (multiplying the total time).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_sensor_reset(const std::string& robot_model, int board_no,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's current-loop gains.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param pgain Proportional gain of the current control loop.
   * @param igain Integral gain of the current control loop.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_gain_cur(const std::string& robot_model, int board_no, int pgain, int igain,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's position-loop gains.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param pgain Proportional gain of the position control loop.
   * @param igain Integral gain of the position control loop.
   * @param dgain Derivative gain of the position control loop.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_gain_pos(const std::string& robot_model, int board_no, int pgain, int igain,
                                              int dgain, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to log/broadcast a joint board's current-loop gains.
   *
   * Counterpart to @c set_joint_gain_cur, but this does not return the
   * gain values through the SDK call — the robot only reports
   * success/failure here. The actual gains are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         gain payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_gain_cur(const std::string& robot_model, int board_no,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to log/broadcast a joint board's position-loop gains.
   *
   * Counterpart to @c set_joint_gain_pos, but this does not return the
   * gain values through the SDK call — the robot only reports
   * success/failure here. The actual gains are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         gain payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_gain_pos(const std::string& robot_model, int board_no,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to change a joint board's board-number assignment.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param channel_no Channel the joint board is on.
   * @param board_no Current joint board number. A negative value applies
   *        to every joint board.
   * @param target_no New board number to assign.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_bno_change(const std::string& robot_model, int channel_no, int board_no,
                                                 int target_no, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's big-error/input-error pulse thresholds.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param bigerr Big-error pulse threshold.
   * @param inputerr Input-error pulse threshold.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_big_input(const std::string& robot_model, int board_no, int bigerr, int inputerr,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to log/broadcast a joint board's big-error/input-error pulse thresholds.
   *
   * Counterpart to @c set_joint_big_input, but this does not return the
   * threshold values through the SDK call — the robot only reports
   * success/failure here. The actual values are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         threshold payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_big_input(const std::string& robot_model, int board_no,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's jam/overcurrent error thresholds.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param jam_current Jam-error current limit, in mA.
   * @param jam_time Jam-error duration threshold, in units of 0.1s.
   * @param ovr_current Overcurrent-error current limit, in mA.
   * @param ovr_time Overcurrent-error duration threshold, in units of 0.1s
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_jam_over(const std::string& robot_model, int board_no, int jam_current,
                                              int jam_time, int ovr_current, int ovr_time,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to log/broadcast a joint board's jam/overcurrent error thresholds.
   *
   * Counterpart to @c set_joint_jam_over, but this does not return the
   * threshold values through the SDK call — the robot only reports
   * success/failure here. The actual values are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         threshold payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_jam_over(const std::string& robot_model, int board_no,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to log/broadcast a joint board's DQ-axis encoder values.
   *
   * This does not return the DQ-axis encoder values through the SDK call —
   * the robot only reports success/failure here. The actual values are
   * logged and broadcast as a general message on the robot side (visible
   * on the teach-pendant/UI, not returned to this caller). Also powers the
   * robot on if it isn't already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         DQ-axis encoder payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_dq_axis(const std::string& robot_model, int board_no,
                                             FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to run a short-circuit check.
   *
   * The robot only reports success/failure of the request here. Detailed
   * check results are not returned through the SDK call.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         short-circuit check payload.
   *
   * @throws std::runtime_error If the check request fails or the result
   *         cannot be retrieved.
   */
  IPC::Response_FunctionsT call_shortcircuit_check(const std::string& robot_model,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to force the bleeder on for a given duration.
   *
   * Forces the bleeder (regenerative-energy dissipation circuit) on
   * regardless of its normal activation condition. The robot only reports
   * success/failure of the request here.
   *
   * @param robot_model Name of the robot model.
   * @param time_sec Duration, in seconds, to keep the bleeder forced on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure.
   *
   * @throws std::runtime_error If the request fails or the result cannot
   *         be retrieved.
   */
  IPC::Response_FunctionsT call_force_eater_on(const std::string& robot_model, float time_sec,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to run a CAN message check and log/broadcast the result.
   *
   * This does not return the check result through the SDK call — the
   * robot only reports success/failure here. The actual result is logged
   * and broadcast as a general message on the robot side (visible on the
   * teach-pendant/UI, not returned to this caller).
   *
   * @param robot_model Name of the robot model.
   * @param range_optoin Scope of the CAN message check:
   *        - 0: Control box only
   *        - 1: Control box + robot
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         CAN message check payload.
   *
   * @throws std::runtime_error If the check request fails or the result
   *         cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_can_message_check(const std::string& robot_model, int range_optoin,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Erases the cobot's persisted last joint angle DB.
   *
   * Clears the joint angles the robot has stored as its last known
   * position for all joints at once, and resets the stored entries to
   * @p target_angle.
   *
   * @param robot_model Name of the robot model.
   * @param target_angle Joint angles, in degrees, to store in place of the
   *        erased values. One value per joint, covering every joint.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure.
   *
   * @throws std::runtime_error If the erase request fails or the result
   *         cannot be retrieved.
   */
  IPC::Response_FunctionsT call_persist_joint_erase(const std::string& robot_model, std::vector<float> target_angle,
                                                    FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @defgroup Joint Origin Calibration Origin Calibration Functions
   * @brief Functions for calibrating the robot's origin (base/world reference frame).
   *
   * Typical workflow:
   *   1. @c call_origin_calib_add    — Add one or more joint/TCP pose samples.
   *   2. @c call_origin_calib_run    — Compute calibration from the added samples.
   *   3. @c call_origin_calib_reflect — Commit (apply) the computed calibration,
   *                                     requires a password for authorization.
   *
   * @c call_origin_calib_clr can be called at any point to clear existing
   * calibration data (e.g. to restart the workflow from scratch).
   *
   * All functions in this group only report success/failure through the SDK
   * call; no calibration data itself is returned to the caller.
   * @{
   */

  /**
   * @brief Requests the cobot to clear its origin calibration data.
   *
   * Sends an origin-calibration clear request to the robot. The SDK call
   * only reports success/failure of the clear operation — no calibration
   * data is returned through this call.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         additional payload.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   * @ingroup Joint Origin Calibration
 */
  IPC::Response_FunctionsT call_origin_calib_clr(const std::string& robot_model,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to add a joint/TCP pose sample to its origin
   *        calibration data.
   *
   * Sends one calibration sample — a joint configuration together with the
   * corresponding TCP pose (position and orientation) — to be added to the
   * robot's origin calibration set. The SDK call only reports success/
   * failure of the add operation — no calibration data is returned through
   * this call.
   *
   * @param robot_model Name of the robot model.
   * @param joints Joint angles for this calibration sample.
   * @param tcp_x TCP position, X component.
   * @param tcp_y TCP position, Y component.
   * @param tcp_z TCP position, Z component.
   * @param tcp_rx TCP orientation, X-axis rotation component.
   * @param tcp_ry TCP orientation, Y-axis rotation component.
   * @param tcp_rz TCP orientation, Z-axis rotation component.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         additional payload.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   * @ingroup Joint Origin Calibration
   */
  IPC::Response_FunctionsT call_origin_calib_add(const std::string& robot_model, std::vector<float> joints, float tcp_x,
                                                 float tcp_y, float tcp_z, float tcp_rx, float tcp_ry, float tcp_rz,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
    * @brief Requests the cobot to run origin calibration using the previously
    *        added sample data.
    *
    * Triggers the robot to compute/apply origin calibration from the samples
    * accumulated via @c call_origin_calib_add. The @p option parameter
    * selects the calibration mode/behavior (meaning is robot/firmware
    * defined). The SDK call only reports success/failure of the run
    * operation — no calibration result data is returned through this call.
    *
    * @param robot_model Name of the robot model.
    * @param option Calibration run option/mode selector. (0: Use Position Info,
    *                1: Use Position and Orientation)
    * @param flow_manager_args Optional PyFM step context. If provided,
    *        completion is reported to the flow manager immediately
    *        (synchronous) once the result is received.
    *
    * @return IPC::Response_FunctionsT containing only success/failure — no
    *         additional payload.
    *
    * @throws std::runtime_error If the query fails or the result cannot be
    *         retrieved.
    * @ingroup Joint Origin Calibration
  */
  IPC::Response_FunctionsT call_origin_calib_run(const std::string& robot_model, int option,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to reflect (apply/commit) the computed origin
   *        calibration results.
   *
   * Finalizes the origin calibration process by committing the results
   * produced via @c call_origin_calib_run to the robot. A password is
   * required to authorize this operation, since it permanently changes the
   * robot's origin calibration. The SDK call only reports success/failure —
   * no additional data is returned through this call.
   *
   * @param robot_model Name of the robot model.
   * @param password Authorization password required to commit the
   *        calibration change.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         additional payload.
   *
   * @throws std::runtime_error If the query fails, @p password is invalid,
   *         or the result cannot be retrieved.
   * @ingroup Joint Origin Calibration
   */
  IPC::Response_FunctionsT call_origin_calib_reflect(const std::string& robot_model, int password,
                                                     FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Sends a CAN message from the robot on the specified channel.
   *
   * Transmits a single CAN frame built from the given channel, CAN ID,
   * DLC and data bytes.
   *
   * @param robot_model Name of the robot model.
   * @param channel CAN channel to send on. 0: Ch 0, 1: Ch 1.
   * @param id CAN identifier of the message.
   * @param dlc Data length code (number of data bytes), 0 to 8.
   * @param d0 Data byte 0 (0 to 255).
   * @param d1 Data byte 1 (0 to 255).
   * @param d2 Data byte 2 (0 to 255).
   * @param d3 Data byte 3 (0 to 255).
   * @param d4 Data byte 4 (0 to 255).
   * @param d5 Data byte 5 (0 to 255).
   * @param d6 Data byte 6 (0 to 255).
   * @param d7 Data byte 7 (0 to 255).
   *        Only the first @p dlc bytes (d0 to d(dlc-1)) are transmitted.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the result of the
   *         send request (success/failure).
   *
   * @throws std::runtime_error If the send request fails or the result
   *         cannot be retrieved.
   */
  IPC::Response_FunctionsT call_send_can(const std::string& robot_model, int channel, int id, int dlc, int d0, int d1,
                                         int d2, int d3, int d4, int d5, int d6, int d7,
                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Publishes a CAN message from the robot on the specified channel
   *        without waiting for a response.
   *
   * Fire-and-forget counterpart to call_send_can(): builds and transmits
   * a single CAN frame the same way, but publishes the request (real-time
   * priority, dropped under congestion) instead of querying, and does not
   * report failures back to the caller.
   *
   * @param robot_model Name of the robot model.
   * @param channel CAN channel to send on. 0: Ch 0, 1: Ch 1.
   * @param id CAN identifier of the message.
   * @param dlc Data length code (number of data bytes), 0 to 8.
   * @param d0 Data byte 0 (0 to 255).
   * @param d1 Data byte 1 (0 to 255).
   * @param d2 Data byte 2 (0 to 255).
   * @param d3 Data byte 3 (0 to 255).
   * @param d4 Data byte 4 (0 to 255).
   * @param d5 Data byte 5 (0 to 255).
   * @param d6 Data byte 6 (0 to 255).
   * @param d7 Data byte 7 (0 to 255).
   *        Only the first @p dlc bytes (d0 to d(dlc-1)) are transmitted.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   *
   * @see call_send_can
   */
  void pub_send_can(const std::string& robot_model, int channel, int id, int dlc, int d0, int d1, int d2, int d3,
                    int d4, int d5, int d6, int d7, FlowManagerArgsPtr flow_manager_args = nullptr);

  /** @} */
};
