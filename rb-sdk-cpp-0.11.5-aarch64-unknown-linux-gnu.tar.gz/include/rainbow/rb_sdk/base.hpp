#pragma once

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <memory>
#include <mutex>
#include <nlohmann/json.hpp>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#include "rb_sdk_api.hpp"

#include "binding/glue/gil_release.hpp"
#include "flow_manager_args.hpp"
#include "zenoh_client.hpp"
#include "zenoh_core.hpp"
#include "zenoh_exception.hpp"

// Windows 헤더(basetyps.h)가 `#define interface struct` 를 한다. host_pcan_generated.h 의
// RequestCANConnectT::interface 필드가 `struct` 로 바뀌어 소비자 TU 가 깨지므로 여기서 지운다.
#ifdef interface
#undef interface
#endif

#include "common_struct_generated.h"
#include "host_pcan_generated.h"

#include "mechmind/mechmind_client.hpp"
#include "photoneo/exceptions.hpp"
#include "photoneo/photoneo_client.hpp"
#include "pickit3d/pickit_client.hpp"

/**
 * @brief SDK service family selector used by legacy construction paths.
 *
 * Kept only for source compatibility with the original Python SDK, where the
 * constructor accepted a server family. The C++ RBBaseSDK constructor accepts
 * this value and ignores it: every SDK instance in a process shares the same
 * zenoh session regardless of the service family it talks to.
 */
enum class ServerType { AMR, MANIPULATE };

/**
 * @brief Zenoh congestion-control names used by SDK helpers when calling publish().
 *
 * publish() takes the congestion control as a plain int and casts it straight
 * to zenoh-c's z_congestion_control_t, where 0 = BLOCK and 1 = DROP (the
 * zenoh-c default, and the default of publish()).
 *
 * The values must match z_congestion_control_t exactly: the int is cast
 * without translation, so a mismatch turns DROP into BLOCK and stalls the
 * sender thread under congestion.
 */
enum class CongestionControl : int {
  BLOCK = 0,
  DROP = 1,
  DROP_LATEST = 2,  // zenoh-c unstable BLOCK_FIRST
};

/**
 * @brief Zenoh priority values used by publish().
 *
 * The values match zenoh-c's z_priority_t one-to-one (1 is the highest
 * priority, 7 the lowest) and are passed through unchanged. Lower numbers are
 * scheduled first by the zenoh transport when several messages are queued on
 * the same link. DATA (5) is the default for publish(). Real-time control
 * streams such as servo commands use REAL_TIME.
 */
enum class Priority : int {
  REAL_TIME = 1,
  INTERACTIVE_HIGH = 2,
  INTERACTIVE_LOW = 3,
  DATA_HIGH = 4,
  DATA = 5,
  DATA_LOW = 6,
  BACKGROUND = 7,
};

/**
 * @brief Move-type string constants shared by manipulate program/point helpers.
 *
 * - J: joint-space move.
 * - L: linear (Cartesian) move.
 * - JB: joint-blend sequence (call_move_jb_clr/add/run).
 * - LB: linear-blend sequence (call_move_lb_clr/add/run).
 * - PB: point-blend sequence (call_move_pb_clr/add/run).
 * - XB: mixed blend sequence where each segment chooses joint or linear
 *   motion (call_move_xb_clr/add/run).
 */
struct MoveType {
  inline static constexpr std::string_view J = "J";
  inline static constexpr std::string_view L = "L";
  inline static constexpr std::string_view JB = "JB";
  inline static constexpr std::string_view LB = "LB";
  inline static constexpr std::string_view PB = "PB";
  inline static constexpr std::string_view XB = "XB";
};

/**
 * @brief Options for connecting this SDK process as a remote zenoh peer.
 *
 * Passed to RBBaseSDK::connect() when the SDK runs on a different machine
 * than the robot (for example a developer PC or an external vision PC). The
 * SDK opens a zenoh listen port, registers its IP and port with the robot's
 * common service over HTTP, and keeps that registration alive with periodic
 * heartbeats so that the robot's services connect back to it and the process
 * joins the robot's zenoh mesh.
 *
 * Only token and host are required; every other field has a usable default.
 */
struct ConnectOptions {
  /**
   * Bearer token sent as "Authorization: Bearer <token>" on every peer
   * registration, heartbeat, and unregistration request to the common
   * service.
   */
  std::string token;
  /**
   * IPv4 address or hostname of the robot that runs the common service. The
   * service is reached at http://<host>:8000. If this resolves to the local
   * machine ("127.0.0.1", "localhost", "::1", or an address of this host),
   * connect() does nothing because the process is already in the local mesh.
   */
  std::string host;

  /**
   * Local TCP port on which this process listens for zenoh connections from
   * the robot. When omitted, a free port is picked by the OS. Set it when a
   * firewall only allows a known port.
   */
  std::optional<int> zenoh_port;

  /**
   * Peer registration time-to-live in seconds. The common service drops the
   * peer if no heartbeat arrives within this time. Default: 30.
   */
  int ttl = 30;

  /**
   * Heartbeat interval in seconds. When omitted, ttl / 2 is used, with a
   * lower bound of 1 second. Must be shorter than ttl or the registration
   * expires between heartbeats.
   */
  std::optional<double> heartbeat;
  /**
   * Maximum time in seconds connect() waits for the zenoh echo check to
   * prove that the robot can reach this process. When omitted, 5 seconds is
   * used. If the check does not pass in time, the peer is unregistered and
   * connect() returns no peer id.
   */
  std::optional<double> mesh_timeout;

  /** Time in seconds to wait for each individual echo probe reply. Default: 1.0. */
  double mesh_probe_timeout = 1.0;
  /** Delay in seconds between two consecutive echo probes. Default: 0.5. */
  double mesh_probe_interval = 0.5;
};

/**
 * @brief Owns vendor vision clients keyed by module_name.
 */
template <typename ClientT, typename ConfigT>
class VisionClientRegistry {
 public:
  /**
   * @brief Returns the client currently registered for @p module_name.
   *
   * @return Pointer to the owned client, or nullptr when no client is registered.
   */
  ClientT* get(const std::string& module_name) {
    auto it = clients_.find(module_name);
    return it == clients_.end() ? nullptr : it->second.get();
  }

  /**
   * @brief Replaces the client for @p module_name and connects the new one.
   *
   * If an existing connected client is present for the same module, it is
   * disconnected before the replacement is stored.
   *
   * @return Reference to the connected client owned by this registry.
   *
   * @throws std::exception Propagates errors thrown by the vendor client's
   *         constructor or connect().
   */
  ClientT& connect(const std::string& module_name, const ConfigT& config) {
    auto it = clients_.find(module_name);
    if (it != clients_.end() && it->second->is_connected())
      it->second->disconnect();

    auto client = std::make_unique<ClientT>(config);
    client->connect();
    ClientT& ref = *client;
    clients_[module_name] = std::move(client);
    return ref;
  }

  /**
   * @brief Disconnects all connected clients owned by this registry.
   *
   * Individual disconnect errors are logged and swallowed so SDK cleanup can continue.
   */
  void disconnect_all() {
    for (auto& [module_name, client] : clients_) {
      try {
        if (client && client->is_connected())
          client->disconnect();
      } catch (const std::exception& e) {
        std::cerr << "[VisionClientRegistry] disconnect failed: module=" << module_name << ", err=" << e.what()
                  << std::endl;
      }
    }
  }

 private:
  std::unordered_map<std::string, std::unique_ptr<ClientT>> clients_;
};

/**
 * @brief Common SDK base for zenoh transport, lifecycle, logging, and shared helpers.
 *
 * Every domain SDK (RBManipulateSDK, RBAmrSDK, RBProgramSDK, RBRby1SDK, ...)
 * derives from this class. It provides:
 *
 * - One zenoh session per process. All SDK instances in the same process
 *   share a single rb_zenoh::ZenohClient. The session is opened lazily by the
 *   first constructor and is closed only when the last SDK instance is
 *   closed (reference counted per process id).
 * - Raw and FlatBuffer-typed request/reply (query, query_one, query_all),
 *   publish/subscribe (publish, zenoh_subscribe, receive_one), and serving
 *   requests (zenoh_queryable).
 * - Automatic recovery: query-style calls that fail with a transport error or
 *   no reply reconnect the shared session and retry exactly once.
 * - Remote peer mode (connect/disconnect): lets a process running off-robot
 *   join the robot's zenoh mesh through the common service.
 * - Cross-domain helpers: program logs (log), PyFM step result checks
 *   (manipulate_return_value, validate_single_return_value), CAN bus access
 *   through the host_pcan service (connect_can, disconnect_can,
 *   transmit_can), and vendor vision client registries.
 *
 * Threading: blocking network calls release the Python GIL when it is held,
 * so other Python threads and zenoh callbacks keep running while a call
 * waits for a reply. Calls are safe to make from multiple threads.
 *
 * Fork safety: the zenoh runtime does not survive fork(). An instance that
 * was created in a parent process is ignored by close() in a forked child;
 * the child must create its own SDK instances.
 *
 * Python binding: the Python class keeps one instance per (process id,
 * class), so constructing the same SDK class twice in one process returns the
 * same object. connect() and disconnect() return awaitables in Python, and
 * zenoh_subscribe()/zenoh_queryable() are used as decorators.
 */
class RB_SDK_API RBBaseSDK {
 public:
  /**
   * @brief Returns a process-local singleton base SDK instance.
   *
   * The instance is created on first use and lives until process exit. Use
   * it when only the shared transport and helpers are needed and no domain
   * SDK is involved.
   *
   * @return Reference to the singleton. Do not delete it.
   */
  static RBBaseSDK& instance();

  RBBaseSDK(const RBBaseSDK&) = delete;
  RBBaseSDK& operator=(const RBBaseSDK&) = delete;

  RBBaseSDK(RBBaseSDK&&) = delete;
  RBBaseSDK& operator=(RBBaseSDK&&) = delete;

 protected:
  RB_SDK_LOCAL static int pid_;

  static std::shared_ptr<rb_zenoh::ZenohClient> zenoh_client_;

  static std::recursive_mutex lock_;

  static std::mutex mutex_;

  RB_SDK_LOCAL static std::optional<std::string> peer_id_;

  RB_SDK_LOCAL static std::optional<std::string> peer_common_url_;

  RB_SDK_LOCAL static std::optional<std::string> peer_token_;

  RB_SDK_LOCAL static std::thread heartbeat_thread_;

  RB_SDK_LOCAL static std::atomic<bool> heartbeat_stop_;

  bool instance_closed_ = false;

  std::string sender = "";

  std::optional<std::string> name;

  std::unordered_set<std::string> zenoh_queryables;

  std::unordered_set<std::string> zenoh_subscribes;

  std::string SERVICE;

  bool IS_DEV = false;

 public:
  /**
   * @brief Creates an SDK instance and ensures the shared zenoh session exists.
   *
   * The first SDK constructed in a process opens the shared zenoh session
   * (as a leaf peer, using the SERVICE and IS_DEV environment variables).
   * Later constructions reuse it, and if the session had been closed
   * explicitly it is reopened. Each instance increments the per-process
   * reference count that close() uses to decide when the shared session can
   * be closed, and is added to the registry used by close_all_for_pid().
   *
   * A failure to open the zenoh session is logged and does not throw; the
   * first call that needs the session then fails or triggers a reconnect.
   *
   * @param server Legacy service selector. Currently accepted for API
   *        compatibility and not used by the C++ implementation.
   * @param use_directly Legacy construction flag. Currently accepted for API
   *        compatibility and not used by the C++ implementation.
   */
  RBBaseSDK(std::optional<ServerType> server = std::nullopt, bool use_directly = false);

  /**
   * @brief Closes this SDK instance. Virtual so derived SDKs can be deleted through RBBaseSDK*.
   *
   * Equivalent to calling close(). close() is idempotent, so an explicit
   * close() before destruction is safe.
   */
  virtual ~RBBaseSDK();

  /**
   * @brief Registers this process as a remote zenoh peer through the common service.
   *
   * Use this when the SDK runs on a machine other than the robot. The steps
   * are:
   *
   * 1. If @p options.host resolves to this machine, return std::nullopt
   *    immediately: the process is already part of the local mesh.
   * 2. If a peer is already registered in this process, return its id.
   * 3. Pick the listen port (options.zenoh_port or a free port), add
   *    "tcp/0.0.0.0:<port>" to ZENOH_PEER_LISTEN_ENDPOINTS, and reopen the
   *    shared zenoh session so it listens on that port.
   * 4. POST this machine's IP (the local address used to reach the host),
   *    port, and ttl to http://<host>:8000/zenoh/peer.
   * 5. Start a background keepalive thread that sends a heartbeat every
   *    options.heartbeat seconds (ttl / 2 by default) and re-registers the
   *    peer if the common service forgets it (for example after a restart).
   * 6. Publish echo probes on "muscat/zenoh/echo_req" until a matching reply
   *    arrives on "muscat/zenoh/echo_res" or options.mesh_timeout expires.
   *
   * If the first registration request fails (for example the robot is still
   * booting), the error is logged, the keepalive thread keeps retrying with
   * exponential backoff (2 s up to 30 s), and std::nullopt is returned. If
   * registration succeeds but the echo check times out, the peer is
   * unregistered and std::nullopt is returned.
   *
   * In Python this method returns an awaitable that runs the blocking work
   * in a worker thread: use "await sdk.connect(options)".
   *
   * @param options Remote peer registration and heartbeat options.
   *
   * @return Registered peer id, or std::nullopt when registration is skipped,
   *         still pending in the background, or the mesh echo check fails.
   *
   * @throws std::runtime_error If local IP/port detection or zenoh
   *         reconnection fails, or if unregistering the peer after a failed
   *         echo check fails.
   */
  std::optional<std::string> connect(const ConnectOptions& options);

  /**
   * @brief Declares a raw zenoh subscriber.
   *
   * The callback runs on an rb_zenoh dispatch worker thread, not on the
   * calling thread, and receives (key, payload bytes, attachment string).
   * The topic is remembered by this instance so that close() and
   * disconnect() undeclare it.
   *
   * In Python this method is a decorator factory with a higher-level
   * callback contract; see the Python docstring.
   *
   * @param topic Zenoh key expression to subscribe to. Wildcards ("*",
   *        "**") are allowed.
   * @param callback Callback invoked with raw samples.
   * @param opts Zenoh subscription options. Defaults: queue_size 8,
   *        overflow LatestOnly (only the newest pending sample is kept when
   *        the callback falls behind), dispatch Queue (callback runs on a
   *        dedicated worker), no self-sender filtering, no rate limit.
   *
   * @return Subscriber id that can be passed to zenoh_unsubscribe().
   *
   * @throws std::exception Propagates errors from ZenohClient::declare_subscriber().
   */
  int zenoh_subscribe(const std::string& topic, rb_zenoh::SubCallback callback,
                      rb_zenoh::CppSubscribeOptions opts = {});

  /**
   * @brief Undeclares one subscriber id returned by zenoh_subscribe().
   *
   * Only that subscriber is removed; the shared session and other
   * subscribers on the same topic are left untouched. Negative ids (the
   * failure value of the FlatBuffer overload) are ignored.
   */
  RB_SDK_LOCAL void zenoh_unsubscribe(int sub_id);

  /**
   * @brief Declares a FlatBuffer-decoding zenoh subscriber.
   *
   * Each sample payload is decoded as @p FBSType and unpacked into its
   * native table (FBSType::NativeTableType) before the callback runs. The
   * callback receives (key, decoded object, attachment string) on an
   * rb_zenoh dispatch worker thread.
   *
   * Unlike the raw overload, declaration errors are not thrown: they are
   * printed and -1 is returned.
   *
   * @param topic Zenoh key expression to subscribe to.
   * @param callback Callback invoked with the decoded native table.
   * @param opts Zenoh subscription options.
   *
   * @return Subscriber id, or -1 if declaration fails.
   */
  template <typename FBSType>
  int zenoh_subscribe(
      const std::string& topic,
      std::function<void(const std::string&, std::unique_ptr<typename FBSType::NativeTableType>, const std::string&)>
          callback,
      rb_zenoh::CppSubscribeOptions opts = {}) {
    _gil_release_if_held _g;
    std::lock_guard<std::mutex> guard(mutex_);
    try {
      int sub_id_ = RBBaseSDK::zenoh_client_->declare_subscriber<FBSType>(topic, callback, opts);
      zenoh_subscribes.insert(topic);

      return sub_id_;
    } catch (const std::exception& e) {
      std::cout << "error at zenoh_subscribe()" << std::endl;
      std::cerr << e.what() << '\n';
    }

    // Subscribe failed; -1 means no valid subscriber id.
    return -1;
  }

  /**
   * @brief Declares a zenoh queryable for raw request/reply handling.
   *
   * The handler is called for every query that matches @p topic with
   * (key, parameters, optional payload bytes, attachment, reply_fn, del_fn).
   * It answers by calling reply_fn(key, payload, attachment, content_type,
   * is_error), or calls del_fn() to finish without a reply so the caller
   * gets no answer from this queryable.
   *
   * Duplicate declarations for the same topic on this SDK instance are
   * ignored with a warning; the first handler stays active. The topic is
   * undeclared by close() and disconnect().
   *
   * In Python this method is a decorator factory whose handler returns the
   * reply value; see the Python docstring.
   *
   * @param topic Zenoh key expression to serve.
   * @param handler Query handler invoked by ZenohClient.
   */
  void zenoh_queryable(const std::string& topic, rb_zenoh::QueryHandler handler);

  /**
   * @brief Registers an externally declared subscriber topic for cleanup by close().
   *
   * Use this when a subscriber was declared on the shared zenoh session by
   * some path other than zenoh_subscribe() and should still be removed when
   * this instance is closed or disconnected. Cleanup is by topic, so every
   * subscriber on that topic in the shared session is removed.
   *
   * @param topic Zenoh key expression of the subscriber.
   */
  void register_zenoh_subscriber(const std::string& topic);

  /**
   * @brief Registers an externally declared queryable topic for cleanup by close().
   *
   * Same as register_zenoh_subscriber() for queryables. Registering a topic
   * also makes later zenoh_queryable() calls for that topic on this instance
   * a no-op, because the topic is treated as already declared.
   *
   * @param topic Zenoh key expression of the queryable.
   */
  void register_zenoh_queryable(const std::string& topic);

  /**
   * @brief Stops the peer keepalive thread and joins it.
   *
   * Sets heartbeat_stop_ and wakes heartbeat_loop's wait immediately (a plain sleep_for used to
   * block disconnect() for the whole interval, ttl/2 = 15s by default). Also called from a static
   * exit guard in base.cpp: heartbeat_thread_ is a static std::thread, and a process that ends
   * without disconnect() would otherwise destroy it while joinable and hit std::terminate
   * ("libc++abi: terminating"). That is the common case when a subscribe handler lives in
   * __main__, because its __globals__ keeps the SDK object alive so close()/disconnect() never run.
   * Not a nested struct on purpose: srcML (gen_rb_sdk_docstrings) drops the class's later
   * docstrings when RBBaseSDK declares a nested struct.
   */
  RB_SDK_LOCAL static void shutdown_heartbeat();

  /**
   * @brief Unregisters this process from the remote peer mesh and closes its shared zenoh session.
   *
   * Reverses connect(): stops and joins the keepalive thread, sends
   * DELETE /zenoh/peer/<peer_id> to the common service (a failure is logged,
   * not thrown), undeclares this instance's subscribers and queryables, and
   * closes the shared zenoh session unconditionally. Other SDK instances in
   * the process lose their session too; their next query-style call reopens
   * it, but their subscribers and queryables are not restored.
   *
   * In Python this method returns an awaitable: use "await sdk.disconnect()".
   *
   * @return true when a peer registration or keepalive thread was active and
   *         has been torn down; false when there was nothing to disconnect.
   */
  bool disconnect();

  /**
   * @brief Optional cleanup hook called by close() before shared resources are released.
   *
   * The default implementation does nothing. Override it to release
   * resources owned by a derived SDK (for example vendor vision clients).
   * Exceptions thrown from it are logged and swallowed.
   *
   * @note C++ calls a virtual function on the class whose destructor is
   *       running, so when close() is reached only from ~RBBaseSDK(), the
   *       override is no longer dispatched. A derived class that overrides
   *       this hook must call close() from its own destructor.
   */
  virtual void before_close();

  /**
   * @brief Releases this instance's resources and closes the shared session when it is the last SDK.
   *
   * In order: runs before_close(), decrements the per-process SDK reference
   * count, then either calls disconnect() when a remote peer is registered
   * (which always closes the shared session), or undeclares only this
   * instance's subscribers and queryables and closes the shared session if
   * no other SDK instance is left.
   *
   * Idempotent: later calls do nothing. Does nothing in a forked child for
   * an instance created by the parent process. Called automatically by the
   * destructor.
   */
  void close();

  /**
   * @brief Closes every live SDK instance in the current process.
   *
   * Calls close() on every RBBaseSDK (including derived SDKs and sub-SDKs
   * held as members of an aggregate SDK) that was constructed in this
   * process and is not closed yet. The reference count therefore reaches
   * zero and the shared zenoh session is closed. Use it at shutdown when
   * relying on destructor or garbage-collection order is not acceptable.
   * Errors from individual close() calls are logged and skipped.
   *
   * In Python this also clears the per-process instance cache, so the next
   * construction creates a fresh object.
   *
   * @return Number of instances that were closed. 0 when called from a
   *         forked child.
   */
  static int close_all_for_pid();

  /**
   * @brief Runs a zenoh call and retries it once after reconnecting on transport/no-reply errors.
   *
   * Every public query, publish, and receive method goes through this
   * helper. Because of the single retry, the worst-case wait of a call that
   * gets no reply is about twice its timeout. Other exceptions (for example
   * rb_zenoh::ZenohReplyError, where the peer answered with an error) are
   * not retried.
   *
   * Intended for query-style calls. Transport errors force a reconnect;
   * no-reply errors refresh the current process's shared client without
   * forcing an otherwise healthy session closed. If the retry also fails, the
   * original rb_zenoh exception propagates unchanged: pybind translates it to
   * Python ZenohNoReply/ZenohTransportError, which the FastAPI handlers map to
   * 504/502. Wrapping it in std::runtime_error would lose that type (C++ has no
   * __cause__ chain across pybind) and surface as a 500.
   */
  template <typename Fn>
  RB_SDK_LOCAL auto _zenoh_call_with_retry(const char* op, Fn&& fn) -> decltype(fn()) {
    try {
      return fn();
    } catch (const rb_zenoh::ZenohTransportError& e) {
      std::cerr << "[" << op << "] zenoh transport error: " << e.what() << " -> reconnect and retry once" << std::endl;
      _refresh_zenoh_client_for_pid(/*force=*/true);
      return fn();
    } catch (const rb_zenoh::ZenohNoReply& e) {
      std::cerr << "[" << op << "] zenoh no-reply: " << e.what() << " -> reconnect and retry once" << std::endl;
      _refresh_zenoh_client_for_pid(/*force=*/false);
      return fn();
    }
  }

  /**
   * @brief Sends a raw zenoh query and returns every raw reply.
   *
   * Blocks until every matching queryable has answered or @p timeout_ms
   * elapses, then returns all replies received, including error replies
   * (RawReply::is_error is true for those). Unlike query_one(), getting no
   * reply is not an error: the result is simply empty.
   *
   * @param topic Zenoh key expression to query. Wildcards fan the query out
   *        to every matching queryable.
   * @param payload Optional raw payload bytes sent with the query.
   * @param timeout_ms Query timeout in milliseconds.
   * @param target zenoh-c query target: 0 = BEST_MATCHING (default), 1 =
   *        ALL, 2 = ALL_COMPLETE.
   *
   * @return Raw replies (key, payload, attachment, encoding, is_error)
   *         received before timeout. May be empty.
   *
   * @throws rb_zenoh::ZenohTransportError If the session is not open or the
   *         query cannot be sent, even after one reconnect and retry.
   * @throws std::runtime_error If @p topic is not a valid key expression.
   */
  std::vector<rb_zenoh::RawReply> query(const std::string& topic, const std::optional<std::vector<uint8_t>>& payload,
                                        int timeout_ms, int target = 0);

  using _gil_release_if_held = rb_sdk::gil_release_if_held;

  /**
   * @brief Sends a raw zenoh query and returns one raw reply.
   *
   * Waits for the query to finish (all replies or @p timeout_ms), then
   * returns the first non-error reply. This is the usual call for a service
   * RPC that has exactly one responder.
   *
   * In Python, ZenohNoReply and ZenohTransportError keep their rb_zenoh
   * exception types, which the FastAPI services map to HTTP 504 and 502.
   *
   * @param topic Zenoh key expression to query.
   * @param payload Optional raw payload bytes sent with the query.
   * @param timeout_ms Query timeout in milliseconds. With the single
   *        reconnect-and-retry, the worst case is about twice this value.
   * @param target zenoh-c query target: 0 = BEST_MATCHING (default), 1 =
   *        ALL, 2 = ALL_COMPLETE.
   *
   * @return The first successful raw reply (key, payload, attachment,
   *         encoding, is_error = false).
   *
   * @throws rb_zenoh::ZenohTransportError If the session is not open or the
   *         query cannot be sent, even after one reconnect and retry.
   * @throws rb_zenoh::ZenohNoReply If no reply arrives before timeout, even
   *         after one reconnect and retry.
   * @throws rb_zenoh::ZenohReplyError If only error replies arrive. The
   *         message contains the first error payload. Not retried.
   */
  rb_zenoh::RawReply query_one(const std::string& topic, const std::optional<std::vector<uint8_t>>& payload,
                               int timeout_ms, int target = 0);

  /**
   * @brief Sends a zenoh query and decodes one FlatBuffer reply.
   *
   * Same as the raw query_one(), then unpacks the reply payload as
   * @p FBSType (the FlatBuffer table type, for example
   * IPC::ResponseCANConnect) into its native object type
   * (FBSType::NativeTableType, for example IPC::ResponseCANConnectT).
   *
   * @warning The reply buffer is not run through a FlatBuffer verifier. The
   *          responder must actually send an @p FBSType buffer.
   *
   * @param topic Zenoh key expression to query.
   * @param payload Optional raw payload bytes sent with the query.
   * @param timeout_ms Query timeout in milliseconds.
   * @param target zenoh-c query target: 0 = BEST_MATCHING (default), 1 =
   *        ALL, 2 = ALL_COMPLETE.
   *
   * @return Decoded native FlatBuffer table. Never null.
   *
   * @throws rb_zenoh::ZenohTransportError, rb_zenoh::ZenohNoReply Same
   *         conditions as the raw query_one().
   * @throws rb_zenoh::ZenohReplyError If only error replies arrive, or if
   *         the successful reply has an empty payload.
   */
  template <typename FBSType>
  std::unique_ptr<typename FBSType::NativeTableType> query_one(
      const std::string& topic, const std::optional<std::vector<uint8_t>>& payload = std::nullopt,
      int timeout_ms = 1000, int target = 0) {
    _gil_release_if_held _g;
    return _zenoh_call_with_retry(
        "query_one", [&] { return RBBaseSDK::zenoh_client_->query_one<FBSType>(topic, payload, timeout_ms, target); });
  }

  /**
   * @brief Serializes @p req as a FlatBuffer request and decodes one FlatBuffer reply.
   *
   * The typical service RPC call: @p req is a native request object (for
   * example IPC::RequestCANConnectT), packed with its own table type and
   * sent as the query payload. The reply is decoded as @p FBSType. Only
   * @p FBSType has to be given explicitly; @p ReqT is deduced from @p req.
   *
   * @param topic Zenoh key expression to query.
   * @param req Native request table to serialize.
   * @param req_buf_size Initial FlatBuffer builder size in bytes. The
   *        builder grows if needed, so this is only a performance hint.
   * @param timeout_ms Query timeout in milliseconds.
   * @param target zenoh-c query target: 0 = BEST_MATCHING (default), 1 =
   *        ALL, 2 = ALL_COMPLETE.
   *
   * @return Decoded native FlatBuffer table. Never null.
   *
   * @throws rb_zenoh::ZenohTransportError, rb_zenoh::ZenohNoReply,
   *         rb_zenoh::ZenohReplyError Same conditions as the
   *         raw-payload query_one<FBSType>().
   */
  template <typename FBSType, typename ReqT>
  requires rb_zenoh::FlatBufferTClass<ReqT> std::unique_ptr<typename FBSType::NativeTableType> query_one(
      const std::string& topic, const ReqT& req, size_t req_buf_size = 512, int timeout_ms = 1000, int target = 0) {
    _gil_release_if_held _g;
    return _zenoh_call_with_retry("query_one", [&] {
      return RBBaseSDK::zenoh_client_->query_one<FBSType, ReqT>(topic, req, req_buf_size, timeout_ms, target);
    });
  }

  /**
   * @brief Sends a raw zenoh query and returns every successful raw reply.
   *
   * Like query(), but error replies are dropped from the result. Use it to
   * collect answers from several responders, for example with a wildcard
   * key expression. Getting no reply is not an error.
   *
   * @param topic Zenoh key expression to query.
   * @param payload Optional raw payload bytes sent with the query.
   * @param timeout_ms Query timeout in milliseconds.
   * @param target zenoh-c query target: 0 = BEST_MATCHING (default), 1 =
   *        ALL, 2 = ALL_COMPLETE.
   *
   * @return Successful raw replies received before timeout. May be empty.
   *
   * @throws rb_zenoh::ZenohTransportError If the session is not open or the
   *         query cannot be sent, even after one reconnect and retry.
   */
  std::vector<rb_zenoh::RawReply> query_all(const std::string& topic,
                                            const std::optional<std::vector<uint8_t>>& payload, int timeout_ms,
                                            int target = 0);

  /**
   * @brief Sends a zenoh query and decodes all FlatBuffer replies.
   *
   * Same as the raw query_all(), with every successful reply decoded as
   * @p FBSType. The reply buffers are not verified.
   *
   * @return Decoded native tables, one per successful reply. May be empty.
   */
  template <typename FBSType>
  std::vector<std::unique_ptr<typename FBSType::NativeTableType>> query_all(
      const std::string& topic, const std::optional<std::vector<uint8_t>>& payload = std::nullopt,
      int timeout_ms = 1000, int target = 0) {
    _gil_release_if_held _g;
    return _zenoh_call_with_retry(
        "query_all", [&] { return RBBaseSDK::zenoh_client_->query_all<FBSType>(topic, payload, timeout_ms, target); });
  }

  /**
   * @brief Serializes @p req as a FlatBuffer request and decodes all FlatBuffer replies.
   *
   * Combines the request packing of query_one<FBSType>(topic, req) with the
   * multi-reply behavior of query_all<FBSType>().
   *
   * @return Decoded native tables, one per successful reply. May be empty.
   */
  template <typename FBSType, typename ReqT>
  requires rb_zenoh::FlatBufferTClass<ReqT> std::vector<std::unique_ptr<typename FBSType::NativeTableType>> query_all(
      const std::string& topic, const ReqT& req, size_t req_buf_size = 512, int timeout_ms = 1000, int target = 0) {
    _gil_release_if_held _g;
    return _zenoh_call_with_retry("query_all", [&] {
      return RBBaseSDK::zenoh_client_->query_all<FBSType, ReqT>(topic, req, req_buf_size, timeout_ms, target);
    });
  }

  /**
   * @brief Publishes raw bytes to a zenoh topic.
   *
   * Non-blocking: the sample is put on the session's transmit queue and sent
   * by a background worker, so this returns before the data is on the wire.
   * The queue holds up to 4096 samples; when it is full, the oldest pending
   * sample is dropped. While the session is closing, samples are silently
   * discarded. There is no delivery confirmation; use query_one() when an
   * acknowledgement is needed.
   *
   * @param topic Zenoh key expression to publish to. Must not contain
   *        wildcards.
   * @param payload Raw payload bytes.
   * @param extra_attachment Optional attachment string appended to the
   *        sender metadata that subscribers receive.
   * @param congestion_control zenoh-c congestion control: 1 = DROP (default,
   *        drop the sample when the network is congested) or 0 = BLOCK (wait
   *        until it can be sent). See CongestionControl.
   * @param priority zenoh-c priority 1 (REAL_TIME) to 7 (BACKGROUND).
   *        Default 5 (DATA). See Priority.
   * @param express If true, zenoh sends the sample immediately instead of
   *        batching it with others. Lowers latency at the cost of throughput.
   *
   * @throws std::runtime_error If @p topic is not a valid key expression.
   */
  void publish(const std::string& topic, const std::vector<uint8_t>& payload, const std::string& extra_attachment = "",
               int congestion_control = 1 /* zenoh-c: DROP */, int priority = 5, bool express = false);

  /**
   * @brief Serializes a native FlatBuffer object and publishes it to zenoh.
   *
   * Packs @p obj (a native object such as muscat::RB_Program_LogT) with its
   * own table type and publishes the buffer with the same non-blocking,
   * queued semantics as the raw publish().
   *
   * @param topic Zenoh key expression to publish to.
   * @param obj Native FlatBuffer table to serialize.
   * @param initial_size Initial FlatBuffer builder size in bytes. The
   *        builder grows if needed, so this is only a performance hint.
   * @param extra_attachment Optional attachment string.
   * @param congestion_control zenoh-c congestion control: 1 = DROP
   *        (default) or 0 = BLOCK.
   * @param priority zenoh-c priority 1 (REAL_TIME) to 7 (BACKGROUND).
   *        Default 5 (DATA).
   * @param express If true, send immediately without batching.
   */
  template <typename TObj>
  requires rb_zenoh::FlatBufferTClass<TObj> void publish(const std::string& topic, const TObj& obj,
                                                         size_t initial_size = 512,
                                                         const std::string& extra_attachment = "",
                                                         int congestion_control = 1 /* zenoh-c: DROP */,
                                                         int priority = 5, bool express = false) {
    _gil_release_if_held _g;
    _zenoh_call_with_retry("publish", [&] {
      RBBaseSDK::zenoh_client_->publish(topic, obj, initial_size, extra_attachment, congestion_control, priority,
                                        express);
    });
  }

  /**
   * @brief Receives and decodes one FlatBuffer sample from @p topic.
   *
   * Same as the raw receive_one(), with the sample payload decoded as
   * @p FBSType. The buffer is not verified.
   *
   * @param topic Zenoh key expression to receive from.
   * @param timeout_ms Receive timeout in milliseconds.
   * @param self_sender_id Sender id whose samples are ignored. Empty means
   *        no filtering.
   *
   * @return Decoded native FlatBuffer table, by value.
   *
   * @throws rb_zenoh::ZenohNoReply If no sample arrives before timeout, even
   *         after one reconnect and retry.
   */
  template <typename FBSType>
  typename FBSType::NativeTableType receive_one(const std::string& topic, int timeout_ms = 1000,
                                                const std::string& self_sender_id = "") {
    _gil_release_if_held _g;
    return _zenoh_call_with_retry("receive_one", [&] {
      return RBBaseSDK::zenoh_client_->receive_one<FBSType>(topic, timeout_ms, self_sender_id);
    });
  }

  /**
   * @brief Receives one raw queued sample from @p topic.
   *
   * Declares a temporary subscriber, waits for the first sample published
   * after this call, undeclares the subscriber, and returns the sample.
   * Samples published before the call are not seen. Use it to wait for the
   * next value of a periodic stream or for a one-off event.
   *
   * @param topic Zenoh key expression to receive from.
   * @param timeout_ms Receive timeout in milliseconds. With the single
   *        reconnect-and-retry, the worst case is about twice this value.
   * @param self_sender_id Sender id to ignore when filtering self-originated
   *        samples. Empty means no filtering.
   *
   * @return Raw queued sample (key, payload, attachment).
   *
   * @throws rb_zenoh::ZenohNoReply If no sample arrives before timeout, even
   *         after one reconnect and retry.
   */
  rb_zenoh::QueuedSample receive_one(const std::string& topic, int timeout_ms = 1000,
                                     const std::string& self_sender_id = "");

  /**
   * @brief Emits a program log entry on the shared muscat log topic.
   *
   * Publishes a muscat::RB_Program_LogT on "muscat/program/log", where the
   * common service's program feature picks it up as a program log. The call
   * is fire-and-forget (see publish()); it does not wait for the log to be
   * stored.
   *
   * @param content Log message content.
   * @param robot_model Name of the robot model associated with the log.
   * @param level Log level: "INFO", "WARNING", "ERROR", "USER", "DEBUG", or
   *        "GENERAL". Matching is case-sensitive. Any other string leaves the
   *        log type at its FlatBuffer default.
   * @param disable_db Kept for parity with the Python SDK; currently ignored.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done after publishing the log.
   */
  void log(const std::string& content, const std::string& robot_model,
           const std::string& level /* INFO|WARNING|ERROR|USER|DEBUG|GENERAL */, bool disable_db = false,
           FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Raises on non-zero return_value when called from a PyFM step.
   *
   * If @p flow_manager_args is omitted, this helper ignores return_value,
   * matching the Python SDK's direct-call behavior. A failed step should stop
   * the program, while a direct caller is expected to inspect return_value
   * itself.
   *
   * This helper never calls flow_manager_args->done(); the caller marks the
   * step done after this check passes.
   *
   * @param func_name Name used in the generated error message.
   * @param obj_payload Response object to inspect. Types without a
   *        return_value field pass through.
   * @param flow_manager_args Optional PyFM step context.
   *
   * @throws std::runtime_error If @p flow_manager_args is provided and
   *         obj_payload.return_value is non-zero.
   */
  template <typename T>
  void manipulate_return_value(const std::string& func_name, const T& obj_payload,
                               FlowManagerArgsPtr flow_manager_args = nullptr) {
    if constexpr (requires(const T& t) { t.return_value; }) {
      if (flow_manager_args && obj_payload.return_value != 0) {
        std::string error_msg = "[" + func_name + "] return value is " + std::to_string(obj_payload.return_value);

        std::cerr << error_msg << std::endl;
        throw std::runtime_error(error_msg);
      }
    }
  }

  /**
   * @brief Validates an optional response payload and optionally completes the PyFM step.
   *
   * Unlike manipulate_return_value(), a non-zero return_value raises even
   * when @p flow_manager_args is omitted.
   *
   * @param obj_payload Optional response payload.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done after validation succeeds.
   *
   * @return The contained payload value.
   *
   * @throws std::runtime_error If @p obj_payload is empty, or if the payload
   *         has a non-zero return_value field.
   */
  template <typename T>
  T validate_single_return_value(const std::optional<T>& obj_payload, FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!obj_payload)
      throw std::runtime_error("validate_single_return value got no payload");

    if constexpr (requires(const T& t) { t.return_value; }) {
      if (obj_payload.value().return_value != 0)
        throw std::runtime_error("return value is not 0: " + std::to_string(obj_payload.value().return_value));
    }

    if (flow_manager_args)
      flow_manager_args->done();

    return obj_payload.value();
  }

  /**
   * @brief Opens a CAN channel through the host_pcan service.
   *
   * Sends a request on "muscat/can/connect" (1 s timeout) to the host
   * service, which opens the bus on the robot PC. Each channel is opened
   * once and stays open until disconnect_can() is called; frames are then
   * sent with transmit_can().
   *
   * In Python the keyword arguments use the FlatBuffer field names:
   * channel, bitrate, fd, dataBitrate, receiveOwnMessages, interface,
   * flow_manager_args (all keyword-only).
   *
   * @param channel CAN channel name as understood by the interface backend,
   *        for example "PCAN_USBBUS1".
   * @param bitrate Nominal (arbitration phase) bitrate in bit/s, for
   *        example 500000.
   * @param fd Whether to open the channel in CAN-FD mode.
   * @param data_bitrate CAN-FD data phase bitrate in bit/s. Used only when
   *        @p fd is true; 0 leaves it to the backend default.
   * @param receive_own_messages Whether transmitted frames should be looped
   *        back to this channel's receivers.
   * @param iface CAN interface backend, defaults to "pcan" (PEAK-System
   *        adapters).
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done on success and an unsuccessful response raises.
   *
   * @return IPC::ResponseCANConnectT returned by the host service. Check
   *         success and message when @p flow_manager_args is not given,
   *         because a failure is then returned instead of raised.
   *
   * @throws std::runtime_error If no response is received, or if
   *         @p flow_manager_args is provided and the response reports failure
   *         (the exception message is the service's message).
   * @throws rb_zenoh::ZenohNoReply, rb_zenoh::ZenohTransportError If the host
   *         service cannot be reached.
   */
  IPC::ResponseCANConnectT connect_can(const std::string& channel, uint32_t bitrate, bool fd = false,
                                       uint32_t data_bitrate = 0, bool receive_own_messages = false,
                                       const std::string& iface = "pcan",
                                       FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Closes a CAN channel through the host_pcan service.
   *
   * Sends a request on "muscat/can/disconnect" (1 s timeout). Same success
   * and error handling as connect_can().
   *
   * @param channel CAN channel name previously passed to connect_can().
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done on success and an unsuccessful response raises.
   *
   * @return IPC::ResponseCANDisconnectT returned by the host service.
   *
   * @throws std::runtime_error If no response is received, or if
   *         @p flow_manager_args is provided and the response reports failure.
   * @throws rb_zenoh::ZenohNoReply, rb_zenoh::ZenohTransportError If the host
   *         service cannot be reached.
   */
  IPC::ResponseCANDisconnectT disconnect_can(const std::string& channel,
                                             FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Transmits one CAN/CAN-FD frame through the host_pcan service.
   *
   * Sends a request on "muscat/can/transmit" (1 s timeout) carrying one
   * IPC::CANMessageT. The channel must have been opened with connect_can().
   * The call returns once the host service has handed the frame to the bus,
   * not when another node acknowledges it. Same success and error handling
   * as connect_can().
   *
   * In Python the keyword arguments use the FlatBuffer field names:
   * channel, arbitrationId, data, dlc, isExtendedId, isRemoteFrame, isFd,
   * bitrateSwitch, isErrorFrame, errorStateIndicator, timestamp,
   * flow_manager_args (all keyword-only).
   *
   * @param channel CAN channel name previously passed to connect_can().
   * @param arbitration_id CAN arbitration id: 11-bit (0x000-0x7FF) for a
   *        standard id, 29-bit for an extended id.
   * @param data Frame payload bytes: up to 8 for classic CAN, up to 64 for
   *        CAN-FD.
   * @param dlc Data length code. 0 lets the backend derive it from
   *        @p data.
   * @param is_extended_id Whether @p arbitration_id is an extended (29-bit)
   *        id.
   * @param is_remote_frame Whether the frame is a remote transmission
   *        request (no data).
   * @param is_fd Whether the frame is CAN-FD.
   * @param bitrate_switch Whether the CAN-FD data phase uses the faster data
   *        bitrate.
   * @param is_error_frame Whether the frame is an error frame.
   * @param error_state_indicator CAN-FD error-state indicator flag.
   * @param timestamp Optional frame timestamp in seconds. 0 means unset.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done on success and an unsuccessful response raises.
   *
   * @return IPC::ResponseCANTransmitT returned by the host service.
   *
   * @throws std::runtime_error If no response is received, or if
   *         @p flow_manager_args is provided and the response reports failure.
   * @throws rb_zenoh::ZenohNoReply, rb_zenoh::ZenohTransportError If the host
   *         service cannot be reached.
   */
  IPC::ResponseCANTransmitT transmit_can(const std::string& channel, uint32_t arbitration_id,
                                         const std::vector<uint8_t>& data = {}, uint8_t dlc = 0,
                                         bool is_extended_id = false, bool is_remote_frame = false, bool is_fd = false,
                                         bool bitrate_switch = false, bool is_error_frame = false,
                                         bool error_state_indicator = false, double timestamp = 0.0,
                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Vendor Mech-Mind clients keyed by PyFM module/task id. Each module can
   * hold its own connection to a different vision server. Cleanup is done by
   * the vision SDK that uses the registry, through before_close().
   */
  VisionClientRegistry<mechmind::MechMindClient, mechmind::MechMindConfig> mechmind_clients_;
  /** Vendor Photoneo clients keyed by PyFM module/task id. */
  VisionClientRegistry<photoneo::PhotoneoClient, photoneo::PhotoneoConfig> photoneo_clients_;
  /** Vendor Pickit clients keyed by PyFM module/task id. */
  VisionClientRegistry<pickit3d::PickitClient, pickit3d::PickitConfig> pickit_clients_;

 private:
  RB_SDK_LOCAL void _connect(
      const std::optional<std::vector<std::pair<std::string, std::string>>>& pairs = std::nullopt,
      const std::optional<std::string>& sender = std::nullopt, const int max_attempts = 8,
      const float initial_delay_s = 0.5, const float max_delay_s = 3.0);

  RB_SDK_LOCAL void _zenoh_unsubscribe_mine();

  RB_SDK_LOCAL void _zenoh_unqueryable_mine();

  std::shared_ptr<rb_zenoh::ZenohClient> _refresh_zenoh_client_for_pid(bool force = false);

  RB_SDK_LOCAL void _reconnect_shared_zenoh_for_remote_peer(int listen_port);

  static constexpr double kPeerRetryMinSec = 2.0;
  static constexpr double kPeerRetryMaxSec = 30.0;

  RB_SDK_LOCAL static void heartbeat_loop(std::string peer_id, int ttl, double interval_sec,
                                          nlohmann::json registration_payload, double retry_min_sec = kPeerRetryMinSec,
                                          double retry_max_sec = kPeerRetryMaxSec);

  RB_SDK_LOCAL bool _wait_for_zenoh_echo(const std::string& req_keyexpr, const std::string& res_keyexpr,
                                         std::optional<double> timeout, double probe_timeout, double interval);
};
