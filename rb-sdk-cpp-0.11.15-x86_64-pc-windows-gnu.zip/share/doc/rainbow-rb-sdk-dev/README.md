# Rainbow RB SDK C++

This package provides the C++ RB SDK development files.

Typical CMake usage:

```cmake
find_package(rb_sdk REQUIRED)
target_link_libraries(my_plugin PRIVATE rb_sdk::rb_sdk)
```

The `rainbow-rb-sdk-dev` package must be built and used with the exact matching
`rainbow-rb-sdk` runtime package version. The Debian package dependency enforces
this with `rainbow-rb-sdk (= <version>)`.

For zenoh-client-only use (no SDK), install `rainbow-rb-zenoh-dev` and use
`find_package(rb_zenoh)` or `pkg-config rb_zenoh`. To configure the session:

```sh
export ZENOH_CONFIG=~/zenoh.json5   # example: /usr/share/rainbow-rb-zenoh/zenoh.json5.example
```

### Upgrade note

`librb_sdk.so` now links `librb_zenoh.so` dynamically (zenoh-c is embedded in
`librb_zenoh.so`, one copy per process). Headers moved to
`include/rainbow/rb_zenoh/`. Consumers that link by hand (no CMake/pkg-config)
now also need `-lrb_zenoh -I.../rainbow/rb_zenoh -I.../rainbow/rb_zenoh/vendor`.
Tarball / Windows zip users must ship `librb_zenoh.so.<ver>` / `librb_zenoh.dll`
next to `librb_sdk`. `apt-get upgrade` keeps `rainbow-rb-sdk` back because of the
new dependency — use `apt install rainbow-rb-sdk-dev` or `apt full-upgrade`.

Do not load `librb_sdk.so.<version>` and the Python package `rainbow.rb_sdk` in
the same process, nor `librb_zenoh` and Python `rb_zenoh._core` (each embeds its
own zenoh-c). Both paths embed native networking/runtime libraries, and the
supported process model is one SDK runtime path per process.

## Windows (x86_64-pc-windows-gnu)

`rb-sdk-cpp-<version>-x86_64-pc-windows-gnu.zip` 은 **llvm-mingw(UCRT) 로 빌드된 MinGW/clang ABI** 배포본이다.

- 포함: `bin/librb_sdk.dll`, `lib/librb_sdk.dll.a`(import lib), `include/`, `lib/cmake/rb_sdk/`, `lib/pkgconfig/`
- 소비자 툴체인: llvm-mingw 또는 MSYS2 mingw-w64(UCRT) `clang++`/`g++`. **MSVC 로는 C++ 클래스에 링크할 수 없다** (C++ ABI 불일치). MSVC 지원이 필요하면 별도 빌드가 필요하다.
- 런타임: libc++/winpthread 는 DLL 에 정적 포함. 시스템 UCRT 만 있으면 된다.
- 미포함: EtherNet/IP·FINS 클라이언트(`RB_ENABLE_EIP_FINS` 미정의).

```cmake
list(APPEND CMAKE_PREFIX_PATH "C:/path/to/rb-sdk-cpp-<version>-x86_64-pc-windows-gnu")
find_package(rb_sdk CONFIG REQUIRED)
target_link_libraries(my_plugin PRIVATE rb_sdk::rb_sdk)
```
