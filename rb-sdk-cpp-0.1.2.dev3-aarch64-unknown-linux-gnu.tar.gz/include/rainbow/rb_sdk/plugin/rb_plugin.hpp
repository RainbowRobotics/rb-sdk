#pragma once

// plugin.py -> rb_plugin.hpp. Pure C++ core API.
//
// RBPluginCall runs inside a plugin process, either the plugin developer's
// main.py or a C++ plugin executable. It connects to the plugin Socket.IO
// gateway (scripts/backend/runtime/plugin_gateway.py, default
// http://127.0.0.1:10000) to pub/sub/serve/call with the plugin UI.
// This is separate from PluginProgramContext, which covers robot executor
// <-> plugin communication over zenoh.

#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

#include <nlohmann/json_fwd.hpp>

#include "rb_sdk_api.hpp"

namespace rb_plugin {

class PluginRouter;

/**
 * @brief plugin.py::RBPluginGatewayError.
 *
 * Thrown when a plugin gateway call or emit operation fails.
 */
class RB_SDK_API RBPluginGatewayError : public std::runtime_error {
 public:
  explicit RBPluginGatewayError(const std::string& what);
};

/**
 * @brief plugin.py::PluginRouteError.
 *
 * Throw this from a serve handler to choose the external response status
 * code and message.
 */
class RB_SDK_API PluginRouteError : public std::runtime_error {
 public:
  PluginRouteError(int code, const std::string& message);

  int code() const noexcept;

  const std::string& message() const noexcept;

 private:
  int code_;
  std::string message_;
};

/**
 * @brief Handle returned by subscribe().
 *
 * Copyable value type around a globally unique token. This is not RAII:
 * destroying it does not unsubscribe. Pass it to
 * RBPluginCall::unsubscribe(topic, sub) to remove the subscription.
 *
 * This replaces the plugin.py pattern of passing the callback function
 * back to unsubscribe. The token is meaningful only for the RBPluginCall
 * instance that created it; token() is exposed for bindings.
 */
class RB_SDK_API Subscription {
 public:
  Subscription() noexcept;

  explicit Subscription(std::uint64_t token) noexcept;

  std::uint64_t token() const noexcept;

  bool valid() const noexcept;

  explicit operator bool() const noexcept;

 private:
  std::uint64_t token_ = 0;
};

class RB_SDK_API RBPluginCall {
 public:
  /**
   * @brief Callback invoked for subscribed plugin messages.
   *
   * @param topic Fully scoped topic, echoed by the gateway.
   * @param payload Message payload, or JSON null when the gateway sends no payload.
   */
  using SubCallback = std::function<void(const std::string& topic, const nlohmann::json& payload)>;

  /**
   * @brief Handler invoked for served gateway calls.
   *
   * plugin.py::_on_serve_call equivalent: payload in, reply payload out.
   *
   * @param payload Request payload, or JSON null when omitted.
   *
   * @return Reply payload to send through the gateway.
   */
  using ServeHandler = std::function<nlohmann::json(const nlohmann::json& payload)>;

  /**
   * @brief plugin.py::_resolve_plugin_id.
   *
   * Resolves in explicit argument > RB_PLUGIN_ID > PLUGIN_ID order, then
   * strips leading and trailing slashes.
   *
   * @param plugin_id Optional explicit plugin id.
   *
   * @return Resolved plugin id without leading or trailing slashes.
   *
   * @throws std::invalid_argument If no non-empty plugin id is available.
   */
  static std::string resolve_plugin_id(const std::optional<std::string>& plugin_id);

  /**
   * @brief Returns the process-global singleton keyed by (getpid(), plugin_id).
   *
   * Equivalent to plugin.py::_instances[(pid, plugin_id)]. @p plugin_id
   * must already be resolved and slash-stripped.
   *
   * @param plugin_id Resolved plugin id.
   *
   * @return Shared RBPluginCall instance for this process and plugin id.
   */
  static std::shared_ptr<RBPluginCall> get_instance(const std::string& plugin_id);

  /**
   * @brief Releases callbacks that may capture py::object before interpreter shutdown.
   *
   * Called by the binding from atexit. After this call, existing instances
   * no longer invoke Python callbacks.
   */
  static void shutdown_all();

  ~RBPluginCall();
  RBPluginCall(const RBPluginCall&) = delete;
  RBPluginCall& operator=(const RBPluginCall&) = delete;

  const std::string& plugin_id() const;

  /**
   * @brief plugin.py::_scoped.
   *
   * A key starting with "/" is treated as absolute and ignores the plugin
   * prefix. Other keys become @c "{plugin_id}/{key}", unless they already
   * carry this plugin_id prefix.
   *
   * @param key Topic or key expression to scope.
   *
   * @return Slash-trimmed absolute or plugin-scoped topic.
   */
  std::string scoped(const std::string& key) const;

  /**
   * @brief Returns whether the Socket.IO namespace is currently connected.
   *
   * plugin.py::self._client.connected.
   */
  bool connected() const;

  /**
   * @brief plugin.py::publish.
   *
   * Scopes @p topic with scoped() and publishes through the gateway. If
   * disconnected, the message is silently dropped.
   *
   * @param topic Topic to publish to.
   * @param payload Payload to send.
   */
  void publish(const std::string& topic, const nlohmann::json& payload);

  /**
   * @brief plugin.py::subscribe.
   *
   * Scopes @p topic with scoped(). If this is the first local subscription
   * for that topic and the gateway is connected, emits @c "sub". Keep the
   * returned Subscription and pass it to unsubscribe(topic, sub) to remove
   * only this subscription.
   *
   * @param topic Topic to subscribe to.
   * @param cb Callback invoked for matching messages.
   *
   * @return Subscription handle. Keep it and pass it to unsubscribe() to
   *         remove only this subscription.
   */
  [[nodiscard]] Subscription subscribe(const std::string& topic, SubCallback cb);

  /**
   * @brief One-to-one equivalent of plugin.py::unsubscribe.
   *
   * Both arguments are optional. A valid @p sub removes only that
   * subscription. Without a valid handle, this removes a topic or all
   * subscriptions.
   *
   * - @c unsubscribe()                 -> remove all subscriptions
   * - @c unsubscribe("ui/event")       -> remove all subscriptions on that topic
   * - @c unsubscribe(std::nullopt, s)  -> remove only handle s
   * - @c unsubscribe("ui/event", s)    -> remove s only if it belongs to that topic
   *
   * Emits @c "unsub" for each topic that becomes empty.
   *
   * @param topic Optional topic filter. The topic is scoped with scoped().
   * @param sub Optional subscription handle to remove.
   */
  void unsubscribe(const std::optional<std::string>& topic = std::nullopt, const Subscription& sub = Subscription{});

  /**
   * @brief plugin.py::unsubscribe_topic, alias for unsubscribe().
   *
   * Removes every subscription on @p topic; the callback-less alias form.
   *
   * @param topic Topic whose subscriptions should be removed.
   */
  void unsubscribe_topic(const std::string& topic);

  /**
   * @brief plugin.py::serve register path.
   *
   * Scopes @p keyexpr. Each scoped key expression has one handler;
   * registering again replaces the previous handler. If connected, emits
   * @c "serve_register".
   *
   * @param keyexpr Key expression to serve.
   * @param handler Handler invoked for matching calls.
   */
  void serve(const std::string& keyexpr, ServeHandler handler);

  /**
   * @brief plugin.py::unserve.
   *
   * If @p keyexpr is provided, unregisters only that key expression.
   * Otherwise unregisters all served handlers. Emits @c "serve_unregister"
   * for each removed item.
   *
   * @param keyexpr Optional key expression to unregister.
   */
  void unserve(const std::optional<std::string>& keyexpr = std::nullopt);

  /**
   * @brief plugin.py::undeclare_queryable.
   *
   * Alias for unserve().
   *
   * @param keyexpr Optional key expression to unregister.
   */
  void undeclare_queryable(const std::optional<std::string>& keyexpr = std::nullopt);

  /**
   * @brief plugin.py::call action path.
   *
   * Scopes @p keyexpr and sends an action request. Waits up to
   * @p timeout_sec for the ack and returns its first argument. If the ack
   * has no arguments, returns JSON null.
   *
   * @param keyexpr Key expression to call.
   * @param payload Payload to send.
   * @param timeout_sec Maximum time to wait for the gateway ack, in seconds.
   *
   * @return First ack argument, or JSON null if the ack is empty.
   *
   * @throws RBPluginGatewayError If the gateway is disconnected or the ack
   *         does not arrive before @p timeout_sec.
   */
  nlohmann::json call(const std::string& keyexpr, const nlohmann::json& payload, double timeout_sec);

  /**
   * @brief plugin.py::RBPluginCall.router.
   *
   * Helper for declaring external endpoints using MuscatRouter terms.
   * Each RBPluginCall owns exactly one router, created in the constructor.
   * C++ plugins use this directly.
   *
   * @return Router helper for this plugin call instance.
   */
  PluginRouter& router();

  /**
   * @brief Binding-only shared_ptr accessor for router().
   *
   * The binding needs a shared_ptr to deduplicate the Python wrapper object.
   */
  const std::shared_ptr<PluginRouter>& router_ptr() const;

 private:
  explicit RBPluginCall(std::string plugin_id);

  RB_SDK_LOCAL void _install_handlers();
  RB_SDK_LOCAL void _on_connect();
  RB_SDK_LOCAL void _on_msg(const nlohmann::json& data);
  RB_SDK_LOCAL void _on_serve_call(const nlohmann::json& data);
  RB_SDK_LOCAL void _emit(const std::string& event, const nlohmann::json& payload);

  struct Impl;
  std::unique_ptr<Impl> impl_;
  std::string plugin_id_;
  std::shared_ptr<PluginRouter> router_;
};

struct PluginRouterBindingAccess;

/**
 * @brief One-to-one C++ core equivalent of plugin.py::PluginRouter.
 *
 * RBPluginCall adds the plugin_id prefix, so this class only deals with
 * relative paths/topics. The public API intentionally matches plugin.py:
 * on(), subscribe(), and emit().
 */
class RB_SDK_API PluginRouter {
 public:
  /**
   * @brief Route handler.
   *
   * (payload, meta) -> reply. Called only after the transport gate passes.
   * Throw PluginRouteError to choose the external response status.
   *
   * @param payload Request payload.
   * @param meta Request metadata, including transport and principal when
   *        supplied by the gateway.
   *
   * @return Reply payload.
   */
  using RouteHandler =
      std::function<nlohmann::json(const nlohmann::json& payload, const nlohmann::json& meta)>;

  /**
   * @brief Event handler.
   *
   * Receives only payload. Called only after the transport gate passes.
   *
   * @param payload Event payload.
   */
  using EventHandler = std::function<void(const nlohmann::json& payload)>;

  explicit PluginRouter(RBPluginCall& call);
  PluginRouter(const PluginRouter&) = delete;
  PluginRouter& operator=(const PluginRouter&) = delete;

  /**
   * @brief plugin.py::PluginRouter.on.
   *
   * Strips "/" from @p path, checks duplicates and @p explicit_routes,
   * then registers @c {plugin_id}/{path} as a queryable. Empty/duplicate
   * paths and unknown transports raise std::invalid_argument (ValueError
   * in the binding).
   *
   * @param path Route path relative to the plugin id.
   * @param handler Handler invoked for accepted calls.
   * @param explicit_routes Optional list of allowed transports: @c api,
   *        @c socket, @c tcp, @c mqtt, or @c webrtc.
   *
   * @throws std::invalid_argument If @p path is empty, duplicated, or an
   *         unknown transport is listed.
   */
  void on(const std::string& path, RouteHandler handler,
          const std::optional<std::vector<std::string>>& explicit_routes = std::nullopt);

  /**
   * @brief plugin.py::PluginRouter.subscribe.
   *
   * Subscribes to the @c {plugin_id}/{topic} room. Strips "/" from @p topic
   * and checks duplicates plus @p explicit_events.
   *
   * @param topic Event topic relative to the plugin id.
   * @param handler Handler invoked for accepted events.
   * @param explicit_events Optional list of allowed transports: @c api,
   *        @c socket, @c tcp, @c mqtt, or @c webrtc.
   *
   * @throws std::invalid_argument If @p topic is empty, duplicated, or an
   *         unknown transport is listed.
   */
  void subscribe(const std::string& topic, EventHandler handler,
                 const std::optional<std::vector<std::string>>& explicit_events = std::nullopt);

  /**
   * @brief plugin.py::PluginRouter.emit.
   *
   * Publishes through @c __muscat__/emit. External clients subscribe to
   * @c common/plugin/{id}/{topic}. Like publish/call, payload is always
   * explicit; pass @c nlohmann::json(nullptr) when there is no payload.
   *
   * @param topic Event topic relative to the plugin id.
   * @param payload Event payload.
   */
  void emit(const std::string& topic, const nlohmann::json& payload);

 private:
  friend struct PluginRouterBindingAccess;

  std::string reserve_route(const std::string& path,
                            const std::optional<std::vector<std::string>>& explicit_routes);
  void attach_route(const std::string& key, RouteHandler handler);
  std::string reserve_subscription(const std::string& topic,
                                   const std::optional<std::vector<std::string>>& explicit_events);
  void attach_subscription(const std::string& key, EventHandler handler);

  RB_SDK_LOCAL static std::optional<std::vector<std::string>> allowed_transports(
      const std::optional<std::vector<std::string>>& explicit_list);

  RBPluginCall& call_;
  std::unordered_map<std::string, std::optional<std::vector<std::string>>> route_gates_;
  std::unordered_map<std::string, std::optional<std::vector<std::string>>> sub_gates_;
};

}  // namespace rb_plugin
