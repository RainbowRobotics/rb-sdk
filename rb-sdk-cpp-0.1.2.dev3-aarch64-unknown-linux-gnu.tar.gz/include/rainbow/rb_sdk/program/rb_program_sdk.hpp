#pragma once

// Program SDK API.
//
// RBProgramSDK provides the C++ core surface for program variables, scripts,
// waits, dialogs, protocol interface calls, program switching, and plugin
// execution.

#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

#include <nlohmann/json.hpp>

#include "base.hpp"
#include "flow_manager_args.hpp"
#include "program_generated.h"

#include "rpc_manager.h"

#include "rb_sdk_api.hpp"

/**
 * @brief Owns RpcManager instances keyed by module_name.
 */
class RB_SDK_API RpcManagerRegistry {
 public:
  RB_SDK_LOCAL RpcManager* get(const std::string& module_name);

  RB_SDK_LOCAL RpcManager& get_or_create(const std::string& module_name, RpcLogCallback log_cb = nullptr);

  RB_SDK_LOCAL void disconnect_all();

 private:
  std::unordered_map<std::string, std::unique_ptr<RpcManager>> managers_;
};

/**
 * @brief Digital-input condition for wait(), matching base_schema.py::DigitalInputConditionSchema.
 */
struct ProgramDigitalInputCondition {
  std::vector<int> signal;
  std::string logical_operator = "AND";  // "AND" | "OR"
};

class RB_SDK_API RBProgramSDK : public RBBaseSDK {
 public:
  RBProgramSDK();

  ~RBProgramSDK() override;

  static std::string type_name();

  /**
   * @brief Sink used for logs emitted by RpcManager worker threads.
   */
  using RpcLogSink = std::function<void(LogType type, const std::string& module_name, const std::string& message)>;

  static void set_rpc_log_sink(RpcLogSink sink);

  /**
   * Emits a program log entry.
   *
   * @param content Log message content.
   * @param robot_model Name of the robot model this log entry is associated with.
   * @param level Log level ("INFO", "WARNING", "ERROR", "USER", "DEBUG", or "GENERAL").
   * @param disable_db Unused (kept for parity with the Python original, which also
   *        never reads this parameter).
   * @param flow_manager_args Optional PyFM step context. If provided, the step is
   *        marked done immediately after the log entry is published.
   */
  void log(const std::string& content, const std::string& robot_model, const std::string& level,
           bool disable_db = false, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Returns the RpcManager registered for @p module_name, creating it on
   * first use.
   *
   * @param module_name PFM task id used as the RpcManager cache key.
   * @return The RpcManager instance for @p module_name, owned by rpc_managers_.
   */
  RpcManager& get_rpc(const std::string& module_name);

  // Variables / scripts.

  /**
   * Initializes local task variables from their configured init values.
   *
   * @param variables List of variable definition dicts, each carrying an
   *        "init_value" key, in the same order as the task's declared variables.
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything — if omitted, returns immediately without
   *        touching @p variables. When provided, each variable is applied
   *        via @p flow_manager_args's local variable updater and the step
   *        is marked done afterwards.
   */
  void set_variables(const nlohmann::json& variables, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Runs a program script step, in either GENERAL or ADVANCED mode.
   *
   * In GENERAL mode, @p flow_manager_args's "general_contents" argument is
   * evaluated as a single expression against the step's context (assignments
   * are reflected into state). In ADVANCED mode, @p contents is compiled and
   * executed as an arbitrary python script with `variables`/`var`,
   * `update_variable`/`update_var`, `get_var`, `done`, `pause`, `stop`,
   * `resume`, `check_stop`, and `rb_log` injected into its globals (the bridge
   * builds that env from @p flow_manager_args; compile/exec runs on the PyFM
   * side in ctx.run_advanced_script). `rb_log` is this SDK's own log
   * (RBBaseSDK::log), called as `rb_log(content, robot_model, level)`.
   *
   * @param mode "GENERAL" or "ADVANCED".
   * @param contents ADVANCED-mode script source. Required when @p mode is
   *        "ADVANCED".
   * @param flow_manager_args PyFM step context. Required; the step is marked
   *        done when the script finishes (or immediately raises, in ADVANCED
   *        mode, since the step is still marked done before the exception
   *        propagates).
   *
   * @throws std::runtime_error If GENERAL mode is missing
   *         "general_contents", or ADVANCED mode is missing @p contents.
   */
  void make_script(const std::string& mode /* GENERAL|ADVANCED */, std::optional<std::string> contents,
                   FlowManagerArgsPtr flow_manager_args = nullptr);

  // Wait / control / dialogs.

  /**
   * Blocks the calling thread for @p second seconds, polling for stop/pause
   * requests every 1/50s. Time spent blocked inside a pause is excluded from
   * the wait duration.
   *
   * @param second Seconds to wait. Must be greater than 0 when
   *        @p flow_manager_args is not provided (a standalone caller has no
   *        other way to be notified that the wait was skipped).
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done once the wait elapses (or immediately, if
   *        @p second <= 0).
   *
   * @throws std::runtime_error If @p second <= 0 and @p flow_manager_args is
   *         not provided.
   */
  void simple_wait(double second, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Pauses every running program process on this robot.
   *
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step's own execution context is paused too, after the broadcast
   *        pause request.
   */
  void all_pause(FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Stops every running program process on this robot.
   *
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done after the broadcast stop request.
   */
  void all_stop(FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Publishes a program dialog alarm.
   *
   * @param title Dialog title. Falls back to "No Title" when empty.
   * @param content Dialog content.
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done immediately after the alarm is published.
   */
  void alarm(const std::string& title, const std::string& content, const std::string& robot_model,
             FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Raises an alarm and/or halts execution, depending on @p option.
   *
   * @param robot_model Name of the robot model.
   * @param option "ALARM" (publish an alarm dialog), "HALT" (stop the step's
   *        context), "FOLDER_HALT" (break out of the enclosing folder), or
   *        "SUB_PROGRAM_HALT" (halt the enclosing sub task).
   * @param save_log If true, also emits a USER-level log entry with
   *        @p content (or @p title if @p content is None).
   * @param is_only_at_ui If true and the step is not running from a UI
   *        execution, the step is marked done and this call is a no-op.
   * @param pause_option "ALL" (pause every process) or "CURRENT" (pause only
   *        this context). Only consulted when @p option resolves to a pause.
   * @param title Alarm dialog title (used when @p option is "ALARM", and as
   *        the log fallback content when @p save_log is set and @p content
   *        is None).
   * @param content Alarm dialog / log content.
   * @param flow_manager_args PyFM step context. Required; the step is marked
   *        done after the alarm/halt/pause sequence completes.
   */
  void alarm_or_halt(const std::string& robot_model, const std::string& option, bool save_log, bool is_only_at_ui,
                     const std::string& pause_option, const nlohmann::json& title, const nlohmann::json& content,
                     FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Reports the current values of @p variables for debugging, then pauses.
   *
   * Compares each variable's raw (pre-evaluation) string against its
   * evaluated JSON value; numeric values/lists are rounded to 3 decimals for
   * display, and unchanged variables are reported as "Undefined".
   *
   * @param robot_model Name of the robot model.
   * @param option "DIALOG" (publish a single alarm dialog listing every
   *        variable) or "LOG" (emit one USER-level log entry per variable).
   * @param is_only_at_ui If true and the step is not running from a UI
   *        execution, the step is marked done and this call is a no-op.
   * @param variables Evaluated current variable values, in the same order as
   *        @p flow_manager_args's raw "variables" list.
   * @param log_content Optional extra USER-level log entry (any value; non-str
   *        is JSON-encoded) appended after the per-variable LOG entries.
   * @param pause_option "ALL" (pause every process) or "CURRENT" (pause only
   *        this context).
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything; the step is marked done after pausing.
   */
  void debug_variables(const std::string& robot_model, const std::string& option, bool is_only_at_ui,
                       const nlohmann::json& variables, const nlohmann::json& log_content,
                       const std::string& pause_option, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Publishes a "user input" prompt dialog and pauses the step until the
   * operator supplies a value (resumed out-of-band via the program
   * service's change_user_input_value endpoint).
   *
   * Mirrors program.py::RBProgramSDK.user_input: the dialog content is
   * `"{raw var_selection arg} ({resolved var_selection})"` — the raw name
   * comes from `flow_manager_args.args["var_selection"]` (pre-substitution)
   * and the resolved value from the @p var_selection parameter.
   *
   * @param robot_model Name of the robot model.
   * @param var_form Input widget kind: "STRING" (default), "NUMERIC",
   *        "BOOLEAN", "LIST", "DICTIONARY", or "VAR". Only used to tag the
   *        alarm title (`USER_INPUT_{var_form}`).
   * @param var_selection Resolved value of the target variable. PyFM evaluates
   *        the step's `var_selection` expression before the call, so this can
   *        arrive as any Python type (int/float/list/dict, ...), not only str —
   *        it is stringified here, mirroring the Python original's f-string.
   * @param flow_manager_args PyFM step context. When provided, the step's
   *        context is paused, checked for stop, and marked done.
   */
  void user_input(const std::string& robot_model, const nlohmann::json& var_selection, const std::string& var_form,
                  FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Publishes a "user select" prompt dialog and pauses the step until the
   * operator picks one of @p content (resumed out-of-band via the program
   * service's set_user_select_value endpoint).
   *
   * Mirrors program.py::RBProgramSDK.user_select: the dialog content is
   * `json.dumps([var_name, timeout, disconn_timeout, content])`.
   *
   * @param robot_model Name of the robot model.
   * @param ask_ment Prompt text, used to tag the alarm title
   *        (`USER_SELECT_{ask_ment}`).
   * @param var_name Name of the variable that will receive the choice.
   * @param content Selectable option strings.
   * @param timeout Seconds before the select auto-resolves.
   * @param disconn_timeout Behavior label when the operator UI disconnects.
   * @param flow_manager_args PyFM step context. When provided, the step's
   *        context is paused, checked for stop, and marked done.
   *
   * @note ask_ment/var_name/content/timeout/disconn_timeout arrive as values
   *       PyFM produced by evaluating the step's args, so their runtime types
   *       are not fixed (e.g. a `"60"` arg resolves to int 60, `"0"` to int 0).
   *       They are accepted as JSON values and normalized to the expected
   *       C++ type before serialization.
   */
  void user_select(const std::string& robot_model, const nlohmann::json& ask_ment, const nlohmann::json& var_name,
                   const nlohmann::json& content, const nlohmann::json& timeout, const nlohmann::json& disconn_timeout,
                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Queries the digital input state of @p robot_model.
   *
   * @param robot_model Name of the robot model.
   * @return The digital input list, or std::nullopt if the robot has no
   *         `{robot_model}/get_digital_input` zenoh queryable (e.g. not
   *         connected / not running).
   */
  std::optional<std::vector<int8_t>> get_digital_input(const std::string& robot_model);

  // ---------------------------------------------------------------------
  // Interface (MC/XGT/Modbus/Socket)
  // ---------------------------------------------------------------------

  /**
   * Dispatches a protocol interface call (Modbus/MC/XGT/socket) via the
   * native RpcManager cached for this step's task id (rpc_managers_).
   *
   * @param option "MODBUS_CLIENT", "MC_PROTOCOL", "XGT_PROTOCOL", or
   *        "SOCKET_INTERFACE".
   * @param data Protocol payload generated from manipulate.fbs. Must contain a
   *        non-empty "server_ip" and a "type" of "READ"/"WRITE" (plus
   *        "CONNECT" for SOCKET_INTERFACE).
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything — if omitted, returns immediately without
   *        dispatching to any protocol. When provided, it's forwarded to
   *        the underlying execute_* call and the step is marked done after
   *        dispatch.
   *
   * @throws std::runtime_error If @p option or @p data["type"] is
   *         unsupported for the given @p option.
   */
  void interface(const std::string& option, muscat::InterfacePayloadUnion data,
                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Blocks until the requested wait condition is satisfied (or times out),
   * polling for stop requests every 10ms.
   *
   * @param robot_model Name of the robot model (used for DIGITAL_INPUT
   *        polling).
   * @param wait_type "TIME" (delegates to simple_wait()), "HOLDING" (wait
   *        while the condition holds), or "EXIT" (wait until the condition
   *        becomes true / the digital input matches).
   * @param mode "GENERAL" (evaluate @p flow_manager_args's "condition"
   *        expression) or "DIGITAL_INPUT" (poll get_digital_input() against
   *        @p digital_input's expected signal pattern).
   * @param second Wait duration in seconds, used only when @p wait_type is
   *        "TIME".
   * @param digital_input Digital input condition dict ("signal" list and
   *        optional "logical_operator", "AND" by default). Required when
   *        @p mode is "DIGITAL_INPUT".
   * @param time_out Optional timeout in seconds; the wait loop breaks once
   *        elapsed time reaches this value, regardless of whether the
   *        condition was satisfied.
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything — if omitted, returns immediately without
   *        waiting (despite the default of py::none(), calling this
   *        standalone is a no-op). The step is marked done once the wait
   *        loop exits.
   */
  void wait(const std::string& robot_model, const std::string& wait_type, const std::string& mode,
            std::optional<double> second, std::optional<ProgramDigitalInputCondition> digital_input,
            std::optional<double> time_out, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Changes the running program and immediately starts it (program.py::change_program).
   *
   * Sends a Request_Change_Program to the "muscat/change/program" queryable
   * and waits (up to 20s — the handler can take several seconds) for a
   * ResponseProgramExecution. Either @p program_id or @p program_name must
   * be given.
   *
   * @param program_id Target program id (mutually optional with @p program_name).
   * @param program_name Target program name.
   * @param flow_manager_args PyFM step context. Required — raises if omitted.
   *        The step is marked done once the change is accepted.
   *
   * @throws std::runtime_error If @p flow_manager_args is omitted, if
   *         neither @p program_id nor @p program_name is given, or if the
   *         change/start request gets no (usable) reply.
   */
  void change_program(std::optional<std::string> program_id, std::optional<std::string> program_name,
                      FlowManagerArgsPtr flow_manager_args = nullptr);

  // ---------------------------------------------------------------------
  // Event tree / plugin
  // ---------------------------------------------------------------------

  /**
   * Sends an execute request to a plugin process and waits until it reports
   * completion (or stop). Concurrent calls for the same @p plugin_id are
   * serialized so their control queryables don't collide.
   *
   * @param plugin_id Target plugin id; the request is sent to
   *        "muscat/plugin/{plugin_id}/execute" and control messages are
   *        exchanged over "muscat/plugin/{plugin_id}/control".
   * @param user_args Execute request JSON object. The Python binding collects
   *        `**kwargs` into this object.
   * @param flow_manager_args PyFM step context. Required; the step is marked
   *        done once the plugin reports "done" (directly, or by exiting its
   *        control loop after "stop").
   *
   * @throws std::runtime_error If @p flow_manager_args is not provided, or
   *         if the plugin is not running/responding to the execute request.
   */
  void plugin_execute(const std::string& plugin_id, FlowManagerArgsPtr flow_manager_args = nullptr,
                      const nlohmann::json& user_args = nlohmann::json::object());

 private:
  RB_SDK_LOCAL void _plugin_execute_locked(const std::string& plugin_id, const FlowManagerArgsPtr& flow_manager_args,
                                           const nlohmann::json& user_args);

 public:
  /**
   * Disconnects every RpcManager module cached in rpc_managers_ before the
   * SDK instance is closed.
   */
  void before_close() override;

 private:
  RpcManagerRegistry rpc_managers_;

  RB_SDK_LOCAL static RpcLogSink rpc_log_sink_;
};
