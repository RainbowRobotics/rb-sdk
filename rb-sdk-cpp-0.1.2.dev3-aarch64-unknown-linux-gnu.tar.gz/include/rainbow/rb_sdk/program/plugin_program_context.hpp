#pragma once

// Pure C++ core API.
//
// PluginProgramContext runs inside a plugin process and lets that plugin
// report done/pause/stop to the executor and read/write program variables.
// It is the opposite direction from RBProgramSDK, which calls plugins from
// the robot/program side.

#include <atomic>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

#include <nlohmann/json.hpp>

#include "rb_sdk_api.hpp"

#include "zenoh_client.hpp"

namespace rb_plugin {

using nlohmann::json;

/**
 * @brief Thrown by check_stop() when the current program is stopped.
 *
 * The Python wrapper translates this to asyncio.CancelledError.
 */
struct RB_SDK_API PluginStopped : std::runtime_error {
  PluginStopped() : std::runtime_error("program stopped") {}
};

/**
 * @brief Plugin-side context for executor control and variables.
 */
class RB_SDK_API PluginProgramContext {
 public:
  using ExecuteHandler = std::function<void(const json& args)>;
  using StateChangeHandler = std::function<void(const std::string& robot_model, const std::string& state)>;

  /**
   * @brief Optional runner used to execute blocking cleanup.
   *
   * C++ plugins may leave this unset; cleanup then runs directly.
   */
  using BlockingRunner = std::function<void(const std::function<void()>&)>;

  explicit PluginProgramContext(std::string plugin_id);

  PluginProgramContext(const PluginProgramContext&) = delete;
  PluginProgramContext& operator=(const PluginProgramContext&) = delete;

  ~PluginProgramContext();

  /**
   * @brief Sets the handler invoked for each plugin execute request.
   */
  void set_execute_handler(ExecuteHandler h);

  /**
   * @brief Sets an optional callback invoked when a robot executor state changes.
   */
  void set_state_change_handler(StateChangeHandler h);

  /**
   * @brief Sets an optional runner for blocking cleanup.
   */
  void set_blocking_runner(BlockingRunner r);

  /**
   * @brief Stops callbacks, undeclares zenoh handles, and joins an active execute handler.
   *
   * Idempotent; safe to call from both wrapper cleanup and the destructor.
   */
  void shutdown();

  /**
   * @brief Returns whether shutdown/destruction has started.
   */
  bool stopping() const;

  const std::string& plugin_id() const;
  const std::string& control_topic() const;

  // Execute lifecycle.
  void begin_execution(std::optional<std::string> robot_model);
  void end_execution();
  bool in_execute() const;
  std::optional<std::string> exec_robot_model() const;

  /**
   * @brief Sends a control action to the current program execution.
   */
  json send_control(const std::string& action, const json& extra = json::object());

  /** @brief Reports that the current plugin execution is done. */
  json done();
  /** @brief Requests pause for the current plugin execution. */
  json pause();
  /** @brief Requests stop for the current plugin execution. */
  json stop();

  /**
   * @brief Queries the always-on executor variable endpoint.
   */
  json query_variable_endpoint(const std::string& action, const std::string& name,
                               const std::optional<std::string>& robot_model,
                               const std::optional<std::string>& plugin_id, const json& value = json());

  /**
   * @brief Gets a program variable.
   *
   * During execute handling, unqualified calls use the current control
   * topic. Outside execute handling, or when robot/plugin is specified,
   * the always-on executor variable endpoint is used.
   */
  json get_variable(const std::string& name, const std::optional<std::string>& robot_model = std::nullopt,
                    const std::optional<std::string>& plugin_id = std::nullopt);

  /**
   * @brief Sets a program variable for this plugin.
   */
  void set_variable(const std::string& name, const json& value);

  // State queries read the local executor-state cache.
  bool is_stopped(const std::optional<std::string>& robot_model = std::nullopt) const;
  bool is_paused(const std::optional<std::string>& robot_model = std::nullopt) const;
  std::optional<std::string> executor_state_for(const std::string& robot_model) const;
  std::map<std::string, std::string> executor_states() const;

  /**
   * @brief Blocks while paused and throws PluginStopped if the program stops.
   */
  void check_stop(const std::optional<std::string>& robot_model = std::nullopt);

  /**
   * @brief Registers the executor-state subscriber and execute queryable.
   *
   * Does not block. The execute handler must be set before calling this.
   */
  void start();

  bool started() const;

  // Test hooks.
  void feed_executor_state_bytes(const std::vector<uint8_t>& payload);
  void feed_executor_state_bytes_from_native_thread(const std::vector<uint8_t>& payload);
  void feed_execute_request_for_test(const json& args);

 private:
  RB_SDK_LOCAL std::runtime_error error_(const std::string& m) const;
  RB_SDK_LOCAL void require_started() const;

  RB_SDK_LOCAL json query_json_(const std::string& topic, const json& payload, int timeout_ms);

  RB_SDK_LOCAL std::map<std::string, std::string> model_states_locked_(const std::optional<std::string>& robot_model) const;

  RB_SDK_LOCAL void on_executor_state_(const std::vector<uint8_t>& payload);

  RB_SDK_LOCAL void on_execute_(const std::optional<std::vector<uint8_t>>& payload, const rb_zenoh::ReplyFn& reply_fn);

  RB_SDK_LOCAL void safe_notify_(const std::string& action);

  const std::string plugin_id_;
  const std::string execute_topic_;
  const std::string control_topic_;

  ExecuteHandler execute_handler_;
  StateChangeHandler state_change_handler_;
  BlockingRunner blocking_runner_;

  std::shared_ptr<rb_zenoh::ZenohClient> zenoh_;
  int sub_id_ = -1;
  int queryable_id_ = -1;
  std::atomic<bool> started_{false};
  std::atomic<bool> stopping_{false};
  std::thread exec_thread_;
  std::atomic<bool> exec_running_{false};

  mutable std::mutex mu_;
  std::map<std::string, std::string> executor_states_;
  std::set<std::string> exec_seen_active_;
  bool in_execute_ = false;
  std::optional<std::string> exec_robot_model_;
};

}  // namespace rb_plugin
