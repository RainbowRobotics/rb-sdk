#pragma once
#include <functional>  // RpcLogCallback — libstdc++ 는 <future> 경유로 딸려오지만 libc++(llvm-mingw) 는 아니다
#include "modbus_types.h"

/*
 * RPC 레벨 결과
 * ModbusResult + RpcError 조합
 */
enum RpcError {
    MSG_OK = 0,

    MSG_COMM_SERVICE_NOT_FOUND = 80,
    MSG_COMM_SERVICE_NOT_WORKING,
    MSG_COMM_SERVICE_ERROR,
    MSG_COMM_CLIENT_NO_CLIENT,
    MSG_COMM_SERVER_CONNECT_FAIL,
    MSG_COMM_SERVER_REFUSE_ME,
    MSG_COMM_MAX_USER,
    MSG_COMM_UNKNOWN_ERROR,
    MSG_COMM_EXCEPTION_ERROR,
    MSG_COMM_WRONG_FC,
    MSG_COMM_WRONG_DLC,
    MSG_COMM_WRONG_INPUT_PARA,
    MSG_COMM_TIME_OUT,
    MSG_COMM_CHECK_DLC_FAIL,
    MSG_COMM_CHECK_ACK_FAIL,
    MSG_COMM_CHECK_FORMAT_FAIL,
};

struct RpcResult {
    bool success{false};
    int error{MSG_COMM_UNKNOWN_ERROR};

    // Modbus 데이터
    std::vector<uint8_t>  bits;
    std::vector<uint16_t> regs;

    // 일반 소켓 데이터 (신규 추가)
    std::vector<uint8_t>  payload;

    //MC Protocol
    std::vector<uint8_t>  data_bit;
    std::vector<int16_t> data_word;

    //Xgt Protocol
    std::vector<int16_t>  data_word_xgt;

    // FINS Protocol
    std::vector<uint16_t> data_word_fins;
    std::vector<uint8_t>  data_bit_fins;
};

enum class LogType {
    INFO = 0,
    WARN = 1,
    ERR  = 2,
    COMM_ERROR = 3  // 통신 장애 전용
};

// 콜백 함수 정의: (로그 타입, 세션 ID, 메시지)
using RpcLogCallback = std::function<void(LogType, int sid, const std::string&)>;