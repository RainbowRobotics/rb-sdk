

#pragma once

#include <string>
#include <vector>
#include <thread>
#include <mutex>
#include <queue>
#include <condition_variable>
#include <atomic>
#include <future>
#include <functional>
#include <chrono>

#include <cerrno>

#include "sock_types.h"
// #include "common/common.h"
#include "common/rpc_result.h"

// 콜백 함수 타입 정의
using SocketAsyncCallback = std::function<void(const std::vector<uint8_t>&)>;

using SessionEventCB = std::function<void(int, const std::string&)>;

class SocketSession {
public:
    SocketSession(const std::string& ip, int port, SocketAsyncCallback callback = nullptr);
    ~SocketSession();

    /**
     * @brief 송신 작업을 큐에 추가합니다.
     */
    std::future<SocketResult> enqueue(SocketTask task);

    /**
     * @brief 수신 큐에 쌓인 데이터를 모두 가져오고 비웁니다 (즉시 반환).
     */
    std::vector<uint8_t> fetch_and_clear_recv_buffer();

    /**
     * @brief 데이터가 도착할 때까지 최대 timeout_ms 대기 후 반환합니다.
     *        timeout_ms = 0 이면 즉시 반환 (기존 동작).
     */
    std::vector<uint8_t> fetch_with_timeout(int timeout_ms);

    void set_event_callback(SessionEventCB cb) { event_cb_ = cb; }
    void notify_event(int code, const std::string& msg) { if (event_cb_) event_cb_(code, msg); }

    bool is_functional() const { return !stop_; }

private:
    // --- Backoff Logic ---
    bool connect_allowed();
    void record_fail();
    void reset_backoff();

    // --- Connection ---
    bool connect_to_server();
    void disconnect();

    // --- Worker ---
    void worker_loop();

private:
    std::string ip_;
    int port_;
    int sock_fd_{-1};
    SocketAsyncCallback async_callback_;

    std::thread worker_;
    std::atomic<bool> stop_{false};

    // Send Queue
    std::mutex q_mtx_;
    std::condition_variable cv_;
    std::queue<SocketTask> tasks_;

    // Receive Queue
    std::mutex              recv_mtx_;
    std::condition_variable recv_cv_;
    std::queue<std::vector<uint8_t>> recv_queue_;

    // Backoff state
    int fail_count_{0};
    const int MAX_RETRY_LIMIT = 2;
    std::chrono::steady_clock::time_point next_retry_time_{};

    SessionEventCB event_cb_;
};