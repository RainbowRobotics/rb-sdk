#pragma once

// interface()/vision() payload의 source of truth는 schemas/nexus/v1/manipulate.fbs다
// (flatc 생성 muscat::Interface*PayloadT / muscat::PhotoneoJointTargetT 를 그대로 쓴다).
// 이 헤더는 그 위에 얹히는, 자동 caster 로 표현 못 하는 Python 입력 정규화용 C++ DTO만 둔다.
// Python dict 변환은 muscat/rb_fbs_casters.hpp의 flatc type_caster가 담당한다.

#include "manipulate_generated.h"
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace rb_payload {
// Direct execute_* API는 기존 list 입력 계약을 유지한다. Dispatcher가 사용하는
// Interface*Payload 본체는 flatc 생성 타입(muscat::…T)을 직접 쓰고, 이 두 타입만
// Python 입력 정규화용(bool 거부/중첩 리스트 평탄화 등, interface_payload_caster.hpp)이다.
struct WriteRegisterValues {
  std::vector<std::int64_t> values;
};

struct TrajectoryNameInput {
  std::optional<std::string> variable_name;
  std::vector<std::vector<double>> waypoints;
};
}  // namespace rb_payload
