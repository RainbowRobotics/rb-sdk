#pragma once

#include "base.hpp"
#include "rb_sdk_api.hpp"
#include "common_struct_generated.h"
#include "func_arm_generated.h"
#include "func_box_generated.h"
#include "func_config_generated.h"
#include "func_flow_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "func_set_generated.h"
#include "state_core_generated.h"

class RB_SDK_API RBManipulateConfigSDK : public RBBaseSDK {
 public:
  RBManipulateConfigSDK() {}

  static std::string type_name() { return "RBManipulateConfigSDK"; }

  /**
   * @brief Requests the cobot to set its speed bar multiplier (range: 0.0–1.0),
            which is displayed as a percentage (%) in the UI (e.g., 1.0 = 100%).
   *
   * @param robot_model Name of the robot model.
   * @param alpha Speed bar value, 0.0-1.0. Multiplied against the robot's
   *        final commanded speed: 0.0 means stop, 1.0 means the full
   *        intended speed.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_speedbar(const std::string& robot_model, const float alpha,
                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot's full robot-arm configuration snapshot.
   *
   * Returns the aggregate configuration written by this class's various
   * `save_*`/`set_*` arm-related calls: out/self collision settings,
   * gravity compensation, direct-teach sensitivity, tool-flange special
   * function/filter settings, joint kinematic limits, and deflection
   * compensation mode.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_CallConfigRobotArmT containing the robot arm
   *         configuration snapshot.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_CallConfigRobotArmT call_config_robotarm(const std::string& robot_model,
                                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot's full control-box configuration snapshot.
   *
   * Returns the aggregate configuration written by this class's various
   * `save_*`/`set_*` control-box-related calls: side/ext digital I/O
   * special function and filter settings, the 8 area configs, and the 8
   * user frame configs.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_CallConfigControlBoxT containing the control box
   *         configuration snapshot.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_CallConfigControlBoxT call_config_controlbox(const std::string& robot_model,
                                                             FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save its robot model/hardware code.
   *
   * @warning @p code identifies which
   *          hardware/kinematics parameter set the robot loads. It is
   *          written to persistent storage but does NOT take effect until
   *          the next reboot (the firmware source marks this "NO ADJUST" —
   *          no live re-apply happens). If @p code doesn't match a known
   *          robot model, the parameter set loaded on next boot can be
   *          invalid, and the robot control program can fail to
   *          initialize / crash immediately on restart. Do not call this
   *          with a value that isn't a known, correct model code for this
   *          physical robot.
   *
   * @param robot_model Name of the robot model.
   * @param code Robot model/hardware code to save. Takes effect only after
   *        the robot control program is restarted.
   * @param option Accepted but currently unused by the robot firmware.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_robot_code(const std::string& robot_model, const int32_t code, const int option,
                                           FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot's saved tool list configuration.
   *
   * Returns up to 8 tool slots (per @c save_tool_list_parameter), each with
   * name, TCP offset, mass/center-of-mass, and bounding-box parameters.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_CallConfigToolListT containing the tool list
   *         configuration.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_CallConfigToolListT call_config_toollist(const std::string& robot_model,
                                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to select the active tool from its saved tool list.
   *
   * @param robot_model Name of the robot model.
   * @param target_tool_num Tool slot number to activate (see
   *        @c call_config_toollist / @c save_tool_list_parameter).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_toollist_num(const std::string& robot_model, int target_tool_num,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a tool's parameters into its tool list.
   *
   * @param robot_model Name of the robot model.
   * @param tool_no Tool slot number to save into, 0-7.
   * @param tool_name Display name for the tool.
   * @param tcp_x TCP offset from the flange along X, in mm.
   * @param tcp_y TCP offset from the flange along Y, in mm.
   * @param tcp_z TCP offset from the flange along Z, in mm.
   * @param tcp_rx TCP orientation offset from the flange around X, in
   *        degrees.
   * @param tcp_ry TCP orientation offset from the flange around Y, in
   *        degrees.
   * @param tcp_rz TCP orientation offset from the flange around Z, in
   *        degrees.
   * @param mass_m Tool mass.
   * @param mass_x Tool center-of-mass offset from the flange along X.
   * @param mass_y Tool center-of-mass offset from the flange along Y.
   * @param mass_z Tool center-of-mass offset from the flange along Z.
   * @param box_type Bounding-box shape used to interpret @p box_para_0
   *        through @p box_para_8: 0 None, 1 Sphere, 2 Cylinder, 3 Box.
   * @param box_para_0 Bounding-box parameter 0, interpreted according to
   *        @p box_type.
   * @param box_para_1 Bounding-box parameter 1, interpreted according to
   *        @p box_type.
   * @param box_para_2 Bounding-box parameter 2, interpreted according to
   *        @p box_type.
   * @param box_para_3 Bounding-box parameter 3, interpreted according to
   *        @p box_type.
   * @param box_para_4 Bounding-box parameter 4, interpreted according to
   *        @p box_type.
   * @param box_para_5 Bounding-box parameter 5, interpreted according to
   *        @p box_type.
   * @param box_para_6 Bounding-box parameter 6, interpreted according to
   *        @p box_type.
   * @param box_para_7 Bounding-box parameter 7, interpreted according to
   *        @p box_type.
   * @param box_para_8 Bounding-box parameter 8, interpreted according to
   *        @p box_type.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_tool_list_parameter(
      const std::string& robot_model, int tool_no, const std::string& tool_name, float tcp_x, float tcp_y, float tcp_z,
      float tcp_rx, float tcp_ry, float tcp_rz, float mass_m, float mass_x, float mass_y, float mass_z, int box_type,
      float box_para_0, float box_para_1, float box_para_2, float box_para_3, float box_para_4, float box_para_5,
      float box_para_6, float box_para_7, float box_para_8, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to select the active user frame.
   *
   * @param robot_model Name of the robot model.
   * @param target_user_frame_num User frame slot number to activate, 0-7
   *        (see @c save_user_frame_parameter).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_userframe_num(const std::string& robot_model, const int target_user_frame_num,
                                             FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a user frame's parameters.
   *
   * @param robot_model Name of the robot model.
   * @param userf_no User frame slot number to save into, 0-7.
   * @param userf_name Display name for the user frame.
   * @param userf_x User frame origin offset along X, in mm.
   * @param userf_y User frame origin offset along Y, in mm.
   * @param userf_z User frame origin offset along Z, in mm.
   * @param userf_rx User frame orientation offset around X, in degrees.
   * @param userf_ry User frame orientation offset around Y, in degrees.
   * @param userf_rz User frame orientation offset around Z, in degrees.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_user_frame_parameter(const std::string& robot_model, int userf_no,
                                                     const std::string& userf_name, float userf_x, float userf_y,
                                                     float userf_z, float userf_rx, float userf_ry, float userf_rz,
                                                     FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot's saved global pin list, including both
            pin joint (joint-space) and pin point (Cartesian-space) entries.
   *
   * Returns each global pin's name along with its joint-space (pin_j) and
   * Cartesian-space (pin_l) target values (see @c save_globpin_parameter).
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_CallConfigGlobPinListT containing the global pin
   *         list.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_CallConfigGlobPinListT call_config_globpinlist(const std::string& robot_model,
                                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to capture its current pose into a named global pin slot.
   *
   * Saves the robot's current joint values and Cartesian pose (at the
   * moment this is called) into the given pin slot under @p pin_name.
   * @c call_move_home's home_type = 3 + @p pin_num moves the robot to this
   * pin's joint pose (Move-J) or Cartesian pose (Move-L).
   *
   * @param robot_model Name of the robot model.
   * @param pin_num Global pin slot number, 0-15.
   * @param pin_name Display name for the pin.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_globpin_parameter(const std::string& robot_model, int pin_num,
                                                  const std::string& pin_name,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot's flange configuration options.
   *
   * Returns the currently configured flange (end-effector mounting)
   * option settings for the robot.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_CallConfigFlangeOptionT containing the flange
   *         option configuration.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_CallConfigFlangeOptionT call_config_flangeoption(const std::string& robot_model,
                                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot's network configuration options.
   *
   * Returns the currently configured network option settings for the robot.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_CallConfigNetworkT containing the flange
   *         option configuration.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_CallConfigNetworkT call_config_network(const std::string& robot_model,
                                                       FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a user frame directly via a 6-DOF pose.
   *
   * @param robot_model Name of the robot model.
   * @param user_frame_num User frame slot number, 0-7.
   * @param setting_option 0 restores the previously saved frame, 1 applies
   *        the given target temporarily, 2 applies and permanently saves
   *        the given target.
   * @param target_frame Frame the given target is expressed in: 0 Global,
   *        1 Local, 2 User.
   * @param target_x Target position along X, in mm.
   * @param target_y Target position along Y, in mm.
   * @param target_z Target position along Z, in mm.
   * @param target_rx Target orientation around X, in degrees.
   * @param target_ry Target orientation around Y, in degrees.
   * @param target_rz Target orientation around Z, in degrees.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_userframe_6dof(const std::string& robot_model, int user_frame_num, int setting_option,
                                              int target_frame, float target_x, float target_y, float target_z,
                                              float target_rx, float target_ry, float target_rz,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a user frame from the current TCP pose.
   *
   * @param robot_model Name of the robot model.
   * @param user_frame_num User frame slot number, 0-7.
   * @param setting_option 0 restores the previously saved frame, 1 applies
   *        the current TCP pose temporarily, 2 applies and permanently
   *        saves it.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_userframe_tcp(const std::string& robot_model, const int user_frame_num,
                                             const int setting_option, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a user frame from 3 taught points.
   *
   * @param robot_model Name of the robot model.
   * @param user_frame_num User frame slot number, 0-7.
   * @param setting_option 0 restores the previously saved frame, 1 applies
   *        the frame computed from the 3 points temporarily, 2 applies and
   *        permanently saves it.
   * @param order_option How the 3 points define the frame's axes:
   *        0 Origin->X Axis->XY Plane, 1 Origin->Y Axis->YZ Plane,
   *        2 Origin->Z Axis->ZX Plane.
   * @param point_1_x First point's X coordinate, in mm.
   * @param point_1_y First point's Y coordinate, in mm.
   * @param point_1_z First point's Z coordinate, in mm.
   * @param point_2_x Second point's X coordinate, in mm.
   * @param point_2_y Second point's Y coordinate, in mm.
   * @param point_2_z Second point's Z coordinate, in mm.
   * @param point_3_x Third point's X coordinate, in mm.
   * @param point_3_y Third point's Y coordinate, in mm.
   * @param point_3_z Third point's Z coordinate, in mm.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_userframe_3points(const std::string& robot_model, int user_frame_num, int setting_option,
                                                 int order_option, float point_1_x, float point_1_y, float point_1_z,
                                                 float point_2_x, float point_2_y, float point_2_z, float point_3_x,
                                                 float point_3_y, float point_3_z,

                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a restricted area's parameters.
   *
   * @param robot_model Name of the robot model.
   * @param area_no Area slot number to save into, 0-7.
   * @param area_name Display name for the area.
   * @param area_type Area shape used to interpret @p area_para_0 through
   *        @p area_para_2 (same enum as @c save_tool_list_parameter's
   *        box_type): 0 None, 1 Sphere, 2 Cylinder, 3 Box.
   * @param area_x Area origin offset along X, in mm.
   * @param area_y Area origin offset along Y, in mm.
   * @param area_z Area origin offset along Z, in mm.
   * @param area_rx Area orientation offset around X, in degrees.
   * @param area_ry Area orientation offset around Y, in degrees.
   * @param area_rz Area orientation offset around Z, in degrees.
   * @param area_para_0 Area shape parameter 0, interpreted according to
   *        @p area_type.
   * @param area_para_1 Area shape parameter 1, interpreted according to
   *        @p area_type.
   * @param area_para_2 Area shape parameter 2, interpreted according to
   *        @p area_type.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_area_parameter(const std::string& robot_model, int area_no,
                                               const std::string& area_name, int area_type, float area_x, float area_y,
                                               float area_z, float area_rx, float area_ry, float area_rz,
                                               float area_para_0, float area_para_1, float area_para_2,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save its gravity compensation parameters.
   *
   * Effectively sets the robot's installation/mounting angle, expressed as
   * the direction of gravitational acceleration relative to the Global
   * coordinate system.
   *
   * @param robot_model Name of the robot model.
   * @param mode Gravity compensation mode: 0 Static, 1 Dynamic.
   * @param gx Gravity direction vector X component (Global frame).
   * @param gy Gravity direction vector Y component (Global frame).
   * @param gz Gravity direction vector Z component (Global frame).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_gravity_parameter(const std::string& robot_model, const int mode, const float gx,
                                                  const float gy, const float gz,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save its direct-teach sensitivity.
   *
   * @param robot_model Name of the robot model.
   * @param sensitivity Per-joint direct-teach sensitivity values (range: 0.0–2.0).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_direct_teach_sensitivity(const std::string& robot_model, std::vector<float> sensitivity,
                                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save its out collision detection parameters.
   *
   * Persist-and-apply counterpart to @c set_out_collision_para: writes to
   * persistent storage and then applies it immediately, whereas
   * @c set_out_collision_para only applies it for the current session
   * (lost on restart).
   * Same out_coll_onoff/out_coll_react/out_coll_limit fields reported by
   * @c call_config_robotarm.
   *
   * @param robot_model Name of the robot model.
   * @param onoff Enables/disables collision detection: 0 Off, 1 On.
   * @param react Reaction behavior when a collision is detected: 0 Pause
   *        Movement, 1 Evasion Stop.
   * @param threshold Collision detection sensitivity threshold (clamped to 0–1 by the robot);
   *        lower values trigger a stop at weaker impacts.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_collision_parameter(const std::string& robot_model, const int onoff, const int react,
                                                    const float threshold, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save its self-collision detection parameters.
   *
   * Persist-and-apply counterpart to @c set_self_collision_para: writes to
   * persistent storage and then applies it immediately, whereas
   * @c set_self_collision_para only applies it for the current session
   * (lost on restart).
   * Same self_coll_mode/self_coll_distance_inter/self_coll_distance_exter
   * fields reported by @c call_config_robotarm.
   *
   * @param robot_model Name of the robot model.
   * @param mode Self-collision detection mode: 0 stop just before
   *        self-collision, 1 control speed during self-collision.
   * @param dist_internal Internal self-collision distance (mm) threshold,
   *        floored at 0 by the robot.
   * @param dist_external External self-collision distance (mm) threshold,
   *        floored at 0 by the robot.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_selfcoll_parameter(const std::string& robot_model, const int mode,
                                                   const float dist_internal, const float dist_external,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save its per-joint kinematic limits.
   *
   * @param robot_model Name of the robot model.
   * @param position_low Per-joint lower position limit, in degrees.
   * @param position_up Per-joint upper position limit, in degrees.
   * @param speed_limit Per-joint speed limit, in degrees/s.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_joint_kinematic_limit(const std::string& robot_model, std::vector<float> position_low,
                                                      std::vector<float> position_up, std::vector<float> speed_limit,
                                                      FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save its deflection compensation mode.
   *
   * @param robot_model Name of the robot model.
   * @param mode Compensation mode: 0 Off, 1 Adjust Deflection.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_deflection_compensation(const std::string& robot_model, int mode,
                                                        FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set its out collision detection parameters.
   *
   * Applies immediately for the current session only — not written to
   * persistent storage, unlike @c save_collision_parameter (same fields),
   * which also persists.
   *
   * @param robot_model Name of the robot model.
   * @param onoff Enables/disables collision detection: 0 Off, 1: On.
   * @param react_mode Reaction behavior when a collision is detected: 0
   *        Pause Movement, 1 Evasion Stop.
   * @param threshold Collision detection sensitivity threshold (clamped to 0–1 by the robot);
   *        lower values trigger a stop at weaker impacts.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_out_collision_para(const std::string& robot_model, int onoff, int react_mode,
                                                  float threshold, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set its self-collision detection parameters.
   *
   * Applies immediately for the current session only — not written to
   * persistent storage, unlike @c save_selfcoll_parameter (same fields),
   * which also persists.
   *
   * @param robot_model Name of the robot model.
   * @param mode Self-collision detection mode: 0 stop just before
   *        self-collision, 1 control speed during self-collision.
   * @param dist_int Internal self-collision distance (mm) threshold.
   * @param dist_ext External self-collision distance (mm) threshold.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_self_collision_para(const std::string& robot_model, int mode, float dist_int,
                                                   float dist_ext, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set its master (teleoperation) mode.
   *
   * @param robot_model Name of the robot model.
   * @param mode 0 Off, 1 Reflected Joint Angle, 2 Synchronized Cartesian.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_master_mode(const std::string& robot_model, int mode,
                                           FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a fixed speed/acceleration override for a move type.
   *
   * @param robot_model Name of the robot model.
   * @param target_move Move type this override applies to: 0 J-Types, 1
   *        L-Types (Position), 2 L-Types (Orientation).
   * @param vel_option Velocity override mode: 0 Off, 1 Fixed mode (%), 2
   *        Fixed mode (physical units).
   * @param vel_parameter Velocity value, interpreted according to
   *        @p vel_option.
   * @param acc_option Acceleration override mode: 0 Off, 1 Fixed mode (%),
   *        2 Fixed mode (physical units).
   * @param acc_parameter Acceleration value, interpreted according to
   *        @p acc_option.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_fixed_speed(const std::string& robot_model, int target_move, int vel_option,
                                           float vel_parameter, int acc_option, float acc_parameter,
                                           FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a target shift.
   *
   * @param robot_model Name of the robot model.
   * @param shift_no Target shift slot number.
   * @param shift_mode Shift mode: 0 Off, 1 Adjust L-Move, 2 Adjust L,J-Move, 3 Adjust J-Move.
   * @param target Shift target position and frame information.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_shift(const std::string& robot_model, int shift_no, int shift_mode,
                                     IPC::MoveInput_TargetT target, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a move time constraint.
   *
   * @param robot_model Name of the robot model.
   * @param option 0 Off, 1 Unit Move Time-Constraint, 2 Multi Move Time-Constraint.
   * @param time_sec Target time, in seconds.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_timeconstraint(const std::string& robot_model, int option, float time_sec,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to run/queue an ASCII function call command.
   *
   * @param robot_model Name of the robot model.
   * @param option 0 Direct Execution, 1 Queue Message.
   * @param message ASCII command message.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_ascii_functioncall(const std::string& robot_model, int option,
                                                  const std::string& message,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set per-joint impedance control parameters.
   *
   * @param robot_model Name of the robot model.
   * @param onoff 0 Off, 1 On Joint Impedance.
   * @param stiffness Per-joint stiffness, each value 0-1.
   * @param torquelimit Per-joint torque limit, each value 0-1.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_joint_impedance(const std::string& robot_model, int onoff, std::vector<float> stiffness,
                                               std::vector<float> torquelimit,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to enable/configure free-drive (hand guiding) mode.
   *
   * @param robot_model Name of the robot model.
   * @param onoff 0 Off, 1 On Free Drive, 2 On When Button Clicked.
   * @param extra_force_frame Frame the additional force is expressed in:
   *        0 Global Frame, 1 Local TCP Frame, 2 User Frame.
   * @param extra_force_fx Additional force along X, in Nm.
   * @param extra_force_fy Additional force along Y, in Nm.
   * @param extra_force_fz Additional force along Z, in Nm.
   * @param sensitivity Operation sensitivity, 0-1.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_freedrive(const std::string& robot_model, int onoff, int extra_force_frame,
                                         float extra_force_fx, float extra_force_fy, float extra_force_fz,
                                         float sensitivity, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to compute and set a target shift from landmark points.
   *
   * Computes the shift between a reference set of 3 points and the
   * corresponding present set of 3 points (e.g. touched up after a
   * workpiece moved), then applies it as a target shift.
   *
   * @param robot_model Name of the robot model.
   * @param shift_mode Shift mode: 0 Off, 1 Adjust L-Move, 2 Adjust L,J-Move, 3 Adjust J-Move.
   * @param tolerance Match tolerance between the reference and present point sets.
   * @param reference_point_1 First reference-set point.
   * @param reference_point_2 Second reference-set point.
   * @param reference_point_3 Third reference-set point.
   * @param present_point_1 First present-set point, corresponding to @p reference_point_1.
   * @param present_point_2 Second present-set point, corresponding to @p reference_point_2.
   * @param present_point_3 Third present-set point, corresponding to @p reference_point_3.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_shift_landmark(
      const std::string& robot_model, int shift_mode, float tolerance, IPC::MoveInput_TargetT reference_point_1,
      IPC::MoveInput_TargetT reference_point_2, IPC::MoveInput_TargetT reference_point_3,
      IPC::MoveInput_TargetT present_point_1, IPC::MoveInput_TargetT present_point_2,
      IPC::MoveInput_TargetT present_point_3, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to control program flow (stop/pause/resume/reset collision).
   *
   * @param robot_model Name of the robot model.
   * @param target 0 All Robot Components, 1 This Component.
   * @param option 0 Stop, 1 Pause, 2 Resume, 3 Reset Collision.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_program_flow_manage(const std::string& robot_model, int target, int option,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to enable/disable a digital input port's special function.
   *
   * @param robot_model Name of the robot model.
   * @param device 0 Control Box I/O, 1 Extension I/O, 2 ToolFlange I/O.
   * @param port_num Digital input port number, 0-15.
   * @param option 0 Disable-Mask Off, 1 Disable-Mask On.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_din_function_mask(const std::string& robot_model, int device, int port_num, int option,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to enable/disable a digital output port's special function.
   *
   * @param robot_model Name of the robot model.
   * @param device 0 Control Box I/O, 1 Extension I/O, 2 ToolFlange I/O.
   * @param port_num Digital output port number, 0-15.
   * @param option 0 Disable-Mask Off, 1 Disable-Mask On.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_dout_function_mask(const std::string& robot_model, int device, int port_num, int option,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to enable/disable Jacobian-based speed control.
   *
   * @param robot_model Name of the robot model.
   * @param mode 0 Active (default), 1 De-active.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_jacob_speed_mode(const std::string& robot_model, int mode,
                                                FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to enable/configure self-vibration.
   *
   * @param robot_model Name of the robot model.
   * @param mode 0 Off, 1 On.
   * @param time Vibration duration, in seconds.
   * @param frequency Vibration frequency, in Hz.
   * @param magnitudes Per-joint vibration magnitude, each value 0-1.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_self_vibration_mode(const std::string& robot_model, int mode, float time,
                                                   float frequency, std::vector<float> magnitudes,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to start motion-based vibration.
   *
   * @param robot_model Name of the robot model.
   * @param frame Frame the vibration is expressed in: 0 Global, 1 Local,
   *        2 User, 3 Target, 4 Active Local.
   * @param x_mag Vibration magnitude along X, in mm.
   * @param y_mag Vibration magnitude along Y, in mm.
   * @param z_mag Vibration magnitude along Z, in mm.
   * @param x_freq Vibration frequency along X, in Hz.
   * @param y_freq Vibration frequency along Y, in Hz.
   * @param z_freq Vibration frequency along Z, in Hz.
   * @param x_phase Vibration phase along X, in degrees.
   * @param y_phase Vibration phase along Y, in degrees.
   * @param z_phase Vibration phase along Z, in degrees.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_vibration_motion_on(const std::string& robot_model, int frame, float x_mag, float y_mag,
                                                    float z_mag, float x_freq, float y_freq, float z_freq,
                                                    float x_phase, float y_phase, float z_phase,
                                                    FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to stop motion-based vibration.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_vibration_motion_off(const std::string& robot_model,
                                                     FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to enable/disable external axis synchronization.
   *
   * @param robot_model Name of the robot model.
   * @param mode 0 Sync Off, 1 Sync On.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_external_axis_sync(const std::string& robot_model, int mode,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a TCP speed bound.
   *
   * @param robot_model Name of the robot model.
   * @param mode 0 Bound Off (system default), 1 Bound On.
   * @param speed_parameter TCP speed limit, in mm/s.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_tcp_speed_bound(const std::string& robot_model, int mode, float speed_parameter,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set move break/block behavior.
   *
   * @param robot_model Name of the robot model.
   * @param mode 0 Off (release), 1 Continuous Block, 2 Break Once.
   * @param stopping_time Stopping time, in seconds.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_move_break(const std::string& robot_model, int mode, float stopping_time,
                                          FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Sets the joint reference filter mode and filter strength.
   *
   * Configures the low-pass filter applied to joint reference (command)
   * values, used to smooth joint motion commands before they are sent
   * to the drives.
   *
   * @param robot_model Name of the robot model.
   * @param mode Filter mode. 0: Off (System default), 1: On.
   * @param filter_percent Filter strength as a percentage (0.0 ~ 1.0).
   *        Only effective when @p mode is 1.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the result of the request.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_joint_reference_filter(const std::string& robot_model, int mode, float filter_percent,
                                                      FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Sets the self-collision detection blind time.
   *
   * Configures the duration for which self-collision detection is
   * temporarily disabled (blinded), used to suppress false-positive
   * self-collision triggers during specific motions.
   *
   * @param robot_model Name of the robot model.
   * @param time Self-collision detection blind time, in seconds.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the result of the request.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT set_self_collision_blind(const std::string& robot_model, float time,
                                                    FlowManagerArgsPtr flow_manager_args = nullptr);
};
