#pragma once

#include "base.hpp"
#include "rb_sdk_api.hpp"
#include "common_struct_generated.h"
#include "func_config_generated.h"
#include "func_get_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "state_core_generated.h"

using Response_get_core_data_variant = std::optional<std::variant<float, std::vector<float>, std::string>>;

class RB_SDK_API RBManipulateGetDataSDK : public RBBaseSDK {
 public:
  RBManipulateGetDataSDK() {}

  static std::string type_name() { return "RBManipulateGetDataSDK"; }

  /**
   * @brief Computes the coordinate a relative move would resolve to.
   *
   * Given @p reference_value as the starting point, computes the absolute
   * target that moving by @p relative_value from it resolves to. Used
   * internally by the move-family functions' relative-move calculation
   * (e.g. @c call_move_j / @c call_move_l).
   *
   * @p relative_value and @p reference_value do not need the same
   * tar_frame: if one is Joint Space (tar_frame -1) and the other isn't,
   * the robot converts one to match the other (forward/inverse kinematics)
   * before combining them, then converts the combined result again if
   * needed to match @p move_type. This conversion can itself fail (e.g. an
   * unreachable target), which surfaces as a nonzero calculated_result.
   *
   * @param robot_model Name of the robot model.
   * @param relative_value Relative offset target and frame information.
   *        tar_values must have exactly 7 elements — this SDK passes it
   *        through unmodified, so callers must pad to 7 themselves (e.g.
   *        with 0 for a 6-axis model's unused ArmAngle slot).
   * @param reference_value Reference target and frame information.
   *        tar_values must resolve to exactly 7 elements after this SDK
   *        truncates it to at most 7 — supplying fewer than 7 will not be
   *        padded and will fail the same way as an oversized/undersized
   *        @p relative_value.
   * @param move_type 0 for the move-J family (joint-space), 1 for the
   *        move-L family (Cartesian-space).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_Get_Relative_ValueT with calculated_result (0 on
   *         success) and calculated_value (the computed absolute target).
   *         If either tar_values doesn't resolve to exactly 7 elements,
   *         the robot rejects the request before any calculation runs:
   *         calculated_result is nonzero and calculated_value is left
   *         unset.
   *
   * @note This function does not throw on calculation failure —
   *       calculated_result nonzero must be checked by the caller (as the
   *       move-family functions do).
   *
   * @throws std::runtime_error If the query itself fails (e.g. no reply).
   */
  IPC::Response_Get_Relative_ValueT get_relative_value(const std::string& robot_model,
                                                       const IPC::MoveInput_TargetT& relative_value,
                                                       const IPC::MoveInput_TargetT& reference_value, int move_type,
                                                       FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Looks up a named runtime variable/system value on the robot.
   *
   * @param robot_model Name of the robot model.
   * @param name Variable name to query.
   *
   * @return The variable's value as a float, a list of floats, or a
   *         string, depending on its reported type; std::nullopt if the
   *         response is invalid or the response's type doesn't match any
   *         of those. This matches the Python original.
   *
   * @throws std::runtime_error If the query itself fails (e.g. no reply).
   */
  Response_get_core_data_variant get_variable(const std::string& robot_model, const std::string& name);

  /**
   * @brief Computes the absolute coordinate a reference target resolves to.
   *
   * Used internally for absolute (non-relative) target resolution, e.g. by
   * @c set_pin_point_or_joint when no reference_target offset is given.
   * @p reference_value's tar_frame does not need to match @p move_type:
   * the robot always converts it (forward/inverse kinematics as needed) to
   * the frame matching @p move_type. This conversion can itself fail (e.g.
   * an unreachable target), which surfaces as a nonzero calculated_result.
   *
   * @param robot_model Name of the robot model.
   * @param reference_value Reference target and frame information.
   *        tar_values must resolve to exactly 7 elements — this SDK
   *        truncates it to at most 7, so supplying fewer than 7 will not
   *        be padded and the request will be rejected.
   * @param move_type 0 for the move-J / pin-joint family (joint-space), 1
   *        for the move-L / pin-point family (Cartesian-space).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_Get_Absolute_ValueT with calculated_result (0 on
   *         success) and calculated_value (the computed absolute target).
   *         If tar_values doesn't resolve to exactly 7 elements, the robot
   *         rejects the request before any calculation runs:
   *         calculated_result is nonzero and calculated_value is left
   *         unset.
   *
   * @note This function does not throw on calculation failure —
   *       calculated_result nonzero must be checked by the caller.
   *
   * @throws std::runtime_error If the query itself fails (e.g. no reply).
   */
  IPC::Response_Get_Absolute_ValueT get_absolute_value(const std::string& robot_model,
                                                       const IPC::MoveInput_TargetT& reference_value, int move_type,
                                                       FlowManagerArgsPtr flow_manager_args = nullptr);
};
