#pragma once

#include <iostream>
#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "base.hpp"
#include "rb_sdk_api.hpp"
#include "common_struct_generated.h"
#include "func_config_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "move_speed_args.hpp"
#include "move_target_values_arg.hpp"
class RB_SDK_API RBManipulateMoveSDK : public RBBaseSDK {
 public:
  RBManipulateMoveSDK() {}

  static std::string type_name() { return "RBManipulateMoveSDK"; }

  /**
   * @brief Requests the cobot to start a J-type (joint-space) movement.
   *
   * Supports J-type (joint-space) movement of the cobot: the target is given
   * as a per-joint angle set, and each joint moves independently toward its
   * target angle, so the resulting end-effector path is not constrained to
   * a straight line (as opposed to L-type movement). If reference joint
   * values are provided, the target is calculated as a relative movement
   * from the reference position.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. When
   *        @p reference_value is provided, tar_values must have exactly 7
   *        elements (the underlying relative-value calculation rejects any
   *        other length).
   * @param reference_value Optional reference joint values used for
   *        relative movement calculation. Must have exactly 7 elements
   *        when provided — e.g. [0, 0, 0, 0, 0, 0, 0].
   * @param speed Optional movement speed parameters.
   * @param ext_axis Optional external axis values.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager and completion is
   *        handled asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the movement request result.
   *
   * @throws std::runtime_error If relative movement calculation fails,
   *         or if the movement result cannot be retrieved.
   *
   * @note If @p speed is not provided, the default values are:
   *       spd_mode = 1, spd_vel_para = 60, spd_acc_para = 120.
   *
   * @note If @p flow_manager_args is provided, this function returns
   *       immediately after submitting the request; a background monitor
   *       waits for the actual motion-completion signal from the robot
   *       before invoking the flow manager's completion callback.
   */
  IPC::Response_FunctionsT call_move_j(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                       std::optional<std::vector<float>> reference_value,
                                       std::optional<MoveSpeedArg> speed,
                                       std::optional<std::vector<float>> ext_axis = std::nullopt,
                                       std::optional<std::vector<IPC::Move_Property_EntryT>> properties = std::nullopt,
                                       FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to start an L-type (linear/Cartesian-space) movement.
   *
   * Supports L-type (linear/Cartesian-space) movement of the cobot: the
   * target is given as a Cartesian pose, and the end-effector moves in a
   * straight line to that pose (as opposed to J-type movement). If
   * reference_value is provided, the target is calculated as a relative
   * movement from the reference position.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. tar_values is
   *        [x, y, z, rx, ry, rz, aa] for 7-axis models, or
   *        [x, y, z, rx, ry, rz] for 6-axis models (aa = ArmAngle). When
   *        @p reference_value is provided, tar_values must have exactly 7
   *        elements regardless of axis count (pad with 0 for a 6-axis
   *        model's unused aa slot) — the underlying relative-value
   *        calculation rejects any other length.
   * @param reference_value Optional reference target used for relative
   *        movement calculation, in the same [x, y, z, rx, ry, rz(, aa)]
   *        format as @p target. Must have exactly 7 elements when
   *        provided, regardless of axis count.
   * @param speed Optional movement speed parameters.
   * @param ext_axis Optional external axis values.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager and completion is
   *        handled asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the movement request result.
   *
   * @throws std::runtime_error If relative movement calculation fails,
   *         or if the movement result cannot be retrieved.
   *
   * @note If @p speed is not provided, the default values are:
   *       spd_mode = 1, spd_vel_para = 60, spd_acc_para = 120.
   *
   * @note If @p flow_manager_args is provided, this function returns
   *       immediately after submitting the request; a background monitor
   *       waits for the actual motion-completion signal from the robot
   *       before invoking the flow manager's completion callback.
   */
  IPC::Response_FunctionsT call_move_l(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                       std::optional<std::vector<float>> reference_value,
                                       std::optional<MoveSpeedArg> speed,
                                       std::optional<std::vector<float>> ext_axis = std::nullopt,
                                       std::optional<std::vector<IPC::Move_Property_EntryT>> properties = std::nullopt,
                                       FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to clear its queued joint-blend movement commands.
   *
   * Clears the internal list of joint-blend move segments previously
   * accumulated via @c call_move_jb_add, so a new joint-blend sequence can be
   * started from scratch.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        blend command list is cleared and completion is reported to the
   *        flow manager immediately (synchronous), unlike move commands
   *        whose completion is tracked asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the clear request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_move_jb_clr(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to add a segment to the queued joint-blend movement sequence.
   *
   * Appends one joint-space segment to the internal blend list built up
   * across successive calls; the queued segments run together once
   * @c call_move_jb_run is invoked. If reference joint values are provided,
   * the segment's target is calculated as a relative movement from the
   * reference position.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. When
   *        @p reference_value is provided, tar_values must have exactly 7
   *        elements (the underlying relative-value calculation rejects any
   *        other length).
   * @param reference_value Optional reference joint values used for
   *        relative movement calculation. Must have exactly 7 elements
   *        when provided — e.g. [0, 0, 0, 0, 0, 0, 0].
   * @param speed Optional movement speed parameters.
   * @param blend_type Blend transition parameters. pnt_type is 0 (Percentage)
   *        or 1 (Distance); pnt_para is a percentage when pnt_type is 0, or
   *        millimeters when pnt_type is 1.
   * @param ext_axis Optional external axis values.
   * @param flow_manager_args Optional PyFM step context. If provided, this
   *        segment is recorded for the blend sequence and completion is
   *        reported to the flow manager immediately (synchronous), unlike
   *        run commands whose completion is tracked asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the add request result.
   *
   * @throws std::runtime_error If relative movement calculation fails,
   *         or if the add request result cannot be retrieved.
   *
   * @note If @p speed is not provided, the default values are:
   *       spd_mode = 1, spd_vel_para = 60, spd_acc_para = 120.
   */
  IPC::Response_FunctionsT call_move_jb_add(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                            std::optional<std::vector<float>> reference_value,
                                            std::optional<MoveSpeedArg> speed,
                                            const IPC::MoveInput_TypeT& blend_type,
                                            std::optional<std::vector<float>> ext_axis = std::nullopt,
                                            std::optional<std::vector<IPC::Move_Property_EntryT>> properties = std::nullopt,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to execute the queued joint-blend movement sequence.
   *
   * Runs the sequence of joint-space segments previously accumulated via
   * @c call_move_jb_add.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the run request result.
   *
   * @throws std::runtime_error If the query fails or the run request result
   *         cannot be retrieved.
   */
  IPC::Response_FunctionsT call_move_jb_run(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to clear its queued linear-blend movement commands.
   *
   * Clears the internal list of linear-blend (Cartesian-space) move segments
   * previously accumulated via @c call_move_lb_add, so a new linear-blend
   * sequence can be started from scratch.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        blend command list is cleared and completion is reported to the
   *        flow manager immediately (synchronous), unlike move commands
   *        whose completion is tracked asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the clear request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_move_lb_clr(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to add a segment to the queued linear-blend movement sequence.
   *
   * Appends one Cartesian-space segment to the internal blend list built up
   * across successive calls; the queued segments run together once
   * @c call_move_lb_run is invoked. If reference_value is provided, the
   * segment's target is calculated as a relative movement from the
   * reference position.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. tar_values is
   *        [x, y, z, rx, ry, rz, aa] for 7-axis models, or
   *        [x, y, z, rx, ry, rz] for 6-axis models (aa = ArmAngle). When
   *        @p reference_value is provided, tar_values must have exactly 7
   *        elements regardless of axis count (pad with 0 for a 6-axis
   *        model's unused aa slot) — the underlying relative-value
   *        calculation rejects any other length.
   * @param reference_value Optional reference target used for relative
   *        movement calculation, in the same [x, y, z, rx, ry, rz(, aa)]
   *        format as @p target. Must have exactly 7 elements when
   *        provided, regardless of axis count.
   * @param speed Optional movement speed parameters.
   * @param blend_type Blend transition parameters. pnt_type is 0 (Percentage)
   *        or 1 (Distance); pnt_para is a percentage when pnt_type is 0, or
   *        millimeters when pnt_type is 1.
   * @param ext_axis Optional external axis values.
   * @param flow_manager_args Optional PyFM step context. If provided, this
   *        segment is recorded for the blend sequence and completion is
   *        reported to the flow manager immediately (synchronous), unlike
   *        run commands whose completion is tracked asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the add request result.
   *
   * @throws std::runtime_error If relative movement calculation fails,
   *         or if the add request result cannot be retrieved.
   *
   * @note If @p speed is not provided, the default values are:
   *       spd_mode = 1, spd_vel_para = 60, spd_acc_para = 120.
   */
  IPC::Response_FunctionsT call_move_lb_add(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                            std::optional<std::vector<float>> reference_value,
                                            std::optional<MoveSpeedArg> speed,
                                            const IPC::MoveInput_TypeT& blend_type,
                                            std::optional<std::vector<float>> ext_axis = std::nullopt,
                                            std::optional<std::vector<IPC::Move_Property_EntryT>> properties = std::nullopt,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to execute the queued linear-blend movement sequence.
   *
   * Runs the sequence of Cartesian-space segments previously accumulated via
   * @c call_move_lb_add.
   *
   * @param robot_model Name of the robot model.
   * @param orientation Orientation option for the blended path.
   *        (0: Intended, 1: Constant)
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the run request result.
   *
   * @throws std::runtime_error If the query fails or the run request result
   *         cannot be retrieved.
   */
  IPC::Response_FunctionsT call_move_lb_run(const std::string& robot_model, const int orientation,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to clear its queued XB-type blend movement commands.
   *
   * Clears the internal list of XB-type blend move segments previously
   * accumulated via @c call_move_xb_add, so a new blend sequence can be
   * started from scratch.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        blend command list is cleared and completion is reported to the
   *        flow manager immediately (synchronous), unlike move commands
   *        whose completion is tracked asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the clear request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_move_xb_clr(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to add a segment to the queued XB-type blend movement sequence.
   *
   * Appends one segment to the internal blend list built up across
   * successive calls; the queued segments run together once
   * @c call_move_xb_run is invoked.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param speed Movement speed parameters.
   * @param blend_type Blend transition parameters. pnt_type is 0 (Percentage)
   *        or 1 (Distance); pnt_para is a percentage when pnt_type is 0, or
   *        millimeters when pnt_type is 1.
   * @param method Motion (movement) type option
   *        (0: Joint movement, 1: Linear movement).
   * @param flow_manager_args Optional PyFM step context. If provided, this
   *        segment is recorded for the blend sequence and completion is
   *        reported to the flow manager immediately (synchronous), unlike
   *        run commands whose completion is tracked asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the add request result.
   *
   * @throws std::runtime_error If the add request result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_move_xb_add(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                            const MoveSpeedArg& speed, const IPC::MoveInput_TypeT& blend_type,
                                            const int method,
                                            std::optional<std::vector<IPC::Move_Property_EntryT>> properties = std::nullopt,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to execute the queued XB-type blend movement sequence.
   *
   * Runs the sequence of segments previously accumulated via
   * @c call_move_xb_add.
   *
   * @param robot_model Name of the robot model.
   * @param running_mode Execution mode option for the blended run.
   *        (0: Velocity Blending, 1: Position Blending)
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the run request result.
   *
   * @throws std::runtime_error If the query fails or the run request result
   *         cannot be retrieved.
   */
  IPC::Response_FunctionsT call_move_xb_run(const std::string& robot_model, int running_mode,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to start continuous joint-space jog motion toward a target.
   *
   * Starts jog-style motion in joint space toward @p target; unlike a
   * regular move command, motion continues until stopped via
   * @c call_smoothjog_stop.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param ext_axis Optional external axis values.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the jog command is accepted.
   *
   * @return IPC::Response_FunctionsT containing the jog request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_smoothjog_j(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                            std::optional<std::vector<float>> ext_axis = std::nullopt,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to start continuous Cartesian-space jog motion toward a target.
   *
   * Starts jog-style motion in Cartesian space toward @p target; unlike a
   * regular move command, motion continues until stopped via
   * @c call_smoothjog_stop.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. tar_values is
   *        [x, y, z, rx, ry, rz, aa] for 7-axis models, or
   *        [x, y, z, rx, ry, rz] for 6-axis models (aa = ArmAngle).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the jog command is accepted.
   *
   * @return IPC::Response_FunctionsT containing the jog request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_smoothjog_l(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to decelerate and stop an active smooth-jog motion.
   *
   * Stops motion previously started by @c call_smoothjog_j / @c call_smoothjog_l.
   *
   * @param robot_model Name of the robot model.
   * @param stop_time Deceleration time, in seconds, used to bring the jog
   *        motion to a stop.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the stop command is accepted.
   *
   * @return IPC::Response_FunctionsT containing the stop request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT call_smoothjog_stop(const std::string& robot_model, const float stop_time,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to move a single joint-space tick step toward a target.
   *
   * Unlike @c call_smoothjog_j's continuous motion, this moves the cobot by
   * a single discrete tick increment in joint space toward @p target.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param speed Movement speed parameters.
   * @param ext_axis Optional external axis values.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the tick-jog request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_tickjog_j(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                          const MoveSpeedArg& speed,
                                          std::optional<std::vector<float>> ext_axis = std::nullopt,
                                          FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to move a single Cartesian-space tick step toward a target.
   *
   * Unlike @c call_smoothjog_l's continuous motion, this moves the cobot by
   * a single discrete tick increment in Cartesian space toward @p target.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. tar_values is
   *        [x, y, z, rx, ry, rz, aa] for 7-axis models, or
   *        [x, y, z, rx, ry, rz] for 6-axis models (aa = ArmAngle).
   * @param speed Movement speed parameters.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the tick-jog request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_tickjog_l(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                          const MoveSpeedArg& speed,
                                          FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to start an Approach-J joint-space movement.
   *
   * Sends the same underlying request shape as @c call_move_j; the two are
   * distinguished only by the calling context.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param speed Movement speed parameters.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the movement result is received.
   *
   * @return IPC::Response_FunctionsT containing the movement request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_approach_j(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                           const MoveSpeedArg& speed,
                                           FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to start an Approach-L Cartesian-space movement.
   *
   * Sends the same underlying request shape as @c call_move_l; the two are
   * distinguished only by the calling context.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. tar_values is
   *        [x, y, z, rx, ry, rz, aa] for 7-axis models, or
   *        [x, y, z, rx, ry, rz] for 6-axis models (aa = ArmAngle).
   * @param speed Movement speed parameters.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the movement result is received.
   *
   * @return IPC::Response_FunctionsT containing the movement request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_approach_l(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                           const MoveSpeedArg& speed,
                                           FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to stop an active Approach movement.
   *
   * Sends the same underlying request shape as @c call_smoothjog_stop; the
   * two are distinguished only by the calling context.
   *
   * @param robot_model Name of the robot model.
   * @param stop_time Deceleration time, in seconds, used to bring the
   *        movement to a stop.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the stop command is accepted.
   *
   * @return IPC::Response_FunctionsT containing the stop request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_approach_stop(const std::string& robot_model, const float stop_time,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to stop TCP weaving.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_tcp_weaving_off(const std::string& robot_model,
                                                FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to start TCP weaving on the current move.
   *
   * @param robot_model Name of the robot model.
   * @param type Weave pattern: 0 None, 1 Trapezoidal, 2 Sine wave, 3
   *        Polynomial, 4 Ellipse, 5 8-Shape, 6 Lissajous, 7 C-Shape, 8
   *        Diagonal.
   * @param axis_torch Torch direction axis.
   * @param axis_weave Weaving direction axis.
   * @param plane_option Weaving plane: 0 Present TCP Frame, 1 Follow
   *        base-trajectory.
   * @param user_rx User orientation Rx, in degrees.
   * @param user_ry User orientation Ry, in degrees.
   * @param user_rz User orientation Rz, in degrees.
   * @param magnitude_1 First weave magnitude, in mm.
   * @param magnitude_2 Second weave magnitude, in mm.
   * @param phase_1 First weave phase.
   * @param phase_2 Second weave phase.
   * @param time_1 Time schedule segment 1, in seconds.
   * @param time_2 Time schedule segment 2, in seconds.
   * @param time_3 Time schedule segment 3, in seconds.
   * @param time_4 Time schedule segment 4, in seconds.
   * @param time_5 Time schedule segment 5, in seconds.
   * @param time_6 Time schedule segment 6, in seconds.
   * @param time_7 Time schedule segment 7, in seconds.
   * @param time_8 Time schedule segment 8, in seconds.
   * @param scale_rate Weave scale multiplier (default 1).
   * @param offset_torch Offset along the torch direction, in mm.
   * @param offset_weave Offset along the weaving direction, in mm.
   * @param swing_ang Swing angle, in degrees.
   * @param distortion Distortion angle, in degrees.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_tcp_weaving_on(
      const std::string& robot_model, const int type, const int axis_torch, const int axis_weave,
      const int plane_option, const float user_rx, const float user_ry, const float user_rz, const float magnitude_1,
      const float magnitude_2, const float phase_1, const float phase_2, const float time_1, const float time_2,
      const float time_3, const float time_4, const float time_5, const float time_6, const float time_7,
      const float time_8, const float scale_rate, const float offset_torch, const float offset_weave,
      const float swing_ang, const float distortion, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to stop base conveyor tracking.
   *
   * @param robot_model Name of the robot model.
   * @param stop_time_sec Deceleration time, in seconds.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_base_conveyor_off(const std::string& robot_model, const float stop_time_sec,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to change the base conveyor's tracking speed.
   *
   * @param robot_model Name of the robot model.
   * @param conv_speed Conveyor speed, in mm/s.
   * @param conv_acc_time_sec Speed adjustment time, in seconds.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_base_conveyor_speed(const std::string& robot_model, const float conv_speed,
                                                    const float conv_acc_time_sec,
                                                    FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to start base conveyor tracking.
   *
   * @param robot_model Name of the robot model.
   * @param conv_type 0 No Conveyor, 1 Linear Conveyor, 2 Circular Conveyor.
   * @param conv_speed Conveyor speed, in mm/s.
   * @param conv_acc_time_sec Speed adjustment time, in seconds.
   * @param conv_ref_points Conveyor reference points; each point's values
   *        are rounded to 3 decimal places and padded/truncated to 7
   *        elements.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_base_conveyor_on(const std::string& robot_model, const int conv_type,
                                                 const float conv_speed, const float conv_acc_time_sec,
                                                 const std::vector<MoveTargetValuesArg>& conv_ref_points,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to move in a circle defined by a center and rotation axis.
   *
   * @param robot_model Name of the robot model.
   * @param center Rotation center. Resolved through the same relative-value
   *        calculation as @c get_relative_value before being sent.
   * @param axis Rotation axis. Resolved the same way as @p center.
   * @param angle Rotation angle, in degrees.
   * @param mode Orientation mode: 0 Sync, 1 Constant, 2 Intended.
   * @param speed Movement speed parameters (same concept as move-L speed).
   * @param radius_option Radius option: 0 None, 1 Rate per revolution, 2
   *        Size per revolution.
   * @param radius_para Radius parameter, interpreted according to
   *        @p radius_option.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, the center/axis
   *         relative-value calculation fails, or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_move_cir_axis(const std::string& robot_model, const SafeMoveTargetArg& center,
                                              const SafeMoveTargetArg& axis, const float angle, const int mode,
                                              std::optional<MoveSpeedArg> speed, const int radius_option,
                                              const float radius_para, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to move in a circle defined by a via point and a goal point.
   *
   * @param robot_model Name of the robot model.
   * @param via_p A point the circular path passes through. Resolved
   *        through the same relative-value calculation as
   *        @c get_relative_value before being sent.
   * @param goal_p The circular path's end point. Resolved the same way as
   *        @p via_p.
   * @param mode Orientation mode: 0 Sync, 1 Constant, 2 Intended.
   * @param speed Movement speed parameters (same concept as move-L speed).
   * @param radius_option Radius option: 0 None, 1 Rate per revolution, 2
   *        Size per revolution.
   * @param radius_para Radius parameter, interpreted according to
   *        @p radius_option.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, the via/goal point
   *         relative-value calculation fails, or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_move_cir_threepoint(const std::string& robot_model, const SafeMoveTargetArg& via_p,
                                                    const SafeMoveTargetArg& goal_p, const int mode,
                                                    std::optional<MoveSpeedArg> speed, const int radius_option,
                                                    const float radius_para,
                                                    FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to move to a home position.
   *
   * @param robot_model Name of the robot model.
   * @param home_type Home position: 0 Top-Level (Main) Project, 1
   *        Currently running (Sub) Project, 2 Zero Posture, or 3 + N
   *        (3-18) for Global Pin N (0-15, see @c save_globpin_parameter).
   * @param move_type Movement type used to reach the home position: 0
   *        Move-J, 1 Move-L.
   * @param speed Movement speed parameters.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_move_home(const std::string& robot_model, const int home_type, const int move_type,
                                          const MoveSpeedArg& speed,
                                          FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to stop arc sensing (weld seam tracking).
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_arc_sensing_off(const std::string& robot_model,
                                                FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to start arc sensing (weld seam tracking).
   *
   * @param robot_model Name of the robot model.
   * @param control_type Control mode: 0 RT (Full Cycle), 1 RT (Half
   *        Cycle), 2 Every Full Cycle, 3 Every Half Cycle.
   * @param data_grab_point Sensing data source: 0-3 for Analog Input 0-3.
   * @param data_grab_saturation_mode Sensing saturation mode: 0 No
   *        Saturation, 1 Saturation with Lower/Upper limit, 2 Saturation
   *        with hold.
   * @param data_grab_saturation_l Sensing saturation lower limit.
   * @param data_grab_saturation_u Sensing saturation upper limit.
   * @param data_grab_filter_hz Sensing data low-pass filter, in Hz
   *        (default 20).
   * @param data_grab_weighting_mode Sensing weighting mode: 0 Curve
   *        Weight (default), 1 Even Weight, 2 Linear Weight, 3 Reduced
   *        Linear Weight.
   * @param t1 T1 time, in seconds.
   * @param t2 T2 time, in seconds.
   * @param dep_target_method Depth-direction target method: 0 Desired
   *        Value, 1 Average between T1/T2 (default).
   * @param dep_target_a Depth-direction desired value (default 0),
   *        interpreted when @p dep_target_method is 0.
   * @param sid_target_method Weave-direction target method: 0 Desired
   *        Value (default), 1 Average between T1/T2.
   * @param sid_target_a Weave-direction desired value (default 0),
   *        interpreted when @p sid_target_method is 0.
   * @param gain_dep_p Depth-direction P gain (default 0).
   * @param gain_dep_i Depth-direction I gain (default 0).
   * @param gain_dep_a Depth-direction anti-windup gain (default 0).
   * @param max_dep_dev Depth-direction max deviation, in mm (default 10).
   * @param gain_sid_p Weave-direction P gain (default 0).
   * @param gain_sid_i Weave-direction I gain (default 0).
   * @param gain_sid_a Weave-direction anti-windup gain (default 0).
   * @param max_sid_dev Weave-direction max deviation, in mm (default 10).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_arc_sensing_on(const std::string& robot_model, const int control_type,
                                               const int data_grab_point, const int data_grab_saturation_mode,
                                               const float data_grab_saturation_l, const float data_grab_saturation_u,
                                               const float data_grab_filter_hz, const int data_grab_weighting_mode,
                                               const float t1, const float t2, const int dep_target_method,
                                               const float dep_target_a, const int sid_target_method,
                                               const float sid_target_a, const float gain_dep_p, const float gain_dep_i,
                                               const float gain_dep_a, const float max_dep_dev, const float gain_sid_p,
                                               const float gain_sid_i, const float gain_sid_a, const float max_sid_dev,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to change active arc sensing's target parameters.
   *
   * @param robot_model Name of the robot model.
   * @param t1 T1 time, in seconds.
   * @param t2 T2 time, in seconds.
   * @param dep_target_method Depth-direction target method: 0 Desired
   *        Value, 1 Average between T1/T2 (default).
   * @param dep_target_a Depth-direction desired value (default 0),
   *        interpreted when @p dep_target_method is 0.
   * @param sid_target_method Weave-direction target method: 0 Desired
   *        Value (default), 1 Average between T1/T2.
   * @param sid_target_a Weave-direction desired value (default 0),
   *        interpreted when @p sid_target_method is 0.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_arc_sensing_change_target(const std::string& robot_model, const float t1,
                                                          const float t2, const int dep_target_method,
                                                          const float dep_target_a, const int sid_target_method,
                                                          const float sid_target_a,
                                                          FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to change active arc sensing's gain parameters.
   *
   * @param robot_model Name of the robot model.
   * @param gain_dep_p Depth-direction P gain (default 0).
   * @param gain_dep_i Depth-direction I gain (default 0).
   * @param gain_dep_a Depth-direction anti-windup gain (default 0).
   * @param max_dep_dev Depth-direction max deviation, in mm (default 10).
   * @param gain_sid_p Weave-direction P gain (default 0).
   * @param gain_sid_i Weave-direction I gain (default 0).
   * @param gain_sid_a Weave-direction anti-windup gain (default 0).
   * @param max_sid_dev Weave-direction max deviation, in mm (default 10).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_arc_sensing_change_gain(const std::string& robot_model, const float gain_dep_p,
                                                        const float gain_dep_i, const float gain_dep_a,
                                                        const float max_dep_dev, const float gain_sid_p,
                                                        const float gain_sid_i, const float gain_sid_a,
                                                        const float max_sid_dev,
                                                        FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to stop admittance force control.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_admittance_force_off(const std::string& robot_model,
                                                     FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to start admittance force control.
   *
   * @param robot_model Name of the robot model.
   * @param frame Target frame: 0 Global, 1 Local, 2 User, 3 Target.
   * @param enable_x Enable X axis (0/1, default 0/unchecked).
   * @param enable_y Enable Y axis (0/1, default 0/unchecked).
   * @param enable_z Enable Z axis (0/1, default 0/unchecked).
   * @param enable_rx Enable Rx axis (0/1, default 0/unchecked).
   * @param enable_ry Enable Ry axis (0/1, default 0/unchecked).
   * @param enable_rz Enable Rz axis (0/1, default 0/unchecked).
   * @param target_x Target force/torque along X (default 0).
   * @param target_y Target force/torque along Y (default 0).
   * @param target_z Target force/torque along Z (default 0).
   * @param target_rx Target force/torque around Rx (default 0).
   * @param target_ry Target force/torque around Ry (default 0).
   * @param target_rz Target force/torque around Rz (default 0).
   * @param pgain_x X-axis P gain (default 1).
   * @param pgain_y Y-axis P gain (default 1).
   * @param pgain_z Z-axis P gain (default 1).
   * @param pgain_rx Rx-axis P gain (default 1).
   * @param pgain_ry Ry-axis P gain (default 1).
   * @param pgain_rz Rz-axis P gain (default 1).
   * @param igain_x X-axis I gain (default 0).
   * @param igain_y Y-axis I gain (default 0).
   * @param igain_z Z-axis I gain (default 0).
   * @param igain_rx Rx-axis I gain (default 0).
   * @param igain_ry Ry-axis I gain (default 0).
   * @param igain_rz Rz-axis I gain (default 0).
   * @param spdlim_x X-axis speed limit (default 0).
   * @param spdlim_y Y-axis speed limit (default 0).
   * @param spdlim_z Z-axis speed limit (default 0).
   * @param spdlim_rx Rx-axis speed limit (default 0).
   * @param spdlim_ry Ry-axis speed limit (default 0).
   * @param spdlim_rz Rz-axis speed limit (default 0).
   * @param max_dev_pos Position max deviation, in mm.
   * @param max_dev_rot Rotation max deviation, in degrees.
   * @param sensor_type Force/torque sensor source: 0 External F/T, 1
   *        Internal F/T, 2-5 Analog Input 0-3, 6 Custom.
   * @param sensor_cutoffhz Sensor low-pass filter, in Hz (default 20).
   * @param sensor_handle Sensor signal option: 0 Auto Nulling, 1 Raw
   *        Value.
   * @param contact_force Contact detection force, in N (default 5).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_admittance_force_on(
      const std::string& robot_model, const int frame, const int enable_x, const int enable_y, const int enable_z,
      const int enable_rx, const int enable_ry, const int enable_rz, const float target_x, const float target_y,
      const float target_z, const float target_rx, const float target_ry, const float target_rz, const float pgain_x,
      const float pgain_y, const float pgain_z, const float pgain_rx, const float pgain_ry, const float pgain_rz,
      const float igain_x, const float igain_y, const float igain_z, const float igain_rx, const float igain_ry,
      const float igain_rz, const float spdlim_x, const float spdlim_y, const float spdlim_z, const float spdlim_rx,
      const float spdlim_ry, const float spdlim_rz, const float max_dev_pos, const float max_dev_rot,
      const int sensor_type, const float sensor_cutoffhz, const int sensor_handle, const float contact_force,
      FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to change active admittance force control's parameters.
   *
   * Same fields as @c call_admittance_force_on except sensor/contact-force
   * settings, which cannot be changed while active.
   *
   * @param robot_model Name of the robot model.
   * @param frame Target frame: 0 Global, 1 Local, 2 User, 3 Target.
   * @param enable_x Enable X axis (0/1, default 0/unchecked).
   * @param enable_y Enable Y axis (0/1, default 0/unchecked).
   * @param enable_z Enable Z axis (0/1, default 0/unchecked).
   * @param enable_rx Enable Rx axis (0/1, default 0/unchecked).
   * @param enable_ry Enable Ry axis (0/1, default 0/unchecked).
   * @param enable_rz Enable Rz axis (0/1, default 0/unchecked).
   * @param target_x Target force/torque along X (default 0).
   * @param target_y Target force/torque along Y (default 0).
   * @param target_z Target force/torque along Z (default 0).
   * @param target_rx Target force/torque around Rx (default 0).
   * @param target_ry Target force/torque around Ry (default 0).
   * @param target_rz Target force/torque around Rz (default 0).
   * @param pgain_x X-axis P gain (default 1).
   * @param pgain_y Y-axis P gain (default 1).
   * @param pgain_z Z-axis P gain (default 1).
   * @param pgain_rx Rx-axis P gain (default 1).
   * @param pgain_ry Ry-axis P gain (default 1).
   * @param pgain_rz Rz-axis P gain (default 1).
   * @param igain_x X-axis I gain (default 0).
   * @param igain_y Y-axis I gain (default 0).
   * @param igain_z Z-axis I gain (default 0).
   * @param igain_rx Rx-axis I gain (default 0).
   * @param igain_ry Ry-axis I gain (default 0).
   * @param igain_rz Rz-axis I gain (default 0).
   * @param spdlim_x X-axis speed limit (default 0).
   * @param spdlim_y Y-axis speed limit (default 0).
   * @param spdlim_z Z-axis speed limit (default 0).
   * @param spdlim_rx Rx-axis speed limit (default 0).
   * @param spdlim_ry Ry-axis speed limit (default 0).
   * @param spdlim_rz Rz-axis speed limit (default 0).
   * @param max_dev_pos Position max deviation, in mm.
   * @param max_dev_rot Rotation max deviation, in degrees.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_admittance_force_change(
      const std::string& robot_model, const int frame, const int enable_x, const int enable_y, const int enable_z,
      const int enable_rx, const int enable_ry, const int enable_rz, const float target_x, const float target_y,
      const float target_z, const float target_rx, const float target_ry, const float target_rz, const float pgain_x,
      const float pgain_y, const float pgain_z, const float pgain_rx, const float pgain_ry, const float pgain_rz,
      const float igain_x, const float igain_y, const float igain_z, const float igain_rx, const float igain_ry,
      const float igain_rz, const float spdlim_x, const float spdlim_y, const float spdlim_z, const float spdlim_rx,
      const float spdlim_ry, const float spdlim_rz, const float max_dev_pos, const float max_dev_rot,
      FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to queue a joint-space servo target segment.
   *
   * Streaming/realtime joint control: each call queues one target segment
   * to move smoothly toward from wherever the previous segment left off,
   * rather than performing one discrete move. Intended to be called
   * repeatedly (e.g. once per control tick) to stream a trajectory.
   *
   * @param robot_model Name of the robot model.
   * @param target Target joint position and frame information.
   * @param t1 Time to move from the previous target to this one, in
   *        seconds (must be >= 0).
   * @param t2 Additional hold/settle time after reaching the target, in
   *        seconds (valid range (0, 5]).
   * @param gain Speed scaling gain applied to this segment (must be >
   *        0).
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p t1 / @p t2 / @p gain are
   *         out of their valid ranges, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_servo_j(const std::string& robot_model, IPC::MoveInput_TargetT target, const float t1,
                                        const float t2, const float gain, const float filter,
                                        FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Publishes a joint-space servo target segment without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_servo_j: queues one target
   * segment the same way, but publishes it (real-time priority, dropping
   * under congestion) instead of querying and does not report failures
   * back to the caller.
   *
   * @param robot_model Name of the robot model.
   * @param target Target joint position and frame information.
   * @param t1 Time to move from the previous target to this one, in
   *        seconds (must be >= 0).
   * @param t2 Additional hold/settle time after reaching the target, in
   *        seconds (valid range (0, 5]).
   * @param gain Speed scaling gain applied to this segment (must be >
   *        0).
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_servo_j(const std::string& robot_model, IPC::MoveInput_TargetT target, const float t1, const float t2,
                   const float gain, const float filter, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to queue a Cartesian-space servo target segment.
   *
   * Streaming/realtime Cartesian control: each call queues one target
   * segment to move smoothly toward from wherever the previous segment
   * left off, rather than performing one discrete move. Intended to be
   * called repeatedly (e.g. once per control tick) to stream a
   * trajectory.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param t1 Time to move from the previous target to this one, in
   *        seconds (must be >= 0).
   * @param t2 Additional hold/settle time after reaching the target, in
   *        seconds (must be > 0).
   * @param gain Speed scaling gain applied to this segment (must be >
   *        0).
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p t1 / @p t2 / @p gain are
   *         out of their valid ranges, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_servo_l(const std::string& robot_model, IPC::MoveInput_TargetT target, const float t1,
                                        const float t2, const float gain, const float filter,
                                        FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Publishes a Cartesian-space servo target segment without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_servo_l: queues one target
   * segment the same way, but publishes it (real-time priority, dropping
   * under congestion) instead of querying and does not report failures
   * back to the caller.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param t1 Time to move from the previous target to this one, in
   *        seconds (must be >= 0).
   * @param t2 Additional hold/settle time after reaching the target, in
   *        seconds (must be > 0).
   * @param gain Speed scaling gain applied to this segment (must be >
   *        0).
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_servo_l(const std::string& robot_model, IPC::MoveInput_TargetT target, const float t1, const float t2,
                   const float gain, const float filter, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to queue a joint-space online-tracking target.
   *
   * Streaming/realtime joint control, intended to be called repeatedly
   * (e.g. once per communication cycle) to keep feeding a moving target;
   * if only one target is queued when the robot's control loop next reads
   * it, older undelivered targets are discarded and the latest one wins.
   *
   * @param robot_model Name of the robot model.
   * @param target Target joint position and frame information.
   * @param speed Movement speed parameters — spd_vel_para/spd_acc_para act
   *        as the max velocity/acceleration for this segment and must be
   *        positive (not near zero).
   * @param timeout Communication-loss timeout, in seconds (range 0-10): if
   *        no new target is queued within this time after the last one was
   *        consumed, the motion is considered finished. Rule of thumb:
   *        (1 / your call rate) + a small margin — e.g. 0.02 for 100Hz,
   *        0.01 for 200Hz. Too small a value can trigger a false finish
   *        from ordinary communication jitter.
   * @param filter Output smoothing filter value.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, any input is
   *         non-finite or out of range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_online_j(const std::string& robot_model, const IPC::MoveInput_TargetT& target,
                                         const MoveSpeedArg& speed, const float timeout, const float filter,
                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Publishes a joint-space online-tracking target without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_online_j: queues the target the
   * same way, but publishes it (real-time priority, dropping under
   * congestion) instead of querying and does not report failures back to
   * the caller.
   *
   * @param robot_model Name of the robot model.
   * @param target Target joint position and frame information.
   * @param speed Movement speed parameters — spd_vel_para/spd_acc_para act
   *        as the max velocity/acceleration for this segment and must be
   *        positive (not near zero).
   * @param timeout Communication-loss timeout, in seconds (range 0-10);
   *        see @c call_online_j for the full explanation.
   * @param filter Output smoothing filter value.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_online_j(const std::string& robot_model, const IPC::MoveInput_TargetT& target,
                    const MoveSpeedArg& speed, const float timeout, const float filter,
                    FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to queue a Cartesian-space online-tracking target.
   *
   * Streaming/realtime Cartesian control, intended to be called repeatedly
   * (e.g. once per communication cycle) to keep feeding a moving target;
   * if only one target is queued when the robot's control loop next reads
   * it, older undelivered targets are discarded and the latest one wins.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param speed Movement speed parameters — spd_vel_para/spd_acc_para act
   *        as the max velocity/acceleration for this segment and must be
   *        positive (not near zero).
   * @param timeout Communication-loss timeout, in seconds (range 0-10): if
   *        no new target is queued within this time after the last one was
   *        consumed, the motion is considered finished. Rule of thumb:
   *        (1 / your call rate) + a small margin — e.g. 0.02 for 100Hz,
   *        0.01 for 200Hz. Too small a value can trigger a false finish
   *        from ordinary communication jitter.
   * @param filter Output smoothing filter value.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, any input is
   *         non-finite or out of range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_online_l(const std::string& robot_model, const IPC::MoveInput_TargetT& target,
                                         const MoveSpeedArg& speed, const float timeout, const float filter,
                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Publishes a Cartesian-space online-tracking target without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_online_l: queues the target the
   * same way, but publishes it (real-time priority, dropping under
   * congestion) instead of querying and does not report failures back to
   * the caller.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param speed Movement speed parameters — spd_vel_para/spd_acc_para act
   *        as the max velocity/acceleration for this segment and must be
   *        positive (not near zero).
   * @param timeout Communication-loss timeout, in seconds (range 0-10);
   *        see @c call_online_l for the full explanation.
   * @param filter Output smoothing filter value.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_online_l(const std::string& robot_model, const IPC::MoveInput_TargetT& target,
                    const MoveSpeedArg& speed, const float timeout, const float filter,
                    FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to queue a keyframe-timed joint-space target.
   *
   * Streaming/realtime joint control: each call queues one keyframe
   * (angle, velocity, and acceleration) at a given @p timestamp along a
   * continuous internal timeline, and the robot interpolates a polynomial
   * trajectory between consecutive keyframes. This differs from
   * @c call_servo_j, which specifies each segment as a relative duration
   * (@c t1) from wherever the previous segment left off — here @p
   * timestamp is a point on an absolute, ever-accumulating clock, so
   * keyframes must be queued with strictly increasing timestamps.
   *
   * @param robot_model Name of the robot model.
   * @param j_ang Target joint angles for this keyframe.
   * @param j_vel Target joint velocities for this keyframe. Ignored when
   *        @p polynomial is 2 (linear).
   * @param j_acc Target joint accelerations for this keyframe. Only used
   *        when @p polynomial is 1 (5th order).
   * @param polynomial Trajectory interpolation order between this
   *        keyframe and the previous one: 0 3rd order (uses @p j_ang and
   *        @p j_vel), 1 5th order (uses @p j_ang, @p j_vel, and @p
   *        j_acc), 2 1st order/linear (uses @p j_ang only).
   * @param timestamp Absolute time, in seconds on the internal motion
   *        timeline, at which this keyframe should be reached.
   * @param timeout Communication-loss timeout, in seconds: if no new
   *        keyframe is queued within this time after the last one was
   *        reached, the motion is considered finished.
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_timestamp_j(const std::string& robot_model, const IPC::MoveInput_TargetT& j_ang,
                                            const IPC::MoveInput_TargetT& j_vel, const IPC::MoveInput_TargetT& j_acc,
                                            const int polynomial, const float timestamp, const float timeout,
                                            const float filter, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Publishes a keyframe-timed joint-space target without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_timestamp_j: queues one
   * keyframe the same way, but publishes it (real-time priority, dropping
   * under congestion) instead of querying and does not report failures
   * back to the caller.
   *
   * @param robot_model Name of the robot model.
   * @param j_ang Target joint angles for this keyframe.
   * @param j_vel Target joint velocities for this keyframe. Ignored when
   *        @p polynomial is 2 (linear).
   * @param j_acc Target joint accelerations for this keyframe. Only used
   *        when @p polynomial is 1 (5th order).
   * @param polynomial Trajectory interpolation order between this
   *        keyframe and the previous one; see @c call_timestamp_j for the
   *        full explanation.
   * @param timestamp Absolute time, in seconds on the internal motion
   *        timeline, at which this keyframe should be reached.
   * @param timeout Communication-loss timeout, in seconds; see @c
   *        call_timestamp_j for the full explanation.
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_timestamp_j(const std::string& robot_model, const IPC::MoveInput_TargetT& j_ang,
                       const IPC::MoveInput_TargetT& j_vel, const IPC::MoveInput_TargetT& j_acc, const int polynomial,
                       const float timestamp, const float timeout, const float filter,
                       FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to start joint-space torque (compliance) control.
   *
   * Unlike the position-based servo/online/timestamp motions above, this
   * commands per-joint target torques directly rather than a target pose.
   * The robot must be idle (no other motion in progress) when this is
   * called, or the request is rejected.
   *
   * @param robot_model Name of the robot model.
   * @param target Target torque for each joint, in the same order as the
   *        robot's joints. Must have exactly as many elements as the
   *        robot has joints, or the firmware rejects the request.
   * @param time_out Maximum duration to hold this torque command, in
   *        seconds (valid range [0.0001, 10]).
   * @param option Which compensation terms are combined with @p target:
   *        0 Gravity + Friction feedforward + User target, 1 Gravity +
   *        User target, 2 Friction feedforward + User target, 3 User
   *        target only.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If @p target is not provided, the query
   *         fails, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_servo_t(const std::string& robot_model, std::optional<std::vector<float>> target,
                                        const float time_out, const int option,
                                        FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Publishes a joint-space torque (compliance) control target without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_servo_t: sends the same torque
   * command, but publishes it (real-time priority, dropping under
   * congestion) instead of querying and does not report failures back to
   * the caller.
   *
   * @param robot_model Name of the robot model.
   * @param target Target torque for each joint; see @c call_servo_t for
   *        the full explanation.
   * @param time_out Maximum duration to hold this torque command, in
   *        seconds (valid range [0.0001, 10]).
   * @param option Which compensation terms are combined with @p target;
   *        see @c call_servo_t for the full explanation.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   *
   * @throws std::runtime_error If @p target is not provided.
   */
  void pub_servo_t(const std::string& robot_model, std::optional<std::vector<float>> target, const float time_out,
                   const int option, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to start (or queue a target for) wrapper-layer Cartesian servo tracking.
   *
   * Streaming/realtime Cartesian control, similar in purpose to @c
   * call_servo_l, but runs in the firmware's separate "wrapper" motion
   * layer (the same layer used by @c call_tcp_weaving_on, @c
   * call_admittance_force_on, and @c call_base_conveyor_on) rather than
   * the main move sequencer. Each call queues one target to move smoothly
   * toward from wherever the previous target left off; intended to be
   * called repeatedly (e.g. once per control tick) to stream a
   * trajectory. Call @c call_wrapper_servo_l_off to stop tracking.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param time_gap Time to move from the previous target to this one, in
   *        seconds (valid range [0, 30]).
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p time_gap is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_wrapper_servo_l_on(const std::string& robot_model, const IPC::MoveInput_TargetT& target,
                                                   float time_gap, const float filter,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to stop wrapper-layer Cartesian servo tracking.
   *
   * Stops the tracking started by @c call_wrapper_servo_l_on.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_wrapper_servo_l_off(const std::string& robot_model,
                                                    FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Publishes a wrapper-layer Cartesian servo target without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_wrapper_servo_l_on: queues one
   * target the same way, but publishes it (real-time priority, dropping
   * under congestion) instead of querying and does not report failures
   * back to the caller.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param time_gap Time to move from the previous target to this one, in
   *        seconds (valid range [0, 30]).
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_wrapper_servo_l_on(const std::string& robot_model, const IPC::MoveInput_TargetT& target, float time_gap,
                              const float filter, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Publishes a stop request for wrapper-layer Cartesian servo tracking without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_wrapper_servo_l_off.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_wrapper_servo_l_off(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to block until the current motion finishes.
   *
   * Waits, on the robot side, until whatever motion is currently running
   * reaches completion (or no motion is running, in which case this
   * returns immediately).
   *
   * @param robot_model Name of the robot model.
   * @param timeout_sec Maximum time to wait, in seconds. A negative value
   *        (e.g. -1) waits indefinitely, with no timeout.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the response is received, provided its
   *        motion_result is 0; a nonzero motion_result raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_Move_WaitT whose motion_result field is 0 on
   *         success, -1 if the wait timed out, or another value giving
   *         the underlying motion's execution result code.
   *
   * @throws std::runtime_error If the query fails, the result cannot be
   *         retrieved, or (when @p flow_manager_args is not provided)
   *         motion_result is nonzero.
   */
  IPC::Response_Move_WaitT call_move_wait(const std::string& robot_model, float timeout_sec,
                                          FlowManagerArgsPtr flow_manager_args = nullptr);
};
