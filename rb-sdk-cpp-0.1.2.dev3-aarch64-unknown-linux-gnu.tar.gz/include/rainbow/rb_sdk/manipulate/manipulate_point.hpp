#pragma once

#include "base.hpp"
#include "rb_sdk_api.hpp"
#include "common_struct_generated.h"
#include "func_config_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "manipulate_config.hpp"
#include "manipulate_move.hpp"
#include "state_core_generated.h"

class RB_SDK_API RBManipulatePointSDK : public RBBaseSDK {
public:
  RBManipulatePointSDK() {}

  static std::string type_name() { return "RBManipulatePointSDK"; }

  /**
   * @brief Dispatches a single-point move request to the matching move
   *        function in RBManipulateMoveSDK, keyed by @p move_type.
   *
   * This is a thin routing layer: it builds the shared target and speed
   * structs from the flat parameter list below and forwards the call to
   * @c call_move_j, @c call_move_l, @c call_move_jb_add, @c call_move_lb_add,
   * or @c call_move_xb_add, matching @p move_type against the string
   * constants in @c MoveType (J, L, JB, LB, XB). See those functions'
   * docstrings for the full behavior of each move type (relative-move
   * handling, default speed, flow-manager completion semantics, etc.).
   *
   * @param robot_model Name of the robot model.
   * @param move_type Move type selector; must be one of the @c MoveType
   *        constants: "J" (joint-space), "L" (linear/Cartesian-space),
   *        "JB" (joint-blend add), "LB" (linear-blend add), or "XB"
   *        (XB-type blend add). Any other value is rejected.
   * @param tar_frame_reference_point Optional reference position used for
   *        relative movement calculation, forwarded as the
   *        reference_value argument to the J / L / JB / LB routes. Not
   *        used for the XB route.
   * @param pnt_para Blend parameter, interpreted according to
   *        @p pnt_type. Required (together with @p pnt_type) for the
   *        JB, LB, and XB routes; unused for J and L.
   * @param pnt_type Blend type: 0 (Percentage) or 1 (Distance); pnt_para
   *        is a percentage when pnt_type is 0, or millimeters when
   *        pnt_type is 1. Required (together with @p pnt_para) for the
   *        JB, LB, and XB routes; unused for J and L.
   * @param tar_frame Target coordinate frame: -1 Joint Space, 0 Global
   *        Frame, 1 Tool Frame, 2 User Frame, 3 Target Frame.
   * @param tar_unit Target coordinate unit: 0 mm/degree, 1 meter/radian
   *        (a third value, 2 for inch/degree, appears in one SDK-internal
   *        comment but is not confirmed elsewhere).
   * @param tar_values Target coordinate values, interpreted according to
   *        @p tar_frame and @p tar_unit.
   * @param spd_mode Speed mode: 0 percentage-based, 1 absolute (physical)
   *        values.
   * @param spd_vel_para Speed parameter: a percentage when @p spd_mode is
   *        0, or mm/s (L-type) / degree/s (J-type) when @p spd_mode is 1.
   * @param spd_acc_para Acceleration parameter: a percentage when
   *        @p spd_mode is 0, or mm/s^2 (L-type) / degree/s^2 (J-type)
   *        when @p spd_mode is 1.
   * @param ext_axis Optional external axis values, forwarded to the J /
   *        L / JB / LB routes. Not used for the XB route.
   * @param method Blend method option, required for the XB route only;
   *        unused for J, L, JB, and LB.
   * @param tcp_num Tool slot number to activate before issuing the move,
   *        via @c set_toollist_num. -1 (default) leaves the currently
   *        active tool unchanged.
   * @param flow_manager_args Optional PyFM step context, forwarded
   *        unchanged to the underlying move function; see that
   *        function's docstring for its completion semantics.
   *
   * @return IPC::Response_FunctionsT containing the underlying move
   *         function's request result.
   *
   * @throws std::runtime_error If @p move_type is not one of the
   *         @c MoveType constants, or if @p pnt_para / @p pnt_type is
   *         missing for the JB, LB, or XB route.
   *
   * @note For the XB route, @p method is read via `.value()` without a
   *       null check; passing @c None for @p method while using "XB"
   *       raises a different, less descriptive error than the explicit
   *       checks used for @p pnt_para / @p pnt_type.
   */
  IPC::Response_FunctionsT
  set_point(std::string &robot_model, std::string_view move_type,
            std::optional<std::vector<float>> tar_frame_reference_point,
            std::optional<float> pnt_para, std::optional<int> pnt_type,
            int tar_frame, int tar_unit, std::vector<float> tar_values,
            int spd_mode, float spd_vel_para, float spd_acc_para,
            std::optional<std::vector<float>> ext_axis,
            std::optional<int> method,
            std::optional<std::vector<IPC::Move_Property_EntryT>> properties = std::nullopt,
            int tcp_num = -1,
            FlowManagerArgsPtr flow_manager_args = nullptr);

private:
  RBManipulateMoveSDK _move_sdk = RBManipulateMoveSDK();
  RBManipulateConfigSDK _config_sdk = RBManipulateConfigSDK();
};
