#pragma once

#include "base.hpp"
#include "rb_sdk_api.hpp"
#include "func_config_generated.h"
#include "func_servo_generated.h"
#include "state_core_generated.h"

class RB_SDK_API RBManipulateStateSDK : public RBBaseSDK {
 public:
  RBManipulateStateSDK() {}

  static std::string type_name() { return "RBManipulateStateSDK"; }

  /**
   * @brief Retrieves the latest published core state snapshot of the robot.
   *
   * Waits for and returns the most recent message on the robot's
   * state_core topic, which carries joint/Cartesian references and
   * encoder readings, tool and I/O state, motion status, and force/torque
   * data. This is the same topic that @c call_move_j and the other move
   * functions in RBManipulateMoveSDK subscribe to internally in order to
   * detect motion completion via @c motion_sub_index and
   * @c timestamp_usec_mono.
   *
   * @param robot_model Name of the robot model. A single, non-wildcard
   *        model name is required.
   *
   * @return IPC::State_CoreT containing the current state snapshot.
   *
   * @throws std::runtime_error If @p robot_model contains a wildcard
   *         (`*`) character.
   */
  IPC::State_CoreT state_core(const std::string& robot_model);

  /**
   * @brief Requests identification information from the robot.
   *
   * Queries the robot for its category, model name, firmware version, and
   * alias. @p robot_model may be a zenoh key-expression that matches more
   * than one robot (unlike @c state_core, which rejects wildcards); each
   * matching robot returns its own reply, so the result is a list with one
   * entry per robot instead of a single response.
   *
   * @param robot_model Name of the robot model. May be a key-expression
   *        matching multiple robots.
   * @param flow_manager_args Optional PyFM step context, accepted for API
   *        consistency with the other functions in this class; this
   *        function never reports completion through it (it always
   *        returns synchronously with the query result).
   *
   * @return List of IPC::Response_CallWhoamIT, one per robot that replied.
   *
   * @throws std::runtime_error If no robot replies before the timeout.
   */
  std::vector<IPC::Response_CallWhoamIT> call_whoami(const std::string& robot_model,
                                                     FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to turn its main power on or off.
   *
   * @p robot_model may be a zenoh key-expression that matches more than
   * one robot; each matching robot returns its own reply, so the result
   * is a list with one entry per robot instead of a single response.
   *
   * @param robot_model Name of the robot model. May be a key-expression
   *        matching multiple robots.
   * @param power_option Power state value. 0 = power off, 1 = power on
   *        (with the normal pre-power-on check), 2 = power on without
   *        that check (labeled "force on" in the operator UI). Any other
   *        value is treated as power off.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every matched robot has replied.
   *
   * @return List of IPC::Response_FunctionsT, one per robot that replied.
   *
   * @throws std::runtime_error If no robot replies before the timeout.
   */
  std::vector<IPC::Response_FunctionsT> call_powercontrol(const std::string& robot_model, const int power_option,
                                                          FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to turn its servo on.
   *
   * Every accepted value of @p servo_option turns the servo on; there is
   * no value that turns it off through this call (main power must be
   * turned off via @c call_powercontrol to de-energize the motors).
   *
   * @p robot_model may be a zenoh key-expression that matches more than
   * one robot; each matching robot returns its own reply, so the result
   * is a list with one entry per robot instead of a single response.
   *
   * @param robot_model Name of the robot model. May be a key-expression
   *        matching multiple robots.
   * @param servo_option Servo-on mode. 0 = basic servo-on, 1 = basic
   *        servo-on plus reference-on, 2 = emergency teaching (hand
   *        guiding) mode. Any other value is treated as 0.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every matched robot has replied.
   *
   * @return List of IPC::Response_FunctionsT, one per robot that replied.
   *
   * @throws std::runtime_error If no robot replies before the timeout.
   */
  std::vector<IPC::Response_FunctionsT> call_servocontrol(const std::string& robot_model, const int servo_option,
                                                          FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to switch between simulation and real
   *        operation reference.
   *
   * Turning the reference on requires the servo to already be fully on;
   * the request is rejected otherwise. When turned on, the robot's
   * internal motion reference is re-initialized from the current encoder
   * position of every joint.
   *
   * @p robot_model may be a zenoh key-expression that matches more than
   * one robot; each matching robot returns its own reply, so the result
   * is a list with one entry per robot instead of a single response.
   *
   * @param robot_model Name of the robot model. May be a key-expression
   *        matching multiple robots.
   * @param reference_option Robot operation reference value. 0 =
   *        Simulation (operates in simulation mode), 1 = Real (operates
   *        the actual robot).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every matched robot has replied.
   *
   * @return List of IPC::Response_FunctionsT, one per robot that replied.
   *
   * @throws std::runtime_error If no robot replies before the timeout.
   */
  std::vector<IPC::Response_FunctionsT> call_referencecontrol(const std::string& robot_model,
                                                              const int reference_option,
                                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Publishes a core state message on the robot's state_core topic.
   *
   * Publishes @p state_core to `{robot_model}/state_core`, the same topic
   * that @c state_core reads from and that @c call_move_j and the other
   * move functions in RBManipulateMoveSDK subscribe to for detecting
   * motion completion. On a live robot this topic is normally published
   * to periodically by the robot's own firmware; calling this against a
   * live robot's topic competes with that periodic publish.
   *
   * @param robot_model Name of the robot model.
   * @param state_core State snapshot to publish.
   */
  void publish_state_core(const std::string& robot_model, const IPC::State_CoreT& state_core);

  // ~RBManipulateStateSDK()
  // {
  //     std::cout << "[" << type_name() << "] destroyed" << std::endl;
  // }
};
