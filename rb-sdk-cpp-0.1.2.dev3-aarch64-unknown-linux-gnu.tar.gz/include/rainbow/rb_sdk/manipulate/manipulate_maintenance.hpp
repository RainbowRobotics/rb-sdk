#pragma once

#include "base.hpp"
#include "rb_sdk_api.hpp"
#include "common_struct_generated.h"
#include "func_config_generated.h"
#include "func_maint_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "state_core_generated.h"

class RB_SDK_API RBManipulateMaintenanceSDK : public RBBaseSDK {
 public:
  RBManipulateMaintenanceSDK() {}

  static std::string type_name() { return "RBManipulateMaintenanceSDK"; }

  /**
   * @brief Requests the cobot to log/broadcast a joint board's info.
   *
   * This does not return the joint info through the SDK call itself — the
   * robot only reports success/failure here. The actual info is logged and
   * broadcast as a general message on the robot side (visible on the
   * teach-pendant/UI, not returned to this caller). Also powers the robot
   * on if it isn't already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         joint info payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_infos(std::string& robot_model, int board_no,
                                           FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's brake state.
   *
   * If @p brake_optioin is 1 (Open, Hard) or 2 (Weak), this powers the
   * robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to control. A negative value
   *        applies to every joint board.
   * @param brake_optioin Brake option: 0 (Close), 1 (Open, Hard), 2 (Weak),
   *        or 3 (Close only). (Parameter name matches the underlying wire
   *        field's spelling, including its typo.)
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_brake(std::string& robot_model, int board_no, int brake_optioin,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to zero a joint board's encoder.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to zero. A negative value applies
   *        to every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_encoder_zero(std::string& robot_model, int board_no,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to run a joint board's current-sensor calibration procedure.
   *
   * This is a multi-stage physical calibration, not an instant reset:
   * cycles the brake and runs DQ-axis alignment (3 tries), DQ save (2
   * tries), and current nulling (2 tries), with real delays between steps.
   * Takes on the order of several seconds per joint. Powers the robot on
   * first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to calibrate. A negative value
   *        applies to every joint board (multiplying the total time).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_sensor_reset(std::string& robot_model, int board_no,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's current-loop gains.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param pgain Proportional gain of the current control loop.
   * @param igain Integral gain of the current control loop.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_gain_cur(std::string& robot_model, int board_no, int pgain, int igain,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's position-loop gains.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param pgain Proportional gain of the position control loop.
   * @param igain Integral gain of the position control loop.
   * @param dgain Derivative gain of the position control loop.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_gain_pos(std::string& robot_model, int board_no, int pgain, int igain, int dgain,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to log/broadcast a joint board's current-loop gains.
   *
   * Counterpart to @c set_joint_gain_cur, but this does not return the
   * gain values through the SDK call — the robot only reports
   * success/failure here. The actual gains are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         gain payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_gain_cur(std::string& robot_model, int board_no,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to log/broadcast a joint board's position-loop gains.
   *
   * Counterpart to @c set_joint_gain_pos, but this does not return the
   * gain values through the SDK call — the robot only reports
   * success/failure here. The actual gains are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         gain payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_gain_pos(std::string& robot_model, int board_no,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to change a joint board's board-number assignment.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param channel_no Channel the joint board is on.
   * @param board_no Current joint board number. A negative value applies
   *        to every joint board.
   * @param target_no New board number to assign.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_bno_change(std::string& robot_model, int channel_no, int board_no, int target_no,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's big-error/input-error pulse thresholds.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param bigerr Big-error pulse threshold.
   * @param inputerr Input-error pulse threshold.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_big_input(std::string& robot_model, int board_no, int bigerr, int inputerr,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to log/broadcast a joint board's big-error/input-error pulse thresholds.
   *
   * Counterpart to @c set_joint_big_input, but this does not return the
   * threshold values through the SDK call — the robot only reports
   * success/failure here. The actual values are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         threshold payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_big_input(std::string& robot_model, int board_no,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's jam/overcurrent error thresholds.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param jam_current Jam-error current limit, in mA.
   * @param jam_time Jam-error duration threshold, in units of 0.1s.
   * @param ovr_current Overcurrent-error current limit, in mA.
   * @param ovr_time Overcurrent-error duration threshold, in units of 0.1s
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_jam_over(std::string& robot_model, int board_no, int jam_current, int jam_time,
                                              int ovr_current, int ovr_time,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to log/broadcast a joint board's jam/overcurrent error thresholds.
   *
   * Counterpart to @c set_joint_jam_over, but this does not return the
   * threshold values through the SDK call — the robot only reports
   * success/failure here. The actual values are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         threshold payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_jam_over(std::string& robot_model, int board_no,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @defgroup Joint Origin Calibration Origin Calibration Functions
   * @brief Functions for calibrating the robot's origin (base/world reference frame).
   *
   * Typical workflow:
   *   1. @c call_origin_calib_add    — Add one or more joint/TCP pose samples.
   *   2. @c call_origin_calib_run    — Compute calibration from the added samples.
   *   3. @c call_origin_calib_reflect — Commit (apply) the computed calibration,
   *                                     requires a password for authorization.
   *
   * @c call_origin_calib_clr can be called at any point to clear existing
   * calibration data (e.g. to restart the workflow from scratch).
   *
   * All functions in this group only report success/failure through the SDK
   * call; no calibration data itself is returned to the caller.
   * @{
   */

  /**
   * @brief Requests the cobot to clear its origin calibration data.
   *
   * Sends an origin-calibration clear request to the robot. The SDK call
   * only reports success/failure of the clear operation — no calibration
   * data is returned through this call.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         additional payload.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   * @ingroup Joint Origin Calibration
 */
  IPC::Response_FunctionsT call_origin_calib_clr(const std::string& robot_model,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to add a joint/TCP pose sample to its origin
   *        calibration data.
   *
   * Sends one calibration sample — a joint configuration together with the
   * corresponding TCP pose (position and orientation) — to be added to the
   * robot's origin calibration set. The SDK call only reports success/
   * failure of the add operation — no calibration data is returned through
   * this call.
   *
   * @param robot_model Name of the robot model.
   * @param joints Joint angles for this calibration sample.
   * @param tcp_x TCP position, X component.
   * @param tcp_y TCP position, Y component.
   * @param tcp_z TCP position, Z component.
   * @param tcp_rx TCP orientation, X-axis rotation component.
   * @param tcp_ry TCP orientation, Y-axis rotation component.
   * @param tcp_rz TCP orientation, Z-axis rotation component.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         additional payload.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   * @ingroup Joint Origin Calibration
   */
  IPC::Response_FunctionsT call_origin_calib_add(const std::string& robot_model, std::vector<float> joints, float tcp_x,
                                                 float tcp_y, float tcp_z, float tcp_rx, float tcp_ry, float tcp_rz,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
    * @brief Requests the cobot to run origin calibration using the previously
    *        added sample data.
    *
    * Triggers the robot to compute/apply origin calibration from the samples
    * accumulated via @c call_origin_calib_add. The @p option parameter
    * selects the calibration mode/behavior (meaning is robot/firmware
    * defined). The SDK call only reports success/failure of the run
    * operation — no calibration result data is returned through this call.
    *
    * @param robot_model Name of the robot model.
    * @param option Calibration run option/mode selector. (0: Use Position Info,
    *                1: Use Position and Orientation)
    * @param flow_manager_args Optional PyFM step context. If provided,
    *        completion is reported to the flow manager immediately
    *        (synchronous) once the result is received.
    *
    * @return IPC::Response_FunctionsT containing only success/failure — no
    *         additional payload.
    *
    * @throws std::runtime_error If the query fails or the result cannot be
    *         retrieved.
    * @ingroup Joint Origin Calibration
  */
  IPC::Response_FunctionsT call_origin_calib_run(const std::string& robot_model, int option,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to reflect (apply/commit) the computed origin
   *        calibration results.
   *
   * Finalizes the origin calibration process by committing the results
   * produced via @c call_origin_calib_run to the robot. A password is
   * required to authorize this operation, since it permanently changes the
   * robot's origin calibration. The SDK call only reports success/failure —
   * no additional data is returned through this call.
   *
   * @param robot_model Name of the robot model.
   * @param password Authorization password required to commit the
   *        calibration change.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         additional payload.
   *
   * @throws std::runtime_error If the query fails, @p password is invalid,
   *         or the result cannot be retrieved.
   * @ingroup Joint Origin Calibration
   */
  IPC::Response_FunctionsT call_origin_calib_reflect(const std::string& robot_model, int password,
                                                     FlowManagerArgsPtr flow_manager_args = nullptr);

  /** @} */
};
