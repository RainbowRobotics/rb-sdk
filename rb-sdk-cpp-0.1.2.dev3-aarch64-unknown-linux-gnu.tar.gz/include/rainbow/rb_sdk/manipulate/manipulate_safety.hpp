#pragma once

#include "common_struct_generated.h"

#include "base.hpp"
#include "rb_sdk_api.hpp"
#include "func_safety_generated.h"

class RB_SDK_API RBManipulateSafetySDK : public RBBaseSDK {
 public:
  RBManipulateSafetySDK() {}

  static std::string type_name() { return "RBManipulateSafetySDK"; }

  /**
   * @brief Requests the cobot's safety configuration entries.
   *
   * Pass a specific address in @p safety_addr to fetch a single entry, or
   * -1 to fetch all safety configuration entries. Reads go through the
   * same register table that @c save_safety_parameter writes to.
   *
   * @param robot_model Name of the robot model.
   * @param safety_addr Safety config register address to query, or -1 to
   *        request all entries.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_CallConfigSafetyT containing parallel
   *         list_name/list_addr/list_value arrays: the name, address, and
   *         value of each matching safety configuration entry.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_CallConfigSafetyT call_config_safety(const std::string& robot_model, const int safety_addr,
                                                     FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a safety configuration parameter.
   *
   * Writes @p target_value to the safety configuration register at
   * @p target_addr — the write counterpart to @c call_config_safety's read.
   * The firmware writes the value out over RS485 and, once acknowledged,
   * persists it into the safety register table immediately (no separate
   * commit step).
   *
   * @param robot_model Name of the robot model.
   * @param target_addr Safety config register address to write. The
   *        firmware rejects addresses at or beyond the total number of
   *        safety registers.
   * @param target_value Value to write to that address.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_safety_parameter(std::string& robot_model, int target_addr, int target_value,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);
};
