#pragma once

#include "common_struct_generated.h"

#include "base.hpp"
#include "rb_sdk_api.hpp"
#include "func_flage_generated.h"

class RB_SDK_API RBManipulateFlangeSDK : public RBBaseSDK {
 public:
  RBManipulateFlangeSDK() {}

  static std::string type_name() { return "RBManipulateFlangeSDK"; }

  /**
   * @brief Saves the tool number to be automatically mounted on the
            flange at boot-up.
   *
   * Configures which tool (from the saved tool list) is automatically
   * mounted on the flange when the controller boots up.
   *
   * @param robot_model Name of the robot model.
   * @param tool_num Tool number to mount at boot-up (0~7).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the result of the request.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_flange_bootup_mount_tool(const std::string& robot_model, const int tool_num,
                                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Saves the tool flange's boot-up DC power output voltage.
   *
   * Configures the DC voltage supplied through the tool flange when the
   * controller boots up.
   *
   * @param robot_model Name of the robot model.
   * @param voltage_value Boot-up DC voltage setting (0: 0V, 1: 12V, 2: 24V).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the result of the request.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_flange_bootup_dc_voltage(const std::string& robot_model, const int voltage_value,
                                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Saves the role/usage setting of the tool flange's direct
            teaching button.
   *
   * Configures whether the direct teaching button mounted on the tool
   * flange is enabled for use.
   *
   * @param robot_model Name of the robot model.
   * @param working_mode Usage setting (0: Use, 1: Not use).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the result of the request.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_flange_dt_button_role(const std::string& robot_model, const int working_mode,
                                                      FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Saves the usage setting of the tool flange's vibration sensor.
   *
   * Configures whether the vibration sensor mounted on the tool flange
   * is enabled for use.
   *
   * @param robot_model Name of the robot model.
   * @param working_mode Usage setting (0: Use, 1: Not use).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the result of the request.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_flange_vibration_sensor(const std::string& robot_model, const int working_mode,
                                                        FlowManagerArgsPtr flow_manager_args = nullptr);
};
