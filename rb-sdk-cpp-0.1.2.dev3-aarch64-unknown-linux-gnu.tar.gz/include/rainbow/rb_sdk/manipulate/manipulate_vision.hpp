#pragma once

// Vendor vision SDK API.

#include <optional>
#include <string>
#include <vector>

#include "base.hpp"
#include "common/value_validation.hpp"
#include "common_struct_generated.h"
#include "interface_payload_schema.hpp"
#include "pickit3d/constants.hpp"
#include "state_core_generated.h"

#include "manipulate_move.hpp"

/**
 * @brief Alarm callback used by vision interface calls.
 */
using AlarmFn = ::AlarmFn;

/**
 * @brief SDK for Mech-Mind, Photoneo, and Pickit3D vendor vision integrations.
 */
class RB_SDK_API RBManipulateVisionSDK : public RBBaseSDK {
 public:
  RBManipulateVisionSDK() {}

  ~RBManipulateVisionSDK() override;

  static std::string type_name() { return "RBManipulateVisionSDK"; }

  /**
   * @brief Disconnects vendor vision clients owned by this SDK.
   */
  void before_close() override;

 public:
  // -----------------------------------------------------------------------
  // MechMind
  // -----------------------------------------------------------------------

  /**
   * @brief Connects to a MechMind vision server and registers the client under @p module_name.
   *
   * Reads connection parameters from @p data (server_ip, server_port, an
   * optional timeout_sec defaulting to 10 seconds, an optional project_id
   * defaulting to 1) and opens a MechMind TCP connection, storing the
   * resulting client in the per-module connection registry so later calls
   * (trigger, get_poses, ...) can look it up by the same @p module_name.
   *
   * @param module_name Registry key for the connection, normally the PyFM
   *        task id resolved from @p flow_manager_args.
   * @param data Connect payload. Must contain server_ip and server_port;
   *        timeout_sec and project_id are optional.
   * @param flow_manager_args Optional PyFM step context. When provided,
   *        `flow_manager_args.done()` is called unconditionally once the
   *        connection attempt finishes, even if it failed.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p data's resolve_option is "ASK".
   *
   * @return Pointer to the connected @c mechmind::MechMindClient, owned by
   *         the SDK's connection registry (do not delete it). May be
   *         null, or non-null but not connected, if the attempt failed.
   *
   * @throws std::runtime_error If server_ip or server_port is missing, or
   *         if resolve_option is invalid; and, if resolve_option is
   *         "STOP", if the native connect call throws.
   *
   * @note If the native connect call fails without throwing (client
   *       non-null but not connected), that failure is only logged to
   *       stdout — it does not go through resolve_option's SKIP/STOP/ASK
   *       handling, unlike an actual vendor exception.
   *
   * @note Calling this again with the same @p module_name transparently
   *       disconnects the previous client for that module before opening
   *       the new connection.
   */
  mechmind::MechMindClient* execute_mechmind_connect(const std::string& module_name,
                                                     muscat::InterfaceMechMindPayloadT data,
                                                     FlowManagerArgsPtr flow_manager_args, AlarmFn alarm_fn);

  /**
   * @brief Triggers a MechMind capture + recognition and reads the detected poses in one round-trip.
   *
   * Standalone equivalent of function_code=0 ("Trigger And Get Poses") of
   * the MechMind READ interface. When @p position is "EYE_TO_HAND" the
   * camera is fixed off the robot, so no robot-pose correction is sent.
   * Otherwise (@p position is "EYE_IN_HEAD") the camera is mounted on the
   * robot, so the current TCP pose, joint positions and tool TCP offset
   * (all derived from @p state_core) are sent so the vendor can correct
   * for the arm's current pose.
   *
   * @param client Connected MechMind client, e.g. from @c execute_mechmind_connect.
   * @param project_id MechMind project id to trigger against.
   * @param position "EYE_TO_HAND" or "EYE_IN_HEAD" — selects whether
   *        robot-pose correction is sent, see above.
   * @param return_variable_name PyFM variable name that will receive the
   *        detected poses as a list of [x, y, z, rx, ry, rz] entries.
   * @param state_core Robot state snapshot used for pose correction.
   *        Required when @p position is not "EYE_TO_HAND".
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a MechMind
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        @p return_variable_name is written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return mechmind::VisionResponse with the detected poses. A
   *         default-constructed (empty) response if @p client is null,
   *         not connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error If @p position is not "EYE_TO_HAND" and
   *         @p state_core is not provided; and, under "STOP", if the
   *         native call throws.
   */
  mechmind::VisionResponse execute_mechmind_trigger_and_get_poses(
      mechmind::MechMindClient* client, int project_id, const std::string& position,
      const std::string& return_variable_name, std::optional<IPC::State_CoreT> state_core = std::nullopt,
      const std::string& resolve_option = "SKIP", FlowManagerArgsPtr flow_manager_args = nullptr,
      AlarmFn alarm_fn = nullptr);

  /**
   * @brief Reads the poses detected by the most recent MechMind trigger.
   *
   * Standalone equivalent of function_code=2 ("Get Poses") of the
   * MechMind READ interface. Unlike @c execute_mechmind_trigger_and_get_poses,
   * this does not trigger a new capture — it only re-reads the result of
   * whichever trigger (via @c execute_mechmind_trigger or
   * @c execute_mechmind_trigger_and_get_poses) ran most recently for
   * @p project_id.
   *
   * @param client Connected MechMind client.
   * @param project_id MechMind project id to read poses for.
   * @param return_variable_name PyFM variable name that will receive the
   *        detected poses as a list of [x, y, z, rx, ry, rz] entries.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a MechMind
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        @p return_variable_name is written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return mechmind::VisionResponse with the detected poses. A
   *         default-constructed (empty) response if @p client is null,
   *         not connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  mechmind::VisionResponse execute_mechmind_get_poses(mechmind::MechMindClient* client, int project_id,
                                                      const std::string& return_variable_name,
                                                      const std::string& resolve_option = "SKIP",
                                                      FlowManagerArgsPtr flow_manager_args = nullptr,
                                                      AlarmFn alarm_fn = nullptr);

  /**
   * @brief Triggers a MechMind capture + recognition without reading the resulting poses.
   *
   * Standalone equivalent of function_code=1 ("Trigger") of the MechMind
   * WRITE interface. Same @p position/robot-pose-correction rule as
   * @c execute_mechmind_trigger_and_get_poses: no robot pose is sent for
   * "EYE_TO_HAND", otherwise it is derived from @p stat_core. Call
   * @c execute_mechmind_get_poses afterwards to read the detection
   * result.
   *
   * @param client Connected MechMind client.
   * @param project_id MechMind project id to trigger against.
   * @param expected_count Expected number of objects to detect; passed
   *        through to the native trigger call.
   * @param position "EYE_TO_HAND" or "EYE_IN_HEAD" — selects whether
   *        robot-pose correction is sent.
   * @param stat_core Robot state snapshot used for pose correction.
   *        Required when @p position is not "EYE_TO_HAND".
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a MechMind
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK" (the native call
   *         itself always returns true when it doesn't throw).
   *
   * @throws std::runtime_error If @p position is not "EYE_TO_HAND" and
   *         @p stat_core is not provided; and, under "STOP", if the
   *         native call throws.
   */
  bool execute_mechmind_trigger(mechmind::MechMindClient* client, int project_id, int expected_count,
                                const std::string& position, std::optional<IPC::State_CoreT> stat_core = std::nullopt,
                                const std::string& resolve_option = "SKIP",
                                FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Switches the active MechMind recipe for a project.
   *
   * Standalone equivalent of function_code=3 ("Set Recipe") of the
   * MechMind WRITE interface.
   *
   * @param client Connected MechMind client.
   * @param project_id MechMind project id to switch the recipe on.
   * @param recipe_id Recipe id to activate.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a MechMind
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_mechmind_set_recipe(mechmind::MechMindClient* client, int project_id, int recipe_id,
                                   const std::string& resolve_option = "SKIP",
                                   FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  // -----------------------------------------------------------------------
  // Photoneo
  // -----------------------------------------------------------------------

  /**
   * @brief Connects to a Photoneo Bin Picking Studio (BPS) server and registers the client under @p module_name.
   *
   * Reads connection parameters from @p data (server_ip, server_port, an
   * optional timeout_sec defaulting to 10 seconds) and opens a Photoneo
   * TCP connection, storing the resulting client in the per-module
   * connection registry so later calls (initialize, scan, ...) can look
   * it up by the same @p module_name.
   *
   * @param module_name Registry key for the connection, normally the PyFM
   *        task id resolved from @p flow_manager_args.
   * @param data Connect payload. Must contain server_ip and server_port;
   *        timeout_sec is optional.
   * @param flow_manager_args Optional PyFM step context. When provided,
   *        `flow_manager_args.done()` is called unconditionally once the
   *        connection attempt finishes, even if it failed.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p data's resolve_option is "ASK".
   *
   * @return Pointer to the connected @c photoneo::PhotoneoClient, owned by
   *         the SDK's connection registry (do not delete it). May be
   *         null, or non-null but not connected, if the attempt failed.
   *
   * @throws std::runtime_error If server_ip or server_port is missing, or
   *         if resolve_option is invalid; and, if resolve_option is
   *         "STOP", if the native connect call throws.
   *
   * @note If the native connect call fails without throwing (client
   *       non-null but not connected), that failure is only logged to
   *       stdout — it does not go through resolve_option's SKIP/STOP/ASK
   *       handling, unlike an actual vendor exception.
   *
   * @note Calling this again with the same @p module_name transparently
   *       disconnects the previous client for that module before opening
   *       the new connection.
   */
  photoneo::PhotoneoClient* execute_photoneo_connect(const std::string& module_name,
                                                     muscat::InterfacePhotoneoPayloadT data,
                                                     FlowManagerArgsPtr flow_manager_args, AlarmFn alarm_fn);

  /**
   * @brief Initializes a Photoneo vision system with its scan-approach start/end joint targets.
   *
   * Standalone equivalent of function_code=0 ("Initialize") of the
   * Photoneo WRITE interface.
   *
   * @param client Connected Photoneo client.
   * @param vision_system_id Photoneo vision system id to initialize.
   *        0 uses the client's configured default.
   * @param start_joint Joint target dict with a required "tar_values"
   *        entry (6 joint angles in degrees; 7-axis input is reduced to 6
   *        by dropping the third element). If "input_method" is 1, the
   *        target actually used is instead the required "ref_point" entry
   *        (a resolved list of joint values, not a variable name — PyFM
   *        already substitutes it before this call); "tar_values" is
   *        still required to be present but is ignored in that case.
   * @param end_joint Same shape as @p start_joint, for the scan's end
   *        joint target.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::AckResponse. A default-constructed (error_code=0)
   *         response if @p client is null, not connected, or the call
   *         failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error If either joint dict is missing
   *         "tar_values" (or "ref_point" when input_method=1), or does
   *         not resolve to exactly 6 joint values; and, under "STOP", if
   *         the native call throws.
   */
  photoneo::AckResponse execute_photoneo_initialize(photoneo::PhotoneoClient* client, uint32_t vision_system_id,
                                                    muscat::PhotoneoJointTargetT start_joint,
                                                    muscat::PhotoneoJointTargetT end_joint,
                                                    const std::string& resolve_option = "SKIP",
                                                    FlowManagerArgsPtr flow_manager_args = nullptr,
                                                    AlarmFn alarm_fn = nullptr);

  /**
   * @brief Triggers a Photoneo scan at the robot's current pose.
   *
   * Standalone equivalent of function_code=1 ("Scan") of the Photoneo
   * WRITE interface. This is a Hand-Eye scan: the robot's current TCP
   * pose and tool TCP offset (both derived from @p stat_core) are sent so
   * the vendor can compute the flange pose the scan was taken from.
   *
   * @param client Connected Photoneo client.
   * @param vision_system_id Photoneo vision system id to scan with. 0
   *        uses the client's configured default.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::AckResponse. A default-constructed (error_code=0)
   *         response if @p client is null, not connected, or the call
   *         failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  photoneo::AckResponse execute_photoneo_scan(photoneo::PhotoneoClient* client, uint32_t vision_system_id,
                                              const IPC::State_CoreT& stat_core,
                                              const std::string& resolve_option = "SKIP",
                                              FlowManagerArgsPtr flow_manager_args = nullptr,
                                              AlarmFn alarm_fn = nullptr);

  /**
   * @brief Switches the active Photoneo solution.
   *
   * Standalone equivalent of function_code=4 ("Solution Change") of the
   * Photoneo WRITE interface.
   *
   * @param client Connected Photoneo client.
   * @param solution_id Solution id to switch to.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::AckResponse. A default-constructed (error_code=0)
   *         response if @p client is null, not connected, or the call
   *         failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  photoneo::AckResponse execute_photoneo_solution_change(photoneo::PhotoneoClient* client, uint32_t solution_id,
                                                         const std::string& resolve_option = "SKIP",
                                                         FlowManagerArgsPtr flow_manager_args = nullptr,
                                                         AlarmFn alarm_fn = nullptr);

  /**
   * @brief Starts the currently active Photoneo solution.
   *
   * Standalone equivalent of function_code=5 ("Solution Start") of the
   * Photoneo WRITE interface.
   *
   * @param client Connected Photoneo client.
   * @param solution_id Solution id to start.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::AckResponse. A default-constructed (error_code=0)
   *         response if @p client is null, not connected, or the call
   *         failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  photoneo::AckResponse execute_photoneo_solution_start(photoneo::PhotoneoClient* client, uint32_t solution_id,
                                                        const std::string& resolve_option = "SKIP",
                                                        FlowManagerArgsPtr flow_manager_args = nullptr,
                                                        AlarmFn alarm_fn = nullptr);

  /**
   * @brief Stops the currently running Photoneo solution.
   *
   * Standalone equivalent of function_code=6 ("Solution Stop") of the
   * Photoneo WRITE interface.
   *
   * @param client Connected Photoneo client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::AckResponse. A default-constructed (error_code=0)
   *         response if @p client is null, not connected, or the call
   *         failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  photoneo::AckResponse execute_photoneo_solution_stop(photoneo::PhotoneoClient* client,
                                                       const std::string& resolve_option = "SKIP",
                                                       FlowManagerArgsPtr flow_manager_args = nullptr,
                                                       AlarmFn alarm_fn = nullptr);

  /**
   * @brief Reads the object pose found by the most recent Photoneo scan.
   *
   * Standalone equivalent of function_code=2 ("Get Object Pose") of the
   * Photoneo READ interface. Requires a prior successful scan (via
   * @c execute_photoneo_scan) on @p vision_system_id.
   *
   * @param client Connected Photoneo client.
   * @param vision_system_id Photoneo vision system id to read the object
   *        pose from. 0 uses the client's configured default.
   * @param point_variable_name PyFM variable name that will receive the
   *        detected pose — a 6-element [x, y, z, rx, ry, rz] list for the
   *        Euler-family formalism, a 7-element
   *        [x, y, z, qx, qy, qz, qw] list for the Quaternion formalism, or
   *        None if no pose is available.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        @p point_variable_name is written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::ObjectPoseResponse with the detected pose. A
   *         default-constructed (no pose) response if @p client is null,
   *         not connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  photoneo::ObjectPoseResponse execute_photoneo_get_object_pose(photoneo::PhotoneoClient* client,
                                                                uint32_t vision_system_id,
                                                                const std::string& point_variable_name,
                                                                const std::string& resolve_option = "SKIP",
                                                                FlowManagerArgsPtr flow_manager_args = nullptr,
                                                                AlarmFn alarm_fn = nullptr);

  /**
   * @brief Reads the 4-stage pick trajectory computed by the most recent Photoneo scan.
   *
   * Standalone equivalent of function_code=3 ("Get Trajectory") of the
   * Photoneo READ interface. Requires a prior successful scan (via
   * @c execute_photoneo_scan) on @p vision_system_id. The trajectory is
   * split into exactly four stages — Start->Approach, Approach->Grasp,
   * Grasp->Deapproach, Deapproach->End — and each stage's joint waypoints
   * are written into its own PyFM variable.
   *
   * @param client Connected Photoneo client.
   * @param vision_system_id Photoneo vision system id to read the
   *        trajectory from. 0 uses the client's configured default.
   * @param trajectory_start_to_approach PyFM variable name that will
   *        receive the Start->Approach stage's waypoints, each a list of
   *        joint values.
   * @param trajectory_approach_to_grasp Same, for Approach->Grasp.
   * @param trajectory_grasp_to_deapproach Same, for Grasp->Deapproach.
   * @param trajectory_deapproach_to_end Same, for Deapproach->End.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success, the
   *        four stage variables above are written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::TrajectoryResponse with the raw response. A
   *         default-constructed (empty) response if @p client is null,
   *         not connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error If the response does not contain exactly
   *         4 trajectory segments; and, under "STOP", if the native call
   *         throws.
   *
   * @note Any gripper-action entries interleaved in the raw trajectory,
   *       and the AI Picking INFO values (target bounding-box
   *       dimensions), are not extracted by this function — only the 4
   *       segments' joint waypoints are exposed.
   */
  photoneo::TrajectoryResponse execute_photoneo_get_trajectory(
      photoneo::PhotoneoClient* client, uint32_t vision_system_id, const std::string& trajectory_start_to_approach,
      const std::string& trajectory_approach_to_grasp, const std::string& trajectory_grasp_to_deapproach,
      const std::string& trajectory_deapproach_to_end, const std::string& resolve_option = "SKIP",
      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Reads the id of the currently running Photoneo solution.
   *
   * Standalone equivalent of function_code=7 ("Solution Ask") of the
   * Photoneo READ interface.
   *
   * @param client Connected Photoneo client.
   * @param current_solution_id PyFM variable name that will receive the
   *        running solution's id, or None if none is running.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        @p current_solution_id is written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::SolutionResponse with the running solution id. A
   *         default-constructed (no id) response if @p client is null,
   *         not connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  photoneo::SolutionResponse execute_photoneo_solution_ask(photoneo::PhotoneoClient* client,
                                                           const std::string& current_solution_id,
                                                           const std::string& resolve_option = "SKIP",
                                                           FlowManagerArgsPtr flow_manager_args = nullptr,
                                                           AlarmFn alarm_fn = nullptr);

  /**
   * @brief Moves the robot through an already-resolved list of joint waypoints via a JB (joint-blend) move.
   *
   * Unlike the vendor-facing @c execute_photoneo_* functions above, this
   * does not talk to a Photoneo client at all — it drives the robot
   * itself through @p waypoints using
   * @c RBManipulateMoveSDK::call_move_jb_clr / call_move_jb_add /
   * call_move_jb_run (clear the pending blend queue, add each waypoint,
   * then run). It is the execution half of function_code=8 ("Move (JB)")
   * of the Photoneo interface; callers that already have a resolved
   * waypoint list (as opposed to a PyFM trajectory variable name) can
   * call it directly instead of going through @c vision().
   *
   * Each waypoint is converted from Photoneo's fixed 6-axis trajectory
   * format to the robot's actual @p robot_axis_count: reduced to 6 axes
   * if given more (dropping the third element), then, if the robot has 7
   * or more axes, expanded back to 7 by inserting 0 at index 2.
   *
   * @param waypoints Non-empty list of joint-value sequences (a Python
   *        list/tuple or numpy 2D array is accepted), in Photoneo's
   *        6-axis trajectory order.
   * @param robot_model Name of the robot model to move.
   * @param robot_axis_count Number of axes the target robot actually has;
   *        controls the 6-to-N axis expansion described above.
   * @param pnt_type Blend type for every waypoint: 0 = Percentage,
   *        1 = Distance.
   * @param pnt_para Blend parameter for every waypoint, in the unit
   *        implied by @p pnt_type (percent, or millimeters).
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called once after the final
   *        move request (call_move_jb_run) is accepted — not after the
   *        robot physically finishes the move.
   * @param alarm_fn Optional (title, content) callback fired, with title
   *        "Vision(Photoneo) Move Failed", if any of the clr/add/run
   *        requests reports a nonzero return value.
   *
   * @throws std::runtime_error If @p waypoints is empty, or if any
   *         clr/add/run request reports a nonzero return value (the
   *         first such failure stops the sequence immediately — later
   *         waypoints are never sent).
   *
   * @note Every waypoint is sent with a fixed tar_frame=-1 (Joint Space)
   *       and tar_unit=0 (degree) — this is not currently configurable
   *       through this function.
   *
   * @note Unlike the vendor-facing execute_* functions, there is no
   *       resolve_option here: any move failure always raises (and fires
   *       @p alarm_fn, if provided) rather than being SKIP/STOP/ASK-gated.
   */
  void execute_photoneo_move_waypoints(std::vector<std::vector<double>> waypoints, const std::string& robot_model,
                                       int robot_axis_count, int pnt_type, float pnt_para,
                                       FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  // -----------------------------------------------------------------------
  // Pickit3D
  // -----------------------------------------------------------------------

  /**
   * @brief Connects to a Pickit3D vision server and registers the client under @p module_name.
   *
   * Reads connection parameters from @p data (server_ip, server_port, an
   * optional timeout_sec defaulting to 10 seconds) and opens a Pickit3D
   * TCP connection, storing the resulting client in the per-module
   * connection registry so later calls (look_for_objects, configure, ...)
   * can look it up by the same @p module_name.
   *
   * @param module_name Registry key for the connection, normally the PyFM
   *        task id resolved from @p flow_manager_args.
   * @param data Connect payload. Must contain server_ip and server_port;
   *        timeout_sec is optional.
   * @param flow_manager_args Optional PyFM step context. When provided,
   *        `flow_manager_args.done()` is called unconditionally once the
   *        connection attempt finishes, even if it failed.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p data's resolve_option is "ASK".
   *
   * @return Pointer to the connected @c pickit3d::PickitClient, owned by
   *         the SDK's connection registry (do not delete it). May be
   *         null, or non-null but not connected, if the attempt failed.
   *
   * @throws std::runtime_error If server_ip or server_port is missing, or
   *         if resolve_option is invalid; and, if resolve_option is
   *         "STOP", if the native connect call throws.
   *
   * @note If the native connect call fails without throwing (client
   *       non-null but not connected), that failure is only logged to
   *       stdout — it does not go through resolve_option's SKIP/STOP/ASK
   *       handling, unlike an actual vendor exception.
   *
   * @note Calling this again with the same @p module_name transparently
   *       disconnects the previous client for that module before opening
   *       the new connection.
   */
  pickit3d::PickitClient* execute_pickit_connect(const std::string& module_name, muscat::InterfacePickitPayloadT data,
                                                 FlowManagerArgsPtr flow_manager_args, AlarmFn alarm_fn);

  /**
   * @brief Sends the robot's current TCP pose to Pickit3D for connection-liveness and 3D-view display.
   *
   * Standalone equivalent of function_code=0 ("Update Robot Pose") of the
   * Pickit WRITE interface. This is not required for detection accuracy
   * (the detection calls below carry their own robot pose) — it is used
   * by Pickit only for liveness detection and its web interface's 3D
   * view. It is safe to call periodically (Pickit's own guidance is
   * roughly 10 Hz) from a separate control loop.
   *
   * @param client Connected Pickit client.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true if the update either sent successfully or was skipped
   *         (see @note below); false only if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   *
   * @note The native call itself can return false when a write from
   *       another thread (e.g. a concurrent detection call) is already
   *       in progress and this update was skipped for the cycle. That
   *       return value is intentionally ignored here and never treated
   *       as a failure — only an actual exception is.
   */
  bool execute_pickit_update_robot_pose(pickit3d::PickitClient* client, const IPC::State_CoreT& stat_core,
                                        const std::string& resolve_option = "SKIP",
                                        FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Reads Pickit3D's current operating mode.
   *
   * Standalone equivalent of function_code=1 ("Check Mode") of the Pickit
   * READ interface.
   *
   * @param client Connected Pickit client.
   * @param pickit_mode PyFM variable name that will receive the raw mode
   *        code: 0 = Robot Mode, 1 = Idle Mode. This value is itself the
   *        information being requested, not a success/failure signal.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        @p pickit_mode is written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return The mode code (0 or 1). 0 if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK" — which is
   *         numerically indistinguishable from a genuine Robot Mode
   *         reading; check the client/exception path if that matters.
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  int execute_pickit_check_mode(pickit3d::PickitClient* client, const std::string& pickit_mode,
                                const std::string& resolve_option = "SKIP",
                                FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Shuts down the Pickit3D vision system.
   *
   * Standalone equivalent of function_code=2 ("Shutdown System") of the
   * Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_shutdown_system(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Locates the calibration plate for Pickit3D robot-camera calibration.
   *
   * Standalone equivalent of function_code=3 ("Find Calib Plate") of the
   * Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_find_calib_plate(pickit3d::PickitClient* client, const IPC::State_CoreT& stat_core,
                                       const std::string& resolve_option = "SKIP",
                                       FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Configures the Pickit3D robot-camera calibration procedure.
   *
   * Standalone equivalent of function_code=4 ("Configure Calib") of the
   * Pickit WRITE interface. The robot TCP pose and tool TCP offset
   * (derived from @p stat_core) are always sent, but are only meaningful
   * to Pickit for the SINGLE_POSE/MANUAL calibration methods — other
   * methods ignore them.
   *
   * @param client Connected Pickit client.
   * @param calib_method Pickit calibration method id — see @c
   *        pickit3d::CalibrationMethod (constants.hpp), payload[0] of the
   *        native RC_PICKIT_CONFIGURE_CALIB(11) command: 0=SINGLE_POSE,
   *        1=MULTI_POSE, 2=MANUAL, 3=DEFAULT. The caller (program step) may
   *        also pass the matching label string ("SINGLE_POSE",
   *        "MULTI_POSE", "MANUAL", "DEFAULT") — @c
   *        rb_vision_util::get_calib_method resolves it to this id before
   *        the call reaches here.
   * @param calib_camera_mount Camera mount id —
   *        0=FIXED (Eye-to-Hand — camera fixed in the cell, sees the whole
   *        scene) or 1=ON_ROBOT (Eye-in-Hand — camera mounted on the robot
   *        flange, moves with it). The caller may also pass "EYE_TO_HAND"/
   *        "FIXED" or "EYE_IN_HAND"/"ON_ROBOT" — @c
   *        rb_vision_util::get_calib_camera_mount resolves the label to
   *        this id. Must match how the camera is physically mounted on
   *        this cell; this is the same setting that decides whether
   *        detection uses @c execute_pickit_look_for_objects (FIXED) or @c
   *        execute_pickit_capture_image + @c execute_pickit_process_image
   *        (ON_ROBOT).
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws a
   *         Pickit exception.
   * @throws std::invalid_argument If @p calib_method is SINGLE_POSE and
   *         @p calib_camera_mount is ON_ROBOT (an unsupported
   *         combination). This is not a Pickit protocol exception, so it
   *         is not caught by the resolve_option handling above — it
   *         always propagates directly to the caller.
   */
  bool execute_pickit_configure_calib(pickit3d::PickitClient* client, int calib_method, int calib_camera_mount,
                                      const IPC::State_CoreT& stat_core, const std::string& resolve_option = "SKIP",
                                      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Computes the Pickit3D robot-camera calibration from the poses collected so far.
   *
   * Standalone equivalent of function_code=5 ("Compute Calib") of the
   * Pickit WRITE interface. Requires a prior @c execute_pickit_configure_calib.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_compute_calib(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                    FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Validates the most recently computed Pickit3D robot-camera calibration.
   *
   * Standalone equivalent of function_code=6 ("Validate Calib") of the
   * Pickit WRITE interface. Requires a prior @c execute_pickit_compute_calib.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_validate_calib(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                     FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Triggers a Pickit3D capture + object detection run.
   *
   * Standalone equivalent of function_code=7 ("Look For Objects") of the
   * Pickit READ interface. The robot TCP pose and tool TCP offset
   * (derived from @p stat_core) are sent so Pickit can locate the object
   * relative to the robot.
   *
   * @param client Connected Pickit client.
   * @param pick_point_name PyFM variable name that will receive the
   *        detected object's pose as a 6-element [x, y, z, rx, ry, rz]
   *        list.
   * @param remaining_count_name PyFM variable name that will receive the
   *        number of remaining detectable objects.
   * @param model_id_or_type_name PyFM variable name that will receive the
   *        detected object's model id or type.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success, the
   *        three variables above are written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return pickit3d::ObjectDetection with the detection result. A
   *         default-constructed (empty) result if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  pickit3d::ObjectDetection execute_pickit_look_for_objects(
      pickit3d::PickitClient* client, const std::string& pick_point_name, const std::string& remaining_count_name,
      const std::string& model_id_or_type_name, const IPC::State_CoreT& stat_core,
      const std::string& resolve_option = "SKIP", FlowManagerArgsPtr flow_manager_args = nullptr,
      AlarmFn alarm_fn = nullptr);

  /**
   * @brief Triggers a Pickit3D capture + object detection run, retrying internally on empty results.
   *
   * Standalone equivalent of function_code=8 ("Look For Objects With
   * Retries") of the Pickit READ interface. Same behavior as
   * @c execute_pickit_look_for_objects, except the native call retries up
   * to @p retry_count times internally when the result is NO_OBJECTS
   * (not when the search area is merely empty). Vendor documentation
   * does not specify a delay between retries or an overall timeout.
   *
   * @param client Connected Pickit client.
   * @param retry_count Maximum number of internal retries on NO_OBJECTS.
   * @param pick_point_name PyFM variable name that will receive the
   *        detected object's pose as a 6-element [x, y, z, rx, ry, rz]
   *        list.
   * @param remaining_count_name PyFM variable name that will receive the
   *        number of remaining detectable objects.
   * @param model_id_or_type_name PyFM variable name that will receive the
   *        detected object's model id or type.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success, the
   *        three variables above are written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return pickit3d::ObjectDetection with the detection result. A
   *         default-constructed (empty) result if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  pickit3d::ObjectDetection execute_pickit_look_for_objects_with_retries(
      pickit3d::PickitClient* client, int retry_count, const std::string& pick_point_name,
      const std::string& remaining_count_name, const std::string& model_id_or_type_name,
      const IPC::State_CoreT& stat_core, const std::string& resolve_option = "SKIP",
      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Reads the next detected object from the most recent Pickit3D detection run.
   *
   * Standalone equivalent of function_code=9 ("Next Object") of the
   * Pickit READ interface. Only valid after a prior
   * @c execute_pickit_look_for_objects or
   * @c execute_pickit_look_for_objects_with_retries call.
   *
   * @param client Connected Pickit client.
   * @param pick_point_name PyFM variable name that will receive the
   *        detected object's pose as a 6-element [x, y, z, rx, ry, rz]
   *        list.
   * @param remaining_count_name PyFM variable name that will receive the
   *        number of remaining detectable objects.
   * @param model_id_or_type_name PyFM variable name that will receive the
   *        detected object's model id or type.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success, the
   *        three variables above are written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return pickit3d::ObjectDetection with the detection result. A
   *         default-constructed (empty) result if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  pickit3d::ObjectDetection execute_pickit_next_object(
      pickit3d::PickitClient* client, const std::string& pick_point_name, const std::string& remaining_count_name,
      const std::string& model_id_or_type_name, const IPC::State_CoreT& stat_core,
      const std::string& resolve_option = "SKIP", FlowManagerArgsPtr flow_manager_args = nullptr,
      AlarmFn alarm_fn = nullptr);

  /**
   * @brief Captures an image for the Pickit3D Eye-in-Hand detection workflow.
   *
   * Standalone equivalent of function_code=10 ("Capture Image") of the
   * Pickit WRITE interface. Part of the Eye-in-Hand workflow: this only
   * captures the image and reports a status code — call
   * @c execute_pickit_process_image afterwards to actually run detection
   * on it. The robot TCP pose and tool TCP offset (derived from
   * @p stat_core) are sent, same as the other detection calls.
   *
   * @param client Connected Pickit client.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws —
   *         which, unlike the other Pickit detection calls, includes the
   *         image genuinely not having been captured (NO_IMAGE_CAPTURED
   *         means failure here, not "nothing found" as it does for
   *         @c execute_pickit_look_for_objects).
   */
  bool execute_pickit_capture_image(pickit3d::PickitClient* client, const IPC::State_CoreT& stat_core,
                                    const std::string& resolve_option = "SKIP",
                                    FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Runs Pickit3D object detection on the image captured by @c execute_pickit_capture_image.
   *
   * Standalone equivalent of function_code=11 ("Process Image") of the
   * Pickit READ interface. The second half of the Eye-in-Hand workflow —
   * this is where the actual detection result (object pose, dimensions,
   * remaining count) comes from, not from
   * @c execute_pickit_capture_image (which only reports a status code).
   * Takes no robot pose — the pose already sent to
   * @c execute_pickit_capture_image is what the detection is based on.
   *
   * @param client Connected Pickit client.
   * @param pick_point_name PyFM variable name that will receive the
   *        detected object's pose as a 6-element [x, y, z, rx, ry, rz]
   *        list.
   * @param remaining_count_name PyFM variable name that will receive the
   *        number of remaining detectable objects.
   * @param model_id_or_type_name PyFM variable name that will receive the
   *        detected object's model id or type.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success, the
   *        three variables above are written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return pickit3d::ObjectDetection with the detection result. A
   *         default-constructed (empty) result if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  pickit3d::ObjectDetection execute_pickit_process_image(
      pickit3d::PickitClient* client, const std::string& pick_point_name, const std::string& remaining_count_name,
      const std::string& model_id_or_type_name, const std::string& resolve_option = "SKIP",
      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Reads the gripper pose computed from the most recent Pickit3D detection.
   *
   * Standalone equivalent of function_code=12 ("Get Pick Point Data") of
   * the Pickit READ interface. Takes no robot pose of its own — the
   * client automatically reuses the detected object's pose cached by the
   * most recent successful @c execute_pickit_look_for_objects,
   * @c execute_pickit_look_for_objects_with_retries,
   * @c execute_pickit_next_object, or @c execute_pickit_process_image
   * call. The gripper pose is computed by composing that cached
   * detection pose with the response's offset pose; if no detection pose
   * is cached, the gripper pose is not available.
   *
   * @param client Connected Pickit client.
   * @param gripper_pose_name PyFM variable name that will receive the
   *        computed gripper pose as a 6-element [x, y, z, rx, ry, rz]
   *        list, or None if no cached detection pose is available.
   * @param reference_pick_point_id_name PyFM variable name that will
   *        receive the reference pick point id from the response.
   * @param stat_core Robot state snapshot the tool TCP offset is derived
   *        from (no TCP pose is sent — see above).
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success, the
   *        two variables above are written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return pickit3d::PickPointData with the pick point result. A
   *         default-constructed (empty) result if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  pickit3d::PickPointData execute_pickit_get_pick_point_data(pickit3d::PickitClient* client,
                                                             const std::string& gripper_pose_name,
                                                             const std::string& reference_pick_point_id_name,
                                                             const IPC::State_CoreT& stat_core,
                                                             const std::string& resolve_option = "SKIP",
                                                             FlowManagerArgsPtr flow_manager_args = nullptr,
                                                             AlarmFn alarm_fn = nullptr);

  /**
   * @brief Selects the active Pickit3D setup and product.
   *
   * Standalone equivalent of function_code=13 ("Configure") of the
   * Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param setup_id Setup id to activate. A negative value falls back to
   *        the client's configured default setup id.
   * @param product_id Product id to activate. A negative value falls
   *        back to the client's configured default product id.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_configure(pickit3d::PickitClient* client, int setup_id, int product_id,
                                const std::string& resolve_option = "SKIP",
                                FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Sets the expected cylinder dimensions for Pickit3D's cylinder detection model.
   *
   * Standalone equivalent of function_code=14 ("Set Cylinder Dim") of the
   * Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param cylinder_length Expected cylinder length, in millimeters.
   * @param cylinder_diameter Expected cylinder diameter, in millimeters.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_set_cylinder_dim(pickit3d::PickitClient* client, float cylinder_length, float cylinder_diameter,
                                       const std::string& resolve_option = "SKIP",
                                       FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Persists the currently active Pickit3D setup.
   *
   * Standalone equivalent of function_code=15 ("Save Active Setup") of
   * the Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_save_active_setup(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                        FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Persists the currently active Pickit3D product.
   *
   * Standalone equivalent of function_code=16 ("Save Active Product") of
   * the Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_save_active_product(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                          FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Rebuilds Pickit3D's background model from the current scene.
   *
   * Standalone equivalent of function_code=17 ("Build Background") of the
   * Pickit WRITE interface. Used to (re)learn what counts as empty
   * background so later detections can distinguish objects from it.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_build_background(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                       FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  /**
   * @brief Saves a diagnostic snapshot of Pickit3D's current scene.
   *
   * Standalone equivalent of function_code=18 ("Save Snapshot") of the
   * Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_save_snapshot(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                    FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

  // -----------------------------------------------------------------------
  // Top-level entry point
  // -----------------------------------------------------------------------

  /**
   * @brief Single dispatch entry point for all MechMind / Photoneo / Pickit3D vision interface calls.
   *
   * This is the function a PyFM vision-interface step actually calls;
   * every function above (connect / execute_* / trigger / etc.) is one of
   * this function's dispatch targets and can also be called directly by
   * SDK users who already hold a client and don't need the @p data-driven
   * dispatch. Which sub-function runs is chosen by @p option and, for
   * Photoneo/Pickit, a "function_code" field inside @p data (MechMind
   * instead uses a "type" field, see below):
   *
   * - "MECHMIND_INTERFACE": @p data["type"] selects "CONNECT"
   *   (@c execute_mechmind_connect), "READ" (function_code 0 = Trigger And
   *   Get Poses via @c execute_mechmind_trigger_and_get_poses, 2 = Get
   *   Poses via @c execute_mechmind_get_poses), or "WRITE" (function_code
   *   1 = Trigger via @c execute_mechmind_trigger, 3 = Set Recipe via
   *   @c execute_mechmind_set_recipe).
   * - "PHOTONEO_INTERFACE": @p data["function_code"] selects 99 = Create
   *   Connection (@c execute_photoneo_connect), 0/1/4/5/6 = Initialize /
   *   Scan / Solution Change / Solution Start / Solution Stop (WRITE),
   *   2/3/7 = Get Object Pose / Get Trajectory / Solution Ask (READ), or
   *   8 = Move (JB) through a stored trajectory
   *   (@c execute_photoneo_move_waypoints, resolving the trajectory by
   *   PyFM variable name or an inline waypoint list).
   * - "PICKIT_INTERFACE": @p data["function_code"] selects 99 = Create
   *   Connection (@c execute_pickit_connect), one of
   *   0/2/3/4/5/6/10/13/14/15/16/17/18 for the WRITE-family calls
   *   (update robot pose, shutdown, calibration, configure, capture
   *   image, ...), or one of 1/7/8/9/11/12 for the READ-family calls
   *   (check mode, look for objects (with retries), next object, process
   *   image, get pick point data).
   *
   * See each dispatch target's own docstring above for its payload
   * fields, return value and failure handling — this function only picks
   * which one runs and supplies it with the connection's client, plus a
   * robot state snapshot for calls that need pose correction.
   *
   * @param robot_model Name of the robot model whose state and vision
   *        connection this call applies to.
   * @param option Vision vendor: "MECHMIND_INTERFACE",
   *        "PHOTONEO_INTERFACE", or "PICKIT_INTERFACE".
   * @param data Interface payload; its shape depends on @p option and the
   *        selected type/function_code, see above.
   * @param alarm_fn Optional (title, content) callback used by any
   *        dispatch target whose resolve_option is "ASK".
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything — if omitted, returns immediately without
   *        dispatching to any target (unlike the individual execute_*
   *        functions below, which work standalone; call one of those
   *        directly instead of vision() if PyFM isn't in play). When
   *        provided, it's forwarded as-is to the selected dispatch target.
   *
   * @throws std::runtime_error If @p data["server_ip"] is falsy/missing
   *         (required for every call, not just CONNECT — see @note
   *         below), if @p option is not one of the three vendors, or if
   *         the selected type/function_code is not recognized; and
   *         whatever the selected dispatch target itself throws.
   *
   * @note @p data["server_ip"] is required and validated even for calls
   *       that reuse an already-open connection (READ/WRITE/etc.) and
   *       never use its value — this matches the Python original's
   *       behavior, not a porting oversight.
   *
   * @note If @p alarm_fn is not provided and @p flow_manager_args is,
   *       this function resolves it by looking up "rb_program_sdk.alarm"
   *       in the PyFM context's SDK function registry. If that lookup
   *       also fails, or @p flow_manager_args is not provided either, any
   *       "ASK" resolve_option downstream effectively behaves like
   *       "SKIP" (no alarm is fired, since @p alarm_fn stays null).
   */
  void vision(const std::string& robot_model, const std::string& option, muscat::VisionInterfacePayloadUnion data,
              AlarmFn alarm_fn = nullptr, FlowManagerArgsPtr flow_manager_args = nullptr);

 private:
  RBManipulateMoveSDK manipulate_move_sdk_;
};
