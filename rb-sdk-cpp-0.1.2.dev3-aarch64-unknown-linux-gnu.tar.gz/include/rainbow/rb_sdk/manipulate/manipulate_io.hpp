#pragma once

#include <functional>

#include "base.hpp"
#include "common_struct_generated.h"
#include "func_box_generated.h"
#include "func_config_generated.h"
#include "func_flage_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "rb_sdk_api.hpp"
#include "state_core_generated.h"

class RB_SDK_API RBManipulateIOSDK : public RBBaseSDK {
 public:
  RBManipulateIOSDK() {}

  /**
   * @brief Shared helper that applies a single-call IO function to a list of requests in order.
   *
   * Calls @p single_call_fn once per entry in @p request_list, in order,
   * passing @p flow_manager_args through to every one of those individual
   * calls as-is — so each call's own completion reporting (e.g.
   * @c flow_manager_args.done()) fires on every iteration, not just once.
   * After the loop, this itself also reports completion to
   * @p flow_manager_args once more. Fails fast: if any call returns no
   * result or a nonzero return_value, this throws immediately and does not
   * process the remaining entries.
   *
   * @param single_call_fn Callable taking (robot_model, one request from
   *        @p request_list, flow_manager_args) and returning
   *        IPC::Response_FunctionsT — typically one of this class's own
   *        single-item `call_*`/`save_*` methods.
   * @param robot_model Name of the robot model.
   * @param request_list Requests to apply in order.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every request has succeeded.
   * @param error_title Label used to prefix the exception message if any
   *        call in the list fails.
   *
   * @return IPC::Response_FunctionsT with return_value 0 if @p request_list
   *         was empty, otherwise the last successful call's result.
   *
   * @throws std::runtime_error If any call in @p request_list fails or
   *         returns a nonzero return_value.
   *
   * @note Body lives in manipulate_io.cpp, explicitly instantiated there for
   *       every @p Req actually used by this class's call_multiple_* methods
   *       (all calls are internal to this .cpp — Req is a closed set, so
   *       explicit instantiation is safe here unlike base.hpp's public
   *       FBSType templates, which external plugin code instantiates with
   *       arbitrary types and therefore cannot be moved out of the header).
   *       single_call_fn used to be a deduced `Func&&` template parameter,
   *       but every call site passes a distinct anonymous lambda type, so
   *       there was no fixed set of Func types to instantiate — it is
   *       type-erased to std::function here instead (one small heap
   *       allocation per call, negligible next to the zenoh round trip each
   *       single_call_fn performs).
   */
  template <typename Req>
  RB_SDK_LOCAL IPC::Response_FunctionsT call_multiple_common(
      std::function<IPC::Response_FunctionsT(const std::string&, const Req&, FlowManagerArgsPtr)> single_call_fn,
      const std::string& robot_model, const std::vector<Req>& request_list,
      FlowManagerArgsPtr flow_manager_args = nullptr, std::string error_title = "Multiple IO");

  /**
   * @brief Requests the cobot to set a side board digital output.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Side board digital output port number (0-15). A negative value
   *        applies @p desired_out to every side board digital output port.
   * @param desired_out Desired output value. A negative value is a no-op
   *        (the robot returns success without changing any output).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT call_side_dout(const std::string& robot_model, int port_num, int desired_out,
                                          FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to toggle a side board digital output.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Side board digital output port number (0-15). A negative value
   *        toggles every side board digital output port.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT call_side_dout_toggle(const std::string& robot_model, int port_num,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a range of side board digital outputs at once.
   *
   * Ports that have a special function assigned (see
   * @c save_side_dout_function) are rejected — this call only works on
   * plain digital output ports.
   *
   * @param robot_model Name of the robot model.
   * @param port_start First port number in the range (inclusive).
   * @param port_end Last port number in the range (inclusive), must be >= @p port_start.
   * @param desired_value Bit pattern of output values to apply across the
   *        port range. Let N = @p port_end - @p port_start + 1 (number of
   *        ports in the range); valid range is 0 to (2^N - 1), one bit per
   *        port.
   * @param direction_option Direction to map bits to ports: 0 applies bit
   *        0 to @p port_start (normal), 1 applies bit 0 to @p port_end (inverse).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT call_side_dout_bitcombination(const std::string& robot_model, int port_start, int port_end,
                                                         int desired_value, int direction_option,
                                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to pulse a side board digital output on a timing schedule.
   *
   * Ports that have a special function assigned (see
   * @c save_side_dout_function) are rejected — this call only works on
   * plain digital output ports.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Side board digital output port number (0-15).
   * @param block_mode 0 blocks until the pulse sequence finishes (up to a
   *        10-second internal wait) before returning; 1 returns
   *        immediately without waiting. Any value other than 1 is treated as 0.
   * @param direction Pulse waveform pattern across the 3 time segments: 0
   *        for off/on/off, 1 for on/off/on. Any value other than 1 is
   *        treated as 0.
   * @param time_1 First timing parameter, in seconds (valid range 0-3).
   * @param time_2 Second timing parameter, in seconds (valid range 0-3).
   * @param time_3 Third timing parameter, in seconds (valid range 0-3).
   *        Values below 0.003 are silently raised to 0.003 by the robot
   *        (unlike @p time_1 / @p time_2, which are used as given).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @note The query timeout may increase based on the sum of the
   *       requested pulse times (time_1, time_2, and time_3).
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT call_side_dout_pulse(const std::string& robot_model, int port_num, int block_mode,
                                                int direction, float time_1, float time_2, float time_3,
                                                FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set multiple side board digital outputs in order.
   *
   * Applies @c call_side_dout once per entry in @p side_dout_args, in
   * order; see @c call_multiple_common for the fail-fast/completion
   * semantics.
   *
   * @param robot_model Name of the robot model.
   * @param side_dout_args Side board digital output requests to apply in order.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every request has succeeded.
   *
   * @return IPC::Response_FunctionsT with return_value 0 if
   *         @p side_dout_args was empty, otherwise the last request's
   *         result.
   *
   * @throws std::runtime_error If any request in @p side_dout_args fails.
   */
  IPC::Response_FunctionsT call_multiple_side_dout(const std::string& robot_model,
                                                   std::vector<IPC::Request_SideDout_GeneralT> side_dout_args,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to toggle multiple side board digital outputs in order.
   *
   * Applies @c call_side_dout_toggle once per entry in @p side_dout_args,
   * in order; see @c call_multiple_common for the fail-fast/completion
   * semantics.
   *
   * @param robot_model Name of the robot model.
   * @param side_dout_args Side board digital output toggle requests to apply in
   *        order.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every request has succeeded.
   *
   * @return IPC::Response_FunctionsT with return_value 0 if
   *         @p side_dout_args was empty, otherwise the last request's
   *         result.
   *
   * @throws std::runtime_error If any request in @p side_dout_args fails.
   */
  IPC::Response_FunctionsT call_multiple_side_dout_toggle(const std::string& robot_model,
                                                          std::vector<IPC::Request_SideDout_ToggleT> side_dout_args,
                                                          FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to apply multiple side board digital output bit-combinations in order.
   *
   * Applies @c call_side_dout_bitcombination once per entry in
   * @p side_dout_args, in order; see @c call_multiple_common for the
   * fail-fast/completion semantics.
   *
   * @param robot_model Name of the robot model.
   * @param side_dout_args Side board digital output bit-combination requests to
   *        apply in order.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every request has succeeded.
   *
   * @return IPC::Response_FunctionsT with return_value 0 if
   *         @p side_dout_args was empty, otherwise the last request's
   *         result.
   *
   * @throws std::runtime_error If any request in @p side_dout_args fails.
   */
  IPC::Response_FunctionsT call_multiple_side_dout_bitcombination(
      const std::string& robot_model, std::vector<IPC::Request_SideDout_BitcombinationT> side_dout_args,
      FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to run multiple side board digital output pulses in order.
   *
   * Applies @c call_side_dout_pulse once per entry in @p side_dout_args, in
   * order; see @c call_multiple_common for the fail-fast/completion
   * semantics.
   *
   * @param robot_model Name of the robot model.
   * @param side_dout_args Side board digital output pulse requests to apply in
   *        order.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every request has succeeded.
   *
   * @return IPC::Response_FunctionsT with return_value 0 if
   *         @p side_dout_args was empty, otherwise the last request's
   *         result.
   *
   * @throws std::runtime_error If any request in @p side_dout_args fails.
   */
  IPC::Response_FunctionsT call_multiple_side_dout_pulse(const std::string& robot_model,
                                                         std::vector<IPC::Request_SideDout_PulseT> side_dout_args,
                                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a side board analog output.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Side board analog output port number (0-3). A negative value
   *        applies @p desired_voltage to every side analog output port.
   * @param desired_voltage Desired output voltage. Unlike
   *        @c call_flange_power, there is no bypass convention here — this
   *        value is applied as given.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT call_side_aout(const std::string& robot_model, int port_num, float desired_voltage,
                                          FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set multiple side board analog outputs in order.
   *
   * Applies @c call_side_aout once per entry in @p side_aout_args, in
   * order; see @c call_multiple_common for the fail-fast/completion
   * semantics.
   *
   * @param robot_model Name of the robot model.
   * @param side_aout_args Side board analog output requests to apply in order.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every request has succeeded.
   *
   * @return IPC::Response_FunctionsT with return_value 0 if
   *         @p side_aout_args was empty, otherwise the last request's
   *         result.
   *
   * @throws std::runtime_error If any request in @p side_aout_args fails.
   */
  IPC::Response_FunctionsT call_multiple_side_aout(const std::string& robot_model,
                                                   std::vector<IPC::Request_SideAout_GeneralT> side_aout_args,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set the flange (tool) power voltage.
   *
   * Only available while the robot is power-engaged.
   *
   * @param robot_model Name of the robot model.
   * @param desired_voltage Desired flange power voltage, in volts. Valid
   *        values are:
   *        - 0: power off
   *        - 12: 12V
   *        - 24: 24V
   *        - any negative value (e.g. -1): bypass — leaves the current
   *          voltage unchanged instead of setting a new one
   *        Any other positive value (e.g. 5) is rejected by the robot's
   *        firmware and the call fails (return_value nonzero) rather than
   *        being coerced to one of the values above.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero (the exception
   *         message includes the numeric return_value code).
   */
  IPC::Response_FunctionsT call_flange_power(const std::string& robot_model, int desired_voltage,
                                             FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a flange (tool) digital output.
   *
   * Only available while the robot is power-engaged.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Flange digital output port number (0-1). A negative value
   *        applies @p desired_out to every flange digital output port.
   * @param desired_out Desired output value: 1 is on, any other positive
   *        value is treated as 0 (off). A negative value bypasses —
   *        re-applies the port's current state instead of changing it.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT call_flange_dout(const std::string& robot_model, int port_num, int desired_out,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set multiple flange (tool) digital outputs in order.
   *
   * Applies @c call_flange_dout once per entry in @p flange_dout_args, in
   * order; see @c call_multiple_common for the fail-fast/completion
   * semantics.
   *
   * @param robot_model Name of the robot model.
   * @param flange_dout_args Flange digital output requests to apply in order.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every request has succeeded.
   *
   * @return IPC::Response_FunctionsT with return_value 0 if
   *         @p flange_dout_args was empty, otherwise the last request's
   *         result.
   *
   * @throws std::runtime_error If any request in @p flange_dout_args fails.
   */
  IPC::Response_FunctionsT call_multiple_flange_dout(const std::string& robot_model,
                                                     std::vector<IPC::Request_Flange_Digital_OutT> flange_dout_args,
                                                     FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set an extension board digital output.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Extension board digital output port number (0-15). A negative value
   *        applies @p desired_out to every extension board digital output port.
   * @param desired_out Desired output value. A negative value is a no-op
   *        (the robot returns success without changing any output).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT call_ext_dout(const std::string& robot_model, int port_num, int desired_out,
                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to toggle an extension board digital output.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Extension board digital output port number (0-15). A negative value
   *        toggles every extension board digital output port.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT call_ext_dout_toggle(const std::string& robot_model, int port_num,
                                                FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a range of extension board digital outputs at once.
   *
   * Ports that have a special function assigned (see
   * @c save_ext_dout_function) are rejected — this call only works on
   * plain digital output ports.
   *
   * @param robot_model Name of the robot model.
   * @param port_start First port number in the range (inclusive).
   * @param port_end Last port number in the range (inclusive), must be >= @p port_start.
   * @param desired_value Bit pattern of output values to apply across the
   *        port range. Let N = @p port_end - @p port_start + 1 (number of
   *        ports in the range); valid range is 0 to (2^N - 1), one bit per
   *        port.
   * @param direction_option Direction to map bits to ports: 0 applies bit
   *        0 to @p port_start (normal), 1 applies bit 0 to @p port_end (inverse).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT call_ext_dout_bitcombination(const std::string& robot_model, int port_start, int port_end,
                                                        int desired_value, int direction_option,
                                                        FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to pulse an extension board digital output on a timing schedule.
   *
   * Ports that have a special function assigned (see
   * @c save_ext_dout_function) are rejected — this call only works on
   * plain digital output ports.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Extension board digital output port number (0-15).
   * @param block_mode 0 blocks until the pulse sequence finishes (up to a
   *        10-second internal wait) before returning; 1 returns
   *        immediately without waiting. Any value other than 1 is treated
   *        as 0.
   * @param direction Pulse waveform pattern across the 3 time segments: 0
   *        for off/on/off, 1 for on/off/on. Any value other than 1 is
   *        treated as 0.
   * @param time_1 First timing parameter, in seconds (valid range 0-3).
   * @param time_2 Second timing parameter, in seconds (valid range 0-3).
   * @param time_3 Third timing parameter, in seconds (valid range 0-3).
   *        Values below 0.003 are silently raised to 0.003 by the robot
   *        (unlike @p time_1 / @p time_2, which are used as given).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
 * @note The query timeout may increase based on the sum of the
   *       requested pulse times (time_1, time_2, and time_3).
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT call_ext_dout_pulse(const std::string& robot_model, int port_num, int block_mode,
                                               int direction, float time_1, float time_2, float time_3,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set multiple extension board digital outputs in order.
   *
   * Applies @c call_ext_dout once per entry in @p ext_dout_args, in order;
   * see @c call_multiple_common for the fail-fast/completion semantics.
   *
   * @param robot_model Name of the robot model.
   * @param ext_dout_args Extension board digital output requests to apply in
   *        order.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every request has succeeded.
   *
   * @return IPC::Response_FunctionsT with return_value 0 if
   *         @p ext_dout_args was empty, otherwise the last request's
   *         result.
   *
   * @throws std::runtime_error If any request in @p ext_dout_args fails.
   */
  IPC::Response_FunctionsT call_multiple_ext_dout(const std::string& robot_model,
                                                  std::vector<IPC::Request_ExtDout_GeneralT> ext_dout_args,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to toggle multiple extension board digital outputs in order.
   *
   * Applies @c call_ext_dout_toggle once per entry in @p ext_dout_args, in
   * order; see @c call_multiple_common for the fail-fast/completion
   * semantics.
   *
   * @param robot_model Name of the robot model.
   * @param ext_dout_args Extension board digital output toggle requests to apply
   *        in order.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every request has succeeded.
   *
   * @return IPC::Response_FunctionsT with return_value 0 if
   *         @p ext_dout_args was empty, otherwise the last request's
   *         result.
   *
   * @throws std::runtime_error If any request in @p ext_dout_args fails.
   */
  IPC::Response_FunctionsT call_multiple_ext_dout_toggle(const std::string& robot_model,
                                                         std::vector<IPC::Request_ExtDout_ToggleT> ext_dout_args,
                                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to apply multiple extension board digital output bit-combinations in order.
   *
   * Applies @c call_ext_dout_bitcombination once per entry in
   * @p ext_dout_args, in order; see @c call_multiple_common for the
   * fail-fast/completion semantics.
   *
   * @param robot_model Name of the robot model.
   * @param ext_dout_args Extension board digital output bit-combination requests
   *        to apply in order.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every request has succeeded.
   *
   * @return IPC::Response_FunctionsT with return_value 0 if
   *         @p ext_dout_args was empty, otherwise the last request's
   *         result.
   *
   * @throws std::runtime_error If any request in @p ext_dout_args fails.
   */
  IPC::Response_FunctionsT call_multiple_ext_dout_bitcombination(
      const std::string& robot_model, std::vector<IPC::Request_ExtDout_BitcombinationT> ext_dout_args,
      FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to run multiple extension board digital output pulses in order.
   *
   * Applies @c call_ext_dout_pulse once per entry in @p ext_dout_args, in
   * order; see @c call_multiple_common for the fail-fast/completion
   * semantics.
   *
   * @param robot_model Name of the robot model.
   * @param ext_dout_args Extension board digital output pulse requests to apply
   *        in order.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every request has succeeded.
   *
   * @return IPC::Response_FunctionsT with return_value 0 if
   *         @p ext_dout_args was empty, otherwise the last request's
   *         result.
   *
   * @throws std::runtime_error If any request in @p ext_dout_args fails.
   */
  IPC::Response_FunctionsT call_multiple_ext_dout_pulse(const std::string& robot_model,
                                                        std::vector<IPC::Request_ExtDout_PulseT> ext_dout_args,
                                                        FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set an extension board analog output.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Extension board analog output port number (0-3). A negative value
   *        applies @p desired_voltage to every extension board analog output port.
   * @param desired_voltage Desired output voltage. Unlike
   *        @c call_flange_power, there is no bypass convention here — this
   *        value is applied as given.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT call_ext_aout(const std::string& robot_model, int port_num, float desired_voltage,
                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set multiple extension board analog outputs in order.
   *
   * Applies @c call_ext_aout once per entry in @p ext_aout_args, in order;
   * see @c call_multiple_common for the fail-fast/completion semantics.
   *
   * @param robot_model Name of the robot model.
   * @param ext_aout_args Extension board analog output requests to apply in
   *        order.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once every request has succeeded.
   *
   * @return IPC::Response_FunctionsT with return_value 0 if
   *         @p ext_aout_args was empty, otherwise the last request's
   *         result.
   *
   * @throws std::runtime_error If any request in @p ext_aout_args fails.
   */
  IPC::Response_FunctionsT call_multiple_ext_aout(const std::string& robot_model,
                                                  std::vector<IPC::Request_ExtAout_GeneralT> ext_aout_args,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a special-function assignment for a side board digital output port.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Side board digital output port number (0-15).
   * @param desired_function Special function to assign to the port
   *        (H=digital output signal is High, L=digital output signal is Low):
   *        - 0: None
   *        - 1: H=System Ready
   *        - 2: H=Heart Beat 1sec
   *        - 3: H=Bypass Dout #
   *        - 4: H=Is Power On State
   *        - 5: H=Is Robot Servo On State
   *        - 6: H=Is RealMode
   *        - 7: H=Is Real Mode + Idle
   *        - 8: H=Is Idle Move State
   *        - 9: H=Is Pause State
   *        - 10: H=Is Out Collision State
   *        - 11: H=Is Self Collision State
   *        - 12: H=Is Collision State (Out+Self)
   *        - 13: H=Is FreeDrive State
   *        - 14: H=Is Program Loaded
   *        - 15: H=Is Program Running
   *        - 16-31: H=Joints In-Position Pin 0-15 respectively
   *        Out-of-range values are rejected.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT save_side_dout_function(const std::string& robot_model, int port_num, int desired_function,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a special-function assignment for a side board digital input port.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Side board digital input port number (0-15).
   * @param desired_function Special function to assign to the port
   *        (R=triggered on rising edge, F=triggered on falling edge):
   *        - 0: None
   *        - 1: R=Power On
   *        - 2: R=Power Off
   *        - 3: R=Servo On Robot
   *        - 4: R=Servo On Robot / F=Power Off
   *        - 5: R=Switch to Real Mode
   *        - 6: R=Switch to Simulation Mode
   *        - 7: R=Stop Move
   *        - 8: R=Pause Move
   *        - 9: R=Resume from Pause
   *        - 10: R=Pause Move / F=Resume Move
   *        - 11: R=Resume from Collision
   *        - 12: R=FreeDrive On / F=FreeDrive Off
   *        - 13: R=Load Default Program
   *        - 14: R=Stop Program
   *        - 15: R=Start Program
   *        - 16: R=Pause Program
   *        - 17: R=Resume Program
   *        - 18: R=Pause Program / F=Resume Program
   *        - 19: R=TCP 50mm/s / F=Release
   *        - 20: R=TCP 100mm/s / F=Release
   *        - 21: R=TCP 250mm/s / F=Release
   *        - 22: R=TCP 500mm/s / F=Release
   *        - 23: R=SpeedBar 0% / F=Recover
   *        - 24: R=SpeedBar 10% / F=Recover
   *        - 25: R=SpeedBar 20% / F=Recover
   *        - 26: R=SpeedBar 50% / F=Recover
   *        Out-of-range values are rejected.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT save_side_din_function(const std::string& robot_model, int port_num, int desired_function,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a debounce filter count for a side board digital input port.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Side board digital input port number (0-15).
   * @param desired_count Input signal delay (debounce) count for the
   *        port, 0-200.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT save_side_din_filter(const std::string& robot_model, int port_num, int desired_count,
                                                FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a special-function assignment for an extension board digital output port.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Extension board digital output port number (0-15).
   * @param desired_function Special function to assign to the port; same
   *        0-31 function list as @c save_side_dout_function. Out-of-range
   *        values are rejected.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT save_ext_dout_function(const std::string& robot_model, int port_num, int desired_function,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a special-function assignment for an extension board digital input port.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Extension board digital input port number (0-15).
   * @param desired_function Special function to assign to the port; same
   *        0-18 function list as @c save_side_din_function. Out-of-range
   *        values are rejected.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT save_ext_din_function(const std::string& robot_model, int port_num, int desired_function,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a debounce filter count for an extension board digital input port.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Extension board digital input port number (0-15).
   * @param desired_count Input signal delay (debounce) count for the
   *        port, 0-200.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT save_ext_din_filter(const std::string& robot_model, int port_num, int desired_count,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a special-function assignment for a flange (tool) digital output port.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Flange digital output port number (0-1).
   * @param desired_function Special function to assign to the port; same
   *        0-31 function list as @c save_side_dout_function. Out-of-range
   *        values are rejected.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT save_flange_dout_function(const std::string& robot_model, int port_num, int desired_function,
                                                     FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a special-function assignment for a flange (tool) digital input port.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Flange digital input port number (0-5).
   * @param desired_function Special function to assign to the port; same
   *        0-18 function list as @c save_side_din_function. Out-of-range
   *        values are rejected.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT save_flange_din_function(const std::string& robot_model, int port_num, int desired_function,
                                                    FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a debounce filter count for a flange (tool) digital input port.
   *
   * @param robot_model Name of the robot model.
   * @param port_num Flange digital input port number (0-5).
   * @param desired_count Input signal delay (debounce) count for the
   *        port, 0-200.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT save_flange_din_filter(const std::string& robot_model, int port_num, int desired_count,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save a user script.
   *
   * @param robot_model Name of the robot model.
   * @param script_no User script slot number to save into, 0-15.
   * @param script_txt Script text/content to save.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT save_user_script(const std::string& robot_model, int script_no,
                                            const std::string& script_txt,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to save an "after action" assignment.
   *
   * @param robot_model Name of the robot model.
   * @param after_no After-action slot number, 0-15, one of:
   *        0 After System Boot,
   *        1 After Servo On,
   *        2 After Real Mode On,
   *        3 After Simul Mode On,
   *        4 After Arm DC Power On,
   *        5 After Arm DC Power Off,
   *        6 After Program Start,
   *        7 After Program Stop,
   *        8 After Direct Teaching On,
   *        9 After Direct Teaching Off,
   *        10 After Collision Occur,
   *        11 After Collision Reset,
   *        12 After Pause,
   *        13 After Resume,
   *        14 After Move Start,
   *        15 After Move Done.
   * @param after_option Action to run when the @p after_no event occurs:
   *        0 (Do nothing), or 1-16 to run User Script 0 through User
   *        Script 15 respectively.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT save_after_action(const std::string& robot_model, int after_no, int after_option,
                                             FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to configure its network settings.
   *
   * @param robot_model Name of the robot model.
   * @param static_vs_dhcp Network configuration mode (0: Static IP, 1: DHCP)
   * @param addr_0 IP address, 1st octet.
   * @param addr_1 IP address, 2nd octet.
   * @param addr_2 IP address, 3rd octet.
   * @param addr_3 IP address, 4th octet.
   * @param mask_0 Subnet mask, 1st octet.
   * @param mask_1 Subnet mask, 2nd octet.
   * @param mask_2 Subnet mask, 3rd octet.
   * @param mask_3 Subnet mask, 4th octet.
   * @param gate_0 Gateway address, 1st octet.
   * @param gate_1 Gateway address, 2nd octet.
   * @param gate_2 Gateway address, 3rd octet.
   * @param gate_3 Gateway address, 4th octet.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the save request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT save_network_parameter(const std::string& robot_model, int static_vs_dhcp, int addr_0,
                                                  int addr_1, int addr_2, int addr_3, int mask_0, int mask_1,
                                                  int mask_2, int mask_3, int gate_0, int gate_1, int gate_2,
                                                  int gate_3, FlowManagerArgsPtr flow_manager_args = nullptr);

  static std::string type_name() { return "RBManipulateIOSDK"; }
};
