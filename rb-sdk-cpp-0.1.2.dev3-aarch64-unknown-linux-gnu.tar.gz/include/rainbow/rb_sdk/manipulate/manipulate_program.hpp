#pragma once

#include "base.hpp"
#include "rb_sdk_api.hpp"
#include "common_struct_generated.h"
#include "func_config_generated.h"
#include "func_flow_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "func_set_generated.h"
#include "manipulate_config.hpp"
#include "manipulate_get_data.hpp"
#include "manipulate_io.hpp"
#include "manipulate_maintenance.hpp"
#include "manipulate_move.hpp"
#include "program_setting_args.hpp"
#include "state_core_generated.h"
#include "vibration_motion_arg.hpp"

struct SettingOptions {
  inline static constexpr std::string_view USER_FRAME_SELECTION = "USER_FRAME_SELECTION";
  inline static constexpr std::string_view OUT_COLLISION = "OUT_COLLISION";
  inline static constexpr std::string_view SELF_COLLISION = "SELF_COLLISION";
  inline static constexpr std::string_view FIXED_SPEED = "FIXED_SPEED";
  inline static constexpr std::string_view TARGET_SHIFT = "TARGET_SHIFT";
  inline static constexpr std::string_view SPEED_BAR = "SPEED_BAR";
  inline static constexpr std::string_view TIME_CONSTRAINT = "TIME_CONSTRAINT";
  inline static constexpr std::string_view ASCII_FUNCTION_CALL = "ASCII_FUNCTION_CALL";
  inline static constexpr std::string_view JOINT_IMPEDANCE = "JOINT_IMPEDANCE";
  inline static constexpr std::string_view FREE_DRIVE = "FREE_DRIVE";
  inline static constexpr std::string_view MASTER_MODE = "MASTER_MODE";
  inline static constexpr std::string_view USER_FRAME_6DOF = "USER_FRAME_6DOF";
  inline static constexpr std::string_view USER_FRAME_TCP = "USER_FRAME_TCP";
  inline static constexpr std::string_view USER_FRAME_3POINTS = "USER_FRAME_3POINTS";
  inline static constexpr std::string_view TARGET_SHIFT_LANDMARK = "TARGET_SHIFT_LANDMARK";
  inline static constexpr std::string_view PROGRAM_FLOW_MANAGE = "PROGRAM_FLOW_MANAGE";
  inline static constexpr std::string_view DIN_FUNCTION_MASK = "DIN_FUNCTION_MASK";
  inline static constexpr std::string_view DOUT_FUNCTION_MASK = "DOUT_FUNCTION_MASK";
  inline static constexpr std::string_view JACOBIAN_BASED_SPEED_CONTROL = "JACOBIAN_BASED_SPEED_CONTROL";
  inline static constexpr std::string_view SELF_VIBRATION_MODE = "SELF_VIBRATION_MODE";
  inline static constexpr std::string_view VIBRATION_MOTION_BASED = "VIBRATION_MOTION_BASED";
  inline static constexpr std::string_view EXTERNAL_AXIS_SYNC = "EXTERNAL_AXIS_SYNC";
  inline static constexpr std::string_view TCP_SPEED_BOUND = "TCP_SPEED_BOUND";
  inline static constexpr std::string_view MOVE_BREAK_BLOCK = "MOVE_BREAK_BLOCK";
  inline static constexpr std::string_view JOINT_REFERENCE_FILTER = "JOINT_REFERENCE_FILTER";
  inline static constexpr std::string_view SELF_COLL_DETECT_BLIND = "SELF_COLL_DETECT_BLIND";
  inline static constexpr std::string_view JOINT_ORIGIN_CALIBRATION = "JOINT_ORIGIN_CALIBRATION";
};

struct PinType {
  inline static constexpr std::string_view POINT = "POINT";
  inline static constexpr std::string_view JOINT = "JOINT";
};

struct Project {
  inline static constexpr std::string_view MAIN = "MAIN";
  inline static constexpr std::string_view SUB = "SUB";
};

enum class Posture { ZERO = 0, ONE = 1 };

class RB_SDK_API RBManipulateProgramSDK : public RBBaseSDK {
 public:
  RBManipulateProgramSDK() {}

  static std::string type_name() { return "RBManipulateProgramSDK"; }

  /**
   * @brief Requests the cobot to resume motion.
   *
   * Resumes motion previously paused via @c call_pause, so the in-progress
   * move/program can continue from where it left off.
   *
   * @param robot_model Name of the robot model.
   *
   * @return IPC::Response_FunctionsT containing the resume request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_resume(const std::string& robot_model);

  /**
   * @brief Requests the cobot to pause motion.
   *
   * Temporarily pauses in-progress motion; call @c call_resume afterward
   * to continue from where it was paused.
   *
   * @param robot_model Name of the robot model.
   *
   * @return IPC::Response_FunctionsT containing the pause request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_pause(const std::string& robot_model);

  /**
   * @brief Requests the cobot to stop motion entirely.
   *
   * Fully stops in-progress motion, as opposed to @c call_pause's temporary
   * pause (which can be continued via @c call_resume).
   *
   * @param robot_model Name of the robot model.
   *
   * @return IPC::Response_FunctionsT containing the halt request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_halt(const std::string& robot_model);

  /**
   * @brief Requests the cobot to run setup before a program starts.
   *
   * Called before a program begins execution: the firmware stops all
   * in-progress motion, clears special DIN/DOUT masks, speed saturation,
   * move-break, jacobian reflection mode, manual/landmark target shift,
   * fixed speed/time, and arc-sensing/pattern state, resetting the robot to
   * a clean state for the new program. Also registers the given system
   * variables to monitor while the program runs.
   *
   * @param robot_model Name of the robot model.
   * @param option Currently ignored by the firmware (received but cast
   *        away unused); no option values are assigned or documented
   *        anywhere in the request schema.
   * @param monitoring_name Names of the system variables to monitor.
   *
   * @return IPC::Response_FunctionsT containing the request result, or
   *         std::nullopt if the robot did not reply (or replied with an
   *         error) — that case is logged and swallowed so a silent robot
   *         does not block the program from starting.
   *
   * @note Does not throw on a Zenoh no-reply or peer error response. Other
   *       runtime errors still propagate because they usually indicate local
   *       decode/SDK bugs rather than a silent robot.
   *
   * @note @p monitoring_name is optional; when omitted it is sent as an empty
   *       list
   * @note The firmware requires the robot to be idle; if motion is still
   *       in progress it returns a warning result instead of performing the
   *       reset (this SDK call does not itself throw on that warning — only
   *       on a missing/failed response).
   */
  std::optional<IPC::Response_FunctionsT> call_program_before(const std::string& robot_model, const int option,
                                                              std::optional<std::vector<std::string>> monitoring_name);

  /**
   * @brief Requests the cobot to run teardown after a program ends.
   *
   * Called after a program finishes execution, pairing with
   * @c call_program_before which runs beforehand. The firmware resumes any
   * paused motion, stops all in-progress motion, restores the user-frame,
   * area, out/self-collision, and TCP parameters that were in effect before
   * the program ran, clears special DIN/DOUT masks, speed saturation,
   * move-break, jacobian reflection mode, manual/landmark target shift, and
   * fixed speed/time, and stops any running pattern.
   *
   * @param robot_model Name of the robot model.
   * @param option Currently ignored by the firmware (received but cast
   *        away unused); no option values are assigned or documented
   *        anywhere in the request schema.
   *
   * @return IPC::Response_FunctionsT containing the request result, or
   *         std::nullopt if the robot did not reply (or replied with an
   *         error) — that case is logged and swallowed so a silent robot
   *         does not block the program from finishing.
   *
   * @note Does not throw on a Zenoh no-reply or peer error response. Other
   *       runtime errors still propagate because they usually indicate local
   *       decode/SDK bugs rather than a silent robot.
   */
  std::optional<IPC::Response_FunctionsT> call_program_after(const std::string& robot_model, const int option);

  /**
   * @brief Captures the robot's current pose into PyFM local variables as the task's "begin" position.
   *
   * Only operates within a PyFM step context: if @p flow_manager_args is
   * not provided, this performs no action and immediately returns
   * std::nullopt. Reads the robot's current joint/Cartesian reference pose
   * from the {robot_model}/state_core topic and stores it under
   * MANIPULATE_BEGIN_JOINTS/MANIPULATE_BEGIN_CARTES in the PyFM local
   * variables; if the current step is not inside a sub-task (its PyFM
   * context has an empty sub_task_list), the same values are also stored
   * under MAIN_MANIPULATE_BEGIN_JOINTS/MAIN_MANIPULATE_BEGIN_CARTES. If
   * @p position / @p speed_ratio are given, they override
   * MANIPULATE_BEGIN_JOINTS / MANIPULATE_BEGIN_SPEED_RATIO (and, for a main
   * task, the corresponding MAIN_* variant) instead of the values read from
   * the robot. Finally registers the resulting joint pose with the robot as
   * its home joint info (@c set_home_joint_info: home_type 0 for a main
   * task, 1 otherwise) so @c position_home can later move back to it.
   *
   * @param robot_model Name of the robot model.
   * @param position Optional joint-angle override for
   *        MANIPULATE_BEGIN_JOINTS (and MAIN_MANIPULATE_BEGIN_JOINTS for a
   *        main task); if omitted, the joint pose read from state_core is
   *        used.
   * @param speed_ratio Optional override for MANIPULATE_BEGIN_SPEED_RATIO
   *        (and MAIN_MANIPULATE_BEGIN_SPEED_RATIO for a main task).
   * @param flow_manager_args PyFM step context. Required in practice —
   *        despite the optional type, omitting it makes this function a
   *        no-op that returns std::nullopt.
   *
   * @return IPC::Response_FunctionsT wrapping the set_home_joint_info
   *         result, or std::nullopt if @p flow_manager_args was not
   *         provided, or if reading state_core / setting the home joint
   *         info failed (in which case the begin-position local variables
   *         are instead reset to a seven-value zero pose).
   *
   * @note On failure (state_core read error or a failed
   *       set_home_joint_info result), MANIPULATE_BEGIN_JOINTS and
   *       MANIPULATE_BEGIN_CARTES are reset to seven zeros, the exception
   *       is caught and not re-thrown, and flow_manager_args.done() is
   *       still called so the PyFM step completes.
   */
  std::optional<IPC::Response_FunctionsT> set_begin(const std::string& robot_model,
                                                    std::optional<std::vector<float>> position,
                                                    std::optional<float> speed_ratio,
                                                    FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Moves the robot back to the begin position previously captured by @c set_begin.
   *
   * Reads the MANIPULATE_BEGIN_* / MAIN_MANIPULATE_BEGIN_* PyFM local
   * variables set by @c set_begin and issues a @c call_move_j or
   * @c call_move_l back to that pose, scaled by the speed ratio also
   * captured by @c set_begin. If none of those local variables were ever
   * set (i.e. @c set_begin never ran successfully in this task), or if the
   * specific pose requested by @p posture / @p move_type / @p project is
   * missing, this is a no-op that only calls flow_manager_args.done(). A
   * @p posture other than Posture::ZERO moves to the zero pose rather than
   * to a captured one.
   *
   * @param robot_model Name of the robot model.
   * @param move_type Move type: @c MoveType::J for a joint-space move back
   *        to MANIPULATE_BEGIN_JOINTS, or @c MoveType::L for a Cartesian
   *        move back to MANIPULATE_BEGIN_CARTES.
   * @param posture Posture::ZERO (Project Home Posture) reads the captured
   *        begin position and performs the move described above. Any other
   *        value (Posture::ONE = Joint Zero Posture) moves to a seven-value
   *        zero pose instead, without consulting the captured begin
   *        variables.
   * @param project Project::MAIN reads the MAIN_MANIPULATE_BEGIN_* /
   *        MAIN_MANIPULATE_BEGIN_SPEED_RATIO variables (the outermost
   *        task's begin position); Project::SUB reads the plain
   *        MANIPULATE_BEGIN_* / MANIPULATE_BEGIN_SPEED_RATIO variables
   *        (the current task's own begin position, main or sub).
   * @param spd_vel_ratio Velocity scale factor, multiplied by the speed
   *        ratio captured by @c set_begin (defaults to 1.0 if none was
   *        captured) to form the move's spd_vel_para.
   * @param spd_acc_ratio Acceleration scale factor, multiplied by the same
   *        captured speed ratio to form the move's spd_acc_para.
   * @param flow_manager_args PyFM step context. Required: passing nullptr
   *        raises std::runtime_error, matching the RuntimeError the legacy
   *        Python implementation raises for the same case.
   *
   * @throws std::runtime_error If @p flow_manager_args is not provided, or if
   *         the underlying @c call_move_j / @c call_move_l fails.
   */
  void position_home(const std::string& robot_model, std::string_view move_type, Posture posture,
                     std::string_view project, float spd_vel_ratio, float spd_acc_ratio,
                     FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Computes and stores a pin's target value into the PyFM execution context.
   *
   * Only operates within a PyFM step context: if @p flow_manager_args is
   * not provided, this performs no calculation and immediately returns
   * std::nullopt. When @p reference_target is given, the pin value is
   * computed relative to it (via the SDK's relative-value calculation);
   * otherwise it is computed as an absolute value. If @p flow_manager_args
   * carries a "variable_name" entry in its args, the resulting tar_values
   * are stored under that name in the PyFM local variables.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position/joint values and frame information used
   *        as the pin's (relative) target.
   * @param reference_target Optional reference values used for relative
   *        calculation; if omitted, an absolute value is computed instead.
   * @param pin_type Pin type: "POINT" for a Cartesian-space pin, or "JOINT"
   *        for a joint-space pin.
   * @param flow_manager_args PyFM step context. Required in practice —
   *        despite the optional type, omitting it makes this function a
   *        no-op that returns std::nullopt.
   *
   * @return IPC::Response_Get_ValueT containing the calculated value, or
   *         std::nullopt if @p flow_manager_args was not provided.
   *
   * @throws std::runtime_error If the relative or absolute value
   *         calculation fails.
   */
  std::optional<IPC::Response_Get_ValueT> set_pin_point_or_joint(std::string& robot_model, IPC::MoveInput_TargetT target,
                                                                std::optional<std::vector<float>> reference_target,
                                                                std::string_view pin_type,
                                                                FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Sets the tool (flange) power voltage and digital outputs.
   *
   * Only operates within a PyFM step context: if @p flow_manager_args is
   * not provided, this performs no action and immediately returns
   * std::nullopt.
   *
   * @param robot_model Name of the robot model.
   * @param tool_voltage Desired flange power voltage.
   * @param tool_dout_args Digital output arguments to apply to the flange.
   * @param flow_manager_args PyFM step context. Required in practice —
   *        despite the optional type, omitting it makes this function a
   *        no-op that returns std::nullopt. On success, completion is
   *        reported to the flow manager immediately (synchronous).
   *
   * @return IPC::Response_FunctionsT containing the digital-out request
   *         result, or std::nullopt if @p flow_manager_args was not
   *         provided.
   *
   * @throws std::runtime_error If either underlying flange call fails; the
   *         original message is wrapped as "Tool Out failed: ...". The
   *         failure must propagate — swallowing it would leave the PyFM
   *         step waiting on a done() that never comes.
   */
  std::optional<IPC::Response_FunctionsT> tool_out(const std::string& robot_model, const int tool_voltage,
                                                   std::vector<IPC::Request_Flange_Digital_OutT> tool_dout_args,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Dispatches to the appropriate robot configuration setter based on @p option.
   *
   * A single unified entry point for the many `set_*`/`call_*` configuration
   * calls on @c RBManipulateConfigSDK: pass one of the SettingOptions::*
   * constants as @p option, populate the single corresponding parameter
   * below, and leave every other parameter unset. Throws if the parameter
   * matching @p option is not provided, or if @p option matches none of the
   * known SettingOptions values.
   *
   * @param robot_model Name of the robot model.
   * @param option One of the SettingOptions::* constants selecting which
   *        setter to invoke.
   * @param out_collision Required when @p option is
   *        SettingOptions::OUT_COLLISION; forwarded to
   *        @c RBManipulateConfigSDK::set_out_collision_para.
   * @param self_collision Required when @p option is
   *        SettingOptions::SELF_COLLISION; forwarded to
   *        @c RBManipulateConfigSDK::set_self_collision_para.
   * @param user_frame_selection Required when @p option is
   *        SettingOptions::USER_FRAME_SELECTION; forwarded to
   *        @c RBManipulateConfigSDK::set_userframe_num. Both "user_frame_num"
   *        and the legacy program-args key "target_user_frame_num" are
   *        accepted; neither present throws rather than silently selecting
   *        user frame 0. That resolution runs in the dedicated type_caster
   *        at the pybind boundary (binding/glue/program_setting_caster.hpp);
   *        this function only sees the resolved @c UserFrameSelectionArg.
   * @param fixed_speed Required when @p option is
   *        SettingOptions::FIXED_SPEED; forwarded to
   *        @c RBManipulateConfigSDK::set_fixed_speed.
   * @param target_shift Required when @p option is
   *        SettingOptions::TARGET_SHIFT; forwarded to
   *        @c RBManipulateConfigSDK::set_shift.
   * @param speed_bar Required when @p option is SettingOptions::SPEED_BAR;
   *        forwarded to @c RBManipulateConfigSDK::call_speedbar.
   * @param time_constraint Required when @p option is
   *        SettingOptions::TIME_CONSTRAINT; forwarded to
   *        @c RBManipulateConfigSDK::set_timeconstraint.
   * @param ascii_function_call Required when @p option is
   *        SettingOptions::ASCII_FUNCTION_CALL; forwarded to
   *        @c RBManipulateConfigSDK::set_ascii_functioncall.
   * @param joint_impedance Required when @p option is
   *        SettingOptions::JOINT_IMPEDANCE; forwarded to
   *        @c RBManipulateConfigSDK::set_joint_impedance.
   * @param free_drive Required when @p option is
   *        SettingOptions::FREE_DRIVE; forwarded to
   *        @c RBManipulateConfigSDK::set_freedrive.
   * @param master_mode Required when @p option is
   *        SettingOptions::MASTER_MODE; forwarded to
   *        @c RBManipulateConfigSDK::set_master_mode.
   * @param user_frame_6dof Required when @p option is
   *        SettingOptions::USER_FRAME_6DOF; forwarded to
   *        @c RBManipulateConfigSDK::set_userframe_6dof.
   * @param user_frame_tcp Required when @p option is
   *        SettingOptions::USER_FRAME_TCP; forwarded to
   *        @c RBManipulateConfigSDK::set_userframe_tcp.
   * @param user_frame_3points Required when @p option is
   *        SettingOptions::USER_FRAME_3POINTS; forwarded to
   *        @c RBManipulateConfigSDK::set_userframe_3points.
   * @param target_shift_landmark Required when @p option is
   *        SettingOptions::TARGET_SHIFT_LANDMARK; the 6 reference/present
   *        points are rounded to 3 decimal places and padded to 7 values
   *        before being forwarded to
   *        @c RBManipulateConfigSDK::set_shift_landmark. Each point may be
   *        either a MoveInput_Target dict or, as legacy program args store
   *        them, a bare list of coordinates (taken as frame 0 / unit 0);
   *        that discrimination and the null check run in the dedicated
   *        type_caster at the pybind boundary
   *        (binding/glue/program_setting_caster.hpp), so this function only
   *        sees the resolved @c ShiftLandMarkArg.
   * @param program_flow_manage Required when @p option is
   *        SettingOptions::PROGRAM_FLOW_MANAGE; forwarded to
   *        @c RBManipulateConfigSDK::set_program_flow_manage.
   * @param din_function_mask Required when @p option is
   *        SettingOptions::DIN_FUNCTION_MASK; forwarded to
   *        @c RBManipulateConfigSDK::set_din_function_mask.
   * @param dout_function_mask Required when @p option is
   *        SettingOptions::DOUT_FUNCTION_MASK; forwarded to
   *        @c RBManipulateConfigSDK::set_dout_function_mask.
   * @param jacobian_based_speed_control Required when @p option is
   *        SettingOptions::JACOBIAN_BASED_SPEED_CONTROL; forwarded to
   *        @c RBManipulateConfigSDK::set_jacob_speed_mode.
   * @param self_vibration_mode Required when @p option is
   *        SettingOptions::SELF_VIBRATION_MODE; forwarded to
   *        @c RBManipulateConfigSDK::set_self_vibration_mode.
   * @param vibration_motion_based Required when @p option is
   *        SettingOptions::VIBRATION_MOTION_BASED. Passed from Python as a
   *        flat dict {"onoff": 1/0, "frame":, "x_mag":, ...}, matching the
   *        @c Request_Wrapper_VibrationMotion schema table and what the FE
   *        actually sends — not the wire request shape (@c
   *        Request_Wrapper_VibrationMotion_On / @c _Off, sent as two
   *        separate RPCs; "onoff" only selects which one to call). When
   *        onoff == 1, all 10 of frame/x_mag/y_mag/z_mag/x_freq/y_freq/
   *        z_freq/x_phase/y_phase/z_phase must be present (each parsed via
   *        @c rb_glue::to_int / @c to_double, tolerating string-typed
   *        values from loosely-typed program args) or the request is
   *        rejected — the auto dict-to-struct caster would otherwise
   *        silently fill missing fields with 0. That validation runs in
   *        the dedicated type_caster at the pybind boundary
   *        (binding/glue/vibration_motion_caster.hpp); this function only
   *        sees the resolved @c VibrationMotionBasedArg. Forwarded to
   *        @c RBManipulateConfigSDK::call_vibration_motion_on /
   *        @c call_vibration_motion_off.
   * @param external_axis_sync Required when @p option is
   *        SettingOptions::EXTERNAL_AXIS_SYNC; forwarded to
   *        @c RBManipulateConfigSDK::set_external_axis_sync.
   * @param tcp_speed_bound Required when @p option is
   *        SettingOptions::TCP_SPEED_BOUND; forwarded to
   *        @c RBManipulateConfigSDK::set_tcp_speed_bound.
   * @param move_break Required when @p option is
   *        SettingOptions::MOVE_BREAK_BLOCK; forwarded to
   *        @c RBManipulateConfigSDK::set_move_break.
   * @param joint_reference_filter Required when @p option is
   *        SettingOptions::JOINT_REFERENCE_FILTER; forwarded to
   *        @c RBManipulateConfigSDK::set_joint_reference_filter.
   * @param self_collision_blind Required when @p option is
   *        SettingOptions::SELF_COLL_DETECT_BLIND; forwarded to
   *        @c RBManipulateConfigSDK::set_self_collision_blind.
   * @param joint_origin_calibration Required when @p option is
   *        SettingOptions::JOINT_ORIGIN_CALIBRATION. The underlying dict's
   *        "table_option" key (0: Clear, 1: Add, 2: Run (Calculate), 3: Reflect)
   *        selects which of @c RBManipulateMaintenanceSDK::call_origin_calib_clr,
   *        @c call_origin_calib_add, @c call_origin_calib_run, or
   *        @c call_origin_calib_reflect is invoked; missing "table_option" or a
   *        case's own required fields throws. That resolution runs in the
   *        dedicated type_caster at the pybind boundary
   *        (binding/glue/program_setting_caster.hpp); this function only sees
   *        the resolved @c JointOriginCalibArg.
   * @param flow_manager_args Optional PyFM step context, forwarded as-is to
   *        whichever underlying setter is invoked.
   *
   * @return IPC::Response_FunctionsT containing the underlying setter's
   *         result.
   *
   * @throws std::runtime_error If the parameter matching @p option is not
   *         provided, if @p option matches no known SettingOptions value,
   *         or if the chosen setter's own validation fails.
   */
  IPC::Response_FunctionsT setting(const std::string& robot_model, std::string_view option,
                                   std::optional<IPC::Request_Set_Out_Collision_ParaT> out_collision,
                                   std::optional<IPC::Request_Set_Self_Collision_ParaT> self_collision,
                                   std::optional<UserFrameSelectionArg> user_frame_selection,
                                   std::optional<IPC::Request_Set_Fixed_Speed_ModeT> fixed_speed,
                                   std::optional<IPC::Request_Set_ShiftT> target_shift,
                                   std::optional<IPC::Request_MotionSpeedBarT> speed_bar,
                                   std::optional<IPC::Request_Set_TimeConstraintT> time_constraint,
                                   std::optional<IPC::Request_Set_AsciiFunctionCallT> ascii_function_call,
                                   std::optional<IPC::Request_Set_Joint_ImpedanceT> joint_impedance,
                                   std::optional<IPC::Request_Set_Free_DriveT> free_drive,
                                   std::optional<IPC::Request_Set_Master_ModeT> master_mode,
                                   std::optional<IPC::Request_Set_User_Frame_6DofT> user_frame_6dof,
                                   std::optional<IPC::Request_Set_User_Frame_TCPT> user_frame_tcp,
                                   std::optional<IPC::Request_Set_User_Frame_3PointsT> user_frame_3points,
                                   std::optional<ShiftLandMarkArg> target_shift_landmark,
                                   std::optional<IPC::Request_Set_ProgramFlowManageT> program_flow_manage,
                                   std::optional<IPC::Request_Set_DinFunctionMaskT> din_function_mask,
                                   std::optional<IPC::Request_Set_DoutFunctionMaskT> dout_function_mask,
                                   std::optional<IPC::Request_Set_JacobSpeedModeT> jacobian_based_speed_control,
                                   std::optional<IPC::Request_Set_SelfVibrationModeT> self_vibration_mode,
                                   std::optional<VibrationMotionBasedArg> vibration_motion_based,
                                   std::optional<IPC::Request_Set_ExternalAxisSyncT> external_axis_sync,
                                   std::optional<IPC::Request_Set_TcpSpeedBoundT> tcp_speed_bound,
                                   std::optional<IPC::Request_Set_MoveBreakT> move_break,
                                   std::optional<IPC::Request_Set_JointRef_FilterT> joint_reference_filter,
                                   std::optional<IPC::Request_Set_SelfCollBlindT> self_collision_blind,
                                   std::optional<JointOriginCalibArg> joint_origin_calibration,
                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set its core data publication frequency.
   *
   * Sets how often the robot publishes its periodic core-data state stream
   * on the {robot_model}/state_core topic (@c IPC::State_Core — joint/
   * Cartesian refs, encoder values, etc.) that other parts of this SDK
   * subscribe to (e.g. @c folder_finish_at).
   *
   * @param robot_model Name of the robot model.
   * @param frequency Publication frequency, in Hz. The firmware clamps this
   *        to the range [0.1, 500.0] before applying it; the default rate
   *        before any call is 20 Hz.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_coredata_pub_frequency(const std::string& robot_model, const float frequency);

  /**
   * @brief Starts background monitoring that breaks a Folder step's children
   *        once its finish_at condition becomes true.
   *
   * Used in PyFM: when a Folder step's @p flow_manager_args carries a
   * finish_at expression, this subscribes to the robot's state_core topic
   * and evaluates that expression against the PyFM context on every state
   * update. As soon as it evaluates true, this calls @c call_smoothjog_stop
   * with the evaluated stop_time, then breaks the folder (via the context's
   * break_folder) at the depth captured on entry, terminating the moves
   * underneath that folder. Monitoring also stops on its own once execution
   * has already exited the target folder depth. This is a no-op if
   * @p flow_manager_args is not provided, or if its args do not have a
   * finish_at value set.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args PyFM step context. Expected args:
   *        - finish_at: expression evaluated on every state update;
   *          monitoring only starts if this is set to a non-empty value.
   *        - stop_time: expression evaluated for the deceleration time
   *          passed to @c call_smoothjog_stop once finish_at becomes true
   *          (defaults to 0.0 if not set).
   *
   * @note @c flow_manager_args.done() is called immediately once monitoring
   *       starts, before finish_at ever becomes true — the PyFM step itself
   *       completes right away (so children can proceed) while the finish_at
   *       watch continues running in the background.
   * @note Exceptions from the background monitor (e.g. from evaluating
   *       finish_at/stop_time) are caught and logged to stderr rather than
   *       propagated, since they run asynchronously in a subscription
   *       callback.
   */
  void folder_finish_at(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);

 private:
  RBManipulateMoveSDK _move_sdk = RBManipulateMoveSDK();
  RBManipulateGetDataSDK _get_data_sdk = RBManipulateGetDataSDK();
  RBManipulateIOSDK _io_sdk = RBManipulateIOSDK();
  RBManipulateConfigSDK _config_sdk = RBManipulateConfigSDK();
  RBManipulateMaintenanceSDK _maint_sdk = RBManipulateMaintenanceSDK();
};
