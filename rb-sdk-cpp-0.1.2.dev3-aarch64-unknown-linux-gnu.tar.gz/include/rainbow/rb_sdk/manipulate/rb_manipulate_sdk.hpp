#pragma once

#include "base.hpp"
#include "rb_sdk_api.hpp"
#include "manipulate_config.hpp"
#include "manipulate_flange.hpp"
#include "manipulate_get_data.hpp"
#include "manipulate_io.hpp"
#include "manipulate_maintenance.hpp"
#include "manipulate_move.hpp"
#include "manipulate_point.hpp"
#include "manipulate_program.hpp"
#include "manipulate_safety.hpp"
#include "manipulate_service.hpp"
#include "manipulate_state.hpp"
#include "manipulate_vision.hpp"

/**
 * @brief Rainbow Robotics manipulate SDK aggregate.
 *
 * Groups the manipulate domain's program, motion, configuration, IO, data,
 * point, service, maintenance, safety, flange, state, and vision SDKs under
 * one root object while sharing the RBBaseSDK zenoh session lifecycle.
 */
class RB_SDK_API RBManipulateSDK : public RBBaseSDK
{
 public:
  /** State/data observation SDK. */
  RBManipulateStateSDK state;
  /** Program lifecycle and program-flow SDK. */
  RBManipulateProgramSDK program;
  /** Robot motion command SDK. */
  RBManipulateMoveSDK move;
  /** Robot configuration and parameter SDK. */
  RBManipulateConfigSDK config;
  /** Digital/analog IO SDK. */
  RBManipulateIOSDK io;
  /** State and data lookup SDK. */
  RBManipulateGetDataSDK get_data;
  /** Point and coordinate helper SDK. */
  RBManipulatePointSDK point;
  /** Move mini-tab service SDK. */
  RBManipulateServiceSDK service;
  /** Maintenance/admin settings SDK. */
  RBManipulateMaintenanceSDK maintenance;
  /** Safety function SDK. */
  RBManipulateSafetySDK safety;
  /** Flange peripheral SDK. */
  RBManipulateFlangeSDK flange;
  /** Vendor vision integration SDK. */
  RBManipulateVisionSDK vision;

  // Re-declare the inherited connect() here so litgen (which never parses the
  // zenoh/template-heavy RBBaseSDK base header) sees it and binds it directly.
  std::optional<std::string> connect(const ConnectOptions& options) { return RBBaseSDK::connect(options); }

  void close() { RBBaseSDK::close(); }

  ~RBManipulateSDK() override;

  /**
   * @brief Closes every child SDK owned by this aggregate.
   */
  void before_close() override;

  /**
   * @brief Deprecated alias for program.folder_finish_at().
   */
  [[deprecated("Use program.folder_finish_at instead.")]]
  void move_finish_at_stop(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);
};
