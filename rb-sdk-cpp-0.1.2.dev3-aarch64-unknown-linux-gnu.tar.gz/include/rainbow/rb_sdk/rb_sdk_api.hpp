#pragma once

// rb_sdk 공개 심볼 export 표식.
//
// 목적: header-only 였던 SDK 구현(base/manipulate/program)을 .cpp 로 옮겨
// librb_sdk.so 안에 컴파일한 뒤, 소비자가 링크해야 하는 public 클래스에만 이 매크로를
// 붙인다. -fvisibility=hidden 하드닝(Phase 4)이 적용되기 전까지는 default visibility 라
// 이 매크로는 사실상 no-op 이다 — 미리 부착해 두어 Phase 4 에서 플래그만 켜면 되게 한다.
//
// 정의 규칙
//   RB_SDK_STATIC            소비 측이 rb_sdk(static) 을 링크 → export 표식 없음
//                            (pybind rb_sdk_cpp, rb_sdk_test)
//   RB_SDK_BUILDING_LIBRARY  librb_sdk.so(rb_sdk_shared) 를 빌드하는 중 → export
//   (둘 다 없음)             .so 소비자가 헤더만 include → import (Windows) / default (ELF)

#if defined(_WIN32)
#  if defined(RB_SDK_STATIC)
#    define RB_SDK_API
#  elif defined(RB_SDK_BUILDING_LIBRARY)
#    define RB_SDK_API __declspec(dllexport)
#  else
#    define RB_SDK_API __declspec(dllimport)
#  endif
#  define RB_SDK_LOCAL
#elif defined(__GNUC__) || defined(__clang__)
#  if defined(RB_SDK_STATIC)
#    define RB_SDK_API
#  else
#    define RB_SDK_API __attribute__((visibility("default")))
#  endif
// RB_SDK_LOCAL: class RB_SDK_API 안의 개별 멤버를 .dynsym 에서 빼고 싶을 때 (private
// helper, heartbeat_loop, 중첩 struct 등). visibility("hidden") 은 클래스 기본값보다
// 우선하므로 librb_sdk.so 에서 STV_HIDDEN → 배포 .so 의 nm -D 에 안 나온다.
#  define RB_SDK_LOCAL __attribute__((visibility("hidden")))
#else
#  define RB_SDK_API
#  define RB_SDK_LOCAL
#endif
