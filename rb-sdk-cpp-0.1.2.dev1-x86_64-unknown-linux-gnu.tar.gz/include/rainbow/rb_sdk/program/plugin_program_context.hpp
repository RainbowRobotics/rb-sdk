#pragma once

// plugin_context.py -> plugin_program_context.hpp. 순수 C++ core — pybind11 을 전혀 모른다.
//
// PluginProgramContext 는 "플러그인 프로세스"(플러그인 개발자의 main.py, 또는 C++ 플러그인
// 실행파일) 안에서 도는 헬퍼다. RBProgramSDK(로봇→플러그인)와 반대 방향으로, 플러그인이
// executor 에게 done/pause/stop 을 알리고 프로그램 변수를 조회/설정한다.
//
// 3계층:
//   1. 이 파일 (순수 C++)      — C++ 플러그인이 헤더 include 해서 nlohmann::json + std::function 로 직접 사용
//   2. binding/plugin_program_context_binding.hpp — py::dict <-> nlohmann::json 변환해서 rb_sdk_cpp 로 노출
//   3. program_sdk/plugin_context.py — 위 바인딩을 asyncio(@on_execute / async start) 로 감싼 wrapper
//
// transport 는 nlohmann::json 직렬화 + rb_zenoh::ZenohClient(순수 C++). Python 원본의
// `self._zenoh.query_one(...)["dict_payload"]` 는 C++ 에서 raw reply bytes 를 json::parse 한 것과
// 같다 (핸들러가 json 본문을 그대로 응답하는 계약).
//
// C++ 플러그인 main.cpp 예 (plugin_main_example.py 의 C++ 판):
//
//     #include "plugin_program_context.hpp"
//     int main() {
//       rb_plugin::PluginProgramContext ctx("my-plugin");
//       ctx.set_execute_handler([&](const nlohmann::json& args) {
//         std::string msg = args.value("message", "");
//         for (int i = 0; i < 10; ++i) {
//           ctx.check_stop();                       // stop 이면 PluginStopped throw
//           std::this_thread::sleep_for(std::chrono::milliseconds(100));
//         }
//         nlohmann::json counter = ctx.get_variable("counter");
//         ctx.set_variable("result", "done: " + msg);
//         ctx.done();
//       });
//       ctx.start();                                // subscriber+queryable 등록, 블로킹 안 함
//       std::promise<void>().get_future().wait();   // run forever
//     }
//
// core 가 execute 요청마다 detach 스레드를 띄워 핸들러를 돌리므로, 핸들러는 그냥 blocking 코드로
// 쓰면 된다. 핸들러가 던지면(PluginStopped 포함) core 가 executor 에 stop 을 통지한다.

#include <atomic>
#include <chrono>
#include <functional>
#include <map>
#include <mutex>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

#include <flatbuffers/flatbuffers.h>
#include <nlohmann/json.hpp>

#include "program_generated.h"  // muscat::Response_Get_Executor_State{,T}
#include "zenoh_client.hpp"     // rb_zenoh::ZenohClient (순수 C++)

namespace rb_plugin {

using nlohmann::json;

// "실행 중"으로 취급하는 executor 상태 / "정지"로 취급하는 상태 (plugin_context.py 와 동일).
inline bool is_active_state(const std::string& s) {
  return s == "running" || s == "waiting" || s == "paused" || s == "post_start";
}
inline bool is_stop_state(const std::string& s) {
  return s == "stopped" || s == "error";
}

// check_stop() 이 stop 감지 시 던진다. Python wrapper 는 이걸 asyncio.CancelledError 로 번역한다.
struct PluginStopped : std::runtime_error {
  PluginStopped() : std::runtime_error("program stopped") {}
};

class PluginProgramContext {
 public:
  using ExecuteHandler = std::function<void(const json& args)>;
  using StateChangeHandler = std::function<void(const std::string& robot_model, const std::string& state)>;
  // 블로킹 정리(undeclare/join)를 감싸 실행하는 러너. 바인딩이 [](fn){ py::gil_scoped_release; fn(); }
  // 를 넣어준다 — 정리는 Python dealloc(=GIL 보유) 에서 불리는데, join 을 GIL 쥔 채 하면 GIL 이
  // 필요한 exec_thread_/zenoh 콜백과 데드락. C++ 플러그인은 안 넣으면 그냥 직접 실행.
  using BlockingRunner = std::function<void(const std::function<void()>&)>;

  explicit PluginProgramContext(std::string plugin_id)
      : plugin_id_(std::move(plugin_id)),
        execute_topic_("muscat/plugin/" + plugin_id_ + "/execute"),
        control_topic_("muscat/plugin/" + plugin_id_ + "/control") {}

  PluginProgramContext(const PluginProgramContext&) = delete;
  PluginProgramContext& operator=(const PluginProgramContext&) = delete;

  ~PluginProgramContext() { shutdown(); }

  void set_execute_handler(ExecuteHandler h) { execute_handler_ = std::move(h); }
  void set_state_change_handler(StateChangeHandler h) { state_change_handler_ = std::move(h); }
  void set_blocking_runner(BlockingRunner r) { blocking_runner_ = std::move(r); }

  // 정리: 1) stopping_ 로 진행 중 execute 핸들러에게 "그만" 신호 (바인딩 브리지가 폴링해서
  // fut.result() 무한 대기를 깬다). 2) 콜백 끊기(undeclare). 3) exec_thread_ join (detach 하면
  // handler(this) 가 파괴된 멤버 접근 → UAF). idempotent — 바인딩 start() 의 finally 와
  // ~PluginProgramContext 양쪽에서 불린다.
  void shutdown() {
    stopping_.store(true);
    auto cleanup = [this] {
      if (zenoh_) {
        if (sub_id_ >= 0) {
          try {
            zenoh_->undeclare_subscriber(sub_id_);
          } catch (...) {
          }
          sub_id_ = -1;
        }
        if (queryable_id_ >= 0) {
          try {
            zenoh_->undeclare_queryable(queryable_id_);
          } catch (...) {
          }
          queryable_id_ = -1;
        }
      }
      if (exec_thread_.joinable())
        exec_thread_.join();
    };
    if (blocking_runner_)
      blocking_runner_(cleanup);
    else
      cleanup();
  }

  // 파괴가 시작됐는지 (바인딩 execute 브리지가 무한 대기 방지용으로 폴링).
  bool stopping() const { return stopping_.load(); }

  const std::string& plugin_id() const { return plugin_id_; }
  const std::string& control_topic() const { return control_topic_; }

  // ── execute lifecycle ─────────────────────────────────────────────────────
  // on_execute 처리 시작/끝. Python wrapper 의 _run() 이 감싸며 호출한다. C++ core 가 execute
  // 요청마다 detach 스레드를 띄우고 begin_execution() 을 먼저 부르므로, 핸들러는 완료 시
  // end_execution() 만 부르면 된다(또는 core 가 핸들러 반환 후 자동으로 부른다 — on_execute_ 참고).
  void begin_execution(std::optional<std::string> robot_model) {
    std::lock_guard<std::mutex> g(mu_);
    exec_seen_active_.clear();
    in_execute_ = true;
    exec_robot_model_ = std::move(robot_model);
  }
  void end_execution() {
    std::lock_guard<std::mutex> g(mu_);
    in_execute_ = false;
  }
  bool in_execute() const {
    std::lock_guard<std::mutex> g(mu_);
    return in_execute_;
  }
  std::optional<std::string> exec_robot_model() const {
    std::lock_guard<std::mutex> g(mu_);
    return exec_robot_model_;
  }

  // ── 흐름 제어 / 변수 (blocking zenoh query) ────────────────────────────────
  // Step 실행 중 경로: control queryable. done/pause/stop/get_variable/set_variable.
  json send_control(const std::string& action, const json& extra = json::object()) {
    require_started();
    json payload = extra.is_object() ? extra : json::object();
    payload["action"] = action;
    try {
      return query_json_(control_topic_, payload, 5000);
    } catch (const PluginStopped&) {
      throw;
    } catch (const std::exception& e) {
      throw error_("control send failed (" + action + "): " + e.what());
    }
  }

  // send_control 단축 (Python 의 await ctx.done()/pause()/stop() 대응).
  json done() { return send_control("done"); }
  json pause() { return send_control("pause"); }
  json stop() { return send_control("stop"); }

  // Step 실행 밖 경로: 상시 executor 변수 엔드포인트 (저수준).
  json query_variable_endpoint(const std::string& action, const std::string& name,
                               const std::optional<std::string>& robot_model,
                               const std::optional<std::string>& plugin_id, const json& value = json()) {
    require_started();
    json payload = {{"name", name}};
    if (robot_model)
      payload["robotModel"] = *robot_model;
    if (plugin_id)
      payload["pluginId"] = *plugin_id;
    if (action == "set")
      payload["value"] = value;
    return query_json_("muscat/executor/variable/" + action, payload, 5000);
  }

  // ── 변수 조회/설정 (라우팅 포함 — Python wrapper 와 C++ plugin 이 공유) ─────
  // Step 중이면 control topic(자기 프로그램 즉시), 밖이면 상시 endpoint. plugin_context.py 와 동일.
  json get_variable(const std::string& name, const std::optional<std::string>& robot_model = std::nullopt,
                    const std::optional<std::string>& plugin_id = std::nullopt) {
    bool ie;
    std::optional<std::string> erm;
    {
      std::lock_guard<std::mutex> g(mu_);
      ie = in_execute_;
      erm = exec_robot_model_;
    }
    json reply;
    if (ie && !plugin_id && !robot_model) {
      reply = send_control("get_variable", {{"name", name}});
    } else {
      std::optional<std::string> model = robot_model ? robot_model : (ie ? erm : std::nullopt);
      reply = query_variable_endpoint("get", name, model, plugin_id);
    }
    return (reply.is_object() && reply.contains("value")) ? reply["value"] : json(nullptr);
  }

  void set_variable(const std::string& name, const json& value) {
    bool ie;
    {
      std::lock_guard<std::mutex> g(mu_);
      ie = in_execute_;
    }
    if (ie) {
      json reply = send_control("set_variable", {{"name", name}, {"value", value}});
      if (reply.is_object() && reply.contains("ok") && reply["ok"].is_boolean() && !reply["ok"].get<bool>())
        throw error_("set_variable failed (" + name + "): " + reply.value("error", std::string()));
      return;
    }
    json reply = query_variable_endpoint("set", name, std::nullopt, plugin_id_, value);
    if (!(reply.is_object() && reply.value("ok", false))) {
      std::string err = reply.is_object() ? reply.value("error", std::string("no reply")) : std::string("no reply");
      throw error_("set_variable failed (" + name + "): " + err);
    }
  }

  // ── 상태 조회 (cheap, 캐시 읽기) ───────────────────────────────────────────
  bool is_stopped(const std::optional<std::string>& robot_model = std::nullopt) const {
    std::lock_guard<std::mutex> g(mu_);
    for (const auto& [m, s] : model_states_locked_(robot_model))
      if (is_stop_state(s) && exec_seen_active_.count(m))
        return true;
    return false;
  }
  bool is_paused(const std::optional<std::string>& robot_model = std::nullopt) const {
    std::lock_guard<std::mutex> g(mu_);
    for (const auto& [m, s] : model_states_locked_(robot_model))
      if (s == "paused")
        return true;
    return false;
  }
  std::optional<std::string> executor_state_for(const std::string& robot_model) const {
    std::lock_guard<std::mutex> g(mu_);
    auto it = executor_states_.find(robot_model);
    return it == executor_states_.end() ? std::nullopt : std::optional<std::string>(it->second);
  }
  std::map<std::string, std::string> executor_states() const {
    std::lock_guard<std::mutex> g(mu_);
    return executor_states_;
  }

  // C++ plugin 용 blocking check_stop. Python wrapper 는 자기 async 버전을 쓴다(이건 안 씀).
  void check_stop(const std::optional<std::string>& robot_model = std::nullopt) {
    if (is_stopped(robot_model))
      throw PluginStopped();
    while (is_paused(robot_model) && !is_stopped(robot_model))
      std::this_thread::sleep_for(std::chrono::milliseconds(100));
    if (is_stopped(robot_model))
      throw PluginStopped();
  }

  // ── start: subscriber + queryable 등록. 블로킹하지 않는다 ──────────────────
  void start() {
    if (started_)
      return;
    if (!execute_handler_)
      throw error_("execute handler not registered before start()");
    zenoh_ = rb_zenoh::ZenohClient::get_instance();

    sub_id_ = zenoh_->declare_subscriber(
        "muscat/executor/state",
        [this](std::string, std::vector<uint8_t> payload, std::string) { on_executor_state_(payload); });

    queryable_id_ = zenoh_->declare_queryable(
        execute_topic_, [this](std::string, std::string, std::optional<std::vector<uint8_t>> payload, std::string,
                               rb_zenoh::ReplyFn reply_fn, rb_zenoh::DelFn) { on_execute_(payload, reply_fn); });

    started_ = true;
  }

  bool started() const { return started_; }

  // 테스트 훅: zenoh 없이 상태 캐시 로직만 검증할 때 executor state 바이트를 직접 주입한다.
  void feed_executor_state_bytes(const std::vector<uint8_t>& payload) { on_executor_state_(payload); }

  // 테스트 훅: 위와 같지만 진짜 별도 네이티브 스레드에서 on_executor_state_ 를 태운다.
  // production 의 zenoh subscriber 콜백(GIL 을 안 쥔 스레드)에서 state_change_handler_ 로
  // 재진입하는 경로를 재현한다 — 바인딩 브리지가 GIL 을 되잡는지 검증용. 호출 스레드에서
  // join 하므로 반환 시 처리는 끝나 있다.
  void feed_executor_state_bytes_from_native_thread(const std::vector<uint8_t>& payload) {
    std::thread([this, payload] { on_executor_state_(payload); }).join();
  }

  // 테스트 훅: zenoh queryable 없이 on_execute_ 경로(진짜 exec_thread_ 스폰 포함)를 탄다.
  // 반환 후 exec_thread_ 는 백그라운드에서 돌고, ~PluginProgramContext 가 join(또는 stopping_ 로 중단).
  void feed_execute_request_for_test(const json& args) {
    std::string s = args.dump();
    std::vector<uint8_t> bytes(s.begin(), s.end());
    on_execute_(std::optional<std::vector<uint8_t>>(std::move(bytes)),
                [](const std::string&, const std::vector<uint8_t>&, const std::string&, const std::string&, bool) {});
  }

 private:
  std::runtime_error error_(const std::string& m) const {
    return std::runtime_error("[plugin:" + plugin_id_ + "] " + m);
  }
  void require_started() const {
    if (!zenoh_)
      throw error_("PluginProgramContext not started");
  }

  // payload(json) -> 직렬화 -> query_one -> reply bytes -> json (Python 의 ["dict_payload"] 등가).
  json query_json_(const std::string& topic, const json& payload, int timeout_ms) {
    std::string s = payload.dump();
    std::vector<uint8_t> bytes(s.begin(), s.end());
    rb_zenoh::RawReply reply = zenoh_->query_one(topic, bytes, timeout_ms, 0);
    if (reply.payload.empty())
      return json(nullptr);
    return json::parse(std::string(reply.payload.begin(), reply.payload.end()), nullptr, /*allow_exceptions=*/false);
  }

  // robot_model 미지정 + on_execute 안이면 자기 step 모델만. 없으면 전체. (plugin_context.py::_model_states)
  std::map<std::string, std::string> model_states_locked_(const std::optional<std::string>& robot_model) const {
    std::optional<std::string> rm = robot_model;
    if (!rm && in_execute_)
      rm = exec_robot_model_;
    if (!rm)
      return executor_states_;
    auto it = executor_states_.find(*rm);
    if (it == executor_states_.end())
      return {};
    return {{*rm, it->second}};
  }

  // muscat/executor/state 수신 -> robot model 별 대표 상태 갱신. main task 우선, active 우선.
  void on_executor_state_(const std::vector<uint8_t>& payload) {
    if (payload.empty())
      return;
    std::unique_ptr<muscat::Response_Get_Executor_StateT> obj(
        flatbuffers::GetRoot<muscat::Response_Get_Executor_State>(payload.data())->UnPack());
    if (!obj)
      return;

    std::map<std::string, std::string> states;
    for (const auto& robot_entry : obj->by_robot_model) {
      if (!robot_entry)
        continue;
      std::vector<std::string> main_states;
      std::vector<std::string> all_states;
      for (const auto& e : robot_entry->value) {
        if (!e || !e->value)
          continue;
        all_states.push_back(e->value->state);
        if (e->value->is_main_task)
          main_states.push_back(e->value->state);
      }
      const std::vector<std::string>& pool = main_states.empty() ? all_states : main_states;
      if (pool.empty())
        continue;
      std::string chosen = pool.front();
      for (const auto& s : pool)
        if (is_active_state(s)) {
          chosen = s;
          break;
        }
      states[robot_entry->key] = chosen;
    }

    std::map<std::string, std::string> prev;
    bool has_handler;
    {
      std::lock_guard<std::mutex> g(mu_);
      prev = executor_states_;
      executor_states_ = states;
      for (const auto& [m, s] : states)
        if (is_active_state(s))
          exec_seen_active_.insert(m);
      has_handler = static_cast<bool>(state_change_handler_);
    }

    if (!has_handler)
      return;
    // state_change_handler_ 를 복사하지 않고 멤버를 그대로 호출 — 바인딩 브리지가 py::object 를
    // 캡처하고 여긴 GIL 없는 zenoh 스레드라 복사하면 inc_ref UB. (핸들러는 start() 이후 고정.)
    for (const auto& [m, s] : states) {
      auto it = prev.find(m);
      if (it == prev.end() || it->second != s) {
        try {
          state_change_handler_(m, s);
        } catch (const std::exception& e) {
          // plugin_context.py: state change handler 예외는 로그만
          fprintf(stderr, "[plugin:%s] state change handler error: %s\n", plugin_id_.c_str(), e.what());
        }
      }
    }
  }

  // execute 요청 수신 -> 즉시 {"ok":"started"} 반환, 핸들러는 detach 스레드에서.
  void on_execute_(const std::optional<std::vector<uint8_t>>& payload, const rb_zenoh::ReplyFn& reply_fn) {
    json args = json::object();
    if (payload && !payload->empty()) {
      json parsed = json::parse(std::string(payload->begin(), payload->end()), nullptr, false);
      if (parsed.is_object())
        args = parsed;
    }
    std::optional<std::string> robot_model;
    if (args.contains("__robotModel") && args["__robotModel"].is_string())
      robot_model = args["__robotModel"].get<std::string>();
    args.erase("__robotModel");

    // executor 는 step 을 직렬로 보내므로 이전 execute 는 보통 이미 끝나 있다. 아직 진행 중이면
    // (계약 위반) queryable 스레드를 join 으로 막지 않고 busy 응답한다 — 막으면 destructor 의
    // undeclare_queryable 와 순환 데드락 위험.
    if (exec_running_.load()) {
      std::string busy = json{{"ok", "busy"}}.dump();
      reply_fn(execute_topic_, std::vector<uint8_t>(busy.begin(), busy.end()), "", "application/json", false);
      return;
    }

    begin_execution(robot_model);

    // 끝난 이전 스레드 정리(즉시 반환). detach 대신 멤버로 들고 ~PluginProgramContext 에서 join → UAF 방지.
    if (exec_thread_.joinable())
      exec_thread_.join();

    exec_running_.store(true);
    // execute_handler_ 를 복사하지 않고 멤버를 그대로 호출한다 — 바인딩 브리지 핸들러는 py::object
    // 를 캡처하는데, on_execute_ 는 GIL 없는 zenoh 스레드에서 불려서 복사하면 inc_ref UB.
    // (핸들러는 execute 진행 중 재설정되지 않는다 — start() 이후 고정.)
    exec_thread_ = std::thread([this, args]() {
      try {
        execute_handler_(args);
      } catch (const PluginStopped&) {
        safe_notify_("stop");
      } catch (const std::exception&) {
        safe_notify_("stop");
      }
      end_execution();
      exec_running_.store(false);
    });

    // Python 의 {"ok": "started"} 응답
    std::string ok = json{{"ok", "started"}}.dump();
    reply_fn(execute_topic_, std::vector<uint8_t>(ok.begin(), ok.end()), "", "application/json", false);
  }

  void safe_notify_(const std::string& action) {
    if (!zenoh_)
      return;
    try {
      json payload = {{"action", action}};
      std::string s = payload.dump();
      zenoh_->query_one(control_topic_, std::vector<uint8_t>(s.begin(), s.end()), 3000, 0);
    } catch (...) {
    }
  }

  const std::string plugin_id_;
  const std::string execute_topic_;
  const std::string control_topic_;

  ExecuteHandler execute_handler_;
  StateChangeHandler state_change_handler_;
  BlockingRunner blocking_runner_;

  std::shared_ptr<rb_zenoh::ZenohClient> zenoh_;
  int sub_id_ = -1;
  int queryable_id_ = -1;
  std::atomic<bool> started_{false};
  std::atomic<bool> stopping_{false};  // ~PluginProgramContext 진입 신호
  std::thread exec_thread_;             // 진행 중 execute 핸들러 스레드 (~PluginProgramContext 에서 join)
  std::atomic<bool> exec_running_{false};  // exec_thread_ 안에서 핸들러가 실제 실행 중인지

  mutable std::mutex mu_;
  std::map<std::string, std::string> executor_states_;
  std::set<std::string> exec_seen_active_;
  bool in_execute_ = false;
  std::optional<std::string> exec_robot_model_;
};

}  // namespace rb_plugin
