#pragma once

// program.py -> rb_program_sdk.hpp 1차 포팅 초안 (draft). RBProgramSDK 본체.
//
// rb_manipulate_sdk.hpp 와 파일 역할이 다르다: manipulate 는 최상위 애그리게이터 파일
// (rb_sdk/manipulate.py::RBManipulateSDK) 이 11개의 독립된 하위 SDK 클래스(RBManipulateMoveSDK,
// RBManipulateIOSDK, ...)를 멤버로 묶는 구조라 rb_manipulate_sdk.hpp 도 그 형태(멤버 목록)를
// 그대로 옮겼다. program 쪽은 그런 최상위 애그리게이터가 없다 — rb_sdk/ 최상위에 manipulate.py/
// amr.py/rby1.py 는 있어도 program.py 는 없고, program_sdk/program.py 의 RBProgramSDK 하나가
// 그 자체로 최종 SDK 다(program_interface.py 는 클래스가 아니라 RBProgramSDK.interface() 가
// 내부적으로 쓰는 free function 모음). 그래서 이 파일이 곧 RBProgramSDK 본체를 직접 정의한다
// (예전 초안에서는 program_program.hpp 에 클래스를 두고 이 파일은 include 만 했는데, 묶을 대상이
// 없어 순수 pass-through 였으므로 통합했다).

//
// 아직 결정/검증되지 않은 부분:
//  - all_pause/all_stop 이 노리는 muscat/pause, muscat/stop queryable 은 실제로는 JSON 이 아니라
//    FlatBuffer(Request_Exec_Control_ProgramT) 로 등록돼 있다(program_zenoh.py:89-134). Python
//    원본도 `payload={}`(JSON) 를 보내는데 FlatBuffer 파서가 이를 못 읽어 예외가 나고 `_c_handler`
//    의 broad except 에 삼켜진다 — zenoh 왕복 자체가 사실상 no-op 이고, 실제 pause/stop 효과는
//    그 직후의 로컬 ctx.pause()/ctx.stop() 호출이 만든다(Python 원본의 잠재적 버그, 포팅과 무관).
//    이 C++ 포팅도 all_pause/all_stop 에서 payload 를 std::nullopt 로 보내(아래 all_pause/all_stop
//    구현) 이미 JSON 브리지를 쓰지 않는다 — python 의 `{}` 나 C++ 의 nullopt 나 그 flatbuffer
//    queryable 앞에서 똑같이 씹히므로 관찰 가능한 동작은 동일하다.
//  - plugin_execute 의 control queryable 은 base.hpp::zenoh_queryable() 이 declare_queryable() 의
//    int id 를 버리고 topic 만 기록해서(undeclare 불가) 그대로 못 썼다. RBBaseSDK::zenoh_client_
//    (protected 멤버)를 직접 호출해 id 를 붙잡아 undeclare_queryable(id) 까지 짝을 맞췄다.
//  - get_digital_input 의 Python `except ZenohNoReply: return None` 대응: rb_zenoh::ZenohClient
//    C++ core 도 이제 no-reply/error reply 를 전용 예외 타입으로 던진다. 따라서 Python 원본과
//    동일하게 통신 실패만 좁게 잡고, 실제 로컬 오류는 밖으로 흘린다.
//  - call_event_tree 의 trees: list[Step] 은 rb_flow_manager.step.Step (Python 런타임 클래스)이라
//    C++ 쪽 대응 타입이 없다. py::object/py::list 로 그대로 받아 .attr("execute") 를 호출한다.
//  - plugin_execute 의 **user_args 는 py::kwargs 로 받아 payload dict 로 그대로 합친다.
//  - make_script ADVANCED 모드는 Python 원본이 `exec(code, globals, locals)` 를 쓴다. 이 SDK
//    자체가 pybind11 확장이라 인터프리터 안에서 돌므로 별도 C++ 인터프리터가 필요한 게 아니다.
//    스크립트 env(variables/var/update_variable/get_var/done/pause/stop/resume/check_stop/
//    rb_log) 조립은 glue(PyFlowManagerArgsAdapter::run_advanced_script)가 flow_manager_args
//    로 하고, compile/exec + 제한된 __builtins__ 는 flow_manager_args.ctx.run_advanced_script
//    (rb_flow_manager) 로 넘긴다 (rb_flow_manager -> rb_sdk 단방향 의존이라 glue 에서
//    make_builtins_allow_most 를 import 하지 않으려는 것). 스크립트의 rb_log 는 make_script 가
//    넘기는 ProgramLogFn = 이 SDK 자신의 RBBaseSDK::log (base.hpp).
//  - _plugin_execute_locks 는 Python 원본이 "클래스 레벨 dict + lazy lock 초기화"라는 이중 체크
//    락킹을 썼는데, 이는 Python 특유의 초기화 순서 문제를 우회하기 위한 것이었다. C++ 로는 이런
//    문제가 없으므로 magic-static std::mutex 로 단순화했다 — plugin_id 별로 동시 실행을 막는다는
//    관찰 가능한 동작은 동일하다.
//
// plugin_context.py / plugin_main_example.py 는 포팅 대상에서 제외했다: PluginProgramContext 는
// "로봇이 플러그인을 호출하는" RBProgramSDK 와 반대 방향으로, 플러그인 개발자가 자기 프로세스의
// main.py 에서 `from rainbow.rb_sdk import PluginProgramContext` 로 직접 import 해 쓰는 순수 Python
// 헬퍼다. RBProgramSDK 바인딩 모듈(pybind11 확장, C++ 프로세스 내부에서 도는 쪽)에 넣을 이유가
// 없고 manipulate_sdk 마이그레이션에도 이런 역방향 클래스를 포팅한 선례가 없다.
//
// 바인딩: scripts/backend/gen_rb_sdk_binding.py 가 litgen(실제 C++ 파서)으로 cpp/manipulate/*.hpp
// 를 스캔해 binding.cpp 를 완전 자동 생성하는 구조로 재작성돼 있다(커밋 d37155bb). 지금 디스크의
// binding.cpp 는 그 이전(수동 bind_manipulate/bind_base 분리) 버전이 남아있어 stale 하다 — 최근
// SDK 헤더 변경 이후로 make backend.sdk-pybind 가 재실행되지 않은 것으로 보인다. 이 상황에서
// program 전용 program_binding.hpp 를 손으로 새로 만드는 건 곧 사라질 옛 구조를 따라가는 셈이라,
// 대신 gen_rb_sdk_binding.py 자체가 cpp/program/*.hpp 도 스캔하도록 확장했다 — 나중에 실제로
// make backend.sdk-pybind 를 돌리면(flatc 산출물 + litgen 필요, 이 환경엔 없어 여기선 실행 못 함)
// RBProgramSDK 도 자동으로 바인딩에 포함된다.
// litgen 은 RBBaseSDK(zenoh/템플릿 많아 파싱 불가)를 못 읽으므로, log() 처럼 상속만 받고 재선언
// 안 한 메서드는 바인딩에서 빠진다 — rb_manipulate_sdk.hpp::connect() 와 동일한 이유로 log() 를
// 한 줄 forward 로 재선언해뒀다(아래 log()).
// docstring: DOC()/docstrings.h 매크로는 litgen 이전 구조의 흔적이라 새 파이프라인에서는 안 쓰인다
// — litgen 이 각 메서드 바로 위 Doxygen(/** ... */, @param/@return/@throws/@note) 주석을 그대로
// 파이썬 docstring 으로 박아 넣는다. 이 파일의 public 메서드들에 최신 manipulate_move.hpp 와 같은
// 스타일로 Doxygen 주석을 달아뒀다.

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <functional>
#include <iostream>
#include <memory>
#include <mutex>
#include <optional>
#include <sstream>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include <nlohmann/json.hpp>  // user_select 의 content 직렬화

#include "base.hpp"
#include "flow_manager_args.hpp"
#include "func_get_generated.h"  // IPC::Request_Get_Digital_Input{,T} (get_digital_input() 에서 사용)
#include "binding/glue/gil_release.hpp"
#include "program_generated.h"

#include "interface_payload_schema.hpp"
#include "program_interface.hpp"
#include "rpc_manager.h"  // RpcManagerRegistry(아래) 가 RpcManager/RpcLogCallback 을 직접 쓴다.
#include "common/value_validation.hpp"

// zenoh JSON 페이로드 브리지: rb_zenoh::ZenohClient (C++ core) 는 raw bytes API 만 노출하고
// (query_one/queryable 모두 std::vector<uint8_t>), Python SDK 의 `query_one(topic, payload={...})`
// dict 편의 오버로드는 파이썬 래퍼에만 있다. 이 SDK 자체가 pybind11 확장이라 인터프리터 안에서
// 돈다는 점을 이용해, nlohmann::json <-> bytes 변환을 이 헤더의 작은 순수 C++ helper 로 처리한다.
// [검증 완료] 파이썬 래퍼(rb_zenoh/client.py::ZenohClient._normalize_payload/_decode_payload_dict)와
// 바이트 단위 동일.
// plugin_execute 의 muscat/plugin/{id}/execute, /control 은 순수 JSON dict 핸들러라 충분하고,
// muscat/pause·muscat/stop 은 FlatBuffer 로 등록돼 있어 이 브리지를 안 탄다.

// module_name(PFM 의 task_id) 별로 독립된 RpcManager 를 소유/관리한다. python 원본
// (program_sdk/program.py, program_sdk/program_interface.py, program_sdk/__init__.py)에서도
// client_modules.RpcManager 는 program 도메인 전용이었고 manipulate/amr 등 다른 도메인은 쓰지
// 않는다 - base.hpp::VisionClientRegistry(mechmind/photoneo/pickit, manipulate 뿐 아니라 다른
// 도메인도 재사용) 와 달리 이건 RBBaseSDK 공용으로 올릴 근거가 없어 RBProgramSDK 전용으로 둔다.
// VisionClientRegistry 와 달리 RpcManager 는 connect()/is_connected() 개념이 없다 - 내부적으로
// (module, ip:port) 조합마다 세션을 lazy 하게 만들어 관리한다(get_or_create_session, rpc_manager.h).
// module_name 별로 별도 인스턴스를 두는 이유는 세션 재사용이 아니라 로그 콜백에 module_name
// 접두사를 붙이기 위함이다(Python 원본 RBProgramSDK._get_rpc 의 동작 그대로 - 아래 get_rpc 참고).
class RpcManagerRegistry {
 public:
  RpcManager* get(const std::string& module_name) {
    auto it = managers_.find(module_name);
    return it == managers_.end() ? nullptr : it->second.get();
  }

  RpcManager& get_or_create(const std::string& module_name, RpcLogCallback log_cb = nullptr) {
    auto it = managers_.find(module_name);
    if (it != managers_.end())
      return *it->second;

    auto manager = std::make_unique<RpcManager>(log_cb);
    RpcManager& ref = *manager;
    managers_[module_name] = std::move(manager);
    return ref;
  }

  void disconnect_all() {
    for (auto& [module_name, manager] : managers_) {
      if (!manager)
        continue;
      try {
        manager->disconnect_module(module_name);
      } catch (const std::exception& e) {
        std::cerr << "[RpcManagerRegistry] disconnect failed: module=" << module_name << ", err=" << e.what()
                  << std::endl;
      }
    }
    managers_.clear();
  }

 private:
  std::unordered_map<std::string, std::unique_ptr<RpcManager>> managers_;
};

// wait() 의 digital_input 조건 (base_schema.py::DigitalInputConditionSchema).
// dict <-> 이 struct 변환은 binding/glue/program_wait_caster.hpp 의 type_caster 가 한다.
struct ProgramDigitalInputCondition {
  std::vector<int> signal;
  std::string logical_operator = "AND";  // "AND" | "OR"
};

class RBProgramSDK : public RBBaseSDK {
 public:
  RBProgramSDK() {}

  // before_close() 는 RBBaseSDK::close() 가 자기 자신의 소멸자에서 불릴 때만 가상 디스패치로
  // override 가 걸린다(base.hpp::before_close() 주석 참고) — 그래서 close() 를 직접 부르는
  // 소멸자를 여기 따로 선언해야 rpc_managers_(base.hpp) 의 RpcManager 들이 실제로 정리된다.
  ~RBProgramSDK() override { close(); }

  static std::string type_name() { return "RBProgramSDK"; }

  // RpcManager 워커 스레드의 로그를 rb_log 로 흘려보내는 sink. get_rpc() 가 만드는
  // RpcLogCallback 이 이걸 부른다 — 캐시된 RpcManager 가 호출보다 오래 살고 워커
  // 스레드에서 불리므로, Python 객체(rb_log)를 잡는 건 프로세스 전역 sink 쪽이어야
  // 한다(fm 파생 아님). binding/glue/rpc_log_sink.hpp::install_rpc_log_sink() 가
  // pybind 경계에서 1회 설치. 미설치 시 get_rpc 는 stderr 로 폴백.
  using RpcLogSink = std::function<void(LogType type, const std::string& module_name, const std::string& message)>;

  static void set_rpc_log_sink(RpcLogSink sink) { rpc_log_sink_ = std::move(sink); }

  // ---------------------------------------------------------------------
  // 내부 유틸
  // ---------------------------------------------------------------------

  // PyFM 변수 치환으로 dict/list/숫자가 들어올 수 있는 title/content 를 alarm()/log() 로 넘기기
  // 전에 문자열 1회 정규화. Python alarm() 내부 동작과 동일.
  static std::string _to_fb_text(const nlohmann::json& value, const std::string& default_ = "") {
    if (value.is_null())
      return default_;
    if (value.is_string())
      return value.get<std::string>();
    if (value.is_boolean())
      return value.get<bool>() ? "True" : "False";
    return value.dump();
  }

  // JSON 값을 Python repr 스타일 문자열로 (debug_variables / user_input / user_select 표시용).
  static std::string _to_py_text(const nlohmann::json& value, bool nested = false) {
    if (value.is_null())
      return "None";
    if (value.is_string()) {
      const std::string& s = value.get_ref<const std::string&>();
      if (!nested)
        return s;
      std::string quoted = "'";
      for (char ch : s) {
        if (ch == '\\' || ch == '\'')
          quoted.push_back('\\');
        quoted.push_back(ch);
      }
      quoted.push_back('\'');
      return quoted;
    }
    if (value.is_boolean())
      return value.get<bool>() ? "True" : "False";
    if (value.is_number())
      return value.dump();
    if (value.is_array()) {
      std::ostringstream oss;
      oss << "[";
      for (std::size_t index = 0; index < value.size(); ++index) {
        if (index > 0)
          oss << ", ";
        oss << _to_py_text(value[index], true);
      }
      oss << "]";
      return oss.str();
    }
    std::ostringstream oss;
    oss << "{";
    bool first = true;
    for (auto it = value.begin(); it != value.end(); ++it) {
      if (!first)
        oss << ", ";
      first = false;
      oss << "'" << it.key() << "': " << _to_py_text(it.value(), true);
    }
    oss << "}";
    return oss.str();
  }

  // debug_variables 의 "raw arg 문자열 vs 평가값" 비교용 — JSON 을 Python json.dumps 스타일로.
  static std::string _json_dump_python_style(const nlohmann::json& value) {
    if (value.is_null() || value.is_boolean() || value.is_number() || value.is_string())
      return value.dump();
    if (value.is_array()) {
      std::ostringstream oss;
      oss << "[";
      for (std::size_t index = 0; index < value.size(); ++index) {
        if (index > 0)
          oss << ", ";
        oss << _json_dump_python_style(value[index]);
      }
      oss << "]";
      return oss.str();
    }
    std::ostringstream oss;
    oss << "{";
    bool first = true;
    for (auto it = value.begin(); it != value.end(); ++it) {
      if (!first)
        oss << ", ";
      first = false;
      oss << nlohmann::json(it.key()).dump() << ": " << _json_dump_python_style(it.value());
    }
    oss << "}";
    return oss.str();
  }

  static std::optional<std::string> _json_get_string(const nlohmann::json& value, const char* key) {
    if (!value.is_object() || !value.contains(key) || value[key].is_null())
      return std::nullopt;
    const nlohmann::json& v = value[key];
    return v.is_string() ? v.get<std::string>() : _to_py_text(v);
  }

  static std::vector<std::uint8_t> _json_to_bytes(const nlohmann::json& value) {
    std::string dumped = value.dump();
    return std::vector<std::uint8_t>(dumped.begin(), dumped.end());
  }

  static nlohmann::json _json_from_bytes(const std::optional<std::vector<std::uint8_t>>& payload,
                                         const std::string& error_prefix) {
    if (!payload || payload->empty())
      return nlohmann::json::object();
    try {
      return nlohmann::json::parse(payload->begin(), payload->end());
    } catch (const nlohmann::json::exception& exc) {
      throw std::runtime_error(error_prefix + ": invalid JSON payload: " + std::string(exc.what()));
    }
  }

  static std::optional<rb_payload::WriteRegisterValues> _write_register_values(
      const std::unique_ptr<muscat::WriteRegisterValuesT>& value) {
    if (!value)
      return std::nullopt;
    return rb_payload::WriteRegisterValues{value->values};
  }

  // 숫자/숫자리스트는 소수 3자리 반올림해서 표시.
  static std::string _format_debug_value(const nlohmann::json& real_value) {
    if (real_value.is_array() && !real_value.empty()) {
      bool all_numeric = true;
      nlohmann::json rounded = nlohmann::json::array();
      for (const auto& item : real_value) {
        if (!item.is_number()) {
          all_numeric = false;
          break;
        }
        rounded.push_back(std::round(item.get<double>() * 1000.0) / 1000.0);
      }
      if (all_numeric)
        return _to_py_text(rounded);
    } else if (real_value.is_number()) {
      return nlohmann::json(std::round(real_value.get<double>() * 1000.0) / 1000.0).dump();
    }
    return _json_dump_python_style(real_value);
  }

  // Re-declare the inherited log() here so litgen (which never parses the
  // zenoh/template-heavy RBBaseSDK base header) sees it and binds it directly
  // -- same pattern as RBManipulateSDK::connect() in rb_manipulate_sdk.hpp.
  /**
   * Emits a program log entry.
   *
   * @param content Log message content.
   * @param robot_model Name of the robot model this log entry is associated with.
   * @param level Log level ("INFO", "WARNING", "ERROR", "USER", "DEBUG", or "GENERAL").
   * @param disable_db Unused (kept for parity with the Python original, which also
   *        never reads this parameter).
   * @param flow_manager_args Optional PyFM step context. If provided, the step is
   *        marked done immediately after the log entry is published.
   */
  void log(const std::string& content, const std::string& robot_model, const std::string& level,
           bool disable_db = false, FlowManagerArgsPtr flow_manager_args = nullptr) {
    RBBaseSDK::log(content, robot_model, level, disable_db, flow_manager_args);
  }

  /**
   * Returns the RpcManager registered for @p module_name in this SDK's own
   * RpcManagerRegistry (rpc_managers_, defined above this class), creating
   * one (with a log callback bridged to rb_log) on first use.
   *
   * Public (not `_`-prefixed) so it's individually bindable, mirroring
   * manipulate_vision.hpp::execute_mechmind_connect(): rb_program_interface's
   * execute_* free functions (program_interface.hpp) take an RpcManager&
   * directly, so a Python caller wanting to call them standalone (instead of
   * through interface()) needs a way to obtain that reference first.
   *
   * @param module_name PFM task id used as the RpcManager cache key.
   * @return The RpcManager instance for @p module_name, owned by rpc_managers_.
   */
  RpcManager& get_rpc(const std::string& module_name) {
    if (RpcManager* existing = rpc_managers_.get(module_name))
      return *existing;

    RpcLogCallback log_cb = [module_name](LogType type, int /*sid*/, const std::string& msg) {
      std::string prefixed = "[" + module_name + "] " + msg;
      if (rpc_log_sink_) {
        rpc_log_sink_(type, module_name, prefixed);
        return;
      }
      std::cerr << prefixed << std::endl;
    };

    return rpc_managers_.get_or_create(module_name, log_cb);
  }

  // ---------------------------------------------------------------------
  // 변수 / 스크립트
  // ---------------------------------------------------------------------

  /**
   * Initializes local task variables from their configured init values.
   *
   * @param variables List of variable definition dicts, each carrying an
   *        "init_value" key, in the same order as the task's declared variables.
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything — if omitted, returns immediately without
   *        touching @p variables. When provided, each variable is applied
   *        via @p flow_manager_args's local variable updater and the step
   *        is marked done afterwards.
   */
  void set_variables(const nlohmann::json& variables, FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!flow_manager_args)
      return;

    std::optional<nlohmann::json> raw_variables = flow_manager_args->raw_json_arg("variables");
    if (!raw_variables || !raw_variables->is_array()) {
      fm_done(flow_manager_args);
      return;
    }

    nlohmann::json values = variables.is_array() ? variables : nlohmann::json::array({variables});
    const std::size_t count = std::min(raw_variables->size(), values.size());
    for (std::size_t index = 0; index < count; ++index) {
      const nlohmann::json& raw_variable = (*raw_variables)[index];
      if (!raw_variable.is_object() || !raw_variable.contains("name") || !raw_variable["name"].is_string())
        continue;
      const nlohmann::json& init_value = values[index].is_object() && values[index].contains("init_value")
                                             ? values[index]["init_value"]
                                             : nlohmann::json(nullptr);
      flow_manager_args->context().update_local_variables_json(
          nlohmann::json::object({{raw_variable["name"].get<std::string>(), init_value}}));
    }

    fm_done(flow_manager_args);
  }

  /**
   * Runs a program script step, in either GENERAL or ADVANCED mode.
   *
   * In GENERAL mode, @p flow_manager_args's "general_contents" argument is
   * evaluated as a single expression against the step's context (assignments
   * are reflected into state). In ADVANCED mode, @p contents is compiled and
   * executed as an arbitrary python script with `variables`/`var`,
   * `update_variable`/`update_var`, `get_var`, `done`, `pause`, `stop`,
   * `resume`, `check_stop`, and `rb_log` injected into its globals (the bridge
   * builds that env from @p flow_manager_args; compile/exec runs on the PyFM
   * side in ctx.run_advanced_script). `rb_log` is this SDK's own log
   * (RBBaseSDK::log), called as `rb_log(content, robot_model, level)`.
   *
   * @param mode "GENERAL" or "ADVANCED".
   * @param contents ADVANCED-mode script source. Required when @p mode is
   *        "ADVANCED".
   * @param flow_manager_args PyFM step context. Required; the step is marked
   *        done when the script finishes (or immediately raises, in ADVANCED
   *        mode, since the step is still marked done before the exception
   *        propagates).
   *
   * @throws std::runtime_error If GENERAL mode is missing
   *         "general_contents", or ADVANCED mode is missing @p contents.
   */
  void make_script(const std::string& mode /* GENERAL|ADVANCED */, std::optional<std::string> contents,
                   FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!flow_manager_args)
      return;

    if (mode == "GENERAL") {
      FlowValuePtr general_contents = flow_manager_args->arg("general_contents");
      if (!general_contents)
        throw std::runtime_error("general_contents is required");
      flow_manager_args->context().eval_action(general_contents);  // eval_value(x, use_get_var=true)
      fm_done(flow_manager_args);
    } else if (mode == "ADVANCED") {
      if (!contents)
        throw std::runtime_error("contents is required");
      try {
        // rb_log = this SDK's own RBBaseSDK::log (base.hpp).
        flow_manager_args->run_advanced_script(
            *contents, [this](const std::string& content, const std::string& robot_model, const std::string& level) {
              log(content, robot_model, level);
            });
      } catch (...) {
        fm_done(flow_manager_args);
        throw;
      }
      fm_done(flow_manager_args);
    }
  }

  // ---------------------------------------------------------------------
  // wait 계열
  // ---------------------------------------------------------------------

  /**
   * Blocks the calling thread for @p second seconds, polling for stop/pause
   * requests every 1/50s. Time spent blocked inside a pause is excluded from
   * the wait duration.
   *
   * @param second Seconds to wait. Must be greater than 0 when
   *        @p flow_manager_args is not provided (a standalone caller has no
   *        other way to be notified that the wait was skipped).
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done once the wait elapses (or immediately, if
   *        @p second <= 0).
   *
   * @throws std::runtime_error If @p second <= 0 and @p flow_manager_args is
   *         not provided.
   */
  void simple_wait(double second, FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (second <= 0) {
      if (flow_manager_args) {
        flow_manager_args->done();
        return;
      }
      throw std::runtime_error("time must be greater than 0");
    }

    const double check_hz = 50.0;
    const double interval = 1.0 / check_hz;

    auto end_at = std::chrono::steady_clock::now() + std::chrono::duration_cast<std::chrono::steady_clock::duration>(
                                                         std::chrono::duration<double>(second));

    while (true) {
      if (flow_manager_args) {
        auto before_check = std::chrono::steady_clock::now();
        flow_manager_args->context().check_stop();
        auto after_check = std::chrono::steady_clock::now();
        // pause 로 block된 시간은 wait 시간에서 제외한다.
        end_at += (after_check - before_check);
      }

      auto now = std::chrono::steady_clock::now();
      double remaining = std::chrono::duration<double>(end_at - now).count();
      if (remaining <= 0)
        break;

      double sleep_for = remaining > interval ? interval : remaining;
      {
        rb_sdk::gil_release_if_held release;
        std::this_thread::sleep_for(std::chrono::duration<double>(sleep_for));
      }
    }

    fm_done(flow_manager_args);
  }

  /**
   * Pauses every running program process on this robot.
   *
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step's own execution context is paused too, after the broadcast
   *        pause request.
   */
  void all_pause(FlowManagerArgsPtr flow_manager_args = nullptr) {
    query_one("muscat/pause", std::nullopt, 1000, 0);
    {
      rb_sdk::gil_release_if_held release;
      std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    if (flow_manager_args)
      flow_manager_args->context().pause();
  }

  /**
   * Stops every running program process on this robot.
   *
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done after the broadcast stop request.
   */
  void all_stop(FlowManagerArgsPtr flow_manager_args = nullptr) {
    query_one("muscat/stop", std::nullopt, 1000, 0);
    fm_done(flow_manager_args);
  }

  /**
   * Publishes a program dialog alarm.
   *
   * @param title Dialog title. Falls back to "No Title" when empty.
   * @param content Dialog content.
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done immediately after the alarm is published.
   */
  void alarm(const std::string& title, const std::string& content, const std::string& robot_model,
             FlowManagerArgsPtr flow_manager_args = nullptr) {
    muscat::RB_Program_DialogT req;
    req.robot_model = robot_model;
    req.title = title.empty() ? "No Title" : title;
    req.content = content;

    publish("muscat/program/dialog", req, 256);

    fm_done(flow_manager_args);
  }

  /**
   * Raises an alarm and/or halts execution, depending on @p option.
   *
   * @param robot_model Name of the robot model.
   * @param option "ALARM" (publish an alarm dialog), "HALT" (stop the step's
   *        context), "FOLDER_HALT" (break out of the enclosing folder), or
   *        "SUB_PROGRAM_HALT" (halt the enclosing sub task).
   * @param save_log If true, also emits a USER-level log entry with
   *        @p content (or @p title if @p content is None).
   * @param is_only_at_ui If true and the step is not running from a UI
   *        execution, the step is marked done and this call is a no-op.
   * @param pause_option "ALL" (pause every process) or "CURRENT" (pause only
   *        this context). Only consulted when @p option resolves to a pause.
   * @param title Alarm dialog title (used when @p option is "ALARM", and as
   *        the log fallback content when @p save_log is set and @p content
   *        is None).
   * @param content Alarm dialog / log content.
   * @param flow_manager_args PyFM step context. Required; the step is marked
   *        done after the alarm/halt/pause sequence completes.
   */
  void alarm_or_halt(const std::string& robot_model, const std::string& option, bool save_log, bool is_only_at_ui,
                     const std::string& pause_option, const nlohmann::json& title, const nlohmann::json& content,
                     FlowManagerArgsPtr flow_manager_args = nullptr) {
    std::string stop_type = "pause";

    if (fm_skip_when_not_ui(flow_manager_args, is_only_at_ui))
      return;

    // title/content 는 PyFM 변수 치환으로 dict/list/숫자가 들어올 수 있어 nlohmann::json 으로 받고
    // alarm()/log() 직전에 문자열 1회 정규화한다. 빈 title 은 alarm() 이 "No Title" 로 대체.
    const std::string title_text = _to_fb_text(title);
    const std::string content_text = _to_fb_text(content);

    if (option == "ALARM") {
      alarm(title_text, content_text, robot_model);
      stop_type = "pause";
    } else if (option == "HALT" && flow_manager_args) {
      flow_manager_args->context().stop();
      stop_type = "stop";
    } else if (option == "FOLDER_HALT" && flow_manager_args) {
      FlowManagerContext& c = flow_manager_args->context();
      c.break_folder(c.get_folder_depth());
      stop_type = "continue";
    } else if (option == "SUB_PROGRAM_HALT" && flow_manager_args) {
      flow_manager_args->context().halt_sub_task();
      stop_type = "continue";
    }

    if (save_log) {
      // Python: self.log(content=content or title, ...)
      log(content_text.empty() ? title_text : content_text, robot_model, "USER");
    }

    if (stop_type == "pause") {
      fm_pause_check_stop_done(flow_manager_args, pause_option);
    } else {
      if (flow_manager_args) {
        if (stop_type == "stop")
          flow_manager_args->context().stop();
        flow_manager_args->context().check_stop();
        flow_manager_args->done();
      }
    }
  }

  /**
   * Reports the current values of @p variables for debugging, then pauses.
   *
   * Compares each variable's raw (pre-evaluation) string against its
   * evaluated JSON value; numeric values/lists are rounded to 3 decimals for
   * display, and unchanged variables are reported as "Undefined".
   *
   * @param robot_model Name of the robot model.
   * @param option "DIALOG" (publish a single alarm dialog listing every
   *        variable) or "LOG" (emit one USER-level log entry per variable).
   * @param is_only_at_ui If true and the step is not running from a UI
   *        execution, the step is marked done and this call is a no-op.
   * @param variables Evaluated current variable values, in the same order as
   *        @p flow_manager_args's raw "variables" list.
   * @param log_content Optional extra USER-level log entry (any value; non-str
   *        is JSON-encoded) appended after the per-variable LOG entries.
   * @param pause_option "ALL" (pause every process) or "CURRENT" (pause only
   *        this context).
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything; the step is marked done after pausing.
   */
  void debug_variables(const std::string& robot_model, const std::string& option, bool is_only_at_ui,
                       const nlohmann::json& variables, const nlohmann::json& log_content,
                       const std::string& pause_option, FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (fm_skip_when_not_ui(flow_manager_args, is_only_at_ui))
      return;
    if (!flow_manager_args)
      return;

    nlohmann::json real_variables = variables.is_array() ? variables : nlohmann::json::array({variables});
    std::optional<nlohmann::json> raw_variables = flow_manager_args->raw_json_arg("variables");
    if (!raw_variables || !raw_variables->is_array() || raw_variables->empty()) {
      flow_manager_args->done();
      return;
    }

    auto line = [&](std::size_t index) -> std::string {
      std::string var = _to_py_text((*raw_variables)[index]);
      nlohmann::json real_value = index < real_variables.size() ? real_variables[index] : nlohmann::json(nullptr);
      if (var != _json_dump_python_style(real_value))
        return var + ": " + _format_debug_value(real_value);
      return var + ": Undefined";
    };

    if (option == "DIALOG") {
      std::string content;
      for (std::size_t index = 0; index < raw_variables->size(); ++index)
        content += line(index) + "\n";
      alarm("Debug Variables", content, robot_model);
    } else if (option == "LOG") {
      for (std::size_t index = 0; index < raw_variables->size(); ++index)
        log(line(index), robot_model, "USER");
      // log_content 는 any — 변수식이면 값(list 등)으로 들어오므로 str 이 아니면 JSON 으로 기록.
      if (!log_content.is_null())
        log(log_content.is_string() ? log_content.get<std::string>() : log_content.dump(), robot_model, "USER");
    }

    fm_pause_check_stop_done(flow_manager_args, pause_option);
  }

  /**
   * Publishes a "user input" prompt dialog and pauses the step until the
   * operator supplies a value (resumed out-of-band via the program
   * service's change_user_input_value endpoint).
   *
   * Mirrors program.py::RBProgramSDK.user_input: the dialog content is
   * `"{raw var_selection arg} ({resolved var_selection})"` — the raw name
   * comes from `flow_manager_args.args["var_selection"]` (pre-substitution)
   * and the resolved value from the @p var_selection parameter.
   *
   * @param robot_model Name of the robot model.
   * @param var_form Input widget kind: "STRING" (default), "NUMERIC",
   *        "BOOLEAN", "LIST", "DICTIONARY", or "VAR". Only used to tag the
   *        alarm title (`USER_INPUT_{var_form}`).
   * @param var_selection Resolved value of the target variable. PyFM evaluates
   *        the step's `var_selection` expression before the call, so this can
   *        arrive as any Python type (int/float/list/dict, ...), not only str —
   *        it is stringified here, mirroring the Python original's f-string.
   * @param flow_manager_args PyFM step context. When provided, the step's
   *        context is paused, checked for stop, and marked done.
   */
  void user_input(const std::string& robot_model, const nlohmann::json& var_selection, const std::string& var_form,
                  FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!flow_manager_args)
      return;

    // Python: var_name = flow_manager_args.args.get("var_selection") — 치환 전 step arg. 없으면 "None".
    std::string var_name = flow_manager_args->raw_arg("var_selection").value_or("None");
    // var_selection 은 PyFM 이 표현식을 평가한 치환된 값이라 어떤 타입이든 온다 — Python f-string 처럼 stringify.
    std::string result_string = var_name + " (" + _to_py_text(var_selection) + ")";

    alarm("USER_INPUT_" + var_form, result_string, robot_model);
    fm_pause_check_stop_done(flow_manager_args);
  }

  /**
   * Publishes a "user select" prompt dialog and pauses the step until the
   * operator picks one of @p content (resumed out-of-band via the program
   * service's set_user_select_value endpoint).
   *
   * Mirrors program.py::RBProgramSDK.user_select: the dialog content is
   * `json.dumps([var_name, timeout, disconn_timeout, content])`.
   *
   * @param robot_model Name of the robot model.
   * @param ask_ment Prompt text, used to tag the alarm title
   *        (`USER_SELECT_{ask_ment}`).
   * @param var_name Name of the variable that will receive the choice.
   * @param content Selectable option strings.
   * @param timeout Seconds before the select auto-resolves.
   * @param disconn_timeout Behavior label when the operator UI disconnects.
   * @param flow_manager_args PyFM step context. When provided, the step's
   *        context is paused, checked for stop, and marked done.
   *
   * @note ask_ment/var_name/content/timeout/disconn_timeout arrive as values
   *       PyFM produced by evaluating the step's args, so their runtime types
   *       are not fixed (e.g. a `"60"` arg resolves to int 60, `"0"` to int 0).
   *       They are taken as py::object and normalized to the expected C++ type
   *       here before the (unchanged) nlohmann serialization, so a NUMERIC /
   *       other-typed variable no longer trips the pybind11 argument check.
   */
  void user_select(const std::string& robot_model, const nlohmann::json& ask_ment, const nlohmann::json& var_name,
                   const nlohmann::json& content, const nlohmann::json& timeout, const nlohmann::json& disconn_timeout,
                   FlowManagerArgsPtr flow_manager_args = nullptr) {
    const std::string ask_ment_str = _to_py_text(ask_ment);
    const std::string var_name_str = _to_py_text(var_name);
    const std::string disconn_timeout_str = _to_py_text(disconn_timeout);
    int timeout_int = 0;
    if (timeout.is_number_integer())
      timeout_int = timeout.get<int>();
    else if (timeout.is_number_float())
      timeout_int = static_cast<int>(timeout.get<double>());
    else if (timeout.is_string())
      timeout_int = std::stoi(timeout.get<std::string>());
    else
      timeout_int = std::stoi(_to_py_text(timeout));

    std::vector<std::string> content_list;
    if (content.is_array()) {
      for (const auto& item : content)
        content_list.push_back(_to_py_text(item));
    } else {
      content_list.push_back(_to_py_text(content));
    }

    // Python: json.dumps([var_name, timeout, disconn_timeout, content]). content 는 프론트가
    // JSON.parse 로 읽어 표시만 하므로(백엔드에서 문자열 비교 없음) 공백 차이는 무관하다 — 구분자
    // 없는 nlohmann dump 를 그대로 쓴다.
    nlohmann::json payload = nlohmann::json::array();
    payload.push_back(var_name_str);
    payload.push_back(timeout_int);
    payload.push_back(disconn_timeout_str);
    payload.push_back(content_list);
    std::string result_content = payload.dump();

    alarm("USER_SELECT_" + ask_ment_str, result_content, robot_model);
    fm_pause_check_stop_done(flow_manager_args);
  }

  /**
   * Queries the digital input state of @p robot_model.
   *
   * @param robot_model Name of the robot model.
   * @return The digital input list, or std::nullopt if the robot has no
   *         `{robot_model}/get_digital_input` zenoh queryable (e.g. not
   *         connected / not running).
   */
  std::optional<std::vector<int8_t>> get_digital_input(const std::string& robot_model) {
    try {
      IPC::Request_Get_Digital_InputT req;
      std::unique_ptr<IPC::Response_Get_Digital_InputT> res =
          query_one<IPC::Response_Get_Digital_Input, IPC::Request_Get_Digital_InputT>(
              robot_model + "/get_digital_input", req, 128, 1000, 0);
      if (!res)
        return std::nullopt;
      return res->digital_input;
    } catch (const rb_zenoh::ZenohNoReply&) {
      return std::nullopt;
    }
  }

  // ---------------------------------------------------------------------
  // Interface (MC/XGT/Modbus/Socket)
  // ---------------------------------------------------------------------
  //
  // 개별 프로토콜 호출(execute_modbus_read 등)은 여기 RBProgramSDK 에 thin wrapper 로 올리지 않는다 -
  // program_interface.hpp::rb_program_interface::execute_* free function 이 이미 RpcResult(대부분)/
  // bool(execute_socket_connect)을 그대로 반환하므로, binding/program_binding.hpp 가 그 free
  // function 들을 module 레벨 함수로 직접 바인딩해서 개별 호출을 지원한다 - get_rpc(module_name) 을
  // 먼저 호출해 RpcManager& 를 얻은 뒤 그 free function 들에 넘기는 게 python 쪽 사용 패턴이다
  // (vision.hpp::execute_mechmind_connect 가 client 포인터를 반환하고 이후 호출들이 그 포인터를
  // 받는 것과 유사하되, 여기서는 "연결"이 아니라 registry 조회이므로 get_rpc() 가 그 역할).
  // interface() 자신은 그대로 (rpc 변수 하나로) free function 을 직접 호출한다.

  /**
   * Dispatches a protocol interface call (Modbus/MC/XGT/socket) via the
   * native RpcManager cached for this step's task id (rpc_managers_).
   *
   * @param option "MODBUS_CLIENT", "MC_PROTOCOL", "XGT_PROTOCOL", or
   *        "SOCKET_INTERFACE".
   * @param data Protocol payload generated from program.fbs. Must contain a
   *        non-empty "server_ip" and a "type" of "READ"/"WRITE" (plus
   *        "CONNECT" for SOCKET_INTERFACE).
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything — if omitted, returns immediately without
   *        dispatching to any protocol. When provided, it's forwarded to
   *        the underlying execute_* call and the step is marked done after
   *        dispatch.
   *
   * @throws std::runtime_error If @p option or @p data["type"] is
   *         unsupported for the given @p option.
   */
  void interface(const std::string& option, muscat::InterfacePayloadUnion data,
                 FlowManagerArgsPtr flow_manager_args = nullptr) {
    std::string module_name = get_task_id(flow_manager_args);
    RpcManager& rpc = get_rpc(module_name);

    // AlarmFn 이 py::object 가 아니라 순수 std::function 이라(flow_manager_args.hpp), Python
    // 콜러블로 감쌀 필요 없이 C++ 람다를 그대로 넘긴다.
    AlarmFn alarm_fn = [this](const std::string& title, const std::string& content) {
      this->alarm(title, content, "unknown");
    };

    // return_variable_name 은 "결과를 어디에 쓸지" 지정하는 변수-이름 필드라 위 dict 캐스팅을 거친
    // (PyFM 의 변수 치환이 이미 적용된) payload.return_variable_name 을 그대로 쓰면 안 된다 — 사용자가
    // 입력한 이름이 우연히 flow 안에 이미 선언된 다른 변수명과 같으면 그 변수의 값으로 치환돼버린다.
    // 이 필드는 4개 옵션 전부 READ 에서만 쓰고 WRITE/CONNECT 는 아예 안 읽으므로(program_interface.py
    // 원본도 동일), 덮어쓰기도 READ 분기 안에서만 한다 — WRITE/CONNECT 는 그대로(치환 포함) 둔다.
    if (option == "MODBUS_CLIENT") {
      auto* typed_payload = data.AsInterfaceModbusClientPayload();
      if (!typed_payload)
        throw std::runtime_error("Modbus Client failed: payload type mismatch");
      muscat::InterfaceModbusClientPayloadT& payload = *typed_payload;
      if (payload.server_ip.empty()) {
        if (flow_manager_args)
          flow_manager_args->done();
        return;
      }
      std::string op_type_str = payload.type;
      if (op_type_str == "READ") {

        if (flow_manager_args)
          if (auto raw = flow_manager_args->raw_data_field("return_variable_name"))
            payload.return_variable_name = *raw;
        rb_program_interface::execute_modbus_read(
            rpc, module_name, rb_glue::require(payload.server_ip, "server_ip", "Modbus Read failed"),
            rb_glue::require(payload.server_port, "server_port", "Modbus Read failed"),
            rb_glue::require(payload.function_code, "function_code", "Modbus Read failed"),
            rb_glue::require(payload.register_addr, "register_addr", "Modbus Read failed"),
            rb_glue::require(payload.number_of_read, "number_of_read", "Modbus Read failed"),
            rb_glue::require(payload.return_variable_name, "return_variable_name", "Modbus Read failed"),
            payload.resolve_option.empty() ? "SKIP" : payload.resolve_option, payload.timeout_sec.value_or(1.0),
            flow_manager_args, alarm_fn);
      } else if (op_type_str == "WRITE") {
        rb_program_interface::execute_modbus_write(
            rpc, module_name, rb_glue::require(payload.server_ip, "server_ip", "Modbus Write failed"),
            rb_glue::require(payload.server_port, "server_port", "Modbus Write failed"),
            rb_glue::require(payload.function_code, "function_code", "Modbus Write failed"),
            rb_glue::require(payload.register_addr, "register_addr", "Modbus Write failed"),
            _write_register_values(payload.payload), payload.resolve_option.empty() ? "SKIP" : payload.resolve_option,
            payload.timeout_sec.value_or(1.0), flow_manager_args, alarm_fn);
      } else
        throw std::runtime_error("Modbus Client failed: type must be READ or WRITE");
    } else if (option == "MC_PROTOCOL") {
      auto* typed_payload = data.AsInterfaceMcProtocolPayload();
      if (!typed_payload)
        throw std::runtime_error("MC Protocol failed: payload type mismatch");
      muscat::InterfaceMcProtocolPayloadT& payload = *typed_payload;
      if (payload.server_ip.empty()) {
        if (flow_manager_args)
          flow_manager_args->done();
        return;
      }
      std::string op_type_str = payload.type;
      if (op_type_str == "READ") {
        if (flow_manager_args)
          if (auto raw = flow_manager_args->raw_data_field("return_variable_name"))
            payload.return_variable_name = *raw;
        rb_program_interface::execute_mc_read(
            rpc, module_name, rb_glue::require(payload.server_ip, "server_ip", "MC Protocol Read failed"),
            rb_glue::require(payload.server_port, "server_port", "MC Protocol Read failed"),
            rb_glue::require(payload.register_addr, "register_addr", "MC Protocol Read failed"),
            rb_glue::require(payload.address_type, "address_type", "MC Protocol Read failed"),
            rb_glue::require(payload.protocol, "protocol", "MC Protocol Read failed"),
            rb_glue::require(payload.function_code, "function_code", "MC Protocol Read failed"),
            rb_glue::require(payload.number_of_read, "number_of_read", "MC Protocol Read failed"),
            rb_glue::require(payload.return_variable_name, "return_variable_name", "MC Protocol Read failed"),
            payload.resolve_option.empty() ? "SKIP" : payload.resolve_option, flow_manager_args, alarm_fn);
      } else if (op_type_str == "WRITE") {
        rb_program_interface::execute_mc_write(
            rpc, module_name, rb_glue::require(payload.server_ip, "server_ip", "MC Protocol Write failed"),
            rb_glue::require(payload.server_port, "server_port", "MC Protocol Write failed"),
            rb_glue::require(payload.register_addr, "register_addr", "MC Protocol Write failed"),
            rb_glue::require(payload.address_type, "address_type", "MC Protocol Write failed"),
            rb_glue::require(payload.protocol, "protocol", "MC Protocol Write failed"),
            rb_glue::require(payload.function_code, "function_code", "MC Protocol Write failed"),
            _write_register_values(payload.payload), payload.resolve_option.empty() ? "SKIP" : payload.resolve_option,
            flow_manager_args, alarm_fn);
      } else
        throw std::runtime_error("MC Protocol failed: type must be READ or WRITE");
    } else if (option == "XGT_PROTOCOL") {
      auto* typed_payload = data.AsInterfaceXgtProtocolPayload();
      if (!typed_payload)
        throw std::runtime_error("XGT Protocol failed: payload type mismatch");
      muscat::InterfaceXgtProtocolPayloadT& payload = *typed_payload;
      if (payload.server_ip.empty()) {
        if (flow_manager_args)
          flow_manager_args->done();
        return;
      }
      std::string op_type_str = payload.type;
      if (op_type_str == "READ") {
        if (flow_manager_args)
          if (auto raw = flow_manager_args->raw_data_field("return_variable_name"))
            payload.return_variable_name = *raw;
        rb_program_interface::execute_xgt_read(
            rpc, module_name, rb_glue::require(payload.server_ip, "server_ip", "XGT Protocol Read failed"),
            rb_glue::require(payload.server_port, "server_port", "XGT Protocol Read failed"),
            rb_glue::require(payload.register_addr, "register_addr", "XGT Protocol Read failed"),
            rb_glue::require(payload.cpu_type, "cpu_type", "XGT Protocol Read failed"),
            rb_glue::require(payload.device_type, "device_type", "XGT Protocol Read failed"),
            rb_glue::require(payload.function_code, "function_code", "XGT Protocol Read failed"),
            rb_glue::require(payload.number_of_read, "number_of_read", "XGT Protocol Read failed"),
            rb_glue::require(payload.return_variable_name, "return_variable_name", "XGT Protocol Read failed"),
            payload.resolve_option.empty() ? "SKIP" : payload.resolve_option, flow_manager_args, alarm_fn);
      } else if (op_type_str == "WRITE") {
        rb_program_interface::execute_xgt_write(
            rpc, module_name, rb_glue::require(payload.server_ip, "server_ip", "XGT Protocol Write failed"),
            rb_glue::require(payload.server_port, "server_port", "XGT Protocol Write failed"),
            rb_glue::require(payload.register_addr, "register_addr", "XGT Protocol Write failed"),
            rb_glue::require(payload.cpu_type, "cpu_type", "XGT Protocol Write failed"),
            rb_glue::require(payload.device_type, "device_type", "XGT Protocol Write failed"),
            rb_glue::require(payload.function_code, "function_code", "XGT Protocol Write failed"),
            _write_register_values(payload.payload), payload.resolve_option.empty() ? "SKIP" : payload.resolve_option,
            flow_manager_args, alarm_fn);
      } else
        throw std::runtime_error("XGT Protocol failed: type must be READ or WRITE");
    } else if (option == "SOCKET_INTERFACE") {
      auto* typed_payload = data.AsInterfaceSocketPayload();
      if (!typed_payload)
        throw std::runtime_error("Socket Interface failed: payload type mismatch");
      muscat::InterfaceSocketPayloadT& payload = *typed_payload;
      if (payload.server_ip.empty()) {
        if (flow_manager_args)
          flow_manager_args->done();
        return;
      }
      std::string op_type_str = payload.type;
      if (op_type_str == "READ") {
        if (flow_manager_args)
          if (auto raw = flow_manager_args->raw_data_field("return_variable_name"))
            payload.return_variable_name = *raw;
        rb_program_interface::execute_socket_read(
            rpc, module_name, rb_glue::require(payload.server_ip, "server_ip", "Socket Interface Read failed"),
            rb_glue::require(payload.server_port, "server_port", "Socket Interface Read failed"),
            rb_glue::require(payload.function_code, "function_code", "Socket Interface Read failed"),
            rb_glue::require(payload.return_variable_name, "return_variable_name", "Socket Interface Read failed"),
            payload.resolve_option.empty() ? "SKIP" : payload.resolve_option, payload.timeout_sec.value_or(1.0),
            flow_manager_args, alarm_fn);
      } else if (op_type_str == "WRITE") {
        rb_program_interface::execute_socket_write(
            rpc, module_name, rb_glue::require(payload.server_ip, "server_ip", "Socket Interface Write failed"),
            rb_glue::require(payload.server_port, "server_port", "Socket Interface Write failed"),
            rb_glue::require(payload.function_code, "function_code", "Socket Interface Write failed"),
            rb_glue::require(payload.payload, "payload", "Socket Interface Write failed"),
            payload.resolve_option.empty() ? "SKIP" : payload.resolve_option, flow_manager_args, alarm_fn);
      } else if (op_type_str == "CONNECT") {
        rb_program_interface::execute_socket_connect(
            rpc, module_name, rb_glue::require(payload.server_ip, "server_ip", "Socket Interface Connect failed"),
            rb_glue::require(payload.server_port, "server_port", "Socket Interface Connect failed"),
            payload.resolve_option.empty() ? "SKIP" : payload.resolve_option, flow_manager_args, alarm_fn);
      } else
        throw std::runtime_error("Socket Interface failed: type must be READ, WRITE, or CONNECT");
    } else {
      throw std::runtime_error("Interface failed: unsupported option=" + option);
    }

    if (flow_manager_args)
      flow_manager_args->done();
  }

  /**
   * Blocks until the requested wait condition is satisfied (or times out),
   * polling for stop requests every 10ms.
   *
   * @param robot_model Name of the robot model (used for DIGITAL_INPUT
   *        polling).
   * @param wait_type "TIME" (delegates to simple_wait()), "HOLDING" (wait
   *        while the condition holds), or "EXIT" (wait until the condition
   *        becomes true / the digital input matches).
   * @param mode "GENERAL" (evaluate @p flow_manager_args's "condition"
   *        expression) or "DIGITAL_INPUT" (poll get_digital_input() against
   *        @p digital_input's expected signal pattern).
   * @param second Wait duration in seconds, used only when @p wait_type is
   *        "TIME".
   * @param digital_input Digital input condition dict ("signal" list and
   *        optional "logical_operator", "AND" by default). Required when
   *        @p mode is "DIGITAL_INPUT".
   * @param time_out Optional timeout in seconds; the wait loop breaks once
   *        elapsed time reaches this value, regardless of whether the
   *        condition was satisfied.
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything — if omitted, returns immediately without
   *        waiting (despite the default of py::none(), calling this
   *        standalone is a no-op). The step is marked done once the wait
   *        loop exits.
   */
  void wait(const std::string& robot_model, const std::string& wait_type, const std::string& mode,
            std::optional<double> second, std::optional<ProgramDigitalInputCondition> digital_input,
            std::optional<double> time_out, FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!flow_manager_args)
      return;

    if (wait_type == "TIME") {
      simple_wait(second.value_or(0.0), flow_manager_args);
      return;
    }

    FlowManagerContext& ctx = flow_manager_args->context();
    const auto now = std::chrono::steady_clock::now();
    FlowValuePtr condition = flow_manager_args->arg("condition");
    const std::string logic_operator = digital_input ? digital_input->logical_operator : "AND";

    auto elapsed_sec = [&]() {
      return std::chrono::duration<double>(std::chrono::steady_clock::now() - now).count();
    };
    auto sleep_10ms = [&]() {
      rb_sdk::gil_release_if_held release;
      std::this_thread::sleep_for(std::chrono::milliseconds(10));
    };
    // exit_when_true: EXIT/GENERAL 은 조건이 참이면 탈출, HOLDING/GENERAL 은 거짓이면 탈출.
    const bool exit_when_true = (wait_type == "EXIT");

    // signal 이 응답과 일치하는지 (AND: 전부 일치해야 "일치", OR: 하나라도 일치하면 "일치").
    auto signal_matches = [&](const std::vector<int8_t>& res) -> bool {
      const auto& signal = digital_input->signal;
      if (logic_operator == "OR") {
        for (std::size_t i = 0; i < signal.size(); ++i) {
          if (signal[i] == -1)
            continue;
          if (i < res.size() && res[i] == signal[i])
            return true;
        }
        return false;
      }
      for (std::size_t i = 0; i < signal.size(); ++i) {
        if (signal[i] == -1)
          continue;
        if (i >= res.size() || res[i] != signal[i])
          return false;
      }
      return true;
    };

    if (mode == "DIGITAL_INPUT" && !digital_input)
      throw std::runtime_error("digital_input is required");

    while (true) {
      ctx.check_stop();

      bool should_break = false;
      if (mode == "GENERAL") {
        bool truthy = condition && ctx.eval_bool(condition);
        should_break = (truthy == exit_when_true);
      } else if (mode == "DIGITAL_INPUT") {
        auto res = get_digital_input(robot_model);
        if (!res)
          break;
        should_break = (signal_matches(*res) == exit_when_true);
      }
      if (should_break)
        break;
      if (time_out && elapsed_sec() >= *time_out)
        break;
      sleep_10ms();
    }

    fm_done(flow_manager_args);
  }

  /**
   * Changes the running program and immediately starts it (program.py::change_program).
   *
   * Sends a Request_Change_Program to the "muscat/change/program" queryable
   * and waits (up to 20s — the handler can take several seconds) for a
   * ResponseProgramExecution. Either @p program_id or @p program_name must
   * be given.
   *
   * @param program_id Target program id (mutually optional with @p program_name).
   * @param program_name Target program name.
   * @param flow_manager_args PyFM step context. Required — raises if omitted.
   *        The step is marked done once the change is accepted.
   *
   * @throws std::runtime_error If @p flow_manager_args is omitted, if
   *         neither @p program_id nor @p program_name is given, or if the
   *         change/start request gets no (usable) reply.
   */
  void change_program(std::optional<std::string> program_id, std::optional<std::string> program_name,
                      FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!flow_manager_args)
      throw std::runtime_error("This is the function that needs to be executed via PyFM.");
    if (!program_id && !program_name)
      throw std::runtime_error("Either program_id or program_name is required.");

    muscat::Request_Change_ProgramT req;
    if (program_id)
      req.program_id = *program_id;
    if (program_name)
      req.program_name = *program_name;

    std::unique_ptr<muscat::ResponseProgramExecutionT> res;
    try {
      // 핸들러 reply 까지 수 초 걸릴 수 있어 timeout 을 20s 로 (Python 원본과 동일).
      res = query_one<muscat::ResponseProgramExecution, muscat::Request_Change_ProgramT>("muscat/change/program", req,
                                                                                         128, 20000, 0);
    } catch (const rb_zenoh::ZenohNoReply&) {
      throw std::runtime_error("The requests to change and start the program have failed.");
    } catch (const rb_zenoh::ZenohReplyError&) {
      throw std::runtime_error("The requests to change and start the program have failed.");
    }
    if (!res)
      throw std::runtime_error("The requests to change and start the program have failed.");

    flow_manager_args->done();
  }

  // ---------------------------------------------------------------------
  // Event tree / plugin
  // ---------------------------------------------------------------------
  //
  // call_event_tree 는 rb_flow_manager.step.Step (Python 런타임 클래스) 리스트를 직접
  // 받아야 해서 이 순수 C++ 헤더에 없다 — binding/glue/event_tree.hpp::call_event_tree
  // 자유함수로 옮겼다.

  // plugin_id 별 동시 실행 방지 락 (Python _plugin_execute_locks 대응, 상단 주석 참고).
  static std::mutex& _plugin_execute_lock_for(const std::string& plugin_id) {
    static std::mutex map_mutex;
    static std::unordered_map<std::string, std::unique_ptr<std::mutex>> locks;

    std::lock_guard<std::mutex> guard(map_mutex);
    auto it = locks.find(plugin_id);
    if (it == locks.end()) {
      it = locks.emplace(plugin_id, std::make_unique<std::mutex>()).first;
    }
    return *it->second;
  }

  /**
   * Sends an execute request to a plugin process and waits until it reports
   * completion (or stop). Concurrent calls for the same @p plugin_id are
   * serialized so their control queryables don't collide.
   *
   * @param plugin_id Target plugin id; the request is sent to
   *        "muscat/plugin/{plugin_id}/execute" and control messages are
   *        exchanged over "muscat/plugin/{plugin_id}/control".
   * @param user_args Execute request JSON object (Python 바인딩은 `**kwargs` 를 여기로 모아 넘긴다).
   * @param flow_manager_args PyFM step context. Required; the step is marked
   *        done once the plugin reports "done" (directly, or by exiting its
   *        control loop after "stop").
   *
   * @throws std::runtime_error If @p flow_manager_args is not provided, or
   *         if the plugin is not running/responding to the execute request.
   */
  void plugin_execute(const std::string& plugin_id, FlowManagerArgsPtr flow_manager_args = nullptr,
                      const nlohmann::json& user_args = nlohmann::json::object()) {
    if (!flow_manager_args)
      throw std::runtime_error("plugin_execute requires flow_manager_args");

    std::mutex& plugin_lock = _plugin_execute_lock_for(plugin_id);
    std::lock_guard<std::mutex> guard(plugin_lock);
    _plugin_execute_locked(plugin_id, flow_manager_args, user_args);
  }

 private:
  void _plugin_execute_locked(const std::string& plugin_id, const FlowManagerArgsPtr& flow_manager_args,
                              const nlohmann::json& user_args) {
    // control_handler 는 zenoh 워커 스레드에서 불린다. _plugin_execute_locked 는 done_flag 까지
    // 블로킹하므로 flow_manager_args(및 그 어댑터) 가 그동안 살아있다 — raw 포인터로 캡처해
    // shared_ptr refcount 를 워커 스레드로 넘기지 않는다.
    FlowManagerContext* ctx = &flow_manager_args->context();
    std::string control_topic = "muscat/plugin/" + plugin_id + "/control";

    auto done_flag = std::make_shared<std::atomic<bool>>(false);
    auto last_stop = std::make_shared<std::atomic<bool>>(false);

    rb_zenoh::QueryHandler control_handler =
        [ctx, done_flag, last_stop, plugin_id](std::string /*key*/, std::string /*params*/,
                                               std::optional<std::vector<uint8_t>> payload, std::string /*attachment*/,
                                               rb_zenoh::ReplyFn reply_fn, rb_zenoh::DelFn /*del_fn*/) {
          nlohmann::json payload_d = _json_from_bytes(payload, "plugin control");
          std::string action = _json_get_string(payload_d, "action").value_or("");
          nlohmann::json result = nlohmann::json::object();

          if (action == "get_variable") {
            std::string name = _json_get_string(payload_d, "name").value_or("");
            std::optional<nlohmann::json> value = ctx->lookup_local_or_global_json(name);
            result["ok"] = true;
            result["value"] = value ? *value : nlohmann::json(nullptr);
          } else if (action == "set_variable") {
            std::string name = _json_get_string(payload_d, "name").value_or("");
            nlohmann::json value = payload_d.contains("value") ? payload_d["value"] : nlohmann::json(nullptr);

            // 상시 경로(set_runtime_variable) / program.py::_control_handler 와 동일 규칙:
            // 기존 변수 수정은 이름 그대로 통과, 없는 변수 생성은 RBP_ prefix 강제.
            bool exists = ctx->lookup_local_or_global_json(name).has_value();
            if (!exists && name.rfind("RBP_", 0) != 0) {
              result["ok"] = false;
              result["error"] = "new plugin variable must start with 'RBP_': " + name;
            } else {
              nlohmann::json update = nlohmann::json::object({{name, value}});
              ctx->update_local_variables_json(update);  // 자기 트리 즉시 반영

              // 플러그인별 마지막 쓴 값 기록 → get_var("{plugin_id}", name) 조회용
              nlohmann::json writer_meta =
                  nlohmann::json::object({{"writers", nlohmann::json::object({{plugin_id, value}})}});
              ctx->merge_variable_meta_json(name, writer_meta);

              // 플러그인 변수는 로봇에 안 묶임 — 다른 main task 에도 broadcast
              ctx->broadcast_variables_to_other_mains_json(update, nlohmann::json::object({{name, writer_meta}}));

              result["ok"] = true;
            }
          } else if (action == "pause") {
            ctx->pause();
            result["ok"] = true;
          } else if (action == "stop") {
            last_stop->store(true);
            ctx->stop();
            done_flag->store(true);
            result["ok"] = true;
          } else if (action == "done") {
            done_flag->store(true);
            result["ok"] = true;
          } else {
            done_flag->store(true);
            result["ok"] = false;
            result["error"] = "unknown action: " + action;
          }

          std::vector<uint8_t> reply_bytes = _json_to_bytes(result);
          reply_fn("", reply_bytes, "", "application/json", false);
        };

    // base.hpp::zenoh_queryable() 는 topic 만 zenoh_queryables 셋에 기록하고 declare_queryable() 이
    // 돌려주는 int id 를 버린다 — undeclare 하려면 id 가 필요하므로, 여기서는 RBBaseSDK::zenoh_client_
    // (protected 멤버, declare_queryable/undeclare_queryable 는 rb_zenoh::ZenohClient 의 public API)를
    // 직접 호출해 id 를 붙잡아둔다.
    int queryable_id = RBBaseSDK::zenoh_client_->declare_queryable(control_topic, control_handler);

    try {
      try {
        nlohmann::json payload_d = user_args.is_null() ? nlohmann::json::object() : user_args;
        if (!payload_d.is_object())
          throw std::runtime_error("plugin_execute user_args must be a JSON object");
        std::vector<uint8_t> req_bytes = _json_to_bytes(payload_d);
        query_one(std::string("muscat/plugin/") + plugin_id + "/execute", req_bytes, 5000, 0);
      } catch (const std::runtime_error& exc) {
        throw std::runtime_error("plugin '" + plugin_id + "' not running or not responding: " + exc.what());
      }

      // 0.5초마다 폴링해서 외부 stop 을 빠르게 감지한다.
      while (!done_flag->load()) {
        {
          rb_sdk::gil_release_if_held release;
          std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }
        if (ctx->stop_requested())
          break;
        if (done_flag->load())
          break;
      }
    } catch (...) {
      RBBaseSDK::zenoh_client_->undeclare_queryable(queryable_id);
      throw;
    }
    RBBaseSDK::zenoh_client_->undeclare_queryable(queryable_id);

    if (last_stop->load() || ctx->stop_requested())
      ctx->check_stop();

    flow_manager_args->done();
  }

 public:
  /**
   * Disconnects every RpcManager module cached in rpc_managers_ before the
   * SDK instance is closed.
   */
  void before_close() override {
    std::cout << "[RBProgramSDK] before_close() called, disconnecting all RpcManagers..." << std::endl;
    rpc_managers_.disconnect_all();
  }

 private:
  // program 도메인 전용 (RpcManagerRegistry 주석 참고) - VisionClientRegistry 처럼 RBBaseSDK 공용으로
  // 두지 않고 RBProgramSDK 가 직접 소유한다.
  RpcManagerRegistry rpc_managers_;

  inline static RpcLogSink rpc_log_sink_ = nullptr;
};
