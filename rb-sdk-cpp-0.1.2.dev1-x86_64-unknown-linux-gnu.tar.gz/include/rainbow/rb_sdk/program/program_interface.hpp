#pragma once

// program_interface.py -> program_interface.hpp 1차 포팅 초안 (draft).
//
// manipulate_vision.hpp 구조 참고: manipulate_vision.py 는 이미 Python 단계에서 벤더 클라이언트
// 호출을 "연결 확인 -> call_fn 호출/예외처리 -> 실패 시 resolve_interface_flow -> 성공 시 ctx
// 변수 반영 -> done()" 공통 wrapper(_run_mechmind_read_call / _run_mechmind_write_call /
// _run_photoneo_client_call)로 묶어뒀고, vision.hpp 는 그 구조를 그대로 C++ 로 옮겼다.
//
// program_interface.py 는 반대로 이 tail 부분(resolve_interface_flow 판정 + 변수 반영 + done())을
// 8개 execute_* 함수에 그대로 복붙해뒀다. 다만 vision 과 달리 여기서는 벤더가 3개(MechMind/
// Photoneo/Pickit)로 갈려 성공 판정 로직이 제각각인 것과 달리, client_modules.pyi 를 보면
// RpcResult.success 가 Modbus/MC/XGT/Socket(recv/send) 전부 균일하다(connect_sock 만 예외적으로
// bool 을 직접 리턴). 그래서 vision.hpp 처럼 벤더별로 wrapper 를 나누지 않고 공통 tail 하나
// (_finish_protocol_call)로 합쳤다.
//
// return_variable_name(4개 read 함수 공통)은 이 파일에서 직접 조회하지 않는다 — PyFM 의 변수 치환이
// "결과를 어디에 쓸지" 지정하는 이 필드까지 값 내용만 보고 덮어써버릴 수 있어서
// (flow_manager_args.hpp::raw_data_field 주석 참고), 호출부인 RBProgramSDK::interface() 가 dict->struct
// 캐스팅 직후 원본(raw) 값으로 payload.return_variable_name 을 미리 덮어쓰고, require() 로 뽑아낸 값을
// 이 파일의 explicit return_variable_name 파라미터로 그대로 넘겨준다.
//
// rpc 파라미터: lib/Client_Module/rb_comm_source/rpc_manager.cpp 가 native C++ 소스로 rb_sdk 에
// 직접 추가되면서(CMakeLists.txt add_subdirectory), 예전에 여기 있던 client_modules.hpp
// (py::module_::import("rb_sdk.program_sdk.client_modules") 브리지, 이 아키텍처용 prebuilt .so 가
// 없으면 기능을 죽이던 fallback)를 걷어내고 rb_program_sdk.hpp::RpcManagerRegistry 가 들고 있는
// 실제 RpcManager& 를 그대로 받는다. vision 벤더 클라이언트(mechmind/photoneo/pickit)는 manipulate
// 뿐 아니라 다른 도메인도 재사용할 근거가 있어 base.hpp::VisionClientRegistry 로 공용화됐지만,
// client_modules.RpcManager 는 python 원본(program_sdk/*)에서도 program 도메인 전용이었어서
// RpcManagerRegistry 는 base.hpp 가 아니라 RBProgramSDK 가 직접 소유한다(rb_program_sdk.hpp 참고).
// McDeviceType/McFrameType/... 등 enum 리졸버도 rb_client_modules::attr(...) 대신 rpc_manager.h 가
// transitively 끌어오는 네이티브 enum(mc_types.h/xgt_types.h/modbus_types.h)을 직접 반환한다.
//
// Boundary contract (intentional): PyFM 이 dict 로 넘기는 RBProgramSDK::interface() 는 지금도
// dict->struct(muscat::Interface*PayloadT) 캐스팅과
// require()/resolve_option_of() 를 거쳐 "필수인데 없음"을 검증한 뒤, 이 파일의 explicit 파라미터로
// 풀어서 넘긴다 — vision.hpp::execute_mechmind_trigger_and_get_poses 와 동일한 스타일로, 이 파일의
// execute_* 함수들은 struct/dict 를 직접 받지 않고 개별 타입 있는 파라미터만 받는다(pybind11/향후
// 다른 언어 바인딩에서도 시그니처만 보고 계약을 알 수 있게). WRITE payload 는 순수 C++ DTO
// rb_payload::WriteRegisterValues 로 받는다 — bool 거부/혼합·중첩 리스트 평탄화는
// interface_payload_caster.hpp 의 type_caster 가 하고, 여기 _validate_payload_field 는
// 범위/길이/allowed 만 본다.
//
// flow_manager_args(FlowManagerArgsPtr, nullptr 면 단독 호출): 이 파일은 pybind 에 의존하지
// 않는다. PyFM step context 는 flow_manager_args.hpp 의 FlowManagerArgs/FlowManagerContext
// 가상 브릿지로 직접 만진다(flow_manager_args->done(), ->context().update_local_variables(...) 등;
// 구현체는 pybind 경계 binding/glue/flow_manager_caster.hpp). 실패 처리 정책은
// flow_manager_args.hpp::resolve_interface_flow 하나를 공유한다. 블로킹 rpc 왕복 동안의 GIL
// 해제는 binding/glue/gil_release.hpp 의 rb_sdk::gil_release_if_held (바인딩이 훅 주입, 순수 C++ 은 no-op).
//

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

#include "flow_manager_args.hpp"
#include "binding/glue/gil_release.hpp"
#include "interface_payload_schema.hpp"
#include "rpc_manager.h"
#include "common/value_validation.hpp"

namespace rb_program_interface {

// ---------------------------------------------------------------------------
// client_modules 열거형 리졸버 (program_interface.py 의 모듈 전역 _resolve_* 함수 대응)
// ---------------------------------------------------------------------------

inline std::string _to_upper(const std::string& s) {
  std::string r = s;
  for (auto& c : r)
    c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
  return r;
}

inline McDeviceType _resolve_mc_device(const std::string& address_type) {
  std::string normalized = _to_upper(address_type);
  if (normalized == "1" || normalized == "D")
    return McDeviceType::D;
  if (normalized == "2" || normalized == "M")
    return McDeviceType::M;
  if (normalized == "3" || normalized == "X")
    return McDeviceType::X;
  if (normalized == "4" || normalized == "Y")
    return McDeviceType::Y;
  throw std::runtime_error("MC Protocol failed: unsupported address_type=" + address_type);
}

inline McFrameType _resolve_mc_frame(const std::string& protocol) {
  std::string normalized = _to_upper(protocol);
  if (normalized == "1" || normalized == "MC_1E")
    return McFrameType::MC_1E;
  if (normalized == "2" || normalized == "MC_3E")
    return McFrameType::MC_3E;
  throw std::runtime_error("MC Protocol failed: unsupported protocol=" + protocol);
}

inline McCommandType _resolve_mc_command(int function_code) {
  switch (function_code) {
    case 1:
      return McCommandType::read_bit;
    case 2:
      return McCommandType::read_word;
    case 3:
      return McCommandType::write_bit;
    case 4:
      return McCommandType::write_word;
    default:
      throw std::runtime_error("MC Protocol failed: unsupported function_code=" + std::to_string(function_code));
  }
}

inline XgtCPUinfo _resolve_xgt_cpu(const std::string& cpu_type) {
  std::string normalized = _to_upper(cpu_type);
  if (normalized == "XGK")
    return XgtCPUinfo::XGK;
  if (normalized == "XGI")
    return XgtCPUinfo::XGI;
  if (normalized == "XBC")
    return XgtCPUinfo::XBC;
  if (normalized == "XEC")
    return XgtCPUinfo::XEC;
  if (normalized == "NONE")
    return XgtCPUinfo::NONE;
  throw std::runtime_error("XGT Protocol failed: unsupported cpu_type=" + cpu_type);
}

inline XgtDeviceType _resolve_xgt_device(const std::string& device_type) {
  std::string normalized = _to_upper(device_type);
  if (normalized == "DB")
    return XgtDeviceType::DB;
  throw std::runtime_error("XGT Protocol failed: unsupported device_type=" + device_type);
}

inline XgtCommand _resolve_xgt_command(int function_code) {
  switch (function_code) {
    case 1:
      return XgtCommand::read_byte;
    case 2:
      return XgtCommand::read_word;
    case 3:
      return XgtCommand::write_byte;
    case 4:
      return XgtCommand::write_word;
    default:
      throw std::runtime_error("XGT Protocol failed: unsupported function_code=" + std::to_string(function_code));
  }
}

// ---------------------------------------------------------------------------
// payload 파싱 헬퍼 (program_interface.py 모듈 전역 _parse_bytes_payload 등 대응)
// ---------------------------------------------------------------------------

inline std::vector<int> _parse_bytes_payload(const std::string& payload, const std::string& split,
                                             const std::string& error_prefix) {
  std::vector<int> result;
  size_t start = 0;
  while (start <= payload.size()) {
    size_t pos = payload.find(split, start);
    std::string token = payload.substr(start, pos == std::string::npos ? std::string::npos : pos - start);

    // strip whitespace
    size_t a = token.find_first_not_of(" \t\r\n");
    size_t b = token.find_last_not_of(" \t\r\n");
    token = (a == std::string::npos) ? "" : token.substr(a, b - a + 1);

    if (!token.empty()) {
      int v;
      try {
        size_t consumed = 0;
        v = std::stoi(token, &consumed);
        if (consumed != token.size())
          throw std::invalid_argument("trailing chars");
      } catch (const std::exception&) {
        throw std::runtime_error(error_prefix + ": payload value '" + token + "' is not a valid integer");
      }
      if (v < 0 || v > 255) {
        throw std::runtime_error(error_prefix + ": payload value " + std::to_string(v) +
                                 " is out of byte range [0, 255]");
      }
      result.push_back(v);
    }

    if (pos == std::string::npos)
      break;
    start = pos + split.size();
  }

  if (result.empty())
    throw std::runtime_error(error_prefix + ": payload is empty after splitting");
  return result;
}

inline std::vector<int> _encode_ascii_payload(const std::string& value, const std::string& error_prefix) {
  std::vector<int> result;
  result.reserve(value.size());
  for (unsigned char c : value) {
    if (c > 127)
      throw std::runtime_error(error_prefix + ": payload must contain ASCII characters only");
    result.push_back(static_cast<int>(c));
  }
  return result;
}

// bool 거부 + 혼합/중첩 리스트 평탄화는 interface_payload_caster.hpp 의
// type_caster<rb_payload::WriteRegisterValues> 가 이미 끝냈다. 여기서는 "필수인데 없음" +
// 길이(1~40) + 범위/allowed 검증만 한다(호출부별 파라미터).
inline std::vector<int> _validate_payload_field(const std::optional<rb_payload::WriteRegisterValues>& payload_field,
                                                const std::string& error_prefix,
                                                std::optional<int> min_val = std::nullopt,
                                                std::optional<int> max_val = std::nullopt,
                                                std::optional<std::vector<int>> allowed_values = std::nullopt) {
  if (!payload_field)
    throw std::runtime_error(error_prefix + ": payload is required");

  std::vector<int> payload(payload_field->values.begin(), payload_field->values.end());

  if (payload.empty() || payload.size() > 40) {
    throw std::runtime_error(error_prefix + ": payload length must be between 1 and 40");
  }

  if (allowed_values) {
    for (int v : payload) {
      bool ok = false;
      for (int a : *allowed_values) {
        if (a == v) {
          ok = true;
          break;
        }
      }
      if (!ok)
        throw std::runtime_error(error_prefix + ": payload value " + std::to_string(v) + " is invalid");
    }
  } else if (min_val || max_val) {
    for (int v : payload) {
      if ((min_val && v < *min_val) || (max_val && v > *max_val)) {
        throw std::runtime_error(error_prefix + ": payload value " + std::to_string(v) + " is out of range");
      }
    }
  }

  return payload;
}

// ---------------------------------------------------------------------------
// resolve_option/timeout_sec 검증 헬퍼. 이 파일의 execute_* 는 이제 explicit 파라미터를 직접 받으므로
// "필수인데 없음" 판정(require)은 호출부인 RBProgramSDK::interface() 가 struct 필드에서 값을 뽑아낼 때
// 이미 끝낸다 — 여기서는 resolve_option 값 검증("SKIP"/"STOP"/"ASK")과 timeout_sec(초)->timeout_ms
// 변환만 필요해서 resolve_option_of/timeout_ms_of 만 갖다 쓴다. 둘 다 manipulate_vision.hpp 와 공유하는
// common/value_validation.hpp 헬퍼다.
// ---------------------------------------------------------------------------
using rb_glue::resolve_option_of;
using rb_glue::timeout_ms_of;

// ---------------------------------------------------------------------------
// 공통 wrapper (manipulate_vision.hpp::_run_mechmind_write_call 등과 동일한 역할)
// ---------------------------------------------------------------------------

// bytes(raw).decode("utf-8") 가 성공할지 검사하는 순수 C++ 포팅 (원본 execute_socket_read 는
// py bytes.decode 를 써서 실패 시 UnicodeDecodeError 를 잡았다). overlong/surrogate/범위초과를
// python 과 동일하게 엄격히 거부한다.
inline bool _is_valid_utf8(const std::string& s) {
  size_t i = 0;
  const size_t n = s.size();
  while (i < n) {
    const unsigned char c = static_cast<unsigned char>(s[i]);
    size_t extra;
    uint32_t cp;
    if (c < 0x80) {
      extra = 0;
      cp = c;
    } else if ((c >> 5) == 0x6) {
      extra = 1;
      cp = c & 0x1Fu;
    } else if ((c >> 4) == 0xE) {
      extra = 2;
      cp = c & 0x0Fu;
    } else if ((c >> 3) == 0x1E) {
      extra = 3;
      cp = c & 0x07u;
    } else {
      return false;
    }
    if (i + extra >= n)
      return false;
    for (size_t k = 1; k <= extra; ++k) {
      const unsigned char cc = static_cast<unsigned char>(s[i + k]);
      if ((cc >> 6) != 0x2)
        return false;
      cp = (cp << 6) | (cc & 0x3Fu);
    }
    if (extra == 1 && cp < 0x80u)
      return false;
    if (extra == 2 && cp < 0x800u)
      return false;
    if (extra == 3 && cp < 0x10000u)
      return false;
    if (cp > 0x10FFFFu || (cp >= 0xD800u && cp <= 0xDFFFu))
      return false;
    i += extra + 1;
  }
  return true;
}

// 실패 시 resolve_interface_flow, 성공 시(variables 가 있으면) ctx 변수 반영 후 done().
// success 판정은 client_modules API 마다 형태가 달라(RpcResult.success 인지, connect_sock 처럼
// bool 을 직접 리턴하는지) 호출부에서 이미 계산해 넘긴다 — vision.hpp 가 벤더별로 성공 판정을
// call_fn 안에서 계산해 result 와 함께 넘기던 것과 같은 이유다.
inline void _finish_protocol_call(bool success, const std::string& resolve_option,
                                  const FlowManagerArgsPtr& flow_manager_args, const AlarmFn& alarm_fn,
                                  const std::string& error_prefix, const FlowVariables& variables = {}) {
  if (!success)
    resolve_interface_flow(error_prefix, resolve_option, flow_manager_args, alarm_fn, error_prefix);

  if (!flow_manager_args)
    return;
  if (!variables.empty())
    flow_manager_args->context().update_local_variables(variables);
  flow_manager_args->done();
}

// ---------------------------------------------------------------------------
// execute_* (program_interface.py 모듈 전역 함수 대응)
// ---------------------------------------------------------------------------

/**
 * @brief Reads Modbus holding or input registers.
 *
 * @p function_code selects the register type: 3 reads holding registers
 * (READ_HOLDING), 4 reads input registers (READ_INPUT).
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip Modbus server IP address.
 * @param server_port Modbus server port.
 * @param function_code 3 (READ_HOLDING) or 4 (READ_INPUT).
 * @param register_addr Starting register address to read from.
 * @param number_of_read Number of registers to read.
 * @param return_variable_name PyFM variable name that will receive the
 *        read registers (@c RpcResult::regs).
 * @param resolve_option How to handle a failed read — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param timeout_sec Read timeout in seconds. Defaults to 1.0.
 * @param flow_manager_args Optional PyFM step context. @p
 *        return_variable_name is written into its context and
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the read failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call (success flag plus the read
 *         registers in @c regs).
 *
 * @throws std::runtime_error If @p function_code is not 3 or 4; and,
 *         under "STOP", if the read fails.
 */
inline RpcResult execute_modbus_read(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                     int server_port, int function_code, int register_addr, int number_of_read,
                                     const std::string& return_variable_name,
                                     const std::string& resolve_option = "SKIP", double timeout_sec = 1.0,
                                     FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
  const std::string error_prefix = "Modbus Read failed";
  int timeout_ms = timeout_ms_of(timeout_sec, 1.0);
  std::string resolved_resolve_option = resolve_option_of(resolve_option, error_prefix);

  if (function_code != 3 && function_code != 4)
    throw std::runtime_error(error_prefix + ": invalid function_code");

  ModbusFunction type = (function_code == 3) ? ModbusFunction::READ_HOLDING : ModbusFunction::READ_INPUT;

  // rpc 왕복은 fut.get() 으로 블로킹한다 - GIL 을 놓아야 worker 스레드가 (GIL 을 다시 잡아야
  // 하는) 로그 콜백을 실행할 수 있다(gil_release_if_held).
  RpcResult result;
  {
    rb_sdk::gil_release_if_held _g;
    result = rpc.read_modbus(module_name, server_ip, server_port, type, register_addr, number_of_read, timeout_ms);
  }

  FlowVariables variables;
  variables.emplace(return_variable_name,
                    FlowVariableValue{std::vector<int64_t>(result.regs.begin(), result.regs.end())});

  _finish_protocol_call(result.success, resolved_resolve_option, flow_manager_args, alarm_fn, error_prefix, variables);
  return result;
}

/**
 * @brief Writes Modbus holding registers.
 *
 * @p function_code selects the write mode: 6 writes a single register
 * (WRITE_SINGLE_REG), 16 writes multiple registers (WRITE_MULTI_REGS).
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip Modbus server IP address.
 * @param server_port Modbus server port.
 * @param function_code 6 (WRITE_SINGLE_REG) or 16 (WRITE_MULTI_REGS).
 * @param register_addr Starting register address to write to.
 * @param payload_field List of register values to write (1-40 entries,
 *        each in [0, 65535]).
 * @param resolve_option How to handle a failed write — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param timeout_sec Write timeout in seconds. Defaults to 1.0.
 * @param flow_manager_args Optional PyFM step context.
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the write failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call.
 *
 * @throws std::runtime_error If @p function_code is not 6 or 16, or
 *         @p payload_field is missing/out of range; and, under "STOP",
 *         if the write fails.
 */
inline RpcResult execute_modbus_write(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                      int server_port, int function_code, int register_addr,
                                      const std::optional<rb_payload::WriteRegisterValues>& payload_field,
                                      const std::string& resolve_option = "SKIP", double timeout_sec = 1.0,
                                      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
  const std::string error_prefix = "Modbus Write failed";
  int timeout_ms = timeout_ms_of(timeout_sec, 1.0);
  std::string resolved_resolve_option = resolve_option_of(resolve_option, error_prefix);

  if (function_code != 6 && function_code != 16)
    throw std::runtime_error(error_prefix + ": invalid function_code");

  std::vector<int> payload_ints = _validate_payload_field(payload_field, error_prefix, 0, 65535);
  std::vector<uint16_t> payload(payload_ints.begin(), payload_ints.end());
  ModbusFunction type = (function_code == 6) ? ModbusFunction::WRITE_SINGLE_REG : ModbusFunction::WRITE_MULTI_REGS;

  RpcResult result;
  {
    rb_sdk::gil_release_if_held _g;
    result = rpc.write_modbus(module_name, server_ip, server_port, type, register_addr, std::vector<uint8_t>{}, payload,
                              timeout_ms);
  }

  _finish_protocol_call(result.success, resolved_resolve_option, flow_manager_args, alarm_fn, error_prefix);
  return result;
}

/**
 * @brief Reads MC (Mitsubishi) protocol device values.
 *
 * @p function_code selects the command: 1 reads bit devices (read_bit),
 * 2 reads word devices (read_word). @p address_type and @p protocol
 * resolve the target McDeviceType and McFrameType respectively. The
 * result is always taken from @c RpcResult::data_word — unlike the
 * Python original's `data_word or data_bit` fallback, a bit read does
 * not fall back to @c data_bit (matches the current C++ behavior).
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip MC server IP address.
 * @param server_port MC server port.
 * @param register_addr Starting device address to read from.
 * @param address_type Device type: "1"/"D", "2"/"M", "3"/"X", or "4"/"Y".
 * @param protocol MC frame type: "1"/"MC_1E" or "2"/"MC_3E".
 * @param function_code 1 (read_bit) or 2 (read_word).
 * @param number_of_read Number of devices to read.
 * @param return_variable_name PyFM variable name that will receive the
 *        read values (@c RpcResult::data_word).
 * @param resolve_option How to handle a failed read — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param flow_manager_args Optional PyFM step context. @p
 *        return_variable_name is written into its context and
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the read failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call (success flag plus the read
 *         values in @c data_word).
 *
 * @throws std::runtime_error If @p function_code is not 1 or 2, or
 *         @p address_type/@p protocol cannot be resolved; and, under
 *         "STOP", if the read fails.
 */
inline RpcResult execute_mc_read(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                 int server_port, int register_addr, const std::string& address_type,
                                 const std::string& protocol, int function_code, int number_of_read,
                                 const std::string& return_variable_name, const std::string& resolve_option = "SKIP",
                                 FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
  const std::string error_prefix = "MC Protocol Read failed";
  McDeviceType mc_device = _resolve_mc_device(address_type);
  McFrameType frame = _resolve_mc_frame(protocol);
  McCommandType cmd = _resolve_mc_command(function_code);
  std::string resolved_resolve_option = resolve_option_of(resolve_option, error_prefix);

  if (function_code != 1 && function_code != 2)
    throw std::runtime_error(error_prefix + ": invalid function_code");

  // request_mc() 는 write_word/write_bit 를 non-const 참조로 받는다(rpc_manager.h) - read 호출은
  // 빈 벡터를 lvalue 로 넘겨야 한다(임시객체 바인딩 불가).
  std::vector<int16_t> write_word;
  std::vector<uint8_t> write_bit;
  RpcResult result;
  {
    rb_sdk::gil_release_if_held _g;
    result =
        rpc.request_mc(module_name, server_ip, server_port, frame, cmd, mc_device, static_cast<uint32_t>(register_addr),
                       static_cast<uint16_t>(number_of_read), write_word, write_bit);
  }

  // Python 원본 client_modules.RpcResult 는 data_word/data_bit 모두 항상 존재하는 필드라(리스트가
  // 비어있을 뿐 None 이 아님) return_variable_name 은 항상 data_word 로 채워졌다 - bit 읽기여도
  // data_bit 로 폴백하지 않는 게 기존 동작이라 그대로 유지한다.
  FlowVariables variables;
  variables.emplace(return_variable_name,
                    FlowVariableValue{std::vector<int64_t>(result.data_word.begin(), result.data_word.end())});

  _finish_protocol_call(result.success, resolved_resolve_option, flow_manager_args, alarm_fn, error_prefix, variables);
  return result;
}

/**
 * @brief Writes MC (Mitsubishi) protocol device values.
 *
 * @p function_code selects the command: 3 writes bit devices (write_bit,
 * @p payload_field values restricted to 0/1), 4 writes word devices
 * (write_word, @p payload_field values restricted to
 * [-32768, 32767]). @p address_type also determines which native buffer
 * the payload is sent through: "1"/"D" (word device) uses write_word,
 * "2"/"3"/"4" or "M"/"X"/"Y" (bit devices) use write_bit.
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip MC server IP address.
 * @param server_port MC server port.
 * @param register_addr Starting device address to write to.
 * @param address_type Device type: "1"/"D", "2"/"M", "3"/"X", or "4"/"Y".
 * @param protocol MC frame type: "1"/"MC_1E" or "2"/"MC_3E".
 * @param function_code 3 (write_bit) or 4 (write_word).
 * @param payload_field List of values to write (1-40 entries), range
 *        depends on @p function_code as described above.
 * @param resolve_option How to handle a failed write — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param flow_manager_args Optional PyFM step context.
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the write failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call.
 *
 * @throws std::runtime_error If @p function_code is not 3 or 4, @p
 *         address_type/@p protocol cannot be resolved, or @p
 *         payload_field is missing/out of range; and, under "STOP", if
 *         the write fails.
 */
inline RpcResult execute_mc_write(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                  int server_port, int register_addr, const std::string& address_type,
                                  const std::string& protocol, int function_code,
                                  const std::optional<rb_payload::WriteRegisterValues>& payload_field,
                                  const std::string& resolve_option = "SKIP",
                                  FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
  const std::string error_prefix = "MC Protocol Write failed";
  std::string normalized_address_type = _to_upper(address_type);
  McDeviceType mc_device = _resolve_mc_device(address_type);
  McFrameType frame = _resolve_mc_frame(protocol);
  McCommandType cmd = _resolve_mc_command(function_code);
  std::string resolved_resolve_option = resolve_option_of(resolve_option, error_prefix);

  if (function_code != 3 && function_code != 4)
    throw std::runtime_error(error_prefix + ": invalid function_code");

  std::vector<int> payload = (function_code == 4) ? _validate_payload_field(payload_field, error_prefix, -32768, 32767)
                                                  : _validate_payload_field(payload_field, error_prefix, std::nullopt,
                                                                            std::nullopt, std::vector<int>{0, 1});

  bool is_word = (normalized_address_type == "1" || normalized_address_type == "D");
  bool is_bit = (normalized_address_type == "2" || normalized_address_type == "3" || normalized_address_type == "4" ||
                 normalized_address_type == "M" || normalized_address_type == "X" || normalized_address_type == "Y");
  std::vector<int16_t> write_word;
  std::vector<uint8_t> write_bit;
  if (is_word)
    write_word.assign(payload.begin(), payload.end());
  if (is_bit)
    write_bit.assign(payload.begin(), payload.end());

  RpcResult result;
  {
    rb_sdk::gil_release_if_held _g;
    result =
        rpc.request_mc(module_name, server_ip, server_port, frame, cmd, mc_device, static_cast<uint32_t>(register_addr),
                       static_cast<uint16_t>(payload.size()), write_word, write_bit);
  }

  _finish_protocol_call(result.success, resolved_resolve_option, flow_manager_args, alarm_fn, error_prefix);
  return result;
}

/**
 * @brief Reads XGT (LS Electric) protocol device values.
 *
 * Only @p function_code 1 (read_byte) is currently supported. @p
 * cpu_type and @p device_type resolve the target XgtCPUinfo and
 * XgtDeviceType respectively.
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip XGT server IP address.
 * @param server_port XGT server port.
 * @param register_addr Starting device address to read from.
 * @param cpu_type CPU type: "XGK", "XGI", "XBC", "XEC", or "NONE".
 * @param device_type Device type; only "DB" is currently supported.
 * @param function_code Must be 1 (read_byte).
 * @param number_of_read Number of devices to read.
 * @param return_variable_name PyFM variable name that will receive the
 *        read values (@c RpcResult::data_word_xgt).
 * @param resolve_option How to handle a failed read — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param flow_manager_args Optional PyFM step context. @p
 *        return_variable_name is written into its context and
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the read failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call (success flag plus the read
 *         values in @c data_word_xgt).
 *
 * @throws std::runtime_error If @p function_code is not 1, or @p
 *         cpu_type/@p device_type cannot be resolved; and, under
 *         "STOP", if the read fails.
 */
inline RpcResult execute_xgt_read(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                  int server_port, int register_addr, const std::string& cpu_type,
                                  const std::string& device_type, int function_code, int number_of_read,
                                  const std::string& return_variable_name, const std::string& resolve_option = "SKIP",
                                  FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
  const std::string error_prefix = "XGT Protocol Read failed";
  XgtCPUinfo cpu = _resolve_xgt_cpu(cpu_type);
  XgtDeviceType device = _resolve_xgt_device(device_type);
  XgtCommand cmd = _resolve_xgt_command(function_code);
  std::string resolved_resolve_option = resolve_option_of(resolve_option, error_prefix);

  if (function_code != 1)
    throw std::runtime_error(error_prefix + ": invalid function_code");

  std::vector<int16_t> write_word;  // request_xgt() 도 non-const 참조로 받는다 - read 는 빈 벡터.
  RpcResult result;
  {
    rb_sdk::gil_release_if_held _g;
    result = rpc.request_xgt(module_name, server_ip, server_port, cmd, cpu, device,
                             static_cast<uint32_t>(register_addr), static_cast<uint16_t>(number_of_read), write_word);
  }

  FlowVariables variables;
  variables.emplace(return_variable_name,
                    FlowVariableValue{std::vector<int64_t>(result.data_word_xgt.begin(), result.data_word_xgt.end())});

  _finish_protocol_call(result.success, resolved_resolve_option, flow_manager_args, alarm_fn, error_prefix, variables);
  return result;
}

/**
 * @brief Writes XGT (LS Electric) protocol device values.
 *
 * Only @p function_code 3 (write_byte) is currently supported. @p
 * cpu_type and @p device_type resolve the target XgtCPUinfo and
 * XgtDeviceType respectively.
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip XGT server IP address.
 * @param server_port XGT server port.
 * @param register_addr Starting device address to write to.
 * @param cpu_type CPU type: "XGK", "XGI", "XBC", "XEC", or "NONE".
 * @param device_type Device type; only "DB" is currently supported.
 * @param function_code Must be 3 (write_byte).
 * @param payload_field List of values to write (1-40 entries, each in
 *        [-32768, 32767]).
 * @param resolve_option How to handle a failed write — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param flow_manager_args Optional PyFM step context.
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the write failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call.
 *
 * @throws std::runtime_error If @p function_code is not 3, @p
 *         cpu_type/@p device_type cannot be resolved, or @p
 *         payload_field is missing/out of range; and, under "STOP", if
 *         the write fails.
 */
inline RpcResult execute_xgt_write(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                   int server_port, int register_addr, const std::string& cpu_type,
                                   const std::string& device_type, int function_code,
                                   const std::optional<rb_payload::WriteRegisterValues>& payload_field,
                                   const std::string& resolve_option = "SKIP",
                                   FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
  const std::string error_prefix = "XGT Protocol Write failed";
  XgtCPUinfo cpu = _resolve_xgt_cpu(cpu_type);
  XgtDeviceType device = _resolve_xgt_device(device_type);
  XgtCommand cmd = _resolve_xgt_command(function_code);
  std::vector<int> payload_ints = _validate_payload_field(payload_field, error_prefix, -32768, 32767);
  std::string resolved_resolve_option = resolve_option_of(resolve_option, error_prefix);

  if (function_code != 3)
    throw std::runtime_error(error_prefix + ": invalid function_code");

  std::vector<int16_t> write_word(payload_ints.begin(), payload_ints.end());
  RpcResult result;
  {
    rb_sdk::gil_release_if_held _g;
    result =
        rpc.request_xgt(module_name, server_ip, server_port, cmd, cpu, device, static_cast<uint32_t>(register_addr),
                        static_cast<uint16_t>(payload_ints.size()), write_word);
  }

  _finish_protocol_call(result.success, resolved_resolve_option, flow_manager_args, alarm_fn, error_prefix);
  return result;
}

/**
 * @brief Receives data over a socket connection.
 *
 * @p function_code selects how the received payload is decoded before
 * being stored: 1 keeps it as the raw byte list, 2 decodes it as a
 * UTF-8 string.
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip Socket server IP address.
 * @param server_port Socket server port.
 * @param function_code 1 (raw bytes) or 2 (UTF-8 string).
 * @param return_variable_name PyFM variable name that will receive the
 *        decoded payload.
 * @param resolve_option How to handle a failed receive — "SKIP"
 *        continues without effect, "STOP" raises immediately, "ASK"
 *        fires @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param timeout_sec Receive timeout in seconds. Defaults to 1.0.
 * @param flow_manager_args Optional PyFM step context. @p
 *        return_variable_name is written into its context and
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the receive failed, which
 *        raises instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call (success flag plus the raw
 *         payload in @c payload).
 *
 * @throws std::runtime_error If @p function_code is not 1 or 2, or the
 *         payload cannot be decoded as UTF-8; and, under "STOP", if the
 *         receive fails.
 */
inline RpcResult execute_socket_read(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                     int server_port, int function_code, const std::string& return_variable_name,
                                     const std::string& resolve_option = "SKIP", double timeout_sec = 1.0,
                                     FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
  const std::string error_prefix = "Socket Interface Read failed";
  std::string resolved_resolve_option = resolve_option_of(resolve_option, error_prefix);
  int timeout_ms = timeout_ms_of(timeout_sec, 1.0);

  if (function_code != 1 && function_code != 2)
    throw std::runtime_error(error_prefix + ": invalid function_code");

  RpcResult result;
  {
    rb_sdk::gil_release_if_held _g;
    result = rpc.recv_sock(module_name, server_ip, server_port, nullptr, timeout_ms);
  }

  FlowVariables variables;
  if (function_code == 1) {
    variables.emplace(return_variable_name,
                      FlowVariableValue{std::vector<int64_t>(result.payload.begin(), result.payload.end())});
  } else {
    // function_code == 2: bytes(raw_payload).decode("utf-8")
    std::string raw(result.payload.begin(), result.payload.end());
    if (!_is_valid_utf8(raw))
      throw std::runtime_error(error_prefix + ": failed to decode payload as utf-8");
    variables.emplace(return_variable_name, FlowVariableValue{std::move(raw)});
  }

  _finish_protocol_call(result.success, resolved_resolve_option, flow_manager_args, alarm_fn, error_prefix, variables);
  return result;
}

/**
 * @brief Sends data over a socket connection.
 *
 * @p function_code selects how @p payload is encoded before sending: 3
 * (BYTES) splits @p payload on the delimiter read from
 * `flow_manager_args.args["data"]["split"]` and parses each token as an
 * integer byte value; 4 (ASCII) encodes @p payload directly as ASCII
 * bytes.
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip Socket server IP address.
 * @param server_port Socket server port.
 * @param function_code 3 (BYTES, delimiter-split) or 4 (ASCII).
 * @param payload String payload to send; interpretation depends on
 *        @p function_code as described above.
 * @param resolve_option How to handle a failed send — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param flow_manager_args Optional PyFM step context, required when
 *        @p function_code is 3 to look up the split delimiter.
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the send failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call.
 *
 * @throws std::runtime_error If @p function_code is not 3 or 4, the
 *         BYTES split delimiter is missing, or @p payload cannot be
 *         parsed/encoded; and, under "STOP", if the send fails.
 */
inline RpcResult execute_socket_write(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                      int server_port, int function_code, const std::string& payload,
                                      const std::string& resolve_option = "SKIP",
                                      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
  const std::string error_prefix = "Socket Interface Write failed";
  std::string resolved_resolve_option = resolve_option_of(resolve_option, error_prefix);

  if (function_code != 3 && function_code != 4)
    throw std::runtime_error(error_prefix + ": invalid function_code");

  std::vector<int> encoded_payload_ints;
  if (function_code == 3) {
    // Python 원본과 동일하게 payload 인자가 아니라 flow_manager_args.args["data"]["split"] 에서
    // 읽는다 (return_variable_name 과 같은 이유 — PyFM 이 넘겨주는 raw args 쪽이 원본).
    std::optional<std::string> split = flow_manager_args ? flow_manager_args->raw_data_field("split") : std::nullopt;
    if (!split || split->empty())
      throw std::runtime_error(error_prefix + ": split is required");
    encoded_payload_ints = _parse_bytes_payload(payload, *split, error_prefix);
  } else {
    encoded_payload_ints = _encode_ascii_payload(payload, error_prefix);
  }
  std::vector<uint8_t> encoded_payload(encoded_payload_ints.begin(), encoded_payload_ints.end());

  RpcResult result;
  {
    rb_sdk::gil_release_if_held _g;
    result = rpc.send_sock(module_name, server_ip, server_port, encoded_payload, nullptr);
  }

  _finish_protocol_call(result.success, resolved_resolve_option, flow_manager_args, alarm_fn, error_prefix);
  return result;
}

/**
 * @brief Opens a socket connection and registers the session under @p
 *        module_name.
 *
 * Only creates the session (@c connect_sock()); it does not wait for a
 * response, so unlike the other execute_* calls in this file the GIL is
 * not released while the call runs.
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip Socket server IP address.
 * @param server_port Socket server port.
 * @param resolve_option How to handle a failed connect — "SKIP"
 *        continues without effect, "STOP" raises immediately, "ASK"
 *        fires @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param flow_manager_args Optional PyFM step context.
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the connect failed, which
 *        raises instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return true if the connection was established; false otherwise.
 *
 * @throws std::runtime_error Under "STOP", if the connect fails.
 */
inline bool execute_socket_connect(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                   int server_port, const std::string& resolve_option = "SKIP",
                                   FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
  const std::string error_prefix = "Socket Interface Connect failed";
  std::string resolved_resolve_option = resolve_option_of(resolve_option, error_prefix);

  // connect_sock() 는 세션 생성만 하고 fut.get() 으로 블로킹하지 않는다(rpc_manager.cpp) - binding.cpp
  // 도 fut.get() 블로킹이 없어, 여기서도 GIL 을 놓지 않는다.
  bool success = rpc.connect_sock(module_name, server_ip, server_port, nullptr);

  _finish_protocol_call(success, resolved_resolve_option, flow_manager_args, alarm_fn, error_prefix);
  return success;
}

}  // namespace rb_program_interface
