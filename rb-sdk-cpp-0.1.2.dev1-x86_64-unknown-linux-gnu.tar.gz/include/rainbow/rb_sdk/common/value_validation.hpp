#pragma once

// Pure payload-field validation shared by program_interface.hpp /
// manipulate_vision.hpp / rb_program_sdk.hpp. Not a flow-manager concern and no
// pybind dependency — the generated dict<->struct caster only converts types, so
// "required but missing" / resolve_option enum / seconds->ms still need checking
// on the plain C++ struct fields.
//
// The pybind-side payload helpers (normalize_payload_dict / to_int / to_double /
// cast_payload / ...) stay in binding/util/payload.hpp, which re-includes
// this so existing rb_glue:: call sites keep working.

#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>

namespace rb_glue {

// get_required_field/validate_server_ip: an empty string counts as missing too.
template <typename T>
inline const T& require(const std::optional<T>& value, const std::string& field_name, const std::string& error_prefix) {
  if (!value)
    throw std::runtime_error(error_prefix + ": " + field_name + " is required");
  if constexpr (std::is_same_v<T, std::string>) {
    if (value->empty())
      throw std::runtime_error(error_prefix + ": " + field_name + " is required");
  }
  return *value;
}

inline const std::string& require(const std::string& value, const std::string& field_name,
                                  const std::string& error_prefix) {
  if (value.empty())
    throw std::runtime_error(error_prefix + ": " + field_name + " is required");
  return value;
}

template <typename T>
inline const T& require(const std::unique_ptr<T>& value, const std::string& field_name, const std::string& error_prefix) {
  if (!value)
    throw std::runtime_error(error_prefix + ": " + field_name + " is required");
  return *value;
}

template <typename T>
inline const std::vector<T>& require(const std::vector<T>& value, const std::string& field_name,
                                     const std::string& error_prefix) {
  if (value.empty())
    throw std::runtime_error(error_prefix + ": " + field_name + " is required");
  return value;
}

inline std::string resolve_option_of(const std::optional<std::string>& value, const std::string& error_prefix) {
  std::string result = value.value_or("SKIP");
  if (result != "SKIP" && result != "STOP" && result != "ASK")
    throw std::runtime_error(error_prefix + ": invalid resolve_option=" + result);
  return result;
}

inline std::string resolve_option_of(const std::string& value, const std::string& error_prefix) {
  std::string result = value.empty() ? "SKIP" : value;
  if (result != "SKIP" && result != "STOP" && result != "ASK")
    throw std::runtime_error(error_prefix + ": invalid resolve_option=" + result);
  return result;
}

// Milliseconds (Python get_timeout_sec: seconds default * 1000).
inline int timeout_ms_of(const std::optional<double>& value, double default_sec) {
  return static_cast<int>(value.value_or(default_sec) * 1000);
}

}  // namespace rb_glue
