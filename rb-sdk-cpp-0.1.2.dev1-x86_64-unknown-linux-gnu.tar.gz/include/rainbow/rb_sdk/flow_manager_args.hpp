#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <unordered_map>
#include <variant>
#include <vector>

#include <nlohmann/json.hpp>

// PyFM expressions can be Python values (strings, callables, and compound
// expressions). The C++ core may retain and pass them back to the bridge, but
// must never inspect their Python representation.
class FlowValue {
 public:
  virtual ~FlowValue() = default;
};

using FlowValuePtr = std::shared_ptr<FlowValue>;

// (title, content) alarm-dialog callback. A pure std::function so the C++ core
// can hold and invoke it with no pybind dependency; the bridge wraps the PyFM
// alarm SDK function into one.
using AlarmFn = std::function<void(const std::string&, const std::string&)>;

// (content, robot_model, level) log callback injected into an ADVANCED
// make_script user script as `rb_log`. make_script binds it to RBBaseSDK::log so
// script logs go through the same path as SDK logs; a pure std::function keeps
// the FlowManagerArgs interface pybind-free.
using ProgramLogFn = std::function<void(const std::string&, const std::string&, const std::string&)>;

// std::monostate publishes the variable as None (get_local_variable never
// returns it — it uses std::nullopt for an unset variable).
using FlowVariableValue = std::variant<std::monostate, bool, int64_t, double, std::string, std::vector<int64_t>,
                                       std::vector<float>, std::vector<double>, std::vector<std::vector<double>>>;
using FlowVariables = std::unordered_map<std::string, FlowVariableValue>;

class FlowManagerContext {
 public:
  virtual ~FlowManagerContext() = default;

  virtual void check_stop() = 0;
  virtual void pause() = 0;
  virtual void pause_all() = 0;
  virtual void stop() = 0;
  virtual void halt_sub_task() = 0;
  // ctx.stop_event.is_set() — whether a stop has been requested for this run.
  virtual bool stop_requested() = 0;
  // pause_all(); pause(); check_stop() — the "ASK" interface-failure sequence.
  void pause_and_check_stop() {
    pause_all();
    pause();
    check_stop();
  }
  virtual bool is_ui_execution() = 0;
  // PyFM process/task id used to key interface RpcManager connections;
  // "" when the context exposes none.
  virtual std::string process_id() = 0;
  // ctx.state_dict.get(key) as a string scalar (current_step_id, robot_model …);
  // std::nullopt when absent/None.
  virtual std::optional<std::string> state_get(std::string_view key) = 0;
  // len(ctx.state_dict.get(key, [])) — 0 when absent (sub_task_list emptiness …).
  virtual std::size_t state_seq_len(std::string_view key) = 0;
  // Callback bound to the PyFM "rb_program_sdk.alarm" SDK function for
  // @p robot_model, or nullptr when the context exposes none.
  virtual AlarmFn alarm_callback(std::string_view robot_model) = 0;
  virtual void update_local_variables(const FlowVariables& variables) = 0;
  // ctx.update_local_variables(vars) with a raw JSON object (list/dict values).
  virtual void update_local_variables_json(const nlohmann::json& variables) = 0;
  // ctx.merge_variable_meta(name, meta) — writer/metadata bookkeeping for a
  // runtime-set variable (plugin control path).
  virtual void merge_variable_meta_json(std::string_view name, const nlohmann::json& meta) = 0;
  // ctx.broadcast_variables_to_other_mains(vars, meta_by_name=...) — propagate a
  // runtime variable write to the other MAIN task trees.
  virtual void broadcast_variables_to_other_mains_json(const nlohmann::json& variables,
                                                       const nlohmann::json& meta_by_name) = 0;
  // Reads a PyFM local variable by name. Returns std::nullopt if the variable
  // is unset/None or holds a value that cannot be represented as a
  // FlowVariableValue.
  virtual std::optional<FlowVariableValue> get_local_variable(std::string_view name) = 0;
  // ctx.variables["local"] -> ["global"] lookup, raw JSON. std::nullopt if unset.
  virtual std::optional<nlohmann::json> lookup_local_or_global_json(std::string_view key) = 0;
  // Runtime variable lookup for script-visible values: local -> global ->
  // ctx.get_global_variable(key) for RB_* names. std::nullopt if unset/None.
  virtual std::optional<nlohmann::json> lookup_variable_json(std::string_view key) = 0;
  // Resolves a PyFM variable (local -> global -> "RB_" global lookup) holding a
  // list of joint waypoints (list-of-lists / 2D numpy). Throws if the variable
  // name does not resolve at all; returns std::nullopt if it resolves to a
  // value that is not a waypoint sequence.
  virtual std::optional<std::vector<std::vector<double>>> get_waypoint_variable(std::string_view name) = 0;
  virtual void emit_next(std::string_view step_id) = 0;
  virtual void emit_done(std::string_view step_id) = 0;
  virtual int get_folder_depth() = 0;
  virtual void break_folder(int target_depth) = 0;

  virtual bool eval_bool(const FlowValuePtr& expression) = 0;
  virtual float eval_float(const FlowValuePtr& expression) = 0;
  virtual void eval_action(const FlowValuePtr& expression) = 0;
  virtual bool is_empty_string(const FlowValuePtr& expression) = 0;
};

class FlowManagerArgs {
 public:
  virtual ~FlowManagerArgs() = default;

  virtual FlowManagerContext& context() = 0;
  virtual FlowValuePtr arg(std::string_view name) = 0;
  virtual std::optional<std::string> string_arg(std::string_view name) = 0;
  // Raw (pre-substitution) args["data"][field_name] / args[key] as a string.
  // For "write the result into which variable" fields, whose value must not
  // itself pass through PyFM variable substitution.
  virtual std::optional<std::string> raw_data_field(std::string_view field_name) = 0;
  virtual std::optional<std::string> raw_arg(std::string_view key) = 0;
  // Raw args.get(key) as JSON (keeps list/dict structure — plugin control path).
  virtual std::optional<nlohmann::json> raw_json_arg(std::string_view key) = 0;
  virtual std::string current_step_id() = 0;
  virtual bool is_main_task() = 0;
  virtual void done() = 0;
  // Runs @p contents as an arbitrary user Python script (ADVANCED make_script).
  // The bridge assembles the script env (variables/var/update_variable/
  // update_var/get_var/done/pause/stop/resume/check_stop, plus @p rb_log as
  // `rb_log`) from this args object and hands compile/exec + restricted
  // __builtins__ to ctx.run_advanced_script. Pybind bridge only — a standalone
  // C++ caller cannot reach ADVANCED make_script, so there is no pure-C++
  // implementation.
  virtual void run_advanced_script(std::string_view contents, const ProgramLogFn& rb_log) = 0;
};

using FlowManagerArgsPtr = std::shared_ptr<FlowManagerArgs>;

// ── step tail helpers (all no-op when flow_manager_args is nullptr) ────────

inline void fm_done(const FlowManagerArgsPtr& flow_manager_args) {
  if (flow_manager_args)
    flow_manager_args->done();
}

// (pause_option=="ALL" -> pause_all();) pause(); check_stop(); done().
inline void fm_pause_check_stop_done(const FlowManagerArgsPtr& flow_manager_args,
                                     const std::optional<std::string>& pause_option = std::nullopt) {
  if (!flow_manager_args)
    return;
  FlowManagerContext& c = flow_manager_args->context();
  if (pause_option == "ALL")
    c.pause_all();
  c.pause();
  c.check_stop();
  flow_manager_args->done();
}

// alarm_or_halt / debug_variables guard: is_only_at_ui but not a UI execution
// -> mark done and return true (caller returns immediately).
inline bool fm_skip_when_not_ui(const FlowManagerArgsPtr& flow_manager_args, bool is_only_at_ui) {
  if (!is_only_at_ui || !flow_manager_args)
    return false;
  if (flow_manager_args->context().is_ui_execution())
    return false;
  flow_manager_args->done();
  return true;
}

// PyFM process/task id, "unknown_module" when unavailable — keys the interface
// RpcManager connections (program_interface.hpp / manipulate_vision.hpp).
inline std::string get_task_id(const FlowManagerArgsPtr& flow_manager_args) {
  if (!flow_manager_args)
    return "unknown_module";
  std::string pid = flow_manager_args->context().process_id();
  return pid.empty() ? "unknown_module" : pid;
}

// Shared interface-failure policy (program_interface.hpp / manipulate_vision.hpp).
// @p err_msg is the failure already rendered to a string.
//   ASK  -> fire @p alarm_fn, then flow_manager_args->context().pause_and_check_stop()
//   STOP -> throw std::runtime_error
//   SKIP -> nothing (keep going)
inline void resolve_interface_flow(const std::string& err_msg, const std::string& resolve_option,
                                   const FlowManagerArgsPtr& flow_manager_args, const AlarmFn& alarm_fn,
                                   const std::string& error_prefix) {
  if (resolve_option == "ASK" && alarm_fn) {
    alarm_fn("Interface Debug", error_prefix + ".(Err:" + err_msg + ")");
    if (flow_manager_args)
      flow_manager_args->context().pause_and_check_stop();
  } else if (resolve_option == "STOP") {
    throw std::runtime_error(error_prefix + ": result=" + err_msg);
  }
}
