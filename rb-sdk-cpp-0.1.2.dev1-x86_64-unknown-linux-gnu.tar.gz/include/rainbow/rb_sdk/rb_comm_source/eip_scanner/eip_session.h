#pragma once
#include "eip_types.h"
#include <string>
#include <sstream>
#include <thread>
#include <mutex>
#include <queue>
#include <condition_variable>
#include <atomic>
#include <future>
#include <chrono>
#include <memory>

class EipSession {
public:
    EipSession(const std::string& ip, int port, const EdsData& eds, EipEventCB cb = nullptr);
    ~EipSession();

    static constexpr size_t MAX_QUEUE    = 500;
    static constexpr int    MAX_RETRY    = 2;

    std::future<EipResult>   enqueue_explicit(EipTask task);
    EipIoResult              get_io_input();
    bool                     set_io_output(const std::vector<uint8_t>& data);
    bool                     set_io_output_named(const std::vector<std::string>& names,
                                                  const std::vector<double>& values);

    void set_event_callback(EipEventCB cb) { event_cb_ = cb; }
    void set_rpi(uint32_t rpi_ms);

    bool is_functional()         const { return !stop_; }
    bool is_implicit_connected() const { return io_connected_.load(); }

private:
    // 백오프 (다른 세션과 동일)
    bool connect_allowed();
    void record_fail();
    void reset_backoff();

    // Explicit 워커 루프
    void worker_loop();

    // Implicit IO 루프 (별도 스레드)
    void implicit_loop();

    // CIP raw bytes → EipResult (EDS 타입 참조)
    EipResult  buildResult(const std::vector<uint8_t>& data,
                           uint16_t class_id, uint16_t instance, uint16_t attribute) const;
    EipIoResult buildIoResult(const std::vector<uint8_t>& data) const;

    std::string  ip_;
    int          port_;
    EdsData      eds_;

    // Explicit 큐
    std::mutex              q_mtx_;
    std::condition_variable cv_;
    std::queue<EipTask>     tasks_;

    // Implicit I/O 버퍼
    std::mutex                io_mtx_;
    std::vector<uint8_t>      io_input_;
    std::vector<uint8_t>      io_output_;
    std::atomic<bool>         io_connected_{false};
    std::atomic<uint32_t>     rpi_ms_{10};
    std::atomic<bool>         rpi_changed_{false};    // set_rpi() 호출 시 재연결 트리거
    std::atomic<uint64_t>     last_io_recv_ms_{0};    // 마지막 수신 시각 (ms)
    std::atomic<int>          io_recv_count_{0};      // 재연결마다 초기화되는 수신 카운터

    std::atomic<bool> stop_{false};
    std::thread       worker_;
    std::thread       implicit_worker_;

    // Explicit 전용 backoff (implicit과 분리)
    int  fail_count_{0};
    std::chrono::steady_clock::time_point next_retry_time_{};

    EipEventCB event_cb_;
};
