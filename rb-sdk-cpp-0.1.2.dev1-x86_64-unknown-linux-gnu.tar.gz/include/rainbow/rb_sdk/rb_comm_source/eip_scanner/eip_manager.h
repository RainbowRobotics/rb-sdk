#pragma once
#include "eip_types.h"
#include "eip_session.h"
#include "eip_eds_parser.h"
#include <map>
#include <memory>
#include <mutex>
#include <string>

class EipManager {
public:
    EipManager() = default;
    ~EipManager() = default;

    // EDS 로드 및 검증 — 연결 전에 호출
    // 반환: 파싱 결과 (valid + error 포함)
    EdsData load_eds(const std::string& eds_path);

    // 세션 생성 (EDS 로드 후 호출)
    // eds_path가 비어있으면 기존 로드된 EDS 재사용
    // t2o_assembly / o2t_assembly: 0이면 EDS 자동 검출, 非0이면 해당 인스턴스로 강제
    int create_session(const std::string& ip, int port,
                       const std::string& eds_path = "",
                       uint16_t t2o_assembly = 0,
                       uint16_t o2t_assembly = 0);

    // Explicit 요청
    std::future<EipResult> request_explicit(int session_id, EipTask task);

    // Implicit I/O
    EipIoResult  get_io_input(int session_id);
    bool         set_io_output(int session_id, const std::vector<uint8_t>& data);
    bool         set_io_output_named(int session_id, const std::vector<std::string>& names,
                                     const std::vector<double>& values);
    void         set_rpi(int session_id, uint32_t rpi_ms);
    bool         is_implicit_connected(int session_id);

    void close(int session_id);

    void set_log_callback(RpcLogCallback cb) { log_cb_ = cb; }
    void send_log(LogType type, int sid, const std::string& msg);

private:
    struct SessionEntry {
        std::shared_ptr<EipSession> session;
        int ref_count{1};
    };

    std::mutex mtx_;
    int next_id_{1};

    std::map<std::string, int>          key_to_id_;
    std::map<int, std::string>          id_to_key_;
    std::map<std::string, SessionEntry> sessions_;

    std::map<std::string, EdsData>      eds_cache_;  // path → EdsData

    RpcLogCallback log_cb_;
};
