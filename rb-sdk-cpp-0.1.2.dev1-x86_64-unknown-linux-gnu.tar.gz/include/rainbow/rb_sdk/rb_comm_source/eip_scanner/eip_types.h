#pragma once
#include <string>
#include <vector>
#include <map>
#include <future>
#include <functional>
#include <cstdint>
#include "common/rpc_result.h"

// ─────────────────────────────────────────────
// CIP 데이터 타입 (EDS DataType 필드와 대응)
// ─────────────────────────────────────────────
enum class CipDataType : uint16_t {
    UNKNOWN = 0x0000,
    BOOL    = 0x00C1,
    SINT    = 0x00C2,
    INT     = 0x00C3,
    DINT    = 0x00C4,
    LINT    = 0x00C5,
    USINT   = 0x00C6,
    UINT    = 0x00C7,
    UDINT   = 0x00C8,
    ULINT   = 0x00C9,
    REAL    = 0x00CA,
    LREAL   = 0x00CB,
    STRING  = 0x00D0,
    BYTE    = 0x00D1,
    WORD    = 0x00D2,
    DWORD   = 0x00D3,
    LWORD   = 0x00D4,
};

inline std::string cipTypeToString(CipDataType t) {
    switch (t) {
        case CipDataType::BOOL:   return "BOOL";
        case CipDataType::SINT:   return "SINT";
        case CipDataType::INT:    return "INT";
        case CipDataType::DINT:   return "DINT";
        case CipDataType::LINT:   return "LINT";
        case CipDataType::USINT:  return "USINT";
        case CipDataType::UINT:   return "UINT";
        case CipDataType::UDINT:  return "UDINT";
        case CipDataType::ULINT:  return "ULINT";
        case CipDataType::REAL:   return "REAL";
        case CipDataType::LREAL:  return "LREAL";
        case CipDataType::STRING: return "STRING";
        case CipDataType::BYTE:   return "BYTE";
        case CipDataType::WORD:   return "WORD";
        case CipDataType::DWORD:  return "DWORD";
        case CipDataType::LWORD:  return "LWORD";
        default:                  return "UNKNOWN";
    }
}

inline CipDataType cipTypeFromString(const std::string& s) {
    if (s == "BOOL")   return CipDataType::BOOL;
    if (s == "SINT")   return CipDataType::SINT;
    if (s == "INT")    return CipDataType::INT;
    if (s == "DINT")   return CipDataType::DINT;
    if (s == "LINT")   return CipDataType::LINT;
    if (s == "USINT")  return CipDataType::USINT;
    if (s == "UINT")   return CipDataType::UINT;
    if (s == "UDINT")  return CipDataType::UDINT;
    if (s == "ULINT")  return CipDataType::ULINT;
    if (s == "REAL")   return CipDataType::REAL;
    if (s == "LREAL")  return CipDataType::LREAL;
    if (s == "STRING") return CipDataType::STRING;
    if (s == "BYTE")   return CipDataType::BYTE;
    if (s == "WORD")   return CipDataType::WORD;
    if (s == "DWORD")  return CipDataType::DWORD;
    if (s == "LWORD")  return CipDataType::LWORD;
    return CipDataType::UNKNOWN;
}

inline uint32_t cipTypeByteSize(CipDataType t) {
    switch (t) {
        case CipDataType::BOOL:
        case CipDataType::SINT:
        case CipDataType::USINT:
        case CipDataType::BYTE:    return 1;
        case CipDataType::INT:
        case CipDataType::UINT:
        case CipDataType::WORD:    return 2;
        case CipDataType::DINT:
        case CipDataType::UDINT:
        case CipDataType::REAL:
        case CipDataType::DWORD:   return 4;
        case CipDataType::LINT:
        case CipDataType::ULINT:
        case CipDataType::LREAL:
        case CipDataType::LWORD:   return 8;
        default:                   return 0;
    }
}

// ─────────────────────────────────────────────
// EDS 파싱 결과 구조체
// ─────────────────────────────────────────────

// Assembly 멤버 (이름 있는 경우)
struct EipMember {
    std::string  name;
    CipDataType  type{CipDataType::UNKNOWN};
    uint32_t     bit_offset{0};
    uint32_t     bit_size{0};
};

// Assembly 오브젝트
struct EipAssemblyInfo {
    uint16_t               instance{0};
    uint32_t               size_bytes{0};
    std::string            name;
    std::vector<EipMember> members;  // empty = 이름 없음 → raw 모드
};

// Object Dictionary 속성 (Explicit 용)
struct EipAttributeInfo {
    uint16_t    class_id{0};
    uint16_t    instance{0};
    uint16_t    attribute{0};
    CipDataType type{CipDataType::UNKNOWN};
    std::string name;
    bool        readable{true};
    bool        writable{false};
};

// 디바이스 기본 정보
struct EipDeviceInfo {
    uint16_t    vendor_id{0};
    uint16_t    device_type{0};
    uint16_t    product_code{0};
    uint8_t     major_revision{0};
    uint8_t     minor_revision{0};
    std::string product_name;
    std::string catalog_number;
    std::string vendor_name;
};

// Implicit 연결 파라미터
struct EipConnectionInfo {
    uint16_t o2t_assembly{0};
    uint16_t t2o_assembly{0};
    uint16_t config_assembly{0};
    uint32_t o2t_size{0};
    uint32_t t2o_size{0};
    uint32_t rpi_us{10000};
    bool     has_exclusive_owner{false};
    bool     has_input_only{false};
    bool     t2o_is_multicast{false};  // T->O 연결 타입: true=MULTICAST, false=P2P
};

// EDS 전체 파싱 결과
struct EdsData {
    bool        valid{false};
    std::string path;
    std::string error;
    EipDeviceInfo                    device;
    EipConnectionInfo                connection;
    std::vector<EipAssemblyInfo>     assemblies;
    std::vector<EipAttributeInfo>    attributes;
};

// ─────────────────────────────────────────────
// Task / Result
// ─────────────────────────────────────────────

enum class EipTaskType { EXPLICIT_READ, EXPLICIT_WRITE };

// Explicit 읽기 결과 — EipTask보다 먼저 선언 (promise 타입에 필요)
struct EipResult {
    bool                    success{false};
    std::string             error_msg;
    std::vector<uint8_t>    raw_data;
    int64_t                 int_val{0};
    double                  float_val{0.0};
    std::string             str_val;
    std::string             cip_type;   // "UINT", "REAL", ...
};

// Implicit I/O 결과
struct EipIoResult {
    bool                        success{false};
    std::string                 error_msg;
    bool                        has_names{false};
    std::vector<std::string>    member_names;
    std::vector<double>         member_values;
    std::vector<std::string>    member_types;
    std::vector<uint8_t>        raw_data;
    uint64_t                    last_recv_ms{0};  // 마지막 수신 절대 시각 (steady_clock ms)
};

struct EipTask {
    EipTaskType             type{EipTaskType::EXPLICIT_READ};
    uint16_t                class_id{0};
    uint16_t                instance{0};
    uint16_t                attribute{0};
    std::vector<uint8_t>    write_data;
    std::promise<EipResult> promise;
};

using EipEventCB = std::function<void(int, const std::string&)>;
