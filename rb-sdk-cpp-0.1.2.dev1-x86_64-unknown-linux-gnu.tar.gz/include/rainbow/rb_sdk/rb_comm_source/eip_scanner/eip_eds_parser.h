#pragma once
#include "eip_types.h"
#include <string>
#include <map>

// EDS 파일을 파싱하여 EdsData를 반환합니다.
// ODVA EDS 포맷을 기반으로 두 가지 주요 패턴을 지원합니다:
//   - Minimal (SICK Lector 등): Assembly 크기만 정의, 멤버 없음
//   - Full    (SICK nanoScan3 등): [Params] 섹션에 이름/타입 정의 + Assembly에 비트 단위 멤버 참조
class EipEdsParser {
public:
    static EdsData parse(const std::string& path);

private:
    struct Section {
        std::string name;
        std::map<std::string, std::string> kv;
    };

    // [Params] 섹션에서 추출한 파라미터 정보
    struct ParamInfo {
        std::string  name;
        CipDataType  type{CipDataType::UNKNOWN};
        uint32_t     byte_size{0};
    };

    using ParamsMap = std::map<std::string, ParamInfo>;  // "Param1" → ParamInfo

    static std::vector<Section> loadSections(const std::string& path);
    static std::string trim(const std::string& s);
    static std::string stripComment(const std::string& s);
    static std::string unquote(const std::string& s);
    static uint32_t parseHexOrDec(const std::string& s);

    static void parseDevice(const Section& sec, EipDeviceInfo& out);

    // [Params] 섹션 → ParamsMap 빌드
    static void parseParamsSection(const Section& sec, ParamsMap& out);

    // [Assembly] 섹션 — params_map이 있으면 Params 참조 방식 멤버도 파싱
    static void parseAssemblySection(const Section& sec,
                                     std::map<uint16_t, EipAssemblyInfo>& assemblies,
                                     const ParamsMap& params_map);

    static void parseConnectionManager(const Section& sec, EipConnectionInfo& out,
                                       const std::map<uint16_t, EipAssemblyInfo>& assemblies);

    // 서브섹션 방식 멤버 파싱 (기존 유지)
    static void parseMembersInto(const std::string& sectionName,
                                 const Section& sec,
                                 std::map<uint16_t, EipAssemblyInfo>& assemblies);
};
