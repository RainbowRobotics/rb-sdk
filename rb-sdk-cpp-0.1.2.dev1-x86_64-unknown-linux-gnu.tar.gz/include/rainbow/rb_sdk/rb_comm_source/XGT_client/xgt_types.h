#pragma once
#include <vector>
#include <string>
#include <future>
#include <cstdint>


enum class XgtDeviceType : uint32_t{
    DB = 0x254442,
};

enum class XgtCommandType {
    read_byte = 0,
    read_word = 1,
    write_byte = 2,
    write_word = 3,
};


enum class XgtCommand : uint32_t {
    read_word = 0x54000200,
    read_byte = 0x54001400,
    write_word = 0x58000200,
    write_byte = 0x58001400,
};

enum class XgtCPUinfo : uint8_t {
    NONE = 0x00,
    XGK = 0xA0,
    XBC = 0xB0,
    XGI = 0xA4,
    XEC = 0xB4,
};

enum class XgtDirection : uint8_t {
    P2R = 0x11,
    R2P = 0x33,
};

enum class XgtETC : uint8_t {
    CompanyID_0 = 0x4C,//10bytes
    CompanyID_1 = 0x53,
    CompanyID_2 = 0x49,//10bytes
    CompanyID_3 = 0x53,//10bytes
    CompanyID_4 = 0x2D,//10bytes
    CompanyID_5 = 0x58,//10bytes
    CompanyID_6 = 0x47,//10bytes
    CompanyID_7 = 0x54,//10bytes
    CompanyID_8 = 0x00,//10bytes
    CompanyID_9 = 0x00,//10bytes
    PLC_info = 0x00,//2bytes
    Invoked_ID = 0x00,
    Ent_pos = 0x00,
    Reserve = 0x00,
    chksum = 0x00,
};

struct XgtResult {
    bool success{false};
    uint16_t end_code{0}; // 0이면 정상
    // std::vector<uint16_t> word_data; // 워드 읽기 결과
    std::vector<int16_t>  data_word;
    std::string error_msg;
};

// Task 구조체에 디바이스 코드와 시작 주소 타입을 명시
struct XgtTask {
    XgtCommand cmd;
    XgtCPUinfo cpu;
    XgtDeviceType device;
    uint32_t str_addr;
    uint16_t count;

    std::vector<int16_t> write_word;

    std::promise<XgtResult> promise;
};