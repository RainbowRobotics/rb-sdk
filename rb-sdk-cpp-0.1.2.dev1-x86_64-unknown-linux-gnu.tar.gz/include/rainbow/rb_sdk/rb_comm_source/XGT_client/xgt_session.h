
#pragma once

#include <string>
#include <vector>
#include <thread>
#include <mutex>
#include <queue>
#include <condition_variable>
#include <atomic>
#include <future>
#include <chrono>


#include <sys/socket.h>  // socket(), connect()
#include <arpa/inet.h>   // sockaddr_in, inet_pton(), htons()
#include <unistd.h>      // close(), read(), write()
#include <fcntl.h>       // fcntl(), O_NONBLOCK (Non-blocking 설정용)
#include <sys/select.h>  // select(), fd_set, FD_ZERO, FD_SET (타임아웃용)
#include <cerrno>        // errno, EINPROGRESS
#include <cstring>       // memset

#include "xgt_types.h"
// #include "common/common.h"
#include "common/rpc_result.h"

using SessionEventCB = std::function<void(int, const std::string&)>;

class XgtSession {
public:
    XgtSession(const std::string& ip, int port, XgtCPUinfo cpu);
    ~XgtSession();

    static constexpr size_t MAX_QUEUE = 1000;
    std::future<XgtResult> enqueue(XgtTask task);

    void set_event_callback(SessionEventCB cb) { event_cb_ = cb; }

    bool is_functional() const { return !stop_; }

private:
    // --- Connection & Backoff ---
    bool connect_allowed();
    void record_fail();
    void reset_backoff();
    bool connect_to_server();
    void disconnect();

    // --- Protocol Logic (Original) ---
    std::vector<uint8_t> make_packet(const XgtTask& task);
    uint8_t RCR_GET_DIGIT_NUM(uint32_t t_number);
    bool receive_packet(std::vector<uint8_t>& out_data, const XgtTask& task);
    XgtResult parse_xgt_response(const std::vector<uint8_t>& data, const XgtTask& task);
    XgtResult execute_xgt_packet(const XgtTask& task);
    void worker_loop();

private:
    std::string ip_;
    int port_;
    XgtCPUinfo cpu_type_;
    int sock_fd_{-1};
    
    std::atomic<bool> stop_{false};
    std::thread worker_;
    
    std::mutex q_mtx_;
    std::condition_variable cv_;
    std::queue<XgtTask> tasks_;

    int fail_count_{0};
    const int MAX_RETRY_LIMIT = 2;
    std::chrono::steady_clock::time_point next_retry_time_{};

    SessionEventCB event_cb_;
};