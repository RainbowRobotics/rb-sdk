
#pragma once

#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
#include <future>
#include "xgt_session.h"

struct XgtSessionEntry {
    std::shared_ptr<XgtSession> session;
    int ref_count{0};
};

class XgtManager {
public:
    // 원본 로직: IP, Port, CPU 정보를 받아 세션 생성/재사용
    int create_session(const std::string& ip, int port, XgtCPUinfo cpu);

    // 원본 로직: 세션 ID를 통해 PLC 요청 전달
    std::future<XgtResult> request(
        int session_id,
        XgtCommand cmd,
        XgtCPUinfo cpu,
        uint32_t addr, 
        uint16_t count,
        XgtDeviceType device,
        const std::vector<int16_t>& write_word = {}
    );

    // (선택 사항) 세션 종료 로직 - 필요 없으시면 삭제 가능합니다.
    void close(int session_id);
    bool is_session_alive(int session_id);

    void set_log_callback(RpcLogCallback cb);

private:
    std::mutex mtx_;
    int next_id_{1};

    RpcLogCallback log_cb_ = nullptr;

    void send_log(LogType type, int sid,  const std::string& msg);
        
    std::map<std::string, XgtSessionEntry> sessions_;
    std::map<std::string, int> key_to_id_;
    std::map<int, std::string> id_to_key_;
};