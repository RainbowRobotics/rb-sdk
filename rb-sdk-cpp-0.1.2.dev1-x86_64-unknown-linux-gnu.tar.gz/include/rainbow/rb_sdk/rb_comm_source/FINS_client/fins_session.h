#pragma once
#include <string>
#include <vector>
#include <thread>
#include <mutex>
#include <queue>
#include <condition_variable>
#include <atomic>
#include <future>
#include <chrono>
#include <functional>

#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/select.h>
#include <cerrno>
#include <cstring>

#include "fins_types.h"
#include "common/rpc_result.h"

using FinsEventCB = std::function<void(int, const std::string&)>;

class FinsSession {
public:
    // fallback_server_node / fallback_client_node:
    //   핸드셰이크 성공 시 무시, 실패 시 이 값으로 직접 통신
    //   핸드셰이크 미지원 구형 PLC 또는 UDP 모드 장치에 사용
    FinsSession(const std::string& ip, int port,
                uint8_t fallback_server_node = 1,
                uint8_t fallback_client_node = 0);
    ~FinsSession();

    static constexpr size_t MAX_QUEUE    = 1000;
    static constexpr int    MAX_RETRY    = 2;

    std::future<FinsResult> enqueue(FinsTask task);

    void set_event_callback(FinsEventCB cb) { event_cb_ = cb; }
    bool is_functional() const { return !stop_; }

private:
    bool connect_allowed();
    void record_fail();
    void reset_backoff();
    bool connect_to_server();
    bool fins_handshake();
    void disconnect();

    std::vector<uint8_t> make_packet(const FinsTask& task);
    bool                 receive_packet(std::vector<uint8_t>& out);
    FinsResult           parse_response(const std::vector<uint8_t>& data,
                                        const FinsTask& task);
    FinsResult           execute_fins_packet(const FinsTask& task);
    void                 worker_loop();

    std::string ip_;
    int         port_;
    int         sock_fd_{-1};

    uint8_t     client_node_{0};
    uint8_t     server_node_{0};
    uint8_t     sid_{0};

    uint8_t     fallback_server_node_{1};   // 핸드셰이크 실패 시 사용
    uint8_t     fallback_client_node_{0};

    std::atomic<bool>       stop_{false};
    std::thread             worker_;

    std::mutex              q_mtx_;
    std::condition_variable cv_;
    std::queue<FinsTask>    tasks_;

    int fail_count_{0};
    std::chrono::steady_clock::time_point next_retry_time_{};

    FinsEventCB event_cb_;
};
