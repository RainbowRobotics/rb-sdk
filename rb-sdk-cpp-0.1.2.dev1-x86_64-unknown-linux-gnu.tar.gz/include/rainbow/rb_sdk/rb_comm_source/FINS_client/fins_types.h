#pragma once
#include <vector>
#include <string>
#include <future>
#include <cstdint>

// ─────────────────────────────────────────────
// FINS 메모리 영역 코드
// ─────────────────────────────────────────────
enum class FinsMemArea : uint8_t {
    DM_BIT    = 0x02,   // DM bit
    CIO_BIT   = 0x30,   // CIO bit
    WORK_BIT  = 0x31,   // Work bit
    HOLD_BIT  = 0x32,   // Holding bit
    DM_WORD   = 0x82,   // DM word
    CIO_WORD  = 0xB0,   // CIO word
    WORK_WORD = 0xB1,   // Work word
    HOLD_WORD = 0xB2,   // Holding word
    EM0_WORD  = 0xA0,   // Extended Memory bank 0
    TIMER_PV  = 0x89,   // Timer/Counter present value
    TIMER_FLAG= 0x09,   // Timer/Counter completion flag (bit)
};

inline bool fins_is_bit_area(FinsMemArea area) {
    switch (area) {
        case FinsMemArea::DM_BIT:
        case FinsMemArea::CIO_BIT:
        case FinsMemArea::WORK_BIT:
        case FinsMemArea::HOLD_BIT:
        case FinsMemArea::TIMER_FLAG:
            return true;
        default:
            return false;
    }
}

// ─────────────────────────────────────────────
// FINS 커맨드 코드 (MRC << 8 | SRC)
// ─────────────────────────────────────────────
enum class FinsCommand : uint16_t {
    MEMORY_AREA_READ  = 0x0101,
    MEMORY_AREA_WRITE = 0x0102,
    RUN               = 0x0401,
    STOP              = 0x0402,
};

// ─────────────────────────────────────────────
// 결과 / 태스크
// ─────────────────────────────────────────────
struct FinsResult {
    bool                 success{false};
    uint16_t             end_code{0};     // 0x0000 = 정상
    std::vector<uint16_t> word_data;      // 워드 읽기 결과 (big-endian → host 변환)
    std::vector<uint8_t>  bit_data;       // 비트 읽기 결과 (0/1 per element)
    std::string          error_msg;
};

struct FinsTask {
    FinsCommand           command{FinsCommand::MEMORY_AREA_READ};
    FinsMemArea           mem_area{FinsMemArea::DM_WORD};
    uint16_t              word_addr{0};
    uint8_t               bit_addr{0};    // 워드 접근 시 0x00
    uint16_t              count{1};
    std::vector<uint16_t> write_word;     // 워드 쓰기 데이터
    std::vector<uint8_t>  write_bit;      // 비트 쓰기 데이터 (0/1)
    std::promise<FinsResult> promise;
};
