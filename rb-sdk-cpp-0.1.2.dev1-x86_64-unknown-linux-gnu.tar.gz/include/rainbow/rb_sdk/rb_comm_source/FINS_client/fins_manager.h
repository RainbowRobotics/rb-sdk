#pragma once
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
#include <future>
#include "fins_session.h"
#include "common/rpc_result.h"

class FinsManager {
public:
    // fallback_server_node / fallback_client_node: 핸드셰이크 실패 시 사용할 노드 번호
    int create_session(const std::string& ip, int port,
                       uint8_t fallback_server_node = 1,
                       uint8_t fallback_client_node = 0);

    std::future<FinsResult> request(
        int session_id,
        FinsCommand     cmd,
        FinsMemArea     mem_area,
        uint16_t        word_addr,
        uint8_t         bit_addr,
        uint16_t        count,
        const std::vector<uint16_t>& write_word = {},
        const std::vector<uint8_t>&  write_bit  = {}
    );

    void close(int session_id);
    void set_log_callback(RpcLogCallback cb) { log_cb_ = cb; }

private:
    struct SessionEntry {
        std::shared_ptr<FinsSession> session;
        int ref_count{1};
    };

    void send_log(LogType type, int sid, const std::string& msg);

    std::mutex mtx_;
    int next_id_{1};

    RpcLogCallback log_cb_;

    std::map<std::string, SessionEntry> sessions_;
    std::map<std::string, int>          key_to_id_;
    std::map<int, std::string>          id_to_key_;
};
