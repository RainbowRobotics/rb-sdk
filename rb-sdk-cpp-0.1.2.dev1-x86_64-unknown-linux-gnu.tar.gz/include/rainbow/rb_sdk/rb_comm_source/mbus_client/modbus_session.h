// #pragma once
// #include <modbus/modbus.h>
// #include <string>
// #include <thread>
// #include <mutex>
// #include <queue>
// #include <condition_variable>
// #include <atomic>
// #include <chrono>
// #include <cerrno>
// #include "modbus_types.h"
// #include "common/common.h"


// struct ModbusTask {
//     ModbusFunction fc;
//     int addr;
//     int count;
//     std::vector<uint8_t>  write_bits;
//     std::vector<uint16_t> write_regs;
//     int timeout_ms;
//     std::promise<ModbusResult> promise;
// };

// class ModbusSession {
// public:
//     ModbusSession(const std::string& ip, int port)
//         : ip_(ip), port_(port)
//     {
//         LOG_WARNING("ModbusSession created: " + ip_ + ":" + std::to_string(port_));
//         worker_ = std::thread(&ModbusSession::worker_loop, this);
//     }

//     ~ModbusSession() {
//         stop_ = true;
//         cv_.notify_all();
//         if (worker_.joinable())
//             worker_.join();
//         disconnect();
//         LOG_WARNING("ModbusSession destroyed");
//     }

//     static constexpr size_t MAX_QUEUE = 1000; //<-------------------------------------

//     std::future<ModbusResult> enqueue(ModbusTask task) {
//         auto fut = task.promise.get_future();

//         {
//             std::lock_guard<std::mutex> lock(q_mtx_);

//             if (tasks_.size() >= MAX_QUEUE) //<-------------------------------------
//             {
//                 ModbusResult r; //<-------------------------------------
//                 r.error = "queue overflow"; //<-------------------------------------
//                 task.promise.set_value(r); //<-------------------------------------
//                 return fut; //<-------------------------------------
//             }

//             tasks_.push(std::move(task));
//         }

//         cv_.notify_one();
//         return fut;
//     }

// private:
//     // ---------- Backoff ----------
//     bool connect_allowed() {
//         auto now = std::chrono::steady_clock::now();
//         return now >= next_retry_time_;
//     }

//     void record_fail() {
//         fail_count_++;
//         int backoff_sec = std::min(30, 1 << std::min(fail_count_, 5));
//         next_retry_time_ =
//             std::chrono::steady_clock::now() + std::chrono::seconds(backoff_sec);

//         LOG_WARNING("Modbus reconnect backoff: " +
//                     std::to_string(backoff_sec) + "s");
//     }

//     void reset_backoff() {
//         fail_count_ = 0;
//         next_retry_time_ = std::chrono::steady_clock::time_point::min();
//     }

//     // ---------- Connection ----------
//     bool connect() {
//         if (ctx_) return true;

//         if (!connect_allowed()) {
//             LOG_WARNING("Connect attempt blocked by backoff");
//             return false;
//         }

//         ctx_ = modbus_new_tcp(ip_.c_str(), port_);
//         if (!ctx_) return false;
//         modbus_set_error_recovery(ctx_, MODBUS_ERROR_RECOVERY_LINK); //<-------------------------------------

//         if (modbus_connect(ctx_) == -1) {
//             modbus_free(ctx_);
//             ctx_ = nullptr;
//             record_fail();
//             LOG_WARNING("Modbus connect failed");
//             return false;
//         }

//         LOG_WARNING("Modbus connected: " + ip_);
//         reset_backoff();
//         return true;
//     }

//     void disconnect() {
//         if (ctx_) {
//             modbus_close(ctx_);
//             modbus_free(ctx_);
//             ctx_ = nullptr;
//             LOG_WARNING("Modbus disconnected");
//         }
//     }

//     void set_timeout(int ms) {
//         uint32_t sec  = ms / 1000;
//         uint32_t usec = (ms % 1000) * 1000;
//         modbus_set_response_timeout(ctx_, sec, usec);
//     }

//     // ---------- Worker ----------
//     void worker_loop() {
//         while (!stop_) {
//             ModbusTask task;

//             {
//                 std::unique_lock<std::mutex> lock(q_mtx_);
//                 cv_.wait(lock, [&] { return stop_ || !tasks_.empty(); });
//                 if (stop_) break;
//                 task = std::move(tasks_.front());
//                 tasks_.pop();
//             }

//             ModbusResult result;

//             if (!connect()) {
//                 result.error = "Not connected (backoff or failure)";
//                 task.promise.set_value(result);
//                 continue;
//             }

//             set_timeout(task.timeout_ms);
//             int rc = -1;

//             std::vector<uint8_t>  bit_buf(task.count);
//             std::vector<uint16_t> reg_buf(task.count);

//             switch (task.fc) {
//                 case ModbusFunction::READ_COILS:
//                     rc = modbus_read_bits(ctx_, task.addr, task.count, bit_buf.data());
//                     if (rc > 0) result.bits = bit_buf;
//                     break;
//                 case ModbusFunction::READ_DISCRETE_INPUTS:
//                     rc = modbus_read_input_bits(ctx_, task.addr, task.count, bit_buf.data());
//                     if (rc > 0) result.bits = bit_buf;
//                     break;
//                 case ModbusFunction::WRITE_SINGLE_COIL:
//                     if (task.write_bits.empty()) //<-------------------------------------
//                     {
//                         result.error = "WRITE_SINGLE_COIL invalid data"; //<-------------------------------------
//                         task.promise.set_value(result); //<-------------------------------------
//                         continue; //<-------------------------------------
//                     }
//                     rc = modbus_write_bit(ctx_, task.addr, task.write_bits[0]);
//                     break;
//                 case ModbusFunction::WRITE_MULTI_COILS:
//                     if (task.write_bits.empty()) //<-------------------------------------
//                     {
//                         result.error = "WRITE_MULTI_COILS invalid data"; //<-------------------------------------
//                         task.promise.set_value(result); //<-------------------------------------
//                         continue; //<-------------------------------------
//                     }
//                     rc = modbus_write_bits(ctx_, task.addr,
//                                            task.write_bits.size(),
//                                            task.write_bits.data());
//                     break;
//                 case ModbusFunction::READ_HOLDING:
//                     rc = modbus_read_registers(ctx_, task.addr, task.count, reg_buf.data());
//                     if (rc > 0) std::cout << "mbus read data : " << reg_buf[0] << std::endl;
//                     if (rc > 0) result.regs = reg_buf;
//                     break;
//                 case ModbusFunction::READ_INPUT:
//                     rc = modbus_read_input_registers(ctx_, task.addr, task.count, reg_buf.data());
//                     if (rc > 0) result.regs = reg_buf;
//                     break;
//                 case ModbusFunction::WRITE_SINGLE_REG:
//                     if (task.write_regs.empty()) //<-------------------------------------
//                     {
//                         result.error = "WRITE_SINGLE_REG invalid data"; //<-------------------------------------
//                         task.promise.set_value(result); //<-------------------------------------
//                         continue; //<-------------------------------------
//                     }
//                     std::cout << "write_single_reg : " << task.write_regs[0] << std::endl;

//                     rc = modbus_write_register(ctx_, task.addr, task.write_regs[0]);
//                     break;
//                 case ModbusFunction::WRITE_MULTI_REGS:
//                     if (task.write_regs.empty()) //<-------------------------------------
//                     {
//                         result.error = "WRITE_MULTI_REGS invalid data"; //<-------------------------------------
//                         task.promise.set_value(result); //<-------------------------------------
//                         continue; //<-------------------------------------
//                     }
//                     rc = modbus_write_registers(ctx_, task.addr,
//                                                 task.write_regs.size(),
//                                                 task.write_regs.data());
//                     break;
//             }

//             if (rc == -1) {
//                 LOG_WARNING("Modbus request failed: " +
//                             std::string(modbus_strerror(errno)));
//                 disconnect();
//                 record_fail();
//                 result.error = modbus_strerror(errno);
//             } else {
//                 result.success = true;
//             }

//             task.promise.set_value(result);
//         }
//     }

// private:
//     std::string ip_;
//     int port_;
//     modbus_t* ctx_{nullptr};

//     std::thread worker_;
//     std::atomic<bool> stop_{false};

//     std::mutex q_mtx_;
//     std::condition_variable cv_;
//     std::queue<ModbusTask> tasks_;

//     // backoff state
//     int fail_count_{0};
//     std::chrono::steady_clock::time_point next_retry_time_{};
// };

#pragma once

#include <string>
#include <vector>
#include <thread>
#include <mutex>
#include <queue>
#include <condition_variable>
#include <atomic>
#include <future>
#include <chrono>


// libmodbus structures forward declaration
struct _modbus;
typedef struct _modbus modbus_t;

#include "modbus_types.h"
// #include "common/common.h"
#include "common/rpc_result.h"

struct ModbusTask {
    ModbusFunction fc;
    int addr;
    int count;
    std::vector<uint8_t>  write_bits;
    std::vector<uint16_t> write_regs;
    int timeout_ms;
    std::promise<ModbusResult> promise;
};

using SessionEventCB = std::function<void(int, const std::string&)>;

class ModbusSession {
public:
    ModbusSession(const std::string& ip, int port);
    ~ModbusSession();

    static constexpr size_t MAX_QUEUE = 1000;

    std::future<ModbusResult> enqueue(ModbusTask task);

    void set_event_callback(SessionEventCB cb) { event_cb_ = cb; }

    bool is_functional() const { return !stop_; }

private:
    // ---------- Backoff ----------
    bool connect_allowed();
    void record_fail();
    void reset_backoff();

    // ---------- Connection ----------
    bool connect();
    void disconnect();
    void set_timeout(int ms);

    // ---------- Worker ----------
    void worker_loop();

private:
    std::string ip_;
    int port_;
    modbus_t* ctx_{nullptr};

    std::thread worker_;
    std::atomic<bool> stop_{false};

    std::mutex q_mtx_;
    std::condition_variable cv_;
    std::queue<ModbusTask> tasks_;

    // backoff state
    int fail_count_{0};
    std::chrono::steady_clock::time_point next_retry_time_{};

    SessionEventCB event_cb_;
};