#pragma once
#include <vector>
#include <string>
#include <future>
#include "common/common.h"

enum class ModbusFunction {
    // ---- Bit ----
    READ_COILS           = 1,
    READ_DISCRETE_INPUTS = 2,
    WRITE_SINGLE_COIL    = 5,
    WRITE_MULTI_COILS    = 15,

    // ---- Register ----
    READ_HOLDING         = 3,
    READ_INPUT           = 4,
    WRITE_SINGLE_REG     = 6,
    WRITE_MULTI_REGS     = 16
};

struct ModbusResult {
    bool success{false};
    std::vector<uint8_t>  bits;
    std::vector<uint16_t> regs;
    std::string error;
};
