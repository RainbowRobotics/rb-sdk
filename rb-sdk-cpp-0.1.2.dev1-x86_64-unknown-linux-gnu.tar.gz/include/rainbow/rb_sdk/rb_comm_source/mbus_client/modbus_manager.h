
#pragma once

#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
#include <future>
#include "modbus_session.h"

// LOG_WARNING(...) already defined in common/common.h

struct SessionEntry {
    std::shared_ptr<ModbusSession> session;
    int ref_count{0};
};

class ModbusManager {
public:
    /**
     * @brief Creates a new session or reuses an existing one based on IP and Port.
     */
    int create_session(const std::string& ip, int port);

    /**
     * @brief Forwards a Modbus request to the specified session.
     */
    std::future<ModbusResult> request(
        int session_id,
        ModbusFunction fc,
        int addr,
        int count,
        const std::vector<uint8_t>& bits,
        const std::vector<uint16_t>& regs,
        int timeout_ms);

    /**
     * @brief Decrements reference count and removes session if it reaches zero.
     */
    void close(int session_id);
    bool is_session_alive(int session_id);

    void set_log_callback(RpcLogCallback cb);

    


private:
    std::mutex mtx_;
    int next_id_{1};

    RpcLogCallback log_cb_ = nullptr;

    void send_log(LogType type, int sid,  const std::string& msg);

    std::map<std::string, SessionEntry> sessions_; // key → entry
    std::map<std::string, int> key_to_id_;
    std::map<int, std::string> id_to_key_;
};