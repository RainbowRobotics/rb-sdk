
#pragma once

#include <string>
#include <vector>
#include <thread>
#include <mutex>
#include <queue>
#include <condition_variable>
#include <atomic>
#include <future>
#include <chrono>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <iostream>

#include <sys/socket.h>  // socket(), connect()
#include <arpa/inet.h>   // sockaddr_in, inet_pton(), htons()
#include <unistd.h>      // close(), read(), write()
#include <fcntl.h>       // fcntl(), O_NONBLOCK (Non-blocking 설정용)
#include <sys/select.h>  // select(), fd_set, FD_ZERO, FD_SET (타임아웃용)
#include <cerrno>        // errno, EINPROGRESS
#include <cstring>       // memset

#include "mc_types.h"
// #include "common/common.h" // For LOG_WARNING, etc.
#include "common/rpc_result.h"

using SessionEventCB = std::function<void(int, const std::string&)>;

class McSession {
public:
    McSession(const std::string& ip, int port, McFrameType type);
    ~McSession();

    static constexpr size_t MAX_QUEUE = 1000;

    std::future<McResult> enqueue(McTask task);

    void set_event_callback(SessionEventCB cb) { event_cb_ = cb; }

    bool is_functional() const { return !stop_; }

private:
    // --- Backoff Logic ---
    bool connect_allowed();
    void record_fail();
    void reset_backoff();

    // --- Connection ---
    bool connect_to_server();
    void disconnect();

    // --- Protocol Logic ---
    std::vector<uint8_t> make_3e_packet(const McTask& task);
    bool receive_3e_packet(std::vector<uint8_t>& out_data, const McTask& task);
    
    std::vector<uint8_t> make_1e_packet(const McTask& task);
    bool receive_1e_packet(std::vector<uint8_t>& out_data, const McTask& task);

    McResult parse_mc_response(const std::vector<uint8_t>& data, const McTask& task);
    McResult execute_mc_packet(const McTask& task);
    
   

    void worker_loop();

private:
    std::string ip_;
    int port_;
    int sock_fd_{-1};
    McFrameType frame_type_;
    std::atomic<bool> stop_{false};
    std::atomic<bool> is_connected_{false};
    
    std::thread worker_;
    std::mutex q_mtx_;
    std::condition_variable cv_;
    std::queue<McTask> tasks_;

    // Backoff state
    int fail_count_{0};
    const int MAX_RETRY_LIMIT = 2;
    std::chrono::steady_clock::time_point next_retry_time_{};

    SessionEventCB event_cb_;
};