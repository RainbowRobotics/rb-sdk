#pragma once
#include <vector>
#include <string>
#include <future>
#include <cstdint>


enum class McDeviceType {
    D = 0, M = 1, X = 2, Y = 3
};

enum class McCommandType : uint8_t {
    read_bit = 0,
    read_word = 1,
    write_bit = 2,
    write_word = 3,
};

// MC Frame Types (1E, 3E)
enum class McFrameType {
    MC_1E = 0x01,
    MC_3E = 0x5000,
    NONE = 0x00,
};

// 3E Frame Device Codes (Binary)
enum class McDeviceCode_3E : uint8_t {
    D = 0xA8, // Data Register (Word)
    M = 0x90, // Internal Relay (Bit)
    X = 0x9C, // Input (Bit)
    Y = 0x9D, // Output (Bit)
};

enum class McCommand_3E : uint32_t {
    read_bit = 0x01040100,
    read_word = 0x01040000,
    write_bit = 0x01140100,
    write_word = 0x01140000,
};

enum class McETC_3E : uint8_t {
    net_num = 0x00,
    gugkbun = 0xff,
    unit_io_num_1 = 0xff,
    unit_io_num_2 = 0x03,
    multi_gugkbun = 0x00,
    reserve_1 = 0x00,
    reserve_2 = 0x00,
};

enum class McDeviceCode_1E : uint16_t {
    D = 0x2044, // Data Register (Word)
    M = 0x204D, // Internal Relay (Bit)
    X = 0x2058, // Input (Bit)
    Y = 0x2059, // Output (Bit)
};

enum class McCommand_1E : uint8_t {
    read_bit = 0x00,
    read_word = 0x01,
    write_bit = 0x02,
    write_word = 0x03,
};

enum class McETC_1E : uint8_t {
    PLC_num = 0xFF,
    ACPU_1 = 0x0A,
    ACPU_2 = 0x00,
};


struct McResult {
    bool success{false};
    uint16_t end_code{0}; // 0이면 정상
    // std::vector<uint16_t> word_data; // 워드 읽기 결과
    std::vector<uint8_t>  data_bit;
    std::vector<int16_t>  data_word;
    std::string error_msg;
};

// Task 구조체에 디바이스 코드와 시작 주소 타입을 명시
struct McTask {
    McFrameType which_frame;
    McCommandType cmd;
    McDeviceType device_code;
    uint32_t str_addr;
    uint16_t count;

    std::vector<int16_t> write_word;
    std::vector<uint8_t> write_bit;

    std::promise<McResult> promise;
};