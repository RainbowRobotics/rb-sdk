
#pragma once

#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
#include <future>
#include "mc_session.h"


struct McSessionEntry {
    std::shared_ptr<McSession> session;
    int ref_count{0};
};

class McManager {
public:
    /**
     * @brief 세션을 생성하거나 기존 세션의 참조 횟수를 증가시킵니다.
     */
    int create_session(const std::string& ip, int port, McFrameType type);

    /**
     * @brief 세션 ID를 통해 MC 프로토콜 요청을 큐에 추가합니다.
     */
    std::future<McResult> request(
        int session_id,
        McFrameType which_frame,
        McCommandType cmd_type,
        McDeviceType dev_type,
        uint32_t addr, 
        uint16_t count,
        const std::vector<int16_t>& write_word = {},
        const std::vector<uint8_t>& write_bit = {}
    );

    /**
     * @brief 참조 횟수를 줄이고 0이 되면 세션을 삭제합니다.
     */
    void close(int session_id);
    bool is_session_alive(int session_id);

    void set_log_callback(RpcLogCallback cb);

private:
    std::mutex mtx_;
    int next_id_{1};

    RpcLogCallback log_cb_ = nullptr;

    void send_log(LogType type, int sid,  const std::string& msg);

    std::map<std::string, McSessionEntry> sessions_;
    std::map<std::string, int> key_to_id_;
    std::map<int, std::string> id_to_key_;
};