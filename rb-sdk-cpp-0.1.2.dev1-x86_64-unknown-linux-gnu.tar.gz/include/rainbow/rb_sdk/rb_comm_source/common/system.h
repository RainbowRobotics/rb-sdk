#ifndef SYSTEM_H
#define SYSTEM_H

#include <unistd.h>

#include "common.h"

namespace rb_system {
    std::tuple<std::string, std::string, std::string, std::string> Get_System_Basic_Info();

    int Print_System_Basic_Info();
}

#endif // SYSTEM_H
