#ifndef DOF_H
#define DOF_H

#define SYSTEM_VERSION      "1.0.0"
#define SYSTEM_CATEGORY     "subcore"


#define COUT_RED            "\033[1;31m"
#define COUT_GREEN          "\033[1;32m"
#define COUT_YELLOW         "\033[1;33m"
#define COUT_BLUE           "\033[1;34m"
#define COUT_MAGENTA        "\033[1;35m"
#define COUT_CYAN           "\033[1;36m"
#define COUT_WHITE          "\033[1;37m"
#define COUT_NORMAL         "\033[0m"

#endif // DOF_H
