#ifndef COMMON_H
#define COMMON_H
//------------------------------------------------------------------------
//system
//------------------------------------------------------------------------
#include <pthread.h>
#include <iostream>
#include <string.h>
#include <vector>
#include <chrono>
#include <thread>
#include <mutex>
#include <condition_variable>

enum MESSAGE_LEVEL{
    MSG_LEVEL_INFO = 0,
    MSG_LEVEL_WARN,
    MSG_LEVEL_ERRR,
};

using namespace std::chrono_literals;

//------------------------------------------------------------------------
//functions
//------------------------------------------------------------------------
enum class LogLevel { Info, Warning, Error, User, Debug, Msg};
#define LOG_INFO(msg)                       rb_common::log_push(LogLevel::Info, msg, P_NAME)
#define LOG_WARNING(msg)                    rb_common::log_push(LogLevel::Warning, msg, "SMBC")
#define LOG_ERROR(msg)                      rb_common::log_push(LogLevel::Error, msg, P_NAME)
#define MESSAGE(m_level, m_code)            rb_common::shot_message(m_level, m_code, P_NAME);
#define POPUP(m_level, m_code, m_string)    rb_common::pop_string(m_level, m_code, m_string);

namespace rb_common {
    int     thread_create(void* (*t_handler)(void *), int t_cpu_no, std::string t_name, pthread_t &thread_nrt, void* arg);
    
    void    log_initialize(const std::string& baseName, const std::string& logDir);
    void    log_push(LogLevel level, const std::string& message, const std::string& who_issue);

    int     shot_message(int message_level, int message_code, std::string str_pname);
    int     pop_string(int message_level, int message_code, std::string raw_message);

    std::string get_CurrentTime(int display_unit);
}
#endif // COMMON_H
