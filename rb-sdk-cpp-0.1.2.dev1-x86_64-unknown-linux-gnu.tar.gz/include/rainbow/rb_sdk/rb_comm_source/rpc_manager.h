// #pragma once
// #include <map>
// #include <mutex>
// #include <string>
// #include <vector>
// #include <future>
// #include "common/rpc_result.h"
// #include "mbus_client/modbus_manager.h"
// #include "sock_client/sock_manager.h"
// #include "MC_client/mc_manager.h"
// #include "XGT_client/xgt_manager.h"

// class RpcManager {
// public:
//     RpcManager(ModbusManager* mb_mgr = nullptr, 
//         SocketManager* sk_mgr = nullptr, 
//         McManager* mc_mgr = nullptr,
//         XgtManager* xgt_mgr = nullptr)
//         : modbus_mgr_(mb_mgr), sock_mgr_(sk_mgr), 
//         mc_mgr_(mc_mgr), xgt_mgr_(xgt_mgr) {}

//     void set_modbus_manager(ModbusManager* mgr) {
//         std::lock_guard<std::mutex> lock(mtx_);
//         modbus_mgr_ = mgr;
//     }

//     void set_socket_manager(SocketManager* mgr) {
//         std::lock_guard<std::mutex> lock(mtx_);
//         sock_mgr_ = mgr;
//     }

//     void set_mc_manager(McManager* mgr) {
//         std::lock_guard<std::mutex> lock(mtx_);
//         mc_mgr_ = mgr;
//     }

//     void set_xgt_manager(XgtManager* mgr) {
//         std::lock_guard<std::mutex> lock(mtx_);
//         xgt_mgr_ = mgr;
//     }

//     // =====================================================
//     // 1. Modbus Interface
//     // =====================================================
//     RpcResult read_modbus(const std::string& module, const std::string& ip, int port,
//                           ModbusFunction fc, int addr, int count, int timeout_ms = 1000) {
//         if (!modbus_mgr_) return make_error_result(MSG_COMM_SERVICE_NOT_FOUND);

//         int sid = get_or_create_session(module, ip, port, ProtocolType::MODBUS, McFrameType::NONE, XgtCPUinfo::NONE);
//         if (sid < 0) return make_error_result(MSG_COMM_SERVICE_NOT_FOUND); // 추가

//         auto fut = modbus_mgr_->request(sid, fc, addr, count, {}, {}, timeout_ms);
//         return convert_modbus_result(fut.get());
//     }

//     RpcResult write_modbus(const std::string& module, const std::string& ip, int port,
//                            ModbusFunction fc, int addr, const std::vector<uint8_t>& bits,
//                            const std::vector<uint16_t>& regs, int timeout_ms = 1000) {
//         if (!modbus_mgr_) return make_error_result(MSG_COMM_SERVICE_NOT_FOUND);

//         int sid = get_or_create_session(module, ip, port, ProtocolType::MODBUS, McFrameType::NONE, XgtCPUinfo::NONE);
//         if (sid < 0) return make_error_result(MSG_COMM_SERVICE_NOT_FOUND); // 추가

//         int count = bits.empty() ? regs.size() : bits.size();
//         std::cout << "write value : " << regs[0] << std::endl;
//         auto fut = modbus_mgr_->request(sid, fc, addr, count, bits, regs, timeout_ms);
//         std::cout << "afeter request write value : " << regs[0] << std::endl;
//         return convert_modbus_result(fut.get());
//     }

//     // =====================================================
//     // 2. Socket Interface
//     // =====================================================
//     bool connect_sock(const std::string& module, const std::string& ip, int port, SocketAsyncCallback cb = nullptr) {
//         int sid = get_or_create_session(module, ip, port, ProtocolType::SOCKET, McFrameType::NONE, XgtCPUinfo::NONE, cb);
//         return sid > 0;
//     }
//     // RpcResult request_sock(const std::string& module, const std::string& ip, int port,
//     //                        const std::vector<uint8_t>& data, int timeout_ms = 1000) {
//     //     if (!sock_mgr_) return make_error_result(MSG_COMM_SERVICE_NOT_FOUND);

//     //     int sid = get_or_create_session(module, ip, port, ProtocolType::SOCKET);
//     //     if (sid < 0) return make_error_result(MSG_COMM_SERVICE_NOT_FOUND); // 추가

//     //     auto fut = sock_mgr_->request(sid, data, timeout_ms);
//     //     return convert_sock_result(fut.get());
//     // }

//     // Send data immediately without waiting for a response
//     void send_sock(const std::string& module, const std::string& ip, int port, const std::vector<uint8_t>& data, SocketAsyncCallback cb = nullptr) {
//         int sid = get_or_create_session(module, ip, port, ProtocolType::SOCKET, McFrameType::NONE, XgtCPUinfo::NONE);
//         if (sid > 0 && sock_mgr_) {
//             // sock_mgr_->send(sid, data); // <--- 에러 원인: 이 함수는 없음
//             // 대신 request를 사용 (결과를 기다리지 않으려면 future를 무시)
//             sock_mgr_->request(sid, data); 
//         }
//     }

//     // [수정] Socket 수신 로직
//     RpcResult recv_sock(const std::string& module, const std::string& ip, int port, SocketAsyncCallback cb = nullptr) {
//         int sid = get_or_create_session(module, ip, port, ProtocolType::SOCKET, McFrameType::NONE, XgtCPUinfo::NONE);
//         if (sid <= 0 || !sock_mgr_) {
//             return convert_sock_result({false, {}, "Invalid Session"});
//         }

//         // 세션의 버퍼에서 데이터를 직접 긁어옴 (동기 방식)
//         std::vector<uint8_t> data = sock_mgr_->get_received_data(sid);
        
//         RpcResult res;
//         res.success = !data.empty();
//         res.payload = data; // 수신된 데이터 저장
//         return res;
//     }

//     // =====================================================
//     // 3. MC protocol Interface
//     // =====================================================
//     void connect_mcprotocol(const std::string& module, const std::string& ip, int port, McFrameType frame) {
//         get_or_create_session(module, ip, port, ProtocolType::MCPROTOCOL, frame, XgtCPUinfo::NONE);
//     }   

//     RpcResult reguest_mc(const std::string& module, const std::string& ip, int port,
//                           McFrameType frame, McCommandType cmd, McDeviceType mc_device, uint32_t str_addr,
//                         uint16_t count, std::vector<int16_t>& write_word, std::vector<uint8_t>& write_bit)
//     {
//         // std::cout << "test mc read" << " : " <<static_cast<int>(frame) << 
//         // " : " <<static_cast<int>(cmd) <<" : " << static_cast<int>(mc_device) <<" : " << str_addr << std::endl;
//         if (!mc_mgr_) return make_error_result(MSG_COMM_SERVICE_NOT_FOUND);

//         int mcid = get_or_create_session(module, ip, port, ProtocolType::MCPROTOCOL, frame, XgtCPUinfo::NONE);
//         if (mcid < 0) return make_error_result(MSG_COMM_SERVICE_NOT_FOUND);

//         // Fetch data from Manager's internal buffer
//         auto mc = mc_mgr_->request(mcid, frame, cmd, mc_device, str_addr, count, write_word, write_bit);
//         return convert_mc_result(mc.get());
//     }

//     // =====================================================
//     // 4. XGT protocol Interface
//     // =====================================================
//     void connect_xgtprotocol(const std::string& module, const std::string& ip, int port, XgtCPUinfo cpu) {
//         // std::cout <<"??????" <<std::endl;
//         get_or_create_session(module, ip, port, ProtocolType::XGTPROTOCOL, McFrameType::NONE, cpu);
//     }   

//     RpcResult reguest_xgt(const std::string& module, const std::string& ip, int port,
//                          XgtCommand cmd, XgtCPUinfo cpu, XgtDeviceType device, uint32_t str_addr,
//                         uint16_t count, std::vector<int16_t>& write_word)
//     {
//         if (!xgt_mgr_) return make_error_result(MSG_COMM_SERVICE_NOT_FOUND);

//         int xgtid = get_or_create_session(module, ip, port, ProtocolType::XGTPROTOCOL, McFrameType::NONE, cpu);
//         if (xgtid < 0) return make_error_result(MSG_COMM_SERVICE_NOT_FOUND);

//         // std::cout <<"herereraererer22" << std::endl;

//         // Fetch data from Manager's internal buffer
//         auto xgt = xgt_mgr_->request(xgtid, cmd, cpu, str_addr, count, device, write_word); 

        
        
//         return convert_xgt_result(xgt.get());
//     }


//     // =====================================================
//     // 5. 세션 및 모듈 관리
//     // =====================================================
//     void disconnect_module(const std::string& module) {
//         std::lock_guard<std::mutex> lock(mtx_);
//         auto mit = modules_.find(module);
//         if (mit == modules_.end()) return;

//         // 포인터 접근자 -> 사용 및 Null 체크
//         if (modbus_mgr_) {
//             for (auto& kv : mit->second.mb_sessions) modbus_mgr_->close(kv.second);
//         }
//         if (sock_mgr_) {
//             for (auto& kv : mit->second.sk_sessions) sock_mgr_->close(kv.second);
//         }
//         if (mc_mgr_) {
//             for (auto& kv : mit->second.mc_sessions) mc_mgr_->close(kv.second);
//         }
//         // if (xgt_mgr_) {
//         //     for (auto& kv : mit->second.xgt_sessions) xgt_mgr_->close(kv.second);
//         // }
        
//         modules_.erase(mit);
//         LOG_WARNING("RPC module removed: " + module);
//     }

// private:
//     enum class ProtocolType { MODBUS, SOCKET, MCPROTOCOL, XGTPROTOCOL };

//     struct ModuleEntry {
//         std::map<std::string, int> mb_sessions;
//         std::map<std::string, int> sk_sessions;
//         std::map<std::string, int> mc_sessions;
//         std::map<std::string, int> xgt_sessions;
//     };

//     RpcResult make_error_result(RpcError err) {
//         RpcResult rr;
//         rr.success = false;
//         rr.error = err;
//         return rr;
//     }

//     // Lazy Connection Helper 내부 Null 체크 보강
//     int get_or_create_session(const std::string& module, const std::string& ip, int port, 
//                               ProtocolType type, McFrameType frame, XgtCPUinfo cpu, SocketAsyncCallback cb = nullptr) {
//         std::lock_guard<std::mutex> lock(mtx_);
//         auto& entry = modules_[module];
//         std::string key = ip + ":" + std::to_string(port);

//         if (type == ProtocolType::MODBUS) {
//             if (entry.mb_sessions.count(key)) return entry.mb_sessions[key];
//             if (!modbus_mgr_) return -1; // 매니저 없으면 에러 리턴
//             int sid = modbus_mgr_->create_session(ip, port); // -> 사용
//             entry.mb_sessions[key] = sid;
//             return sid;
//         } else if(type == ProtocolType::SOCKET){
//             if (entry.sk_sessions.count(key)) return entry.sk_sessions[key];
//             if (!sock_mgr_) return -1; // 매니저 없으면 에러 리턴
//             int sid = sock_mgr_->create_session(ip, port, cb); // -> 사용
//             entry.sk_sessions[key] = sid;
//             return sid;
//         } else if(type == ProtocolType::MCPROTOCOL){
//             if (entry.mc_sessions.count(key)) return entry.mc_sessions[key];
//             if (!mc_mgr_) return -1; // 매니저 없으면 에러 리턴
//             int sid = mc_mgr_->create_session(ip, port, frame); // -> 사용
//             entry.mc_sessions[key] = sid;
//             return sid;
//         } else if(type == ProtocolType::XGTPROTOCOL){
//             if (entry.xgt_sessions.count(key)) return entry.xgt_sessions[key];
//             if (!xgt_mgr_) return -1; // 매니저 없으면 에러 리턴
//             int sid = xgt_mgr_->create_session(ip, port, cpu); // -> 사용            
//             entry.xgt_sessions[key] = sid;
//             return sid;
//         }

//         return -1;
//     }

//     // 에러 변환 로직 (Modbus)
//     RpcResult convert_modbus_result(const ModbusResult& mr) {
//         RpcResult rr;
//         rr.success = mr.success;
//         rr.bits = mr.bits;
//         if (!rr.regs.empty()) {
//             std::cout << "rpc_mbus chk : " << rr.regs[0] << std::endl;
//         } else {
//             std::cout << "rpc_mbus chk : No data returned (Write operation)" << std::endl;
//         }
//         // std::cout<< "rpc_mbus chk : " << rr.regs[0] << std::endl;
//         if (!mr.success) rr.error = parse_error_string(mr.error);
//         else rr.error = MSG_OK;
//         // std::cout<< "rpc_mbus chk2 : " << rr.regs[0] << std::endl;
//         return rr;
//     }

//     // 에러 변환 로직 (Socket)
//     RpcResult convert_sock_result(const SocketResult& sr) {
//         RpcResult rr;
//         rr.success = sr.success;
//         rr.payload = sr.payload;
//         if (!sr.success) rr.error = parse_error_string(sr.error);
//         else rr.error = MSG_OK;
//         return rr;
//     }

//     // 에러 변환 로직 (McProtocol)
//     RpcResult convert_mc_result(const McResult& mc) {
//         RpcResult rr;
//         rr.success = mc.success;
//         if (!mc.data_bit.empty()) rr.data_bit = mc.data_bit;
//         if (!mc.data_word.empty()) rr.data_word = mc.data_word;
        
//         if (!mc.success) rr.error = parse_error_hex(mc.end_code);
//         else rr.error = MSG_OK;
//         return rr;
//     }

//     // 에러 변환 로직 (McProtocol)
//     RpcResult convert_xgt_result(const XgtResult& xgt) {
//         RpcResult rr;
//         rr.success = xgt.success;
//         if (!xgt.data_word.empty()) rr.data_word_xgt = xgt.data_word;
//         // if (!mc.data_word.empty()) rr.data_word = mc.data_word;
        
//         if (!xgt.success) rr.error = parse_error_hex(xgt.end_code);
//         else rr.error = MSG_OK;
//         return rr;
//     }

//     int parse_error_string(const std::string& err) {
//         if (err.find("timeout") != std::string::npos) return RpcError::MSG_COMM_TIME_OUT;
//         if (err.find("connect") != std::string::npos || err.find("Connection") != std::string::npos)
//             return RpcError::MSG_COMM_SERVER_CONNECT_FAIL;
//         return RpcError::MSG_COMM_UNKNOWN_ERROR;
//     }

//     int parse_error_hex(const uint16_t& err) {
//         // if (err.find("timeout") != std::string::npos) return RpcError::MSG_COMM_TIME_OUT;
//         // if (err.find("connect") != std::string::npos || err.find("Connection") != std::string::npos)
//         //     return RpcError::MSG_COMM_SERVER_CONNECT_FAIL;
//         return RpcError::MSG_COMM_UNKNOWN_ERROR;
//     }

//     std::mutex mtx_;
//     ModbusManager* modbus_mgr_{nullptr};
//     SocketManager* sock_mgr_{nullptr};
//     McManager* mc_mgr_{nullptr};
//     XgtManager* xgt_mgr_{nullptr};
//     std::map<std::string, ModuleEntry> modules_;
// };

#pragma once

#include <map>
#include <mutex>
#include <string>
#include <vector>
#include <future>
#include <iostream>

#include "common/rpc_result.h"
#include "mbus_client/modbus_manager.h"
#include "sock_client/sock_manager.h"
#include "MC_client/mc_manager.h"
#include "XGT_client/xgt_manager.h"
#ifdef RB_ENABLE_EIP_FINS
#include "eip_scanner/eip_manager.h"
#include "eip_scanner/eip_types.h"
#include "FINS_client/fins_manager.h"
#endif

class RpcManager {
public:
    // RpcManager(ModbusManager* mb_mgr = nullptr, 
    //            SocketManager* sk_mgr = nullptr, 
    //            McManager* mc_mgr = nullptr,
    //            XgtManager* xgt_mgr = nullptr);

    RpcManager(RpcLogCallback log_cb = nullptr);
    ~RpcManager() = default;

    void on_inner_log(LogType type, int sid, const std::string& msg);

    

    // void set_modbus_manager(ModbusManager* mgr);
    // void set_socket_manager(SocketManager* mgr);
    // void set_mc_manager(McManager* mgr);
    // void set_xgt_manager(XgtManager* mgr);

    // 1. Modbus Interface
    RpcResult read_modbus(const std::string& module, const std::string& ip, int port,
                          ModbusFunction fc, int addr, int count, int timeout_ms = 1000);
    RpcResult write_modbus(const std::string& module, const std::string& ip, int port,
                           ModbusFunction fc, int addr, const std::vector<uint8_t>& bits,
                           const std::vector<uint16_t>& regs, int timeout_ms = 1000);

    // 2. Socket Interface
    bool connect_sock(const std::string& module, const std::string& ip, int port, SocketAsyncCallback cb = nullptr);
    RpcResult send_sock(const std::string& module, const std::string& ip, int port, const std::vector<uint8_t>& data, SocketAsyncCallback cb = nullptr);
    RpcResult recv_sock(const std::string& module, const std::string& ip, int port,
                        SocketAsyncCallback cb = nullptr, int timeout_ms = 0);

    // 3. MC protocol Interface
    void connect_mcprotocol(const std::string& module, const std::string& ip, int port, McFrameType frame);
    RpcResult request_mc(const std::string& module, const std::string& ip, int port,
                         McFrameType frame, McCommandType cmd, McDeviceType mc_device, uint32_t str_addr,
                         uint16_t count, std::vector<int16_t>& write_word, std::vector<uint8_t>& write_bit);

    // 4. XGT protocol Interface
    void connect_xgtprotocol(const std::string& module, const std::string& ip, int port, XgtCPUinfo cpu);
    RpcResult request_xgt(const std::string& module, const std::string& ip, int port,
                          XgtCommand cmd, XgtCPUinfo cpu, XgtDeviceType device, uint32_t str_addr,
                          uint16_t count, std::vector<int16_t>& write_word);

#ifdef RB_ENABLE_EIP_FINS
    // 5. EIP (EtherNet/IP) Interface
    EdsData   load_eds(const std::string& eds_path);
    void      connect_eip(const std::string& module, const std::string& ip, int port,
                          const std::string& eds_path = "",
                          uint16_t t2o_assembly = 0, uint16_t o2t_assembly = 0);
    EipResult read_eip_attribute(const std::string& module, const std::string& ip, int port,
                                 uint16_t class_id, uint16_t instance, uint16_t attribute);
    EipResult write_eip_attribute(const std::string& module, const std::string& ip, int port,
                                  uint16_t class_id, uint16_t instance, uint16_t attribute,
                                  const std::vector<uint8_t>& data);
    EipIoResult get_eip_io_input(const std::string& module, const std::string& ip, int port);
    bool        set_eip_io_output(const std::string& module, const std::string& ip, int port,
                                  const std::vector<uint8_t>& data);
    bool        set_eip_io_output_named(const std::string& module, const std::string& ip, int port,
                                        const std::vector<std::string>& names,
                                        const std::vector<double>& values);
    void        set_eip_rpi(const std::string& module, const std::string& ip, int port,
                            uint32_t rpi_ms);
    bool        is_eip_implicit_connected(const std::string& module, const std::string& ip,
                                          int port);

    // 6. FINS (Omron)
    void      connect_fins(const std::string& module, const std::string& ip, int port,
                           uint8_t fallback_server_node = 1,
                           uint8_t fallback_client_node = 0);
    RpcResult request_fins(const std::string& module, const std::string& ip, int port,
                           FinsCommand cmd, FinsMemArea mem_area,
                           uint16_t word_addr, uint8_t bit_addr, uint16_t count,
                           const std::vector<uint16_t>& write_word = {},
                           const std::vector<uint8_t>&  write_bit  = {});
#endif

    // 7. 관리
    void disconnect_module(const std::string& module);

    // 8. 상태 조회
    std::vector<std::string>       get_module_names() const;
    std::map<std::string, int>     get_session_counts(const std::string& module) const;

private:
    enum class ProtocolType { MODBUS, SOCKET, MCPROTOCOL, XGTPROTOCOL, EIP };

    RpcLogCallback external_log_cb_; // main에서 등록한 콜백

    struct ModuleEntry {
        std::map<std::string, int> mb_sessions;
        std::map<std::string, int> sk_sessions;
        std::map<std::string, int> mc_sessions;
        std::map<std::string, int> xgt_sessions;
#ifdef RB_ENABLE_EIP_FINS
        std::map<std::string, int> eip_sessions;
        std::map<std::string, int> fins_sessions;
#endif
    };

    RpcResult make_error_result(RpcError err);
    int get_or_create_session(const std::string& module, const std::string& ip, int port, 
                              ProtocolType type, McFrameType frame, XgtCPUinfo cpu, SocketAsyncCallback cb = nullptr);

    RpcResult convert_modbus_result(const ModbusResult& mr);
    RpcResult convert_sock_result(const SocketResult& sr);
    RpcResult convert_mc_result(const McResult& mc);
    RpcResult convert_xgt_result(const XgtResult& xgt);

    int parse_error_string(const std::string& err);
    int parse_error_hex(const uint16_t& err);

    std::unique_ptr<ModbusManager> modbus_mgr_;
    std::unique_ptr<SocketManager> sock_mgr_;
    std::unique_ptr<McManager>     mc_mgr_;
    std::unique_ptr<XgtManager>    xgt_mgr_;
#ifdef RB_ENABLE_EIP_FINS
    std::unique_ptr<EipManager>    eip_mgr_;
    std::unique_ptr<FinsManager>   fins_mgr_;

    int get_or_create_eip_session(const std::string& module, const std::string& ip,
                                  int port, const std::string& eds_path,
                                  uint16_t t2o_assembly = 0, uint16_t o2t_assembly = 0);
    // 기존 세션만 조회 (없으면 -1) — 조회 전용 함수에서 사용
    int find_eip_session(const std::string& module, const std::string& ip, int port) const;
#endif

    mutable std::mutex mtx_;
    std::map<std::string, ModuleEntry> modules_;
};