
#pragma once

#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
#include <future>
#include "sock_session.h"

struct SocketSessionEntry {
    std::shared_ptr<SocketSession> session;
    int ref_count{0};
};

class SocketManager {
public:
    /**
     * @brief IP와 Port를 기반으로 세션을 생성하거나 기존 세션을 재사용합니다.
     */
    int create_session(const std::string& ip, int port, SocketAsyncCallback callback = nullptr);

    /**
     * @brief 세션 ID를 통해 데이터를 송신하고 응답을 기다리는 future를 반환합니다.
     */
    std::future<SocketResult> request(int session_id, const std::vector<uint8_t>& data, int timeout_ms = 1000);

    /**
     * @brief 세션의 수신 버퍼에서 데이터를 가져옵니다.
     *        timeout_ms > 0 이면 데이터 도착까지 최대 N ms 대기합니다.
     */
    std::vector<uint8_t> get_received_data(int session_id, int timeout_ms = 0);

    /**
     * @brief 참조 횟수를 줄이고 0이 되면 세션을 종료 및 삭제합니다.
     */
    void close(int session_id);
    bool is_session_alive(int session_id);

    void set_log_callback(RpcLogCallback cb);


private:
    std::mutex mtx_;
    int next_id_{1};

    RpcLogCallback log_cb_ = nullptr;

    void send_log(LogType type, int sid,  const std::string& msg);


    std::map<std::string, SocketSessionEntry> sessions_;
    std::map<std::string, int> key_to_id_;
    std::map<int, std::string> id_to_key_;
};