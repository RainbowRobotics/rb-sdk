#pragma once
#include <vector>
#include <string>
#include <future>
#include <cstdint>

// Result of a socket communication task
struct SocketResult {
    bool success{false};
    std::vector<uint8_t> payload; // Received data
    std::string error;
};

// Task to be queued in SocketSession
struct SocketTask {
    std::vector<uint8_t> send_data;
    size_t expected_len{0};       // If 0, receive as much as possible or just send
    int timeout_ms{1000};
    std::promise<SocketResult> promise;
};