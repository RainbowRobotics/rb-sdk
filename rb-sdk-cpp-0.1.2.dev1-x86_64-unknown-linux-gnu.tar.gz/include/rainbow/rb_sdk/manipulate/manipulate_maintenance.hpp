#pragma once

#include "base.hpp"
#include "common_struct_generated.h"
#include "func_config_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "state_core_generated.h"

class RBManipulateMaintenanceSDK : public RBBaseSDK {
 public:
  RBManipulateMaintenanceSDK() {}

  static std::string type_name() { return "RBManipulateMaintenanceSDK"; }

  /**
   * @brief Requests the cobot to log/broadcast a joint board's info.
   *
   * This does not return the joint info through the SDK call itself — the
   * robot only reports success/failure here. The actual info is logged and
   * broadcast as a general message on the robot side (visible on the
   * teach-pendant/UI, not returned to this caller). Also powers the robot
   * on if it isn't already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         joint info payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_infos(std::string& robot_model, int board_no,
                                           FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Pop_JointInfosT req = IPC::Request_Pop_JointInfosT{.board_no = board_no};

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Pop_JointInfosT>(
        robot_model + "/pop_joint_infos", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("pop_joint_infos failed: query one returned nullptr");
    manipulate_return_value("pop_joint_infos", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to set a joint board's brake state.
   *
   * If @p brake_optioin is 1 (Open, Hard) or 2 (Weak), this powers the
   * robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to control. A negative value
   *        applies to every joint board.
   * @param brake_optioin Brake option: 0 (Close), 1 (Open, Hard), 2 (Weak),
   *        or 3 (Close only). (Parameter name matches the underlying wire
   *        field's spelling, including its typo.)
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_brake(std::string& robot_model, int board_no, int brake_optioin,
                                            FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_JointBrakeT req = IPC::Request_JointBrakeT{.board_no = board_no, .brake_optioin = brake_optioin};

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_JointBrakeT>(
        robot_model + "/call_joint_brake", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("call_joint_brake failed: query one returned nullptr");
    manipulate_return_value("call_joint_brake", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to zero a joint board's encoder.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to zero. A negative value applies
   *        to every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_encoder_zero(std::string& robot_model, int board_no,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_JointEncoderZeroT req = IPC::Request_JointEncoderZeroT{.board_no = board_no};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_JointEncoderZeroT>(robot_model + "/call_joint_encoder_zero",
                                                                           req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("call_joint_encoder_zero failed: query one returned nullptr");
    manipulate_return_value("call_joint_encoder_zero", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to run a joint board's current-sensor calibration procedure.
   *
   * This is a multi-stage physical calibration, not an instant reset:
   * cycles the brake and runs DQ-axis alignment (3 tries), DQ save (2
   * tries), and current nulling (2 tries), with real delays between steps.
   * Takes on the order of several seconds per joint. Powers the robot on
   * first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to calibrate. A negative value
   *        applies to every joint board (multiplying the total time).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_sensor_reset(std::string& robot_model, int board_no,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_JointSensorResetT req = IPC::Request_JointSensorResetT{.board_no = board_no};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_JointSensorResetT>(robot_model + "/call_joint_sensor_reset",
                                                                           req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("call_joint_sensor_reset failed: query one returned nullptr");
    manipulate_return_value("call_joint_sensor_reset", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to set a joint board's current-loop gains.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param pgain Proportional gain of the current control loop.
   * @param igain Integral gain of the current control loop.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_gain_cur(std::string& robot_model, int board_no, int pgain, int igain,
                                              FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Set_JointGain_CurT req =
        IPC::Request_Set_JointGain_CurT{.board_no = board_no, .pgain = pgain, .igain = igain};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Set_JointGain_CurT>(robot_model + "/set_joint_gain_cur", req, 8,
                                                                            2000, 0);

    if (!result)
      throw std::runtime_error("set_joint_gain_cur failed: query one returned nullptr");
    manipulate_return_value("set_joint_gain_cur", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to set a joint board's position-loop gains.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param pgain Proportional gain of the position control loop.
   * @param igain Integral gain of the position control loop.
   * @param dgain Derivative gain of the position control loop.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_gain_pos(std::string& robot_model, int board_no, int pgain, int igain, int dgain,
                                              FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Set_JointGain_PosT req =
        IPC::Request_Set_JointGain_PosT{.board_no = board_no, .pgain = pgain, .igain = igain, .dgain = dgain};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Set_JointGain_PosT>(robot_model + "/set_joint_gain_pos", req, 8,
                                                                            2000, 0);

    if (!result)
      throw std::runtime_error("set_joint_gain_pos failed: query one returned nullptr");
    manipulate_return_value("set_joint_gain_pos", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to log/broadcast a joint board's current-loop gains.
   *
   * Counterpart to @c set_joint_gain_cur, but this does not return the
   * gain values through the SDK call — the robot only reports
   * success/failure here. The actual gains are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         gain payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_gain_cur(std::string& robot_model, int board_no,
                                              FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Pop_JointGain_CurT req = IPC::Request_Pop_JointGain_CurT{.board_no = board_no};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Pop_JointGain_CurT>(robot_model + "/pop_joint_gain_cur", req, 8,
                                                                            2000, 0);

    if (!result)
      throw std::runtime_error("pop_joint_gain_cur failed: query one returned nullptr");
    manipulate_return_value("pop_joint_gain_cur", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to log/broadcast a joint board's position-loop gains.
   *
   * Counterpart to @c set_joint_gain_pos, but this does not return the
   * gain values through the SDK call — the robot only reports
   * success/failure here. The actual gains are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         gain payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_gain_pos(std::string& robot_model, int board_no,
                                              FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Pop_JointGain_PosT req = IPC::Request_Pop_JointGain_PosT{.board_no = board_no};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Pop_JointGain_PosT>(robot_model + "/pop_joint_gain_pos", req, 8,
                                                                            2000, 0);

    if (!result)
      throw std::runtime_error("pop_joint_gain_pos failed: query one returned nullptr");
    manipulate_return_value("pop_joint_gain_pos", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to change a joint board's board-number assignment.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param channel_no Channel the joint board is on.
   * @param board_no Current joint board number. A negative value applies
   *        to every joint board.
   * @param target_no New board number to assign.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_bno_change(std::string& robot_model, int channel_no, int board_no, int target_no,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_JointBnoChangeT req =
        IPC::Request_JointBnoChangeT{.channel_no = channel_no, .board_no = board_no, .target_no = target_no};

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_JointBnoChangeT>(
        robot_model + "/call_joint_bno_change", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("call_joint_bno_change failed: query one returned nullptr");
    manipulate_return_value("call_joint_bno_change", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to set a joint board's big-error/input-error pulse thresholds.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param bigerr Big-error pulse threshold.
   * @param inputerr Input-error pulse threshold.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_big_input(std::string& robot_model, int board_no, int bigerr, int inputerr,
                                               FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Set_JointBigInputT req =
        IPC::Request_Set_JointBigInputT{.board_no = board_no, .bigerr = bigerr, .inputerr = inputerr};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Set_JointBigInputT>(robot_model + "/set_joint_big_input", req,
                                                                            8, 2000, 0);

    if (!result)
      throw std::runtime_error("set_joint_big_input failed: query one returned nullptr");
    manipulate_return_value("set_joint_big_input", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to log/broadcast a joint board's big-error/input-error pulse thresholds.
   *
   * Counterpart to @c set_joint_big_input, but this does not return the
   * threshold values through the SDK call — the robot only reports
   * success/failure here. The actual values are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         threshold payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_big_input(std::string& robot_model, int board_no,
                                               FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Pop_JointBigInpT req = IPC::Request_Pop_JointBigInpT{.board_no = board_no};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Pop_JointBigInpT>(robot_model + "/pop_joint_big_input", req, 8,
                                                                          2000, 0);

    if (!result)
      throw std::runtime_error("pop_joint_big_input failed: query one returned nullptr");
    manipulate_return_value("pop_joint_big_input", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to set a joint board's jam/overcurrent error thresholds.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param jam_current Jam-error current limit, in mA.
   * @param jam_time Jam-error duration threshold, in units of 0.1s.
   * @param ovr_current Overcurrent-error current limit, in mA.
   * @param ovr_time Overcurrent-error duration threshold, in units of 0.1s
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_jam_over(std::string& robot_model, int board_no, int jam_current, int jam_time,
                                              int ovr_current, int ovr_time,
                                              FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Set_JointJamOverT req = IPC::Request_Set_JointJamOverT{.board_no = board_no,
                                                                        .jam_current = jam_current,
                                                                        .jam_time = jam_time,
                                                                        .ovr_current = ovr_current,
                                                                        .ovr_time = ovr_time};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Set_JointJamOverT>(robot_model + "/set_joint_jam_over", req, 8,
                                                                           2000, 0);

    if (!result)
      throw std::runtime_error("set_joint_jam_over failed: query one returned nullptr");
    manipulate_return_value("set_joint_jam_over", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to log/broadcast a joint board's jam/overcurrent error thresholds.
   *
   * Counterpart to @c set_joint_jam_over, but this does not return the
   * threshold values through the SDK call — the robot only reports
   * success/failure here. The actual values are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         threshold payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_jam_over(std::string& robot_model, int board_no,
                                              FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Pop_JointJamOvrT req = IPC::Request_Pop_JointJamOvrT{.board_no = board_no};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Pop_JointJamOvrT>(robot_model + "/pop_joint_jam_over", req, 8,
                                                                          2000, 0);

    if (!result)
      throw std::runtime_error("pop_joint_jam_over failed: query one returned nullptr");
    manipulate_return_value("pop_joint_jam_over", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }
};
