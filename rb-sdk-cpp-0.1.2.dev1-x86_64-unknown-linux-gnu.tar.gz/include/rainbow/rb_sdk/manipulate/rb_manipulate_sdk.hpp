#pragma once

#include "base.hpp"
#include "manipulate_config.hpp"
#include "manipulate_flange.hpp"
#include "manipulate_get_data.hpp"
#include "manipulate_io.hpp"
#include "manipulate_maintenance.hpp"
#include "manipulate_move.hpp"
#include "manipulate_point.hpp"
#include "manipulate_program.hpp"
#include "manipulate_safety.hpp"
#include "manipulate_service.hpp"
#include "manipulate_state.hpp"
#include "manipulate_vision.hpp"

class RBManipulateSDK : public RBBaseSDK

// """Rainbow Robotics Manipulate Total SDK"""

// program: RBManipulateProgramSDK
// """프로그램 관련 SDK 집합"""

// move: RBManipulateMoveSDK
// """모션/이동 관련 SDK 집합"""

// config: RBManipulateConfigSDK
// """환경설정/파라미터 관련 SDK 집합"""

// io: RBManipulateIOSDK
// """IO 제어 SDK 집합"""

// get_data: RBManipulateGetDataSDK
// """상태/데이터 조회 SDK 집합"""

// point: RBManipulatePointSDK
// """포인트/좌표 관련 SDK 집합"""

// service: RBManipulateServiceSDK
// """Move 미니 Tab SDK 집합"""

// maintenance: RBManipulateMaintenanceSDK
// """관리자 페이지 설정 집합"""

// state: RBManipulateStateSDK
{
 public:
  RBManipulateStateSDK state;
  RBManipulateProgramSDK program;
  RBManipulateMoveSDK move;
  RBManipulateConfigSDK config;
  RBManipulateIOSDK io;
  RBManipulateGetDataSDK get_data;
  RBManipulatePointSDK point;
  RBManipulateServiceSDK service;
  RBManipulateMaintenanceSDK maintenance;
  RBManipulateSafetySDK safety;
  RBManipulateFlangeSDK flange;
  RBManipulateVisionSDK vision;

  // Re-declare the inherited connect() here so litgen (which never parses the
  // zenoh/template-heavy RBBaseSDK base header) sees it and binds it directly.
  std::optional<std::string> connect(const ConnectOptions& options) { return RBBaseSDK::connect(options); }

  void close() { RBBaseSDK::close(); }

  ~RBManipulateSDK() override { close(); }

  // 자식 멤버 SDK(각자 독립된 RBBaseSDK 서브객체이자 zenoh ref-count 보유자)는 별도
  // 인스턴스 레지스트리가 없다. Python 원본의 close_all_for_pid() 가 sub-SDK 인스턴스까지
  // 개별 정리하던 것에 대응해, root 하나를 정리하면 자식 전부가 정리되도록 여기서 전파한다.
  // 특히 vision.close() 는 RBManipulateVisionSDK::before_close() 를 태워 벤더 클라이언트
  // (mechmind/photoneo/pickit)를 끊는다.
  //
  // PyFM(ExecutionContext._safe_close_sdk)는 task teardown 시 이 before_close() 를 명시
  // 호출한다.
  //
  // ⚠️ 현재 구조의 한계: PyFM 은 before_close() 만 부르고 root 자신의 close() 는 부르지
  //    않으므로, 자식들의 zenoh ref/구독은 여기서 즉시 정리되지만 root 자신의 zenoh ref 는
  //    GC(pybind wrapper 소멸) → ~RBManipulateSDK() → close() 까지 남는다. before_close 만
  //    바인딩한 데서 오는 제약이며 "일단 동작"에는 문제 없다. 나중에 C++ RBBaseSDK 에
  //    Python 의 _instances 레지스트리 + close_all_for_pid() 동등물을 포팅하면, PyFM 은
  //    그 한 줄만 부르고 root 까지 결정론적으로 정리되어 이 override / 전파 루프는 제거 가능.
  void before_close() override {
    state.close();
    program.close();
    move.close();
    config.close();
    io.close();
    get_data.close();
    point.close();
    service.close();
    maintenance.close();
    safety.close();
    flange.close();
    vision.close();
  }

  // deprecated. program.folder_finish_at 로 대체.
  [[deprecated("Use program.folder_finish_at instead.")]]
  void move_finish_at_stop(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr) {
    program.folder_finish_at(robot_model, flow_manager_args);
  }
};
