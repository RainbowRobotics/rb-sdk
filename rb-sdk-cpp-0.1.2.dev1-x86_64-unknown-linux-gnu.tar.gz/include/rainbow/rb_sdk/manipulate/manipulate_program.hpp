#pragma once

#include "base.hpp"
#include "common_struct_generated.h"
#include "func_config_generated.h"
#include "func_flow_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "func_set_generated.h"
#include "manipulate_config.hpp"
#include "manipulate_get_data.hpp"
#include "manipulate_io.hpp"
#include "manipulate_move.hpp"
#include "program_setting_args.hpp"
#include "state_core_generated.h"
#include "vibration_motion_arg.hpp"

struct SettingOptions {
  inline static constexpr std::string_view USER_FRAME_SELECTION = "USER_FRAME_SELECTION";
  inline static constexpr std::string_view OUT_COLLISION = "OUT_COLLISION";
  inline static constexpr std::string_view SELF_COLLISION = "SELF_COLLISION";
  inline static constexpr std::string_view FIXED_SPEED = "FIXED_SPEED";
  inline static constexpr std::string_view TARGET_SHIFT = "TARGET_SHIFT";
  inline static constexpr std::string_view SPEED_BAR = "SPEED_BAR";
  inline static constexpr std::string_view TIME_CONSTRAINT = "TIME_CONSTRAINT";
  inline static constexpr std::string_view ASCII_FUNCTION_CALL = "ASCII_FUNCTION_CALL";
  inline static constexpr std::string_view JOINT_IMPEDANCE = "JOINT_IMPEDANCE";
  inline static constexpr std::string_view FREE_DRIVE = "FREE_DRIVE";
  inline static constexpr std::string_view MASTER_MODE = "MASTER_MODE";
  inline static constexpr std::string_view USER_FRAME_6DOF = "USER_FRAME_6DOF";
  inline static constexpr std::string_view USER_FRAME_TCP = "USER_FRAME_TCP";
  inline static constexpr std::string_view USER_FRAME_3POINTS = "USER_FRAME_3POINTS";
  inline static constexpr std::string_view TARGET_SHIFT_LANDMARK = "TARGET_SHIFT_LANDMARK";
  inline static constexpr std::string_view PROGRAM_FLOW_MANAGE = "PROGRAM_FLOW_MANAGE";
  inline static constexpr std::string_view DIN_FUNCTION_MASK = "DIN_FUNCTION_MASK";
  inline static constexpr std::string_view DOUT_FUNCTION_MASK = "DOUT_FUNCTION_MASK";
  inline static constexpr std::string_view JACOBIAN_BASED_SPEED_CONTROL = "JACOBIAN_BASED_SPEED_CONTROL";
  inline static constexpr std::string_view SELF_VIBRATION_MODE = "SELF_VIBRATION_MODE";
  inline static constexpr std::string_view VIBRATION_MOTION_BASED = "VIBRATION_MOTION_BASED";
  inline static constexpr std::string_view EXTERNAL_AXIS_SYNC = "EXTERNAL_AXIS_SYNC";
  inline static constexpr std::string_view TCP_SPEED_BOUND = "TCP_SPEED_BOUND";
  inline static constexpr std::string_view MOVE_BREAK_BLOCK = "MOVE_BREAK_BLOCK";
  inline static constexpr std::string_view JOINT_REFERENCE_FILTER = "JOINT_REFERENCE_FILTER";
  inline static constexpr std::string_view SELF_COLL_DETECT_BLIND = "SELF_COLL_DETECT_BLIND";
};

struct PinType {
  inline static constexpr std::string_view POINT = "POINT";
  inline static constexpr std::string_view JOINT = "JOINT";
};

struct Project {
  inline static constexpr std::string_view MAIN = "MAIN";
  inline static constexpr std::string_view SUB = "SUB";
};

enum class Posture { ZERO = 0, ONE = 1 };

class RBManipulateProgramSDK : public RBBaseSDK {
 public:
  RBManipulateProgramSDK() {}

  static std::string type_name() { return "RBManipulateProgramSDK"; }

  /**
   * @brief Requests the cobot to resume motion.
   *
   * Resumes motion previously paused via @c call_pause, so the in-progress
   * move/program can continue from where it left off.
   *
   * @param robot_model Name of the robot model.
   *
   * @return IPC::Response_FunctionsT containing the resume request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_resume(const std::string& robot_model) {
    IPC::Request_MotionResumeT req;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_MotionResumeT>(robot_model + "/call_resume", req, 2, 1000, 0);

    if (!result)
      throw std::runtime_error("Call Resume failed: query one returned nullptr");

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to pause motion.
   *
   * Temporarily pauses in-progress motion; call @c call_resume afterward
   * to continue from where it was paused.
   *
   * @param robot_model Name of the robot model.
   *
   * @return IPC::Response_FunctionsT containing the pause request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_pause(const std::string& robot_model) {
    IPC::Request_MotionPauseT req;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_MotionPauseT>(robot_model + "/call_pause", req, 2, 1000, 0);

    if (!result)
      throw std::runtime_error("Call Pause failed: query one returned nullptr");

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to stop motion entirely.
   *
   * Fully stops in-progress motion, as opposed to @c call_pause's temporary
   * pause (which can be continued via @c call_resume).
   *
   * @param robot_model Name of the robot model.
   *
   * @return IPC::Response_FunctionsT containing the halt request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_halt(const std::string& robot_model) {
    IPC::Request_MotionHaltT req;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_MotionHaltT>(robot_model + "/call_halt", req, 2, 1000, 0);

    if (!result)
      throw std::runtime_error("Call Halt failed: query one returned nullptr");

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to run setup before a program starts.
   *
   * Called before a program begins execution: the firmware stops all
   * in-progress motion, clears special DIN/DOUT masks, speed saturation,
   * move-break, jacobian reflection mode, manual/landmark target shift,
   * fixed speed/time, and arc-sensing/pattern state, resetting the robot to
   * a clean state for the new program. Also registers the given system
   * variables to monitor while the program runs.
   *
   * @param robot_model Name of the robot model.
   * @param option Currently ignored by the firmware (received but cast
   *        away unused); no option values are assigned or documented
   *        anywhere in the request schema.
   * @param monitoring_name Names of the system variables to monitor.
   *
   * @return IPC::Response_FunctionsT containing the request result, or
   *         std::nullopt if the robot did not reply (or replied with an
   *         error) — that case is logged and swallowed so a silent robot
   *         does not block the program from starting.
   *
   * @note Does not throw on a Zenoh no-reply or peer error response. Other
   *       runtime errors still propagate because they usually indicate local
   *       decode/SDK bugs rather than a silent robot.
   *
   * @note @p monitoring_name is optional; when omitted it is sent as an empty
   *       list
   * @note The firmware requires the robot to be idle; if motion is still
   *       in progress it returns a warning result instead of performing the
   *       reset (this SDK call does not itself throw on that warning — only
   *       on a missing/failed response).
   */
  std::optional<IPC::Response_FunctionsT> call_program_before(const std::string& robot_model, const int option,
                                                              std::optional<std::vector<std::string>> monitoring_name) {
    IPC::Request_ProgramBeforeT req;
    req.option = option;
    req.monitoring_name = monitoring_name.value_or(std::vector<std::string>{});

    try {
      std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_ProgramBeforeT>(
          robot_model + "/call_program_before", req, 128, 3000, 0);

      if (!result)
        throw std::runtime_error("Call Program Before failed: query one returned nullptr");

      return std::move(*result);
    } catch (const rb_zenoh::ZenohNoReply& e) {
      // 무응답/에러응답은 로그만 남기고 프로그램 시작을 막지 않는다.
      std::cerr << "Call Program Before failed: " << e.what() << std::endl;
    } catch (const rb_zenoh::ZenohReplyError& e) {
      std::cerr << "Call Program Before failed: " << e.what() << std::endl;
    }

    return std::nullopt;
  }

  /**
   * @brief Requests the cobot to run teardown after a program ends.
   *
   * Called after a program finishes execution, pairing with
   * @c call_program_before which runs beforehand. The firmware resumes any
   * paused motion, stops all in-progress motion, restores the user-frame,
   * area, out/self-collision, and TCP parameters that were in effect before
   * the program ran, clears special DIN/DOUT masks, speed saturation,
   * move-break, jacobian reflection mode, manual/landmark target shift, and
   * fixed speed/time, and stops any running pattern.
   *
   * @param robot_model Name of the robot model.
   * @param option Currently ignored by the firmware (received but cast
   *        away unused); no option values are assigned or documented
   *        anywhere in the request schema.
   *
   * @return IPC::Response_FunctionsT containing the request result, or
   *         std::nullopt if the robot did not reply (or replied with an
   *         error) — that case is logged and swallowed so a silent robot
   *         does not block the program from finishing.
   *
   * @note Does not throw on a Zenoh no-reply or peer error response. Other
   *       runtime errors still propagate because they usually indicate local
   *       decode/SDK bugs rather than a silent robot.
   */
  std::optional<IPC::Response_FunctionsT> call_program_after(const std::string& robot_model, const int option) {
    IPC::Request_ProgramAfterT req;
    req.option = option;

    try {
      std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_ProgramAfterT>(
          robot_model + "/call_program_after", req, 2, 1000, 0);

      if (!result)
        throw std::runtime_error("Call Program After failed: query one returned nullptr => " + robot_model);

      return std::move(*result);
    } catch (const rb_zenoh::ZenohNoReply& e) {
      // 무응답/에러응답은 로그만 남기고 프로그램 종료를 막지 않는다.
      std::cerr << "Call Program After failed: " << e.what() << " => " << robot_model << std::endl;
    } catch (const rb_zenoh::ZenohReplyError& e) {
      std::cerr << "Call Program After failed: " << e.what() << " => " << robot_model << std::endl;
    }

    return std::nullopt;
  }

  /**
   * @brief Captures the robot's current pose into PyFM local variables as the task's "begin" position.
   *
   * Only operates within a PyFM step context: if @p flow_manager_args is
   * not provided, this performs no action and immediately returns
   * std::nullopt. Reads the robot's current joint/Cartesian reference pose
   * from the {robot_model}/state_core topic and stores it under
   * MANIPULATE_BEGIN_JOINTS/MANIPULATE_BEGIN_CARTES in the PyFM local
   * variables; if the current step is not inside a sub-task (its PyFM
   * context has an empty sub_task_list), the same values are also stored
   * under MAIN_MANIPULATE_BEGIN_JOINTS/MAIN_MANIPULATE_BEGIN_CARTES. If
   * @p position / @p speed_ratio are given, they override
   * MANIPULATE_BEGIN_JOINTS / MANIPULATE_BEGIN_SPEED_RATIO (and, for a main
   * task, the corresponding MAIN_* variant) instead of the values read from
   * the robot. Finally registers the resulting joint pose with the robot as
   * its home joint info (@c set_home_joint_info: home_type 0 for a main
   * task, 1 otherwise) so @c position_home can later move back to it.
   *
   * @param robot_model Name of the robot model.
   * @param position Optional joint-angle override for
   *        MANIPULATE_BEGIN_JOINTS (and MAIN_MANIPULATE_BEGIN_JOINTS for a
   *        main task); if omitted, the joint pose read from state_core is
   *        used.
   * @param speed_ratio Optional override for MANIPULATE_BEGIN_SPEED_RATIO
   *        (and MAIN_MANIPULATE_BEGIN_SPEED_RATIO for a main task).
   * @param flow_manager_args PyFM step context. Required in practice —
   *        despite the optional type, omitting it makes this function a
   *        no-op that returns std::nullopt.
   *
   * @return IPC::Response_FunctionsT wrapping the set_home_joint_info
   *         result, or std::nullopt if @p flow_manager_args was not
   *         provided, or if reading state_core / setting the home joint
   *         info failed (in which case the begin-position local variables
   *         are instead reset to a seven-value zero pose).
   *
   * @note On failure (state_core read error or a failed
   *       set_home_joint_info result), MANIPULATE_BEGIN_JOINTS and
   *       MANIPULATE_BEGIN_CARTES are reset to seven zeros, the exception
   *       is caught and not re-thrown, and flow_manager_args.done() is
   *       still called so the PyFM step completes.
   */
  std::optional<IPC::Response_FunctionsT> set_begin(const std::string& robot_model,
                                                    std::optional<std::vector<float>> position,
                                                    std::optional<float> speed_ratio,
                                                    FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!flow_manager_args)
      return std::nullopt;

    FlowManagerContext& ctx = flow_manager_args->context();

    try {
      IPC::State_CoreT sc = receive_one<IPC::State_Core>(robot_model + "/state_core");

      // flatbuffers 는 없는 벡터 필드를 빈 벡터([])로 남긴다 (Python dict_payload 의
      // .get(key, [0]*7) 과 달리 길이 있는 기본값이 아니다). Python 원본과 동일하게
      // 값이 없으면 7-zero 로 채운다.
      const std::vector<float>& joints = sc.joint_q_ref.empty() ? std::vector<float>(7, 0.0f) : sc.joint_q_ref;
      const std::vector<float>& cartes = sc.carte_x_ref.empty() ? std::vector<float>(7, 0.0f) : sc.carte_x_ref;

      const bool is_main_task = flow_manager_args->is_main_task();

      ctx.update_local_variables({
          {"MANIPULATE_BEGIN_JOINTS", joints},
          {"MANIPULATE_BEGIN_CARTES", cartes},
      });

      if (is_main_task) {
        ctx.update_local_variables({
            {"MAIN_MANIPULATE_BEGIN_JOINTS", joints},
            {"MAIN_MANIPULATE_BEGIN_CARTES", cartes},
        });
      }

      if (position.has_value()) {
        ctx.update_local_variables({{"MANIPULATE_BEGIN_JOINTS", position.value()}});
        if (is_main_task)
          ctx.update_local_variables({{"MAIN_MANIPULATE_BEGIN_JOINTS", position.value()}});
      }
      if (speed_ratio.has_value()) {
        ctx.update_local_variables({{"MANIPULATE_BEGIN_SPEED_RATIO", static_cast<double>(speed_ratio.value())}});
        if (is_main_task)
          ctx.update_local_variables({{"MAIN_MANIPULATE_BEGIN_SPEED_RATIO", static_cast<double>(speed_ratio.value())}});
      }

      IPC::Request_Set_HomeJointInfoT req;
      req.home_type = is_main_task ? 0 : 1;
      req.joint_angles = position.value_or(joints);

      std::unique_ptr<IPC::Response_FunctionsT> result =
          query_one<IPC::Response_Functions, IPC::Request_Set_HomeJointInfoT>(robot_model + "/set_home_joint_info", req,
                                                                              16, 1000, 0);

      if (!result)
        throw std::runtime_error("Set Home Joint Info failed: query one returned nulltpr");

      return validate_single_return_value<IPC::Response_FunctionsT>(
          std::optional<IPC::Response_FunctionsT>{std::move(*result)}, flow_manager_args);
    } catch (const std::exception& e) {
      ctx.update_local_variables({
          {"MANIPULATE_BEGIN_JOINTS", std::vector<float>{0, 0, 0, 0, 0, 0, 0}},
          {"MANIPULATE_BEGIN_CARTES", std::vector<float>{0, 0, 0, 0, 0, 0, 0}},
      });

      flow_manager_args->done();
      //   std::cerr << e.what() << '\n';
    }

    // 예외 경로에서 done() 만 부르고 값을 반환하지 않으면 UB(Undefined Behavior) 발생
    return std::nullopt;
  }

  /**
   * @brief Moves the robot back to the begin position previously captured by @c set_begin.
   *
   * Reads the MANIPULATE_BEGIN_* / MAIN_MANIPULATE_BEGIN_* PyFM local
   * variables set by @c set_begin and issues a @c call_move_j or
   * @c call_move_l back to that pose, scaled by the speed ratio also
   * captured by @c set_begin. If none of those local variables were ever
   * set (i.e. @c set_begin never ran successfully in this task), or if the
   * specific pose requested by @p posture / @p move_type / @p project is
   * missing, this is a no-op that only calls flow_manager_args.done(). A
   * @p posture other than Posture::ZERO moves to the zero pose rather than
   * to a captured one.
   *
   * @param robot_model Name of the robot model.
   * @param move_type Move type: @c MoveType::J for a joint-space move back
   *        to MANIPULATE_BEGIN_JOINTS, or @c MoveType::L for a Cartesian
   *        move back to MANIPULATE_BEGIN_CARTES.
   * @param posture Posture::ZERO (Project Home Posture) reads the captured
   *        begin position and performs the move described above. Any other
   *        value (Posture::ONE = Joint Zero Posture) moves to a seven-value
   *        zero pose instead, without consulting the captured begin
   *        variables.
   * @param project Project::MAIN reads the MAIN_MANIPULATE_BEGIN_* /
   *        MAIN_MANIPULATE_BEGIN_SPEED_RATIO variables (the outermost
   *        task's begin position); Project::SUB reads the plain
   *        MANIPULATE_BEGIN_* / MANIPULATE_BEGIN_SPEED_RATIO variables
   *        (the current task's own begin position, main or sub).
   * @param spd_vel_ratio Velocity scale factor, multiplied by the speed
   *        ratio captured by @c set_begin (defaults to 1.0 if none was
   *        captured) to form the move's spd_vel_para.
   * @param spd_acc_ratio Acceleration scale factor, multiplied by the same
   *        captured speed ratio to form the move's spd_acc_para.
   * @param flow_manager_args PyFM step context. Required: passing nullptr
   *        raises std::runtime_error, matching the RuntimeError the legacy
   *        Python implementation raises for the same case.
   *
   * @throws std::runtime_error If @p flow_manager_args is not provided, or if
   *         the underlying @c call_move_j / @c call_move_l fails.
   */
  void position_home(const std::string& robot_model, std::string_view move_type, Posture posture,
                     std::string_view project, float spd_vel_ratio, float spd_acc_ratio,
                     FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!flow_manager_args)
      throw std::runtime_error("position_home must be called with rb_flow_manager");

    FlowManagerContext& ctx = flow_manager_args->context();

    if (!ctx.get_local_variable("MANIPULATE_BEGIN_JOINTS").has_value() &&
        !ctx.get_local_variable("MANIPULATE_BEGIN_CARTES").has_value() &&
        !ctx.get_local_variable("MAIN_MANIPULATE_BEGIN_JOINTS").has_value() &&
        !ctx.get_local_variable("MAIN_MANIPULATE_BEGIN_CARTES").has_value()) {
      flow_manager_args->done();
      return;
    }

    const char* ratio_key =
        project == Project::MAIN ? "MAIN_MANIPULATE_BEGIN_SPEED_RATIO" : "MANIPULATE_BEGIN_SPEED_RATIO";

    float speed_ratio = 1.0f;
    if (auto ratio = ctx.get_local_variable(ratio_key)) {
      if (const auto* d = std::get_if<double>(&*ratio))
        speed_ratio = static_cast<float>(*d);
      else if (const auto* i = std::get_if<int64_t>(&*ratio))
        speed_ratio = static_cast<float>(*i);
    }

    MoveSpeedArg speed{
        .spd_mode = 1,
        .spd_vel_para = speed_ratio * spd_vel_ratio,
        .spd_acc_para = speed_ratio * spd_acc_ratio,
    };

    // posture 가 ZERO(Project Home)가 아니면 캡처된 begin 위치를 보지 않고 영점 자세로 이동한다.
    std::optional<std::vector<float>> position = std::vector<float>(7, 0.0f);
    if (posture == Posture::ZERO && move_type == MoveType::J) {
      const char* key = project == Project::MAIN ? "MAIN_MANIPULATE_BEGIN_JOINTS" : "MANIPULATE_BEGIN_JOINTS";
      position = std::nullopt;
      if (auto value = ctx.get_local_variable(key))
        if (const auto* vec = std::get_if<std::vector<float>>(&*value))
          position = *vec;
    } else if (posture == Posture::ZERO && move_type == MoveType::L) {
      const char* key = project == Project::MAIN ? "MAIN_MANIPULATE_BEGIN_CARTES" : "MANIPULATE_BEGIN_CARTES";
      position = std::nullopt;
      if (auto value = ctx.get_local_variable(key))
        if (const auto* vec = std::get_if<std::vector<float>>(&*value))
          position = *vec;
    }
    if (!position.has_value()) {
      flow_manager_args->done();
      return;
    }
    IPC::MoveInput_TargetT target;
    target.tar_values = position.value();
    target.tar_unit = 0;

    if (move_type == MoveType::J) {
      target.tar_frame = -1;
      _move_sdk.call_move_j(robot_model, target, std::nullopt, speed, std::nullopt, flow_manager_args);
    } else if (move_type == MoveType::L) {
      target.tar_frame = 0;

      _move_sdk.call_move_l(robot_model, target, std::nullopt, speed, std::nullopt, flow_manager_args);
    }
  }

  /**
   * @brief Computes and stores a pin's target value into the PyFM execution context.
   *
   * Only operates within a PyFM step context: if @p flow_manager_args is
   * not provided, this performs no calculation and immediately returns
   * std::nullopt. When @p reference_target is given, the pin value is
   * computed relative to it (via the SDK's relative-value calculation);
   * otherwise it is computed as an absolute value. If @p flow_manager_args
   * carries a "variable_name" entry in its args, the resulting tar_values
   * are stored under that name in the PyFM local variables.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position/joint values and frame information used
   *        as the pin's (relative) target.
   * @param reference_target Optional reference values used for relative
   *        calculation; if omitted, an absolute value is computed instead.
   * @param pin_type Pin type: "POINT" for a Cartesian-space pin, or "JOINT"
   *        for a joint-space pin.
   * @param flow_manager_args PyFM step context. Required in practice —
   *        despite the optional type, omitting it makes this function a
   *        no-op that returns std::nullopt.
   *
   * @return IPC::Response_Get_ValueT containing the calculated value, or
   *         std::nullopt if @p flow_manager_args was not provided.
   *
   * @throws std::runtime_error If the relative or absolute value
   *         calculation fails.
   */
  std::optional<IPC::Response_Get_ValueT> set_pin_point_or_joint(std::string& robot_model, IPC::MoveInput_TargetT target,
                                                                std::optional<std::vector<float>> reference_target,
                                                                std::string_view pin_type,
                                                                FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!flow_manager_args)
      return std::nullopt;

    FlowManagerContext& ctx = flow_manager_args->context();
    const std::optional<std::string> variable_name = flow_manager_args->string_arg("variable_name");

    if (reference_target != std::nullopt) {
      auto res = _get_data_sdk.get_relative_value(
          robot_model, target,
          IPC::MoveInput_TargetT{.tar_values = reference_target.value(), .tar_frame = 0, .tar_unit = 0},
          pin_type == PinType::POINT ? 1 : 0);
      if (res.calculated_result != 0)
        throw std::runtime_error("Get Relative Value Failed in set pin point or joint");
      // IPC::Response_Get_Relative_ValueT result = std::move(*res);
      std::unique_ptr<IPC::MoveInput_TargetT> calculated_value =
          std::make_unique<IPC::MoveInput_TargetT>(*res.calculated_value);

      if (variable_name)
        ctx.update_local_variables({{*variable_name, calculated_value->tar_values}});
      flow_manager_args->done();

      IPC::Response_Get_ValueT _ret;
      _ret.calculated_result = res.calculated_result;
      _ret.calculated_value = std::make_unique<IPC::MoveInput_TargetT>(*res.calculated_value);
      return _ret;
    } else {
      auto res = _get_data_sdk.get_absolute_value(robot_model, target, pin_type == PinType::POINT ? 1 : 0);
      if (res.calculated_result != 0)
        throw std::runtime_error("Get Absolute Value Failed in set pin point or joint");
      std::unique_ptr<IPC::MoveInput_TargetT> calculated_value =
          std::make_unique<IPC::MoveInput_TargetT>(*res.calculated_value);

      if (variable_name)
        ctx.update_local_variables({{*variable_name, calculated_value->tar_values}});
      flow_manager_args->done();

      IPC::Response_Get_ValueT _ret;
      _ret.calculated_result = res.calculated_result;
      _ret.calculated_value = std::make_unique<IPC::MoveInput_TargetT>(*res.calculated_value);
      return _ret;
    }
  }

  /**
   * @brief Sets the tool (flange) power voltage and digital outputs.
   *
   * Only operates within a PyFM step context: if @p flow_manager_args is
   * not provided, this performs no action and immediately returns
   * std::nullopt.
   *
   * @param robot_model Name of the robot model.
   * @param tool_voltage Desired flange power voltage.
   * @param tool_dout_args Digital output arguments to apply to the flange.
   * @param flow_manager_args PyFM step context. Required in practice —
   *        despite the optional type, omitting it makes this function a
   *        no-op that returns std::nullopt. On success, completion is
   *        reported to the flow manager immediately (synchronous).
   *
   * @return IPC::Response_FunctionsT containing the digital-out request
   *         result, or std::nullopt if @p flow_manager_args was not
   *         provided.
   *
   * @throws std::runtime_error If either underlying flange call fails; the
   *         original message is wrapped as "Tool Out failed: ...". The
   *         failure must propagate — swallowing it would leave the PyFM
   *         step waiting on a done() that never comes.
   */
  std::optional<IPC::Response_FunctionsT> tool_out(const std::string& robot_model, const int tool_voltage,
                                                   std::vector<IPC::Request_Flange_Digital_OutT> tool_dout_args,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!flow_manager_args)
      return std::nullopt;

    try {
      auto res = _io_sdk.call_flange_power(robot_model, tool_voltage);
      auto _res = _io_sdk.call_multiple_flange_dout(robot_model, tool_dout_args);

      flow_manager_args->done();

      return _res;
    } catch (const std::exception& e) {
      // Python 원본과 동일하게 전파한다. 여기서 삼키면 done() 이 불리지 않아
      // step.py 의 done_event 대기 루프가 영원히 풀리지 않는다.
      throw std::runtime_error(std::string("Tool Out failed: ") + e.what());
    }
  }

  /**
   * @brief Dispatches to the appropriate robot configuration setter based on @p option.
   *
   * A single unified entry point for the many `set_*`/`call_*` configuration
   * calls on @c RBManipulateConfigSDK: pass one of the SettingOptions::*
   * constants as @p option, populate the single corresponding parameter
   * below, and leave every other parameter unset. Throws if the parameter
   * matching @p option is not provided, or if @p option matches none of the
   * known SettingOptions values.
   *
   * @param robot_model Name of the robot model.
   * @param option One of the SettingOptions::* constants selecting which
   *        setter to invoke.
   * @param out_collision Required when @p option is
   *        SettingOptions::OUT_COLLISION; forwarded to
   *        @c RBManipulateConfigSDK::set_out_collision_para.
   * @param self_collision Required when @p option is
   *        SettingOptions::SELF_COLLISION; forwarded to
   *        @c RBManipulateConfigSDK::set_self_collision_para.
   * @param user_frame_selection Required when @p option is
   *        SettingOptions::USER_FRAME_SELECTION; forwarded to
   *        @c RBManipulateConfigSDK::set_userframe_num. Both "user_frame_num"
   *        and the legacy program-args key "target_user_frame_num" are
   *        accepted; neither present throws rather than silently selecting
   *        user frame 0. That resolution runs in the dedicated type_caster
   *        at the pybind boundary (binding/glue/program_setting_caster.hpp);
   *        this function only sees the resolved @c UserFrameSelectionArg.
   * @param fixed_speed Required when @p option is
   *        SettingOptions::FIXED_SPEED; forwarded to
   *        @c RBManipulateConfigSDK::set_fixed_speed.
   * @param target_shift Required when @p option is
   *        SettingOptions::TARGET_SHIFT; forwarded to
   *        @c RBManipulateConfigSDK::set_shift.
   * @param speed_bar Required when @p option is SettingOptions::SPEED_BAR;
   *        forwarded to @c RBManipulateConfigSDK::call_speedbar.
   * @param time_constraint Required when @p option is
   *        SettingOptions::TIME_CONSTRAINT; forwarded to
   *        @c RBManipulateConfigSDK::set_timeconstraint.
   * @param ascii_function_call Required when @p option is
   *        SettingOptions::ASCII_FUNCTION_CALL; forwarded to
   *        @c RBManipulateConfigSDK::set_ascii_functioncall.
   * @param joint_impedance Required when @p option is
   *        SettingOptions::JOINT_IMPEDANCE; forwarded to
   *        @c RBManipulateConfigSDK::set_joint_impedance.
   * @param free_drive Required when @p option is
   *        SettingOptions::FREE_DRIVE; forwarded to
   *        @c RBManipulateConfigSDK::set_freedrive.
   * @param master_mode Required when @p option is
   *        SettingOptions::MASTER_MODE; forwarded to
   *        @c RBManipulateConfigSDK::set_master_mode.
   * @param user_frame_6dof Required when @p option is
   *        SettingOptions::USER_FRAME_6DOF; forwarded to
   *        @c RBManipulateConfigSDK::set_userframe_6dof.
   * @param user_frame_tcp Required when @p option is
   *        SettingOptions::USER_FRAME_TCP; forwarded to
   *        @c RBManipulateConfigSDK::set_userframe_tcp.
   * @param user_frame_3points Required when @p option is
   *        SettingOptions::USER_FRAME_3POINTS; forwarded to
   *        @c RBManipulateConfigSDK::set_userframe_3points.
   * @param target_shift_landmark Required when @p option is
   *        SettingOptions::TARGET_SHIFT_LANDMARK; the 6 reference/present
   *        points are rounded to 3 decimal places and padded to 7 values
   *        before being forwarded to
   *        @c RBManipulateConfigSDK::set_shift_landmark. Each point may be
   *        either a MoveInput_Target dict or, as legacy program args store
   *        them, a bare list of coordinates (taken as frame 0 / unit 0);
   *        that discrimination and the null check run in the dedicated
   *        type_caster at the pybind boundary
   *        (binding/glue/program_setting_caster.hpp), so this function only
   *        sees the resolved @c ShiftLandMarkArg.
   * @param program_flow_manage Required when @p option is
   *        SettingOptions::PROGRAM_FLOW_MANAGE; forwarded to
   *        @c RBManipulateConfigSDK::set_program_flow_manage.
   * @param din_function_mask Required when @p option is
   *        SettingOptions::DIN_FUNCTION_MASK; forwarded to
   *        @c RBManipulateConfigSDK::set_din_function_mask.
   * @param dout_function_mask Required when @p option is
   *        SettingOptions::DOUT_FUNCTION_MASK; forwarded to
   *        @c RBManipulateConfigSDK::set_dout_function_mask.
   * @param jacobian_based_speed_control Required when @p option is
   *        SettingOptions::JACOBIAN_BASED_SPEED_CONTROL; forwarded to
   *        @c RBManipulateConfigSDK::set_jacob_speed_mode.
   * @param self_vibration_mode Required when @p option is
   *        SettingOptions::SELF_VIBRATION_MODE; forwarded to
   *        @c RBManipulateConfigSDK::set_self_vibration_mode.
   * @param vibration_motion_based Required when @p option is
   *        SettingOptions::VIBRATION_MOTION_BASED. Passed from Python as a
   *        flat dict {"onoff": 1/0, "frame":, "x_mag":, ...}, matching the
   *        @c Request_Wrapper_VibrationMotion schema table and what the FE
   *        actually sends — not the wire request shape (@c
   *        Request_Wrapper_VibrationMotion_On / @c _Off, sent as two
   *        separate RPCs; "onoff" only selects which one to call). When
   *        onoff == 1, all 10 of frame/x_mag/y_mag/z_mag/x_freq/y_freq/
   *        z_freq/x_phase/y_phase/z_phase must be present (each parsed via
   *        @c rb_glue::to_int / @c to_double, tolerating string-typed
   *        values from loosely-typed program args) or the request is
   *        rejected — the auto dict-to-struct caster would otherwise
   *        silently fill missing fields with 0. That validation runs in
   *        the dedicated type_caster at the pybind boundary
   *        (binding/glue/vibration_motion_caster.hpp); this function only
   *        sees the resolved @c VibrationMotionBasedArg. Forwarded to
   *        @c RBManipulateConfigSDK::call_vibration_motion_on /
   *        @c call_vibration_motion_off.
   * @param external_axis_sync Required when @p option is
   *        SettingOptions::EXTERNAL_AXIS_SYNC; forwarded to
   *        @c RBManipulateConfigSDK::set_external_axis_sync.
   * @param tcp_speed_bound Required when @p option is
   *        SettingOptions::TCP_SPEED_BOUND; forwarded to
   *        @c RBManipulateConfigSDK::set_tcp_speed_bound.
   * @param move_break Required when @p option is
   *        SettingOptions::MOVE_BREAK_BLOCK; forwarded to
   *        @c RBManipulateConfigSDK::set_move_break.
   * @param joint_reference_filter Required when @p option is
   *        SettingOptions::JOINT_REFERENCE_FILTER; forwarded to
   *        @c RBManipulateConfigSDK::set_joint_reference_filter.
   * @param self_collision_blind Required when @p option is
   *        SettingOptions::SELF_COLL_DETECT_BLIND; forwarded to
   *        @c RBManipulateConfigSDK::set_self_collision_blind.
   * @param flow_manager_args Optional PyFM step context, forwarded as-is to
   *        whichever underlying setter is invoked.
   *
   * @return IPC::Response_FunctionsT containing the underlying setter's
   *         result.
   *
   * @throws std::runtime_error If the parameter matching @p option is not
   *         provided, if @p option matches no known SettingOptions value,
   *         or if the chosen setter's own validation fails.
   */
  IPC::Response_FunctionsT setting(const std::string& robot_model, std::string_view option,
                                   std::optional<IPC::Request_Set_Out_Collision_ParaT> out_collision,
                                   std::optional<IPC::Request_Set_Self_Collision_ParaT> self_collision,
                                   std::optional<UserFrameSelectionArg> user_frame_selection,
                                   std::optional<IPC::Request_Set_Fixed_Speed_ModeT> fixed_speed,
                                   std::optional<IPC::Request_Set_ShiftT> target_shift,
                                   std::optional<IPC::Request_MotionSpeedBarT> speed_bar,
                                   std::optional<IPC::Request_Set_TimeConstraintT> time_constraint,
                                   std::optional<IPC::Request_Set_AsciiFunctionCallT> ascii_function_call,
                                   std::optional<IPC::Request_Set_Joint_ImpedanceT> joint_impedance,
                                   std::optional<IPC::Request_Set_Free_DriveT> free_drive,
                                   std::optional<IPC::Request_Set_Master_ModeT> master_mode,
                                   std::optional<IPC::Request_Set_User_Frame_6DofT> user_frame_6dof,
                                   std::optional<IPC::Request_Set_User_Frame_TCPT> user_frame_tcp,
                                   std::optional<IPC::Request_Set_User_Frame_3PointsT> user_frame_3points,
                                   std::optional<ShiftLandMarkArg> target_shift_landmark,
                                   std::optional<IPC::Request_Set_ProgramFlowManageT> program_flow_manage,
                                   std::optional<IPC::Request_Set_DinFunctionMaskT> din_function_mask,
                                   std::optional<IPC::Request_Set_DoutFunctionMaskT> dout_function_mask,
                                   std::optional<IPC::Request_Set_JacobSpeedModeT> jacobian_based_speed_control,
                                   std::optional<IPC::Request_Set_SelfVibrationModeT> self_vibration_mode,
                                   std::optional<VibrationMotionBasedArg> vibration_motion_based,
                                   std::optional<IPC::Request_Set_ExternalAxisSyncT> external_axis_sync,
                                   std::optional<IPC::Request_Set_TcpSpeedBoundT> tcp_speed_bound,
                                   std::optional<IPC::Request_Set_MoveBreakT> move_break,
                                   std::optional<IPC::Request_Set_JointRef_FilterT> joint_reference_filter,
                                   std::optional<IPC::Request_Set_SelfCollBlindT> self_collision_blind,
                                   FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (option == SettingOptions::USER_FRAME_SELECTION) {
      if (user_frame_selection == std::nullopt)
        throw std::runtime_error("user_frame_selection failed: user_frame_selection is required");
      // user_frame_num / 구버전 program args 의 target_user_frame_num 판별은 type_caster 에서 끝났다.
      return _config_sdk.set_userframe_num(robot_model, user_frame_selection.value().user_frame_num,
                                           flow_manager_args);
    } else if (option == SettingOptions::OUT_COLLISION) {
      if (out_collision == std::nullopt)
        throw std::runtime_error("out_collision failed: out_collision is required");
      const auto& _tmp = out_collision.value();
      return _config_sdk.set_out_collision_para(robot_model, _tmp.onoff, _tmp.react_mode, _tmp.threshold,
                                                flow_manager_args);
    } else if (option == SettingOptions::SELF_COLLISION) {
      if (self_collision == std::nullopt)
        throw std::runtime_error("self_collision failed: self_collision is required");
      const auto& _tmp = self_collision.value();
      return _config_sdk.set_self_collision_para(robot_model, _tmp.mode, _tmp.dist_int, _tmp.dist_ext,
                                                 flow_manager_args);
    } else if (option == SettingOptions::FIXED_SPEED) {
      if (fixed_speed == std::nullopt)
        throw std::runtime_error("fixed_speed failed: fixed_speed is required");
      const auto& _tmp = fixed_speed.value();
      return _config_sdk.set_fixed_speed(robot_model, _tmp.target_move, _tmp.vel_option, _tmp.vel_parameter,
                                         _tmp.acc_option, _tmp.acc_parameter, flow_manager_args);
    } else if (option == SettingOptions::TARGET_SHIFT) {
      if (target_shift == std::nullopt)
        throw std::runtime_error("target_shift failed: target_shift is required");
      const auto& _tmp = target_shift.value();
      return _config_sdk.set_shift(robot_model, _tmp.shift_no, _tmp.shift_mode, std::move(*_tmp.target),
                                   flow_manager_args);
    } else if (option == SettingOptions::SPEED_BAR) {
      if (speed_bar == std::nullopt)
        throw std::runtime_error("speed_bar failed: speed_bar is required");
      const auto& _tmp = speed_bar.value();
      return _config_sdk.call_speedbar(robot_model, _tmp.alpha, flow_manager_args);
    } else if (option == SettingOptions::TIME_CONSTRAINT) {
      if (time_constraint == std::nullopt)
        throw std::runtime_error("time_constraint failed: time_constraint is required");
      const auto& _tmp = time_constraint.value();
      return _config_sdk.set_timeconstraint(robot_model, _tmp.option, _tmp.time_sec, flow_manager_args);
    } else if (option == SettingOptions::ASCII_FUNCTION_CALL) {
      if (ascii_function_call == std::nullopt)
        throw std::runtime_error("ascii_function_call failed: ascii_function_call is required");
      const auto& _tmp = ascii_function_call.value();
      return _config_sdk.set_ascii_functioncall(robot_model, _tmp.option, _tmp.message, flow_manager_args);
    } else if (option == SettingOptions::JOINT_IMPEDANCE) {
      if (joint_impedance == std::nullopt)
        throw std::runtime_error("joint_impedance failed: joint_impedance is required");
      const auto& _tmp = joint_impedance.value();
      return _config_sdk.set_joint_impedance(robot_model, _tmp.onoff, _tmp.stiffness, _tmp.torquelimit,
                                             flow_manager_args);
    } else if (option == SettingOptions::FREE_DRIVE) {
      if (free_drive == std::nullopt)
        throw std::runtime_error("free_drive failed: free_drive is required");
      const auto& _tmp = free_drive.value();
      return _config_sdk.set_freedrive(robot_model, _tmp.onoff, _tmp.extra_force_frame, _tmp.extra_force_fx,
                                       _tmp.extra_force_fy, _tmp.extra_force_fz, _tmp.sensitivity, flow_manager_args);
    } else if (option == SettingOptions::MASTER_MODE) {
      if (master_mode == std::nullopt)
        throw std::runtime_error("master_mode failed: master_mode is required");
      const auto& _tmp = master_mode.value();
      return _config_sdk.set_master_mode(robot_model, _tmp.mode, flow_manager_args);
    } else if (option == SettingOptions::USER_FRAME_6DOF) {
      if (user_frame_6dof == std::nullopt)
        throw std::runtime_error("user_frame_6dof failed: user_frame_6dof is required");
      const auto& _tmp = user_frame_6dof.value();
      return _config_sdk.set_userframe_6dof(robot_model, _tmp.user_frame_num, _tmp.setting_option, _tmp.target_frame,
                                            _tmp.target_x, _tmp.target_y, _tmp.target_z, _tmp.target_rx, _tmp.target_ry,
                                            _tmp.target_rz, flow_manager_args);
    } else if (option == SettingOptions::USER_FRAME_TCP) {
      if (user_frame_tcp == std::nullopt)
        throw std::runtime_error("user_frame_tcp failed: user_frame_tcp is required");
      const auto& _tmp = user_frame_tcp.value();
      return _config_sdk.set_userframe_tcp(robot_model, _tmp.user_frame_num, _tmp.setting_option, flow_manager_args);
    } else if (option == SettingOptions::USER_FRAME_3POINTS) {
      if (user_frame_3points == std::nullopt)
        throw std::runtime_error("user_frame_3points failed: user_frame_3points is required");
      const auto& _tmp = user_frame_3points.value();
      return _config_sdk.set_userframe_3points(robot_model, _tmp.user_frame_num, _tmp.setting_option, _tmp.order_option,
                                               _tmp.point_1_x, _tmp.point_1_y, _tmp.point_1_z, _tmp.point_2_x,
                                               _tmp.point_2_y, _tmp.point_2_z, _tmp.point_3_x, _tmp.point_3_y,
                                               _tmp.point_3_z, flow_manager_args);
    } else if (option == SettingOptions::TARGET_SHIFT_LANDMARK) {
      if (target_shift_landmark == std::nullopt)
        throw std::runtime_error("target_shift_landmark failed: target_shift_landmark is required");

      // 6개 포인트의 null 검증과 dict/구버전 좌표 리스트 판별은 type_caster 에서 끝났다.
      const auto& _lm = target_shift_landmark.value();

      std::vector<IPC::MoveInput_TargetT> result_target_list;

      for (const auto& point : _lm.points) {
        IPC::MoveInput_TargetT target = point;

        for (auto& v : target.tar_values)
          v = std::round(v * 1000.0f) / 1000.0f;

        target.tar_values.resize(7, 0.0f);

        result_target_list.push_back(std::move(target));
      }

      return _config_sdk.set_shift_landmark(robot_model, _lm.shift_mode, _lm.tolerance, result_target_list[0],
                                            result_target_list[1], result_target_list[2], result_target_list[3],
                                            result_target_list[4], result_target_list[5], flow_manager_args);
    } else if (option == SettingOptions::PROGRAM_FLOW_MANAGE) {
      if (program_flow_manage == std::nullopt)
        throw std::runtime_error("program_flow_manage failed: program_flow_manage is required");
      const auto& _tmp = program_flow_manage.value();
      return _config_sdk.set_program_flow_manage(robot_model, _tmp.target, _tmp.option, flow_manager_args);
    } else if (option == SettingOptions::DIN_FUNCTION_MASK) {
      if (din_function_mask == std::nullopt)
        throw std::runtime_error("din_function_mask failed: din_function_mask is required");
      const auto& _tmp = din_function_mask.value();
      return _config_sdk.set_din_function_mask(robot_model, _tmp.device, _tmp.port_num, _tmp.option, flow_manager_args);
    } else if (option == SettingOptions::DOUT_FUNCTION_MASK) {
      if (dout_function_mask == std::nullopt)
        throw std::runtime_error("dout_function_mask failed: dout_function_mask is required");
      const auto& _tmp = dout_function_mask.value();
      return _config_sdk.set_dout_function_mask(robot_model, _tmp.device, _tmp.port_num, _tmp.option,
                                                flow_manager_args);
    } else if (option == SettingOptions::JACOBIAN_BASED_SPEED_CONTROL) {
      if (jacobian_based_speed_control == std::nullopt)
        throw std::runtime_error(
            "jacobian_based_speed_control failed: "
            "jacobian_based_speed_control is required");
      const auto& _tmp = jacobian_based_speed_control.value();
      return _config_sdk.set_jacob_speed_mode(robot_model, _tmp.mode, flow_manager_args);
    } else if (option == SettingOptions::SELF_VIBRATION_MODE) {
      if (self_vibration_mode == std::nullopt)
        throw std::runtime_error("self_vibration_mode failed: self_vibration_mode is required");
      const auto& _tmp = self_vibration_mode.value();
      return _config_sdk.set_self_vibration_mode(robot_model, _tmp.mode, _tmp.time, _tmp.frequency, _tmp.magnitudes,
                                                 flow_manager_args);
    } else if (option == SettingOptions::VIBRATION_MOTION_BASED) {
      if (vibration_motion_based == std::nullopt)
        throw std::runtime_error(
            "vibration_motion_based failed: "
            "vibration_motion_based is required");
      // On/Off 판별과 On 파라미터 10개 존재 검증은 type_caster 에서 끝났다.
      const auto& _vm = vibration_motion_based.value();
      if (_vm.motion_on) {
        const auto& _on = _vm.on;
        return _config_sdk.call_vibration_motion_on(robot_model, _on.frame, _on.x_mag, _on.y_mag, _on.z_mag, _on.x_freq,
                                                    _on.y_freq, _on.z_freq, _on.x_phase, _on.y_phase, _on.z_phase,
                                                    flow_manager_args);
      }
      return _config_sdk.call_vibration_motion_off(robot_model, flow_manager_args);
    } else if (option == SettingOptions::EXTERNAL_AXIS_SYNC) {
      if (external_axis_sync == std::nullopt)
        throw std::runtime_error("external_axis_sync failed: external_axis_sync is required");
      const auto& _tmp = external_axis_sync.value();
      return _config_sdk.set_external_axis_sync(robot_model, _tmp.mode, flow_manager_args);
    } else if (option == SettingOptions::TCP_SPEED_BOUND) {
      if (tcp_speed_bound == std::nullopt)
        throw std::runtime_error("tcp_speed_bound failed: tcp_speed_bound is required");
      const auto& _tmp = tcp_speed_bound.value();
      return _config_sdk.set_tcp_speed_bound(robot_model, _tmp.mode, _tmp.speed_parameter, flow_manager_args);
    } else if (option == SettingOptions::MOVE_BREAK_BLOCK) {
      if (move_break == std::nullopt)
        throw std::runtime_error("move_break failed: move_break is required");
      const auto& _tmp = move_break.value();
      return _config_sdk.set_move_break(robot_model, _tmp.mode, _tmp.stopping_time, flow_manager_args);
    } else if (option == SettingOptions::JOINT_REFERENCE_FILTER) {
      if (joint_reference_filter == std::nullopt)
        throw std::runtime_error("joint_reference_filter failed: joint_reference_filter is required");
      const auto& _tmp = joint_reference_filter.value();
      return _config_sdk.set_joint_reference_filter(robot_model, _tmp.mode, _tmp.filter_percent, flow_manager_args);
    } else if (option == SettingOptions::SELF_COLL_DETECT_BLIND) {
      if (self_collision_blind == std::nullopt)
        throw std::runtime_error("self_collision_blind failed: self_collision_blind is required");
      const auto& _tmp = self_collision_blind.value();
      return _config_sdk.set_self_collision_blind(robot_model, _tmp.time, flow_manager_args);
    } else
      throw std::runtime_error("Wrong SettingOptions String Detected.");
  }

  /**
   * @brief Requests the cobot to set its core data publication frequency.
   *
   * Sets how often the robot publishes its periodic core-data state stream
   * on the {robot_model}/state_core topic (@c IPC::State_Core — joint/
   * Cartesian refs, encoder values, etc.) that other parts of this SDK
   * subscribe to (e.g. @c folder_finish_at).
   *
   * @param robot_model Name of the robot model.
   * @param frequency Publication frequency, in Hz. The firmware clamps this
   *        to the range [0.1, 500.0] before applying it; the default rate
   *        before any call is 20 Hz.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_coredata_pub_frequency(const std::string& robot_model, const float frequency) {
    IPC::Request_CoredataPubFrequencyT req;
    req.frequency_hz = frequency;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CoredataPubFrequencyT>(
            robot_model + "/call_coredata_pub_frequency", req, 2, 5000, 0);

    if (!result)
      throw std::runtime_error("call_coredata_pub_frequency failed: query one returned nullptr");

    return std::move(*result);
  }

  /**
   * @brief Starts background monitoring that breaks a Folder step's children
   *        once its finish_at condition becomes true.
   *
   * Used in PyFM: when a Folder step's @p flow_manager_args carries a
   * finish_at expression, this subscribes to the robot's state_core topic
   * and evaluates that expression against the PyFM context on every state
   * update. As soon as it evaluates true, this calls @c call_smoothjog_stop
   * with the evaluated stop_time, then breaks the folder (via the context's
   * break_folder) at the depth captured on entry, terminating the moves
   * underneath that folder. Monitoring also stops on its own once execution
   * has already exited the target folder depth. This is a no-op if
   * @p flow_manager_args is not provided, or if its args do not have a
   * finish_at value set.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args PyFM step context. Expected args:
   *        - finish_at: expression evaluated on every state update;
   *          monitoring only starts if this is set to a non-empty value.
   *        - stop_time: expression evaluated for the deceleration time
   *          passed to @c call_smoothjog_stop once finish_at becomes true
   *          (defaults to 0.0 if not set).
   *
   * @note @c flow_manager_args.done() is called immediately once monitoring
   *       starts, before finish_at ever becomes true — the PyFM step itself
   *       completes right away (so children can proceed) while the finish_at
   *       watch continues running in the background.
   * @note Exceptions from the background monitor (e.g. from evaluating
   *       finish_at/stop_time) are caught and logged to stderr rather than
   *       propagated, since they run asynchronously in a subscription
   *       callback.
   */
  void folder_finish_at(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!flow_manager_args) {
      return;
    }

    FlowManagerContext& ctx = flow_manager_args->context();

    FlowValuePtr finish_at = flow_manager_args->arg("finish_at");
    FlowValuePtr stop_time = flow_manager_args->arg("stop_time");

    // 빈 문자열 finish_at 은 조건 없음으로 취급 (기존 동작 유지).
    const bool finish_at_set = finish_at && !ctx.is_empty_string(finish_at);

    const int target_depth = ctx.get_folder_depth();

    flow_manager_args->done();  // children 바로 진행

    if (!finish_at_set) {
      return;
    }

    auto state = std::make_shared<_FolderFinishState>();
    state->flow_manager_args = flow_manager_args;
    state->finish_at = finish_at;
    state->stop_time = stop_time;
    state->target_depth = target_depth;

    state->subs_id = zenoh_subscribe<IPC::State_Core>(
        robot_model + "/state_core",
        [this, state, robot_model](const std::string& topic, std::unique_ptr<IPC::State_CoreT> payload,
                                   const std::string& attachment) {
          if (payload == nullptr || state->unsubscribed.load())
            return;

          auto cleanup = [this, &state]() {
            bool expected = false;
            if (state->unsubscribed.compare_exchange_strong(expected, true)) {
              const int sid = state->subs_id.load();
              if (sid >= 0) {
                std::thread unsub_t([this, sid] { zenoh_client_->undeclare_subscriber(sid); });
                unsub_t.detach();
              }
            }
          };

          try {
            // break 요청 후 모션이 실제로 멈췄으면(정지+정상)
            if (state->break_requested.load() && payload->motion_mode % 100 == 0 &&
                payload->motion_execution_result == 0) {
              cleanup();
              return;
            }

            FlowManagerContext& ctx = state->flow_manager_args->context();

            // depth 가 진입 시점보다 낮아짐 = 이미 이 folder 를 벗어남 -> 정리.
            if (ctx.get_folder_depth() < state->target_depth) {
              cleanup();
              return;
            }

            if (state->break_requested.load())
              return;

            if (ctx.eval_bool(state->finish_at)) {
              bool expected = false;
              if (!state->break_requested.compare_exchange_strong(expected, true))
                return;

              float parsed_stop_time = state->stop_time ? ctx.eval_float(state->stop_time) : 0.0f;

              _check_numeric(parsed_stop_time);

              _move_sdk.call_smoothjog_stop(robot_model, parsed_stop_time);

              ctx.break_folder(state->target_depth);  // 다른 스레드 호출 -> 플래그만 세팅
            }
          } catch (const std::exception& e) {
            std::cerr << "[folder_finish_at callback] exception: " << e.what() << std::endl;
          } catch (...) {
            std::cerr << "[folder_finish_at callback] unknown exception" << std::endl;
          }
        });
  }

 private:
  struct _FolderFinishState {
    FlowManagerArgsPtr flow_manager_args;
    FlowValuePtr finish_at;
    FlowValuePtr stop_time;
    int target_depth = 0;
    std::atomic_bool break_requested{false};
    std::atomic_bool unsubscribed{false};
    std::atomic<int> subs_id{-1};
  };

  void _check_numeric(const std::any& a) {
    if (a.type() != typeid(int) && a.type() != typeid(float)) {
      throw std::runtime_error("a must be int or float");
    }
  }

  RBManipulateMoveSDK _move_sdk = RBManipulateMoveSDK();
  RBManipulateGetDataSDK _get_data_sdk = RBManipulateGetDataSDK();
  RBManipulateIOSDK _io_sdk = RBManipulateIOSDK();
  RBManipulateConfigSDK _config_sdk = RBManipulateConfigSDK();
};
