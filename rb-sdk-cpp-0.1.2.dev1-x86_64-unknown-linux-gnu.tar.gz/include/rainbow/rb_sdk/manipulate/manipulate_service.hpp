#pragma once

#include "base.hpp"
#include "common_struct_generated.h"
#include "func_config_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_service_generated.h"
#include "func_servo_generated.h"
#include "manipulate_move.hpp"
#include "move_target_values_arg.hpp"
#include "state_core_generated.h"

class RBManipulateServiceSDK : public RBBaseSDK {
 public:
  RBManipulateServiceSDK() {}

  static std::string type_name() { return "RBManipulateServiceSDK"; }

  /**
   * @brief Starts recording the cobot's motion to a file.
   *
   * Captures the robot's motion trajectory while recording is active, and
   * stores it under the given file name. Call @c call_replay_motion_rec_stop
   * to end the recording, @c call_replay_motion_list to see saved files, and
   * @c call_replay_motion_run to play a recorded file back.
   *
   * @param robot_model Name of the robot model.
   * @param mode Recording mode. 0 = No Save (record without persisting to
   *        disk), 1 = Real Time (save every sample at a fixed frequency),
   *        2 = Mile Stone (save only at key waypoints).
   * @param frequency Sampling frequency (Hz) used in Real Time / Mile
   *        Stone mode.
   * @param filename Name of the file the recording is saved under.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the record-start result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_replay_motion_rec_start(const std::string& robot_model, const int mode,
                                                        const float frequency, const std::string& filename,
                                                        FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Replay_Motion_Rec_StartT req =
        IPC::Request_Replay_Motion_Rec_StartT{.mode = mode, .frequency = frequency, .filename = filename};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Replay_Motion_Rec_StartT>(
            robot_model + "/call_replay_motion_rec_start", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("call_replay_motion_rec_start failed: query one returned nullptr");

    manipulate_return_value("call_replay_motion_rec_start", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Stops the currently active motion recording.
   *
   * Ends a recording previously started by @c call_replay_motion_rec_start.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the record-stop result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_replay_motion_rec_stop(const std::string& robot_model,
                                                       FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Replay_Motion_Rec_StopT req = IPC::Request_Replay_Motion_Rec_StopT{};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Replay_Motion_Rec_StopT>(
            robot_model + "/call_replay_motion_rec_stop", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("call_replay_motion_rec_stop failed: query one returned nullptr");

    manipulate_return_value("call_replay_motion_rec_stop", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Lists the motion recording files saved on the robot.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) after the response is received.
   *
   * @return IPC::Response_FunctionsT containing the query result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   *
   */
  IPC::Response_Replay_Motion_ListT call_replay_motion_list(const std::string& robot_model,
                                                            FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Replay_Motion_ListT req = IPC::Request_Replay_Motion_ListT{};

    std::unique_ptr<IPC::Response_Replay_Motion_ListT> result =
        query_one<IPC::Response_Replay_Motion_List, IPC::Request_Replay_Motion_ListT>(
            robot_model + "/call_replay_motion_list", req, 8, 3000, 0);

    if (!result)
      throw std::runtime_error("call_replay_motion_list failed: query one returned nullptr");

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Replays a previously recorded motion file.
   *
   * @param robot_model Name of the robot model.
   * @param filename Name of the recorded motion file to replay (as
   *        listed by @c call_replay_motion_list).
   * @param type Move type used during replay. 0 = J-type (joint motion),
   *        1 = L-type (linear motion).
   * @param speed Movement speed parameters used during replay.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        replay result is reported to the flow manager and completion is
   *        handled asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the replay-start result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   *
   * @note If @p flow_manager_args is provided, this function returns
   *       immediately after submitting the request; a background monitor
   *       waits for the actual motion-completion signal from the robot
   *       before invoking the flow manager's completion callback.
   */
  IPC::Response_FunctionsT call_replay_motion_run(const std::string& robot_model, const std::string& filename,
                                                  const int type, MoveSpeedArg speed,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Replay_Motion_RunT req;
    req.filename = filename;
    req.type = type;
    // Python 원본과 동일: speed 의 개별 필드가 없으면 60/120 기본값을 쓴다.
    req.speed = std::make_unique<IPC::MoveInput_SpeedT>(IPC::MoveInput_SpeedT{
        .spd_mode = speed.spd_mode.value_or(1),
        .spd_vel_para = speed.spd_vel_para.value_or(60),
        .spd_acc_para = speed.spd_acc_para.value_or(120),
    });

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Replay_Motion_RunT>(robot_model + "/call_replay_motion_run",
                                                                            req, 8, 15000, 0);

    if (!result)
      throw std::runtime_error("call_replay_motion_run failed: query one returned nullptr");

    manipulate_return_value("call_replay_motion_run", *result, flow_manager_args);

    return _move_sdk._apply_time_checking<IPC::Response_FunctionsT>(
        robot_model, "Replay Motion Run", std::move(*result), "call_replay_motion_run", flow_manager_args);
  }

  /**
   * @brief Stops welding: runs the crater-fill sequence and turns the arc off.
   *
   * Runs the counterpart shutdown sequence to @c call_weld_arc_on: holds a
   * crater condition for @p time_crator seconds, then turns the arc off and
   * waits @p time_ending seconds before returning.
   *
   * @param robot_model Name of the robot model.
   * @param time_start Initial wait time before the crater sequence starts
   *        (sec).
   * @param cond_mode Crater condition setting method. 0 = keep current
   *        condition, 1 = set current + voltage, 2 = set feed rate +
   *        voltage, 3 = call job number.
   * @param cond_option Condition option (dropdown). 0 = N/A.
   * @param cond_jobno Job number to call when @p cond_mode is 3 (call job
   *        number).
   * @param cond_current Welding current to apply (A).
   * @param cond_voltage Welding voltage to apply (V).
   * @param cond_feedrate Wire feed rate (m/min).
   * @param cond_arccontrol Arc control value.
   * @param cond_arclength Arc length value.
   * @param cond_para1 Welder-specific parameter 1.
   * @param cond_para2 Welder-specific parameter 2.
   * @param time_crator Crater (arc end point) holding time (sec).
   * @param time_ending Follow-up time to hold position/state after the arc
   *        is turned off (sec).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the arc-off result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_weld_arc_off(const std::string& robot_model, float time_start, int cond_mode,
                                             int cond_option, int cond_jobno, float cond_current, float cond_voltage,
                                             float cond_feedrate, float cond_arccontrol, float cond_arclength,
                                             float cond_para1, float cond_para2, float time_crator, float time_ending,
                                             FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Weld_Arc_OffT req = IPC::Request_Weld_Arc_OffT{
        .time_start = time_start,
        .cond_mode = cond_mode,
        .cond_option = cond_option,
        .cond_jobno = cond_jobno,
        .cond_current = cond_current,
        .cond_voltage = cond_voltage,
        .cond_feedrate = cond_feedrate,
        .cond_arccontrol = cond_arccontrol,
        .cond_arclength = cond_arclength,
        .cond_para1 = cond_para1,
        .cond_para2 = cond_para2,
        .time_crator = time_crator,
        .time_ending = time_ending,
    };

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Weld_Arc_OffT>(
        robot_model + "/call_weld_arc_off", req, 8, 30000, 0);

    if (!result)
      throw std::runtime_error("call_weld_arc_off failed: query one returned nullptr");

    manipulate_return_value("call_weld_arc_off", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Starts welding: turns the arc on with the given condition and
   *        detection settings.
   *
   * Runs the arc-start sequence: waits @p time_start, moves at
   * (@p robot_vel, @p robot_acc), applies the requested welding condition,
   * purges gas for @p time_pregas, then attempts to detect the arc signal
   * (retrying up to @p detect_try_num times with @p detect_timegap between
   * attempts, each bounded by @p detect_timeout), and finally waits
   * @p time_ending before returning. Call @c call_weld_arc_off to end
   * welding.
   *
   * @param robot_model Name of the robot model.
   * @param time_start Initial wait time before the sequence starts (sec).
   * @param robot_vel Robot movement speed during the arc-on motion (mm/s).
   * @param robot_acc Robot movement acceleration during the arc-on motion
   *        (mm/s^2).
   * @param cond_mode Welding condition setting method. 0 = keep current
   *        condition, 1 = set current + voltage, 2 = set feed rate +
   *        voltage, 3 = call job number.
   * @param cond_option Condition option (dropdown). 0 = N/A.
   * @param cond_jobno Job number to call when @p cond_mode is 3 (call job
   *        number).
   * @param cond_current Welding current to apply (A).
   * @param cond_voltage Welding voltage to apply (V).
   * @param cond_feedrate Wire feed rate (m/min).
   * @param cond_arccontrol Arc control value.
   * @param cond_arclength Arc length value.
   * @param cond_para1 Welder-specific parameter 1.
   * @param cond_para2 Welder-specific parameter 2.
   * @param time_pregas Pre-gas purge time before arc start (sec).
   * @param detect_try_num Number of retry attempts for arc signal
   *        detection.
   * @param detect_timeout Timeout duration for a single arc signal
   *        detection attempt (sec).
   * @param detect_timegap Interval time between arc signal detection
   *        retries (sec).
   * @param time_ending Follow-up time to hold position/state after the arc
   *        is confirmed on (sec).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the arc-on result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_weld_arc_on(const std::string& robot_model, float time_start, float robot_vel,
                                            float robot_acc, int cond_mode, int cond_option, int cond_jobno,
                                            float cond_current, float cond_voltage, float cond_feedrate,
                                            float cond_arccontrol, float cond_arclength, float cond_para1,
                                            float cond_para2, float time_pregas, int detect_try_num,
                                            float detect_timeout, float detect_timegap, float time_ending,
                                            FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Weld_Arc_OnT req = IPC::Request_Weld_Arc_OnT{
        .time_start = time_start,
        .robot_vel = robot_vel,
        .robot_acc = robot_acc,
        .cond_mode = cond_mode,
        .cond_option = cond_option,
        .cond_jobno = cond_jobno,
        .cond_current = cond_current,
        .cond_voltage = cond_voltage,
        .cond_feedrate = cond_feedrate,
        .cond_arccontrol = cond_arccontrol,
        .cond_arclength = cond_arclength,
        .cond_para1 = cond_para1,
        .cond_para2 = cond_para2,
        .time_pregas = time_pregas,
        .detect_try_num = detect_try_num,
        .detect_timeout = detect_timeout,
        .detect_timegap = detect_timegap,
        .time_ending = time_ending,
    };

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Weld_Arc_OnT>(
        robot_model + "/call_weld_arc_on", req, 8, 30000, 0);

    if (!result)
      throw std::runtime_error("call_weld_arc_on failed: query one returned nullptr");

    manipulate_return_value("call_weld_arc_on", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Reads the saved welding device configuration
   *        (Settings > Devices > Welding).
   *
   * Returns the device I/O mapping and current/voltage conversion maps
   * previously saved via @c save_weld_parameter.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) after the response is received.
   *
   * @return IPC::Response_CallConfigWeldT containing the saved welding
   *         device configuration.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_CallConfigWeldT call_config_weld(const std::string& robot_model,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CallConfigWeldT req = IPC::Request_CallConfigWeldT{};

    std::unique_ptr<IPC::Response_CallConfigWeldT> result =
        query_one<IPC::Response_CallConfigWeld, IPC::Request_CallConfigWeldT>(robot_model + "/call_config_weld", req, 8,
                                                                              30000, 0);

    if (!result)
      throw std::runtime_error("call_config_weld failed: query one returned nullptr");

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Jogs the welding wire feeder forward or backward, or stops it.
   *
   * @param robot_model Name of the robot model.
   * @param direction Wire feed direction. -1 = backward, 0 = stop,
   *        1 = forward.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the command result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_weld_wire(const std::string& robot_model, const int direction,
                                          FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Weld_WireT req = IPC::Request_Weld_WireT{.direction = direction};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Weld_WireT>(robot_model + "/call_weld_wire", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("call_weld_wire failed: query one returned nullptr");

    manipulate_return_value("call_weld_wire", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Turns the welding shield gas purge on or off.
   *
   * @param robot_model Name of the robot model.
   * @param gas_onoff Gas purge state. 0 = off, 1 = on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the command result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_weld_gas(const std::string& robot_model, const int gas_onoff,
                                         FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Weld_GasT req = IPC::Request_Weld_GasT{.gas_onoff = gas_onoff};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Weld_GasT>(robot_model + "/call_weld_gas", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("call_weld_gas failed: query one returned nullptr");

    manipulate_return_value("call_weld_gas", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the welding device configuration
   *        (Settings > Devices > Welding).
   *
   * Configures which digital/analog I/O ports the welding device is wired
   * to, and the current/voltage conversion maps used to translate a
   * requested welding current/voltage into the corresponding raw
   * analog output value (and vice versa for feedback). Read back with
   * @c call_config_weld.
   *
   * @param robot_model Name of the robot model.
   * @param dev_id Welding device type. 0 = None, 1 = I/O Signal.
   * @param dev_ip_0 First octet of the welding device IP address.
   * @param dev_ip_1 Second octet of the welding device IP address.
   * @param dev_ip_2 Third octet of the welding device IP address.
   * @param dev_ip_3 Fourth octet of the welding device IP address.
   * @param dev_port Communication port of the welding device.
   * @param out_pno_arc Digital output port number for the Arc On signal.
   *        -1 = none, 0-15 = Digital Output 0-15.
   * @param out_pno_touch Digital output port number for the Touch On
   *        signal. -1 = none, 0-15 = Digital Output 0-15.
   * @param out_pno_gas Digital output port number for the Gas On signal.
   *        -1 = none, 0-15 = Digital Output 0-15.
   * @param out_pno_inch Digital output port number for the Wire Inch
   *        signal. -1 = none, 0-15 = Digital Output 0-15.
   * @param out_pno_reinch Digital output port number for the Wire Re-Inch
   *        signal. -1 = none, 0-15 = Digital Output 0-15.
   * @param out_pno_current Analog output port number for the current
   *        setting. -1 = none, 0-3 = Analog Output 0-3.
   * @param out_pno_voltage Analog output port number for the voltage
   *        setting. -1 = none, 0-3 = Analog Output 0-3.
   * @param in_pno_ready Digital input port number for the Welder Ready
   *        feedback signal. -1 = none, 0-15 = Digital Input 0-15.
   * @param in_pno_arc Digital input port number for the Arc Generated
   *        feedback signal. -1 = none, 0-15 = Digital Input 0-15.
   * @param in_pno_touch Digital input port number for the Touch Signal
   *        feedback. -1 = none, 0-15 = Digital Input 0-15.
   * @param in_pno_gas Digital input port number for the Gas Signal
   *        feedback. -1 = none, 0-15 = Digital Input 0-15.
   * @param in_pno_feeder Digital input port number for the Feeder Signal
   *        feedback. -1 = none, 0-15 = Digital Input 0-15.
   * @param in_pno_error Digital input port number for the Welder Error
   *        signal. -1 = none, 0-15 = Digital Input 0-15.
   * @param in_pno_current Analog input port number for the current
   *        feedback. -1 = none, 0-3 = Analog Input 0-3.
   * @param in_pno_voltage Analog input port number for the voltage
   *        feedback. -1 = none, 0-3 = Analog Input 0-3.
   * @param current_map_value Input (raw) value list for the welding
   *        current conversion map.
   * @param current_map_output Output (converted) value list for the
   *        welding current conversion map, paired index-for-index with
   *        @p current_map_value.
   * @param voltage_map_value Input (raw) value list for the welding
   *        voltage conversion map.
   * @param voltage_map_output Output (converted) value list for the
   *        welding voltage conversion map, paired index-for-index with
   *        @p voltage_map_value.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT save_weld_parameter(
      const std::string& robot_model, int dev_id, int dev_ip_0, int dev_ip_1, int dev_ip_2, int dev_ip_3, int dev_port,
      int out_pno_arc, int out_pno_touch, int out_pno_gas, int out_pno_inch, int out_pno_reinch, int out_pno_current,
      int out_pno_voltage, int in_pno_ready, int in_pno_arc, int in_pno_touch, int in_pno_gas, int in_pno_feeder,
      int in_pno_error, int in_pno_current, int in_pno_voltage, int hw_process_type, int hw_wire_type, int hw_wire_size,
      int hw_gas_type, std::vector<float> current_map_value, std::vector<float> current_map_output,
      std::vector<float> voltage_map_value, std::vector<float> voltage_map_output,
      FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Weld_Save_ParameterT req = IPC::Request_Weld_Save_ParameterT{
        .dev_id = dev_id,
        .dev_ip_0 = dev_ip_0,
        .dev_ip_1 = dev_ip_1,
        .dev_ip_2 = dev_ip_2,
        .dev_ip_3 = dev_ip_3,
        .dev_port = dev_port,
        .out_pno_arc = out_pno_arc,
        .out_pno_touch = out_pno_touch,
        .out_pno_gas = out_pno_gas,
        .out_pno_inch = out_pno_inch,
        .out_pno_reinch = out_pno_reinch,
        .out_pno_current = out_pno_current,
        .out_pno_voltage = out_pno_voltage,
        .in_pno_ready = in_pno_ready,
        .in_pno_arc = in_pno_arc,
        .in_pno_touch = in_pno_touch,
        .in_pno_gas = in_pno_gas,
        .in_pno_feeder = in_pno_feeder,
        .in_pno_error = in_pno_error,
        .in_pno_current = in_pno_current,
        .in_pno_voltage = in_pno_voltage,
        .hw_process_type = hw_process_type,
        .hw_wire_type = hw_wire_type,
        .hw_wire_size = hw_wire_size,
        .hw_gas_type = hw_gas_type,
        .current_map_value = current_map_value,
        .current_map_output = current_map_output,
        .voltage_map_value = voltage_map_value,
        .voltage_map_output = voltage_map_output,
    };

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Weld_Save_ParameterT>(robot_model + "/save_weld_parameter", req,
                                                                              8, 2000, 0);

    if (!result)
      throw std::runtime_error("save_weld_parameter failed: query one returned nullptr");

    manipulate_return_value("save_weld_parameter", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Runs a Motion Macro: a pre-built multi-segment move pattern
   *        (flat surface / round / triangle / 3D round) derived from a
   *        small set of corner points.
   *
   * Rounds each point in @p corner_pnts to 3 decimal places, pads or
   * truncates it to the 7-value tar_values format expected by the
   * firmware, and forwards the request. The number of points required in
   * @p corner_pnts depends on @p type: Flat Surface = 4, Round (R) = 6,
   * Round (H) = 6, Triangle = 3, 3D Round = 9.
   *
   * @param robot_model Name of the robot model.
   * @param type Motion Macro type. 0 = Flat Surface, 1 = Round (R),
   *        2 = Round (H), 3 = Triangle, 4 = 3D Round.
   * @param corner_pnts Corner points defining the macro shape, each a
   *        [x, y, z, rx, ry, rz, aa]-style value list (up to 7 elements;
   *        shorter lists are zero-padded). The number of points required
   *        depends on @p type (see above).
   * @param speed Movement speed parameters used to run the macro.
   * @param rotation_mode Orientation option. 0 = Intended, 1 = Constant.
   * @param gap_num Gap number between macro segments.
   * @param margin_h_1 Margin height 1 (mm).
   * @param margin_h_2 Margin height 2 (mm).
   * @param margin_w_1 Margin width 1 (mm).
   * @param margin_w_2 Margin width 2 (mm).
   * @param margin_over Margin over (mm).
   * @param margin_over_para Margin over parameter, in the range [0, 1].
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        macro's motion result is reported to the flow manager and
   *        completion is handled asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the macro-start result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   *
   * @note If @p flow_manager_args is provided, this function returns
   *       immediately after submitting the request; a background monitor
   *       waits for the actual motion-completion signal from the robot
   *       before invoking the flow manager's completion callback.
   */
  IPC::Response_FunctionsT call_move_macro(const std::string& robot_model, int type,
                                           std::vector<MoveTargetValuesArg> corner_pnts,
                                           std::optional<MoveSpeedArg> speed, int rotation_mode, int gap_num,
                                           float margin_h_1, float margin_h_2,
                                           float margin_w_1, float margin_w_2, float margin_over,
                                           float margin_over_para, FlowManagerArgsPtr flow_manager_args = nullptr) {
    std::vector<std::unique_ptr<IPC::MoveInput_TargetT>> result_target_values;

    // 좌표 반올림/7-패딩과, 포인트 하나의 파싱 실패를 조용히 7-zero 로 흡수하는 처리는
    // MoveTargetValuesArg 의 type_caster(binding/glue/move_target_values_caster.hpp) 가
    // 이미 끝냈다 — Python 원본과 동일하게 한 포인트가 잘못돼도 나머지는 계속 처리된다.
    for (const auto& data : corner_pnts) {
      auto target = std::make_unique<IPC::MoveInput_TargetT>();
      target->tar_frame = 0;
      target->tar_unit = 0;
      target->tar_values = data.tar_values;

      result_target_values.push_back(std::move(target));
    }

    // Python 원본과 동일: speed(및 그 개별 필드)가 없으면 250/1000 기본값을 쓴다.
    const MoveSpeedArg speed_arg = speed.value_or(MoveSpeedArg{});
    std::unique_ptr<IPC::MoveInput_SpeedT> result_speed = std::make_unique<IPC::MoveInput_SpeedT>();
    result_speed->spd_mode = speed_arg.spd_mode.value_or(1);
    result_speed->spd_acc_para = speed_arg.spd_acc_para.value_or(1000);
    result_speed->spd_vel_para = speed_arg.spd_vel_para.value_or(250);

    return _run_move_macro(robot_model, type, std::move(result_target_values), std::move(result_speed), rotation_mode,
                           gap_num, margin_h_1, margin_h_2, margin_w_1, margin_w_2, margin_over, margin_over_para,
                           flow_manager_args);
  }

  /**
   * @brief Stops an active repeating Pattern by ID.
   *
   * @param robot_model Name of the robot model.
   * @param id Pattern ID to stop, in the range [0, 29].
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the command result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_pattern_off(const std::string& robot_model, const int id,
                                            FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Pattern_OffT req = IPC::Request_Pattern_OffT{.id = id};

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Pattern_OffT>(
        robot_model + "/call_pattern_off", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("call_pattern_off failed: query one returned nullptr");

    manipulate_return_value("call_pattern_off", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Starts a repeating Pattern move: a grid or randomized sweep of
   *        points around an anchor point.
   *
   * Builds the target point list from @p corner_pnts (for Line / Plane /
   * Cube patterns) or @p random_pnts (when @p type is 3, Random),
   * rounding each point to 3 decimal places and padding/truncating it to
   * the 7-value tar_values format. The number of points required in
   * @p corner_pnts depends on @p type: Line (X) = 2, Plane (X-Y) = 4,
   * Cube (X-Y-Z) = 8; Random patterns instead take @p random_pnts, whose
   * point count is caller-defined. Call @c call_pattern_off to stop.
   *
   * @param robot_model Name of the robot model.
   * @param id Pattern ID to run, in the range [0, 29]. Running a new
   *        pattern on an ID already in use is expected to replace it.
   * @param type Pattern type. 0 = Line (X), 1 = Plane (X-Y),
   *        2 = Cube (X-Y-Z), 3 = Random.
   * @param corner_pnts Corner points defining the pattern grid, each a
   *        [x, y, z, rx, ry, rz, aa]-style value list (up to 7 elements;
   *        shorter lists are zero-padded). Used when @p type is not 3
   *        (Random); ignored otherwise.
   * @param random_pnts Explicit point list used only when @p type is 3
   *        (Random), in the same per-point format as @p corner_pnts.
   *        Ignored for the other pattern types.
   * @param count_x Number of points to generate along the X axis.
   * @param count_y Number of points to generate along the Y axis.
   * @param count_z Number of points to generate along the Z axis.
   * @param anchor_pnt Reference point the pattern grid is built around, as
   *        a [x, y, z, rx, ry, rz, aa]-style value list (up to 7 elements;
   *        shorter lists are zero-padded).
   * @param incremental Whether the pattern advances incrementally between
   *        activations (nonzero) or restarts from the first point each
   *        time (0).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the pattern-start result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_pattern_on(const std::string& robot_model, int id, int type,
                                           std::optional<std::vector<MoveTargetValuesArg>> corner_pnts,
                                           std::optional<std::vector<MoveTargetValuesArg>> random_pnts, int count_x,
                                           int count_y, int count_z, MoveTargetValuesArg anchor_pnt, int incremental,
                                           FlowManagerArgsPtr flow_manager_args = nullptr) {
    std::vector<std::unique_ptr<IPC::MoveInput_TargetT>> result_target_values;
    const auto& data_points = (type == 3) ? random_pnts.value_or(std::vector<MoveTargetValuesArg>{})
                                          : corner_pnts.value_or(std::vector<MoveTargetValuesArg>{});

    // 좌표 반올림/7-패딩과, 포인트 하나의 파싱 실패를 조용히 7-zero 로 흡수하는 처리는
    // MoveTargetValuesArg 의 type_caster(binding/glue/move_target_values_caster.hpp) 가
    // 이미 끝냈다 — Python 원본과 동일하게 한 포인트가 잘못돼도 나머지는 계속 처리된다.
    for (const auto& data : data_points) {
      auto target = std::make_unique<IPC::MoveInput_TargetT>();

      target->tar_frame = 0;
      target->tar_unit = 0;
      target->tar_values = data.tar_values;

      result_target_values.push_back(std::move(target));
    }

    auto anchor_target = std::make_unique<IPC::MoveInput_TargetT>();

    anchor_target->tar_frame = 0;
    anchor_target->tar_unit = 0;
    anchor_target->tar_values = anchor_pnt.tar_values;

    return _run_pattern_on(robot_model, id, type, std::move(result_target_values), count_x, count_y, count_z,
                           std::move(anchor_target), incremental, flow_manager_args);
  }

  /**
   * @brief Runs automatic TCP position calibration from a set of joint
   *        poses (Move > Calibration > TCP Position).
   *
   * The robot is moved through the given joint poses and the TCP offset
   * is computed from the resulting motion. Each entry in @p joints is
   * rounded to 3 decimal places and padded/truncated to 7 values before
   * being sent.
   *
   * @param robot_model Name of the robot model.
   * @param joints Joint poses to calibrate from. Each target's tar_frame
   *        must be Joint (-1) — the values are joint angles, not
   *        Cartesian coordinates.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the calibration result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_calib_tcp_position(const std::string& robot_model,
                                                   std::vector<IPC::MoveInput_TargetT> joints,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Calib_Tcp_PositionT req = IPC::Request_Calib_Tcp_PositionT{};
    std::vector<std::unique_ptr<IPC::MoveInput_TargetT>> joints_vector;

    for (const auto& data : joints) {
      auto target = std::make_unique<IPC::MoveInput_TargetT>();

      target->tar_frame = data.tar_frame;
      target->tar_unit = data.tar_unit;

      target->tar_values.clear();

      for (size_t i = 0; i < std::min<size_t>(7, data.tar_values.size()); ++i) {
        target->tar_values.push_back(std::round(data.tar_values[i] * 1000.0f) / 1000.0f);
      }

      target->tar_values.resize(7, 0.0f);

      joints_vector.push_back(std::move(target));
    }
    req.joints = std::move(joints_vector);

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Calib_Tcp_PositionT>(robot_model + "/call_calib_tcp_position",
                                                                             req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("call_calib_tcp_position failed: query one returned nullptr");

    manipulate_return_value("call_calib_tcp_position", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Runs automatic TCP orientation calibration
   *        (Move > Calibration > TCP Orientation).
   *
   * @param robot_model Name of the robot model.
   * @param frame_option Alignment frame used for the calibration.
   *        0 = Global frame, 1 = Local frame, 2 = User frame.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the calibration result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_calib_tcp_orientation(const std::string& robot_model, int frame_option,
                                                      FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Calib_Tcp_OrientationT req = IPC::Request_Calib_Tcp_OrientationT{.frame_option = frame_option};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Calib_Tcp_OrientationT>(
            robot_model + "/call_calib_tcp_orientation", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("call_calib_tcp_orientation failed: query one returned nullptr");

    manipulate_return_value("call_calib_tcp_orientation", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Sends an Initialize command, plus any additional configured commands (e.g., Set-position, Action), to a configured gripper or end-of-arm tool.
   *
   * A single generic entry point for all supported gripper models
   * (Dynamixel, DH PG/CG/AG, Robotiq E-Pick/2F/Hand-E, Baumer LDS,
   * OnRobot 2FG/RG/3FG/VG/VGC/MG/SoftGripper/VGP20/Sander, JRT JEG
   * series, and others). @p function_list is model-specific: index 0 is
   * always Initialize, and later indices are model-specific actions
   * (e.g. Set Goal Position, Set Goal Pos/Spd/Force, Reset, Suction). The
   * meaning of each @p payload slot depends on both @p gripper_type and
   * @p function_list — each of the 23 supported gripper types has its own
   * per-function payload layout (slot index, unit, and default value),
   * too large to reproduce here in full; consult the gripper's setup UI
   * or vendor documentation for the exact slot mapping of the model in use.
   *
   * @param robot_model Name of the robot model.
   * @param gripper_type Gripper/tool model selector. 0 = Dynamixel Motor,
   *        1 = DH PG/CG Series, 2 = DH AG Series, 3 = Robotiq E-Pick,
   *        4 = Robotiq 2F Series, 5 = Robotiq Hand-E Series, 6 = Baumer
   *        LDS, 7 = OnRobot 2FG7, 8 = OnRobot 2FG14, 9 = OnRobot RG2,
   *        10 = OnRobot RG6, 11 = OnRobot 3FG15, 12 = OnRobot 3FG25,
   *        13 = OnRobot VG10, 14 = OnRobot VGC10, 15 = OnRobot MG10,
   *        16 = OnRobot SoftGripper, 17 = OnRobot VGP20,
   *        18 = OnRobot Sander, 19 = JRT JEGB, 20 = JRT JEGG,
   *        21 = JRT JEGC, 22 = JRT JEGH.
   * @param function_list Action to run for the selected @p gripper_type.
   *        0 is Initialize for every model; the meaning of other indices
   *        is model-specific (see schema).
   * @param payload Positional argument list for the selected
   *        @p gripper_type / @p function_list combination (e.g. connection
   *        port, device ID, target position/speed/force). Layout is
   *        model- and function-specific — see schema.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the command result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_gripper_action(const std::string& robot_model, int gripper_type, int function_list,
                                               std::vector<float> payload,
                                               FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Gripper_ActionT req =
        IPC::Request_Gripper_ActionT{.gripper_type = gripper_type, .function_list = function_list, .payload = payload};

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Gripper_ActionT>(
        robot_model + "/call_gripper_action", req, 8, 15000, 0);

    if (!result)
      throw std::runtime_error("call_gripper_action failed: query one returned nullptr");

    manipulate_return_value("call_gripper_action", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Resets/configures one of the robot's 10 general-purpose
   *        program timers.
   *
   * @param robot_model Name of the robot model.
   * @param timer_no Timer index to configure, in the range [0, 9].
   * @param reset_time Value the timer is reset to (sec).
   * @param option_increase Timing option. 0 = Default, 1 = Sync with
   *        Speed Bar.
   * @param option_action Action option. 0 = Default, 1 = Stop at Pause
   *        State.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the command result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_timer_function(const std::string& robot_model, int timer_no, float reset_time,
                                               int option_increase, int option_action,
                                               FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Timmer_FunctionT req = IPC::Request_Timmer_FunctionT{.timer_no = timer_no,
                                                                      .reset_time = reset_time,
                                                                      .option_increase = option_increase,
                                                                      .option_action = option_action};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Timmer_FunctionT>(robot_model + "/call_timer_function", req, 8,
                                                                          2000, 0);

    if (!result)
      throw std::runtime_error("call_timer_function failed: query one returned nullptr");

    manipulate_return_value("call_timer_function", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Executes a G-code file as a robot motion program.
   *
   * @param robot_model Name of the robot model.
   * @param filename Name of the G-code file to run.
   * @param gcodeframe Reference frame the G-code coordinates are
   *        interpreted in. 0 = Global, 1 = Local, 2 = User.
   * @param feed_spd_default Default feed speed (mm/s).
   * @param feed_spd_rapid Rapid (non-cutting) feed speed (mm/s).
   * @param feed_spd_limit Maximum feed speed allowed (mm/s).
   * @param feed_spd_rotation Feed rotation speed (deg/s).
   * @param default_plane Default working plane. 0 = XY-Plane,
   *        1 = ZX-Plane, 2 = YZ-Plane.
   * @param offset_x X offset applied to all G-code coordinates (mm).
   * @param offset_y Y offset applied to all G-code coordinates (mm).
   * @param offset_z Z offset applied to all G-code coordinates (mm).
   * @param will_const_sped Whether to run at constant speed. 0 = off,
   *        1 = constant speed.
   * @param will_ignore_unknown Whether to ignore unrecognized G-code
   *        commands instead of failing. 0 = off, 1 = ignore unknown code.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        run result is reported to the flow manager and completion is
   *        handled asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the run-start result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   *
   * @note If @p flow_manager_args is provided, this function returns
   *       immediately after submitting the request; a background monitor
   *       waits for the actual motion-completion signal from the robot
   *       before invoking the flow manager's completion callback.
   */
  IPC::Response_FunctionsT call_move_gcode(const std::string& robot_model, const std::string& filename, int gcodeframe,
                                           float feed_spd_default, float feed_spd_rapid, float feed_spd_limit,
                                           float feed_spd_rotation, int default_plane, float offset_x, float offset_y,
                                           float offset_z, int will_const_sped, int will_ignore_unknown,
                                           FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Move_GcodeT req = IPC::Request_Move_GcodeT{
        .filename = filename,
        .gcodeframe = gcodeframe,
        .feed_spd_default = feed_spd_default,
        .feed_spd_rapid = feed_spd_rapid,
        .feed_spd_limit = feed_spd_limit,
        .feed_spd_rotation = feed_spd_rotation,
        .default_plane = default_plane,
        .offset_x = offset_x,
        .offset_y = offset_y,
        .offset_z = offset_z,
        .will_const_sped = will_const_sped,
        .will_ignore_unknown = will_ignore_unknown,
    };

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_GcodeT>(
        robot_model + "/call_move_gcode", req, 8, 60000, 0);

    if (!result)
      throw std::runtime_error("call_move_gcode failed: query one returned nullptr");

    manipulate_return_value("call_move_gcode", *result, flow_manager_args);

    return _move_sdk._apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Call Move Gcode", std::move(*result),
                                                                    "call_move_gcode", flow_manager_args);
  }

  /**
   * @brief Reads the saved external F/T (force/torque) sensor
   *        configuration (Settings > Devices > External F/T).
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) after the response is received.
   *
   * @return IPC::Response_CallConfigEXTFTT containing the saved external
   *         F/T sensor configuration.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_CallConfigEXTFTT call_config_extft(const std::string& robot_model,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CallConfigEXTFTT req = IPC::Request_CallConfigEXTFTT{};

    std::unique_ptr<IPC::Response_CallConfigEXTFTT> result =
        query_one<IPC::Response_CallConfigEXTFT, IPC::Request_CallConfigEXTFTT>(robot_model + "/call_config_extft", req,
                                                                                8, 2000, 0);

    if (!result)
      throw std::runtime_error("call_config_extft failed: query one returned nullptr");

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the external F/T (force/torque) sensor configuration
   *        (Settings > Devices > External F/T).
   *
   * @param robot_model Name of the robot model.
   * @param dev_type External F/T sensor model. 0 = No Sensor,
   *        1 = AIDIN AFT, 2 = Robotous 60HA01.
   * @param dev_mount_opt Mounting option. 0 = Default Mount,
   *        1 = Custom Mount.
   * @param dev_mount_rx Custom mount rotation about X, relative to the
   *        flange (deg). Used when @p dev_mount_opt is Custom Mount.
   * @param dev_mount_ry Custom mount rotation about Y, relative to the
   *        flange (deg). Used when @p dev_mount_opt is Custom Mount.
   * @param dev_mount_rz Custom mount rotation about Z, relative to the
   *        flange (deg). Used when @p dev_mount_opt is Custom Mount.
   * @param dev_filer_hz Signal low-pass filter cutoff frequency (Hz).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT save_extft_parameter(const std::string& robot_model, int dev_type, int dev_mount_opt,
                                                float dev_mount_rx, float dev_mount_ry, float dev_mount_rz,
                                                float dev_filer_hz, FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_EXTFT_Save_ParameterT req = IPC::Request_EXTFT_Save_ParameterT{
        .dev_type = dev_type,
        .dev_mount_opt = dev_mount_opt,
        .dev_mount_rx = dev_mount_rx,
        .dev_mount_ry = dev_mount_ry,
        .dev_mount_rz = dev_mount_rz,
        .dev_filer_hz = dev_filer_hz,
    };

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_EXTFT_Save_ParameterT>(robot_model + "/save_extft_parameter",
                                                                               req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("save_extft_parameter failed: query one returned nullptr");

    manipulate_return_value("save_extft_parameter", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Reads the saved field-bus / fieldbus-like communication
   *        configuration for all 13 supported protocols
   *        (Settings > Devices > Communication).
   *
   * Returns the on/off mode and port number currently saved for each of
   * Modbus, TCP Command, TCP Data, UDP Command, UDP Data, EtherNet/IP
   * External, EtherNet/IP Internal, PROFINET, OPC-UA, MQTT, REST API,
   * RTDE, and gRPC.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) after the response is received.
   *
   * @return IPC::Response_CallConfigCommunicationT containing the
   *         mode_* / port_* pair for each of the 13 protocols.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_CallConfigCommunicationT call_config_communication(const std::string& robot_model,
                                                                   FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CallConfigCommunicationT req = IPC::Request_CallConfigCommunicationT{};

    std::unique_ptr<IPC::Response_CallConfigCommunicationT> result =
        query_one<IPC::Response_CallConfigCommunication, IPC::Request_CallConfigCommunicationT>(
            robot_model + "/call_config_communication", req, 8, 15000, 0);

    if (!result)
      throw std::runtime_error("call_config_communication failed: query one returned nullptr");

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the Modbus communication parameters
   *        (Settings > Devices > Communication > Modbus TCP).
   *
   * @param robot_model Name of the robot model.
   * @param mode Modbus server mode. 0 = Off, 1 = On.
   * @param port TCP port the Modbus server listens on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_communication_para_mbus(const std::string& robot_model, int mode, int port,
                                                        FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CommunicationMbusT req = IPC::Request_CommunicationMbusT{.mode = mode, .port = port};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CommunicationMbusT>(
            robot_model + "/call_communication_para_mbus", req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_communication_para_mbus failed: query one returned nullptr");

    manipulate_return_value("call_communication_para_mbus", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the TCP ASCII Command channel communication parameters
   *        (Settings > Devices > Communication > TCP Ascii Command).
   *
   * Same parameter shape as @c call_communication_para_mbus (mode, port);
   * this configures Rainbow's own ASCII-text TCP command-and-control
   * channel rather than a third-party fieldbus protocol.
   *
   * @param robot_model Name of the robot model.
   * @param mode TCP ASCII Command server mode. 0 = Off, 1 = On.
   * @param port TCP port the ASCII Command server listens on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_communication_para_tcpcmd(const std::string& robot_model, int mode, int port,
                                                          FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CommunicationTcpCmdT req = IPC::Request_CommunicationTcpCmdT{.mode = mode, .port = port};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CommunicationTcpCmdT>(
            robot_model + "/call_communication_para_tcpcmd", req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_communication_para_tcpcmd failed: query one returned nullptr");

    manipulate_return_value("call_communication_para_tcpcmd", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the TCP ASCII Data channel communication parameters
   *        (Settings > Devices > Communication > TCP Ascii Data).
   *
   * Same parameter shape as @c call_communication_para_mbus: @p mode
   * (0 = Off, 1 = On) and @p port (listen port). This configures
   * Rainbow's own ASCII-text TCP realtime-data streaming channel.
   *
   * @param robot_model Name of the robot model.
   * @param mode TCP ASCII Data server mode. 0 = Off, 1 = On.
   * @param port TCP port the ASCII Data server listens on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_communication_para_tcpdatda(const std::string& robot_model, int mode, int port,
                                                            FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CommunicationTcpDataT req = IPC::Request_CommunicationTcpDataT{.mode = mode, .port = port};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CommunicationTcpDataT>(
            robot_model + "/call_communication_para_tcpdatda", req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error(
          "call_communication_para_tcpdatda failed: query "
          "one returned nullptr");

    manipulate_return_value("call_communication_para_tcpdatda", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the UDP ASCII Command channel communication parameters
   *        (Settings > Devices > Communication > UDP Ascii Command).
   *
   * Same parameter shape as @c call_communication_para_mbus: @p mode
   * (0 = Off, 1 = On) and @p port (listen port). UDP counterpart of
   * @c call_communication_para_tcpcmd.
   *
   * @param robot_model Name of the robot model.
   * @param mode UDP ASCII Command server mode. 0 = Off, 1 = On.
   * @param port UDP port the ASCII Command server listens on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_communication_para_udpcmd(const std::string& robot_model, int mode, int port,
                                                          FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CommunicationUdpCmdT req = IPC::Request_CommunicationUdpCmdT{.mode = mode, .port = port};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CommunicationUdpCmdT>(
            robot_model + "/call_communication_para_udpcmd", req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_communication_para_udpcmd failed: query one returned nullptr");

    manipulate_return_value("call_communication_para_udpcmd", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the UDP ASCII Data channel communication parameters
   *        (Settings > Devices > Communication > UDP Ascii Data).
   *
   * Same parameter shape as @c call_communication_para_mbus: @p mode
   * (0 = Off, 1 = On) and @p port (listen port). UDP counterpart of
   * @c call_communication_para_tcpdatda.
   *
   * @param robot_model Name of the robot model.
   * @param mode UDP ASCII Data server mode. 0 = Off, 1 = On.
   * @param port UDP port the ASCII Data server listens on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_communication_para_udpdatda(const std::string& robot_model, int mode, int port,
                                                            FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CommunicationUdpCmdT req = IPC::Request_CommunicationUdpCmdT{.mode = mode, .port = port};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CommunicationUdpCmdT>(
            robot_model + "/call_communication_para_udpdatda", req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error(
          "call_communication_para_udpdatda failed: query "
          "one returned nullptr");

    manipulate_return_value("call_communication_para_udpdatda", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the EtherNet/IP Explicit Messaging communication
   *        parameters (Settings > Devices > Communication > EtherNet/IP Explicit).
   *
   * Same parameter shape as @c call_communication_para_mbus: @p mode
   * (0 = Off, 1 = On) and @p port (listen port). Explicit Messaging is
   * EtherNet/IP's request/response (TCP) channel, as opposed to the
   * cyclic I/O channel configured by @c call_communication_para_eipint.
   *
   * @param robot_model Name of the robot model.
   * @param mode EtherNet/IP Explicit Messaging server mode. 0 = Off,
   *        1 = On.
   * @param port TCP port the EtherNet/IP Explicit Messaging server
   *        listens on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_communication_para_eipext(const std::string& robot_model, int mode, int port,
                                                          FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CommunicationEIPextT req = IPC::Request_CommunicationEIPextT{.mode = mode, .port = port};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CommunicationEIPextT>(
            robot_model + "/call_communication_para_eipext", req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_communication_para_eipext failed: query one returned nullptr");

    manipulate_return_value("call_communication_para_eipext", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the EtherNet/IP Implicit Messaging communication
   *        parameters (Settings > Devices > Communication > EtherNet/IP Implicit).
   *
   * Same parameter shape as @c call_communication_para_mbus: @p mode
   * (0 = Off, 1 = On) and @p port (listen port). Implicit Messaging is
   * EtherNet/IP's cyclic I/O (UDP) channel, as opposed to the
   * request/response channel configured by @c call_communication_para_eipext.
   *
   * @param robot_model Name of the robot model.
   * @param mode EtherNet/IP Implicit Messaging server mode. 0 = Off,
   *        1 = On.
   * @param port Port the EtherNet/IP Implicit Messaging server listens on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_communication_para_eipint(const std::string& robot_model, int mode, int port,
                                                          FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CommunicationEIPintT req = IPC::Request_CommunicationEIPintT{.mode = mode, .port = port};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CommunicationEIPintT>(
            robot_model + "/call_communication_para_eipint", req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_communication_para_eipint failed: query one returned nullptr");

    manipulate_return_value("call_communication_para_eipint", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the PROFINET communication parameters
   *        (Settings > Devices > Communication > ProfiNET).
   *
   * Same parameter shape as @c call_communication_para_mbus: @p mode
   * (0 = Off, 1 = On) and @p port (listen port).
   *
   * @param robot_model Name of the robot model.
   * @param mode PROFINET server mode. 0 = Off, 1 = On.
   * @param port Port the PROFINET server listens on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_communication_para_pnet(const std::string& robot_model, int mode, int port,
                                                        FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CommunicationPNetT req = IPC::Request_CommunicationPNetT{.mode = mode, .port = port};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CommunicationPNetT>(
            robot_model + "/call_communication_para_pnet", req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_communication_para_pnet failed: query one returned nullptr");

    manipulate_return_value("call_communication_para_pnet", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the OPC-UA communication parameters
   *        (Settings > Devices > Communication > OPC-UA).
   *
   * Same parameter shape as @c call_communication_para_mbus: @p mode
   * (0 = Off, 1 = On) and @p port (listen port).
   *
   * @param robot_model Name of the robot model.
   * @param mode OPC-UA server mode. 0 = Off, 1 = On.
   * @param port Port the OPC-UA server listens on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_communication_para_opcua(const std::string& robot_model, int mode, int port,
                                                         FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CommunicationOpcuaT req = IPC::Request_CommunicationOpcuaT{.mode = mode, .port = port};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CommunicationOpcuaT>(
            robot_model + "/call_communication_para_opcua", req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_communication_para_opcua failed: query one returned nullptr");

    manipulate_return_value("call_communication_para_opcua", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the MQTT communication parameters
   *        (Settings > Devices > Communication > MQTT).
   *
   * Same parameter shape as @c call_communication_para_mbus: @p mode
   * (0 = Off, 1 = On) and @p port (listen port).
   *
   * @param robot_model Name of the robot model.
   * @param mode MQTT server mode. 0 = Off, 1 = On.
   * @param port Port the MQTT server listens on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   *
   * @note The MQTT settings card is currently commented out in the
   *       robot's settings UI; this SDK call and its firmware handler
   *       are still present and functional.
   */
  IPC::Response_FunctionsT call_communication_para_mqtt(const std::string& robot_model, int mode, int port,
                                                        FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CommunicationMqttT req = IPC::Request_CommunicationMqttT{.mode = mode, .port = port};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CommunicationMqttT>(
            robot_model + "/call_communication_para_mqtt", req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_communication_para_mqtt failed: query one returned nullptr");

    manipulate_return_value("call_communication_para_mqtt", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the REST API communication parameters
   *        (Settings > Devices > Communication > Rest API).
   *
   * Same parameter shape as @c call_communication_para_mbus: @p mode
   * (0 = Off, 1 = On) and @p port (listen port).
   *
   * @param robot_model Name of the robot model.
   * @param mode REST API server mode. 0 = Off, 1 = On.
   * @param port Port the REST API server listens on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_communication_para_restapi(const std::string& robot_model, int mode, int port,
                                                           FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CommunicationRestapiT req = IPC::Request_CommunicationRestapiT{.mode = mode, .port = port};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CommunicationRestapiT>(
            robot_model + "/call_communication_para_restapi", req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_communication_para_restapi failed: query one returned nullptr");

    manipulate_return_value("call_communication_para_restapi", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the RTDE communication parameters
   *        (Settings > Devices > Communication > RTDE).
   *
   * Same parameter shape as @c call_communication_para_mbus: @p mode
   * (0 = Off, 1 = On) and @p port (listen port).
   *
   * @param robot_model Name of the robot model.
   * @param mode RTDE server mode. 0 = Off, 1 = On.
   * @param port Port the RTDE server listens on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_communication_para_rtde(const std::string& robot_model, int mode, int port,
                                                        FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CommunicationRtdeT req = IPC::Request_CommunicationRtdeT{.mode = mode, .port = port};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CommunicationRtdeT>(
            robot_model + "/call_communication_para_rtde", req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_communication_para_rtde failed: query one returned nullptr");

    manipulate_return_value("call_communication_para_rtde", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the gRPC communication parameters
   *        (Settings > Devices > Communication > gRPC).
   *
   * Same parameter shape as @c call_communication_para_mbus: @p mode
   * (0 = Off, 1 = On) and @p port (listen port).
   *
   * @param robot_model Name of the robot model.
   * @param mode gRPC server mode. 0 = Off, 1 = On.
   * @param port Port the gRPC server listens on.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_communication_para_grpc(const std::string& robot_model, int mode, int port,
                                                        FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CommunicationGrpcT req = IPC::Request_CommunicationGrpcT{.mode = mode, .port = port};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_CommunicationGrpcT>(
            robot_model + "/call_communication_para_grpc", req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_communication_para_grpc failed: query one returned nullptr");

    manipulate_return_value("call_communication_para_grpc", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Reads the saved Software PLC rule table
   *        (Settings > Devices > Software PLC).
   *
   * Returns the configuration of all 32 Software PLC rule slots. Each
   * slot is a simple ladder-logic-style rule: "IF (Input A) [operator]
   * (Input B) THEN (Output)", evaluated while the slot's mode condition
   * holds — see @c save_softplc_parameter for field semantics. Every
   * response field is a length-32 array indexed by PLC slot number.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) after the response is received.
   *
   * @return IPC::Response_CallConfigSoftPLCT containing the 32 saved rule
   *         slots (one entry per array index).
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_CallConfigSoftPLCT call_config_softplc(const std::string& robot_model,
                                                       FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_CallConfigSoftPLCT req = IPC::Request_CallConfigSoftPLCT{};

    std::unique_ptr<IPC::Response_CallConfigSoftPLCT> result =
        query_one<IPC::Response_CallConfigSoftPLC, IPC::Request_CallConfigSoftPLCT>(
            robot_model + "/call_config_softplc", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("call_config_softplc failed: query one returned nullptr");

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves one Software PLC rule slot
   *        (Settings > Devices > Software PLC).
   *
   * Configures a ladder-logic-style rule: "IF (Input A) [operation]
   * (Input B) THEN (Output)", active while the @p mode condition holds.
   * The meaning of @p input_a_select / @p input_b_select /
   * @p output_select depends on the paired @p input_a_type /
   * @p input_b_type / @p output_type — see
   * apps/web/nexus/src/constants/software-plc-opts.c.ts in the frontend
   * repo for the full per-type option index tables (I/O signal numbers,
   * system status/parameter indices, data field indices, output signal
   * numbers, etc.).
   *
   * @param robot_model Name of the robot model.
   * @param plcnum PLC rule slot to configure, in the range [0, 31].
   * @param mode Condition under which the rule is active. 0 = Power Off,
   *        1 = Always, 2 = Idle, 3 = Playing, 4 = Moving.
   * @param operation Operator combining Input A and Input B. 0 = ==,
   *        1 = !=, 2 = >, 3 = <, 4 = >=, 5 = <=, 6 = logical AND,
   *        7 = logical OR, 8 = + (add), 9 = x (multiply),
   *        10 = bitwise AND, 11 = bitwise OR.
   * @param input_a_type Category of Input A. 0 = I/O Signal,
   *        1 = System Status, 2 = System Parameter, 3 = Data
   *        Communication, 4 = Data Dummy, 5 = Signal Level, 6 = User
   *        Number (literal value).
   * @param input_a_select Index within @p input_a_type's option list
   *        selecting Input A (or, when @p input_a_type is 6, the literal
   *        value itself).
   * @param input_b_type Category of Input B, same encoding as
   *        @p input_a_type.
   * @param input_b_select Index within @p input_b_type's option list
   *        selecting Input B (or the literal value, as with
   *        @p input_a_select).
   * @param output_type Category of the rule's Output. 0 = Signal Output,
   *        1 = Ex System Function, 2 = Value Substitution, 3 = Value
   *        Direct Enter.
   * @param output_select Index within @p output_type's option list
   *        selecting the output target.
   * @param output_value Literal value written to the output when
   *        @p output_type is 3 (Value Direct Enter).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT save_softplc_parameter(const std::string& robot_model, int plcnum, int mode, int operation,
                                                  int input_a_type, int input_a_select, int input_b_type,
                                                  int input_b_select, int output_type, int output_select,
                                                  int output_value, FlowManagerArgsPtr flow_manager_args = nullptr) {

    IPC::Request_SoftPLC_Save_ParemeterT req;

    req.plcnum = plcnum;
    req.mode = mode;
    req.operation = operation;
    req.input_a_type = input_a_type;
    req.input_a_select = input_a_select;
    req.input_b_type = input_b_type;
    req.input_b_select = input_b_select;
    req.output_type = output_type;
    req.output_select = output_select;
    req.output_value = output_value;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_SoftPLC_Save_ParemeterT>(
            robot_model + "/save_softplc_parameter", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("save_softplc_parameter failed: query one returned nullptr");

    manipulate_return_value("save_softplc_parameter", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Reads the saved external axis configuration for all 7 external
   *        axis slots (Settings > Devices > External Axis).
   *
   * Every response field is a length-7 array indexed by external axis
   * (joint) number, mirroring the basic parameters saved via
   * @c call_extaxis_para_basic. It additionally exposes internal
   * kinematics fields (offset_x/y/z, axis_x/y/z, dummyaxis_x/y/z) not
   * shown in the settings UI and not settable through this SDK's
   * external-axis functions.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) after the response is received.
   *
   * @return IPC::Response_CallConfigExtAxisT containing the 7 saved
   *         external axis configurations (one entry per array index).
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_CallConfigExtAxisT call_config_extaxis(const std::string& robot_model,
                                                       FlowManagerArgsPtr flow_manager_args = nullptr) {

    IPC::Request_CallConfigExtAxisT req;

    std::unique_ptr<IPC::Response_CallConfigExtAxisT> result =
        query_one<IPC::Response_CallConfigExtAxis, IPC::Request_CallConfigExtAxisT>(
            robot_model + "/call_config_extaxis", req, 8, 15000, 0);

    if (!result)
      throw std::runtime_error("call_config_extaxis failed: query one returned nullptr");

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the basic configuration for one external axis
   *        (Settings > Devices > External Axis).
   *
   * @param robot_model Name of the robot model.
   * @param joint_no External axis slot to configure, in the range [0, 6].
   * @param type Axis type. 0 = No axis, 1 = Revolute, 2 = Linear.
   * @param device Device driving the axis. 0 = RSauto.
   * @param max_a Maximum acceleration.
   * @param max_v Maximum velocity.
   * @param min_p Minimum position limit.
   * @param max_p Maximum position limit.
   * @param jog_a Jog acceleration rate.
   * @param jog_v Jog velocity rate.
   * @param encoder Encoder resolution.
   * @param reduction Gear reduction ratio.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the save result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_extaxis_para_basic(const std::string& robot_model, int joint_no, int type, int device,
                                                   float max_a, float max_v, float min_p, float max_p, float jog_a,
                                                   float jog_v, float encoder, float reduction,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr) {

    IPC::Request_ExtAxis_Para_BasicT req = IPC::Request_ExtAxis_Para_BasicT{
        .joint_no = joint_no,
        .type = type,
        .device = device,
        .max_a = max_a,
        .max_v = max_v,
        .min_p = min_p,
        .max_p = max_p,
        .jog_a = jog_a,
        .jog_v = jog_v,
        .encoder = encoder,
        .reduction = reduction,
    };

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_ExtAxis_Para_BasicT>(robot_model + "/call_extaxis_para_basic",
                                                                             req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_extaxis_para_basic failed: query one returned nullptr");

    manipulate_return_value("call_extaxis_para_basic", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Clears accumulated calibration samples for an external axis,
   *        starting a new calibration sequence
   *        (Move > Calibration > External Axis > Calibration Start Button).
   *
   * Call this first, then @c call_extaxis_calib_add one or more times to
   * record sample points, then @c call_extaxis_calib_run to compute and
   * apply the result.
   *
   * @param robot_model Name of the robot model.
   * @param joint_no External axis slot to calibrate, in the range [0, 6].
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the command result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   *
   */
  IPC::Response_FunctionsT call_extaxis_calib_clr(const std::string& robot_model, int joint_no,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr) {

    IPC::Request_ExtAxis_Calib_ClearT req = IPC::Request_ExtAxis_Calib_ClearT{.joint_no = joint_no};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_ExtAxis_Calib_ClearT>(robot_model + "/call_extaxis_calib_clr",
                                                                              req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_extaxis_calib_clr failed: query one returned nullptr");

    manipulate_return_value("call_extaxis_calib_clr", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Records the current position as a calibration sample point for
   *        an external axis (Move > Calibration > External Axis > Calibration Add+ Button).
   *
   * Call once per sample point after @c call_extaxis_calib_clr; call
   * again for each additional point, then finish with
   * @c call_extaxis_calib_run.
   *
   * @param robot_model Name of the robot model.
   * @param joint_no External axis slot being calibrated, in the range [0, 6].
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the command result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_extaxis_calib_add(const std::string& robot_model, int joint_no,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr) {

    IPC::Request_ExtAxis_Calib_AddT req = IPC::Request_ExtAxis_Calib_AddT{.joint_no = joint_no};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_ExtAxis_Calib_AddT>(robot_model + "/call_extaxis_calib_add",
                                                                            req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_extaxis_calib_add failed: query one returned nullptr");

    manipulate_return_value("call_extaxis_calib_add", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Computes and applies the external axis calibration from the
   *        recorded sample points (Move > Calibration > External Axis > Calibration Finish Button).
   *
   * Finishes the sequence started by @c call_extaxis_calib_clr and
   * continued with one or more @c call_extaxis_calib_add calls.
   *
   * @param robot_model Name of the robot model.
   * @param joint_no External axis slot being calibrated, in the range [0, 6].
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronously) once the response is received, provided its
   *        return_value is 0; a nonzero return_value raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_FunctionsT containing the calibration result.
   *
   * @throws std::runtime_error If the query fails or no payload is returned.
   */
  IPC::Response_FunctionsT call_extaxis_calib_run(const std::string& robot_model, int joint_no,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr) {

    IPC::Request_ExtAxis_Calib_RunT req = IPC::Request_ExtAxis_Calib_RunT{.joint_no = joint_no};

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_ExtAxis_Calib_RunT>(robot_model + "/call_extaxis_calib_run",
                                                                            req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("call_extaxis_calib_run failed: query one returned nullptr");

    manipulate_return_value("call_extaxis_calib_run", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

 private:
  RBManipulateMoveSDK _move_sdk;

  IPC::Response_FunctionsT _run_move_macro(const std::string& robot_model, int type,
                                           std::vector<std::unique_ptr<IPC::MoveInput_TargetT>> corner_pnts,
                                           std::unique_ptr<IPC::MoveInput_SpeedT> speed, int rotation_mode, int gap_num,
                                           float margin_h_1, float margin_h_2, float margin_w_1, float margin_w_2,
                                           float margin_over, float margin_over_para,
                                           FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Move_MacroT req;
    req.type = type;
    req.corner_pnts = std::move(corner_pnts);
    req.speed = std::move(speed);
    req.rotation_mode = rotation_mode;
    req.gap_num = gap_num;
    req.margin_h_1 = margin_h_1;
    req.margin_h_2 = margin_h_2;
    req.margin_w_1 = margin_w_1;
    req.margin_w_2 = margin_w_2;
    req.margin_over = margin_over;
    req.margin_over_para = margin_over_para;
    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_MacroT>(
        robot_model + "/call_move_macro", req, 1024, 60000, 0);

    if (!result)
      throw std::runtime_error("call_move_macro failed: query one returned nullptr");

    manipulate_return_value("call_move_macro", *result, flow_manager_args);

    return _move_sdk._apply_time_checking<IPC::Response_FunctionsT>(
        robot_model, "Call Motion Macro", std::move(*result), "call_move_macro", flow_manager_args);
  }

  IPC::Response_FunctionsT _run_pattern_on(const std::string& robot_model, int id, int type,
                                           std::vector<std::unique_ptr<IPC::MoveInput_TargetT>> corner_pnts,
                                           int count_x, int count_y, int count_z,
                                           std::unique_ptr<IPC::MoveInput_TargetT> anchor_pnt, int incremental,
                                           FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Pattern_OnT req;
    req.id = id;
    req.type = type;
    req.corner_pnts = std::move(corner_pnts);
    req.count_x = count_x;
    req.count_y = count_y;
    req.count_z = count_z;
    req.anchor_pnt = std::move(anchor_pnt);
    req.incremental = incremental;

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Pattern_OnT>(
        robot_model + "/call_pattern_on", req, 1024, 15000, 0);

    if (!result)
      throw std::runtime_error("call_pattern_on failed: query one returned nullptr");

    manipulate_return_value("call_pattern_on", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }
};
