#pragma once

// manipulate_vision.py -> manipulate_vision.hpp 포팅.
//
// lib/Vision/{Mech-Mind,PhotoNeo,Pikit3D} 에 실제 네이티브 C++ 클라이언트(mechmind::MechMindClient,
// photoneo::PhotoneoClient, pickit3d::PickitClient)가 있고, rb_sdk 정적 라이브러리에 이미 링크되어
// 있다(CMakeLists.txt RB_VISION_SOURCES). 세 클라이언트 모두 프로토콜/벤더 실패 시 이미 C++ 예외를
// 던지므로(mechmind::VisionError / photoneo::BinPickingError / pickit3d::CommandError, 전부
// std::runtime_error 파생) 이 파일에서 수동으로 성공 여부를 재판정할 필요가 없다.
//
// module_name(PFM task_id) 별 다중 연결 registry(mechmind_clients_/photoneo_clients_/pickit_clients_)는
// RBBaseSDK(base.hpp)에서 상속받는다 - manipulate 뿐 아니라 차후 amr 등 다른 RBBaseSDK 파생 클래스도
// 같은 registry 를 재사용할 수 있게 하기 위함.
//
// rb_utils/program.py 대응 공용 헬퍼(get_task_id/require/resolve_option_of/resolve_interface_flow/
// raw_data_field/AlarmFn 등)는 순수 C++ core 계약(flow_manager_args.hpp/common/value_validation.hpp)으로
// 옮겼다 — rb_vision_util 네임스페이스는 using-선언으로 끌어와 쓴다.
//
// 아직 결정/검증되지 않은 부분:
//  - validate_server_ip 는 Python 원본처럼 ipaddress.ip_address() 형식 검증까지 하지 않는다(TODO).
//  - resolve_interface_flow 는 Python 원본이 임의 객체(result)를 받아 getattr(result, "error", ...)로
//    메시지를 뽑는 반면, 여기서는 호출부에서 미리 만든 std::string 메시지를 받는다(단순화).
//  - waypoint 변수 조회는 FlowManagerContext::get_waypoint_variable 로 처리한다.
//  - 아직 binding/binding.cpp / rb_manipulate_sdk.hpp 에 이 클래스를 등록하지 않았다. 실제로 pybind
//    모듈에 노출하려면 manipulate_move.hpp 의 RBManipulateMoveSDK 등록부를 참고해 py::class_<...> 를
//    추가해야 한다.

#include <array>
#include <functional>
#include <iostream>
#include <optional>
#include <string>
#include <type_traits>
#include <variant>
#include <vector>

#include "base.hpp"  // brings FlowManagerArgsPtr / AlarmFn / resolve_interface_flow + GIL release hook
#include "common_struct_generated.h"
#include "interface_payload_schema.hpp"
#include "pickit3d/constants.hpp"
#include "state_core_generated.h"
#include "common/value_validation.hpp"  // rb_glue::require / resolve_option_of / timeout_ms_of (pure)

#include "manipulate_move.hpp"

// alarm 콜백은 (title, content) 두 문자열만 받는 얇은 계약이라 py::object 로 감쌀 필요 없이
// std::function 으로 통일한다. Python 쪽에서 함수를 넘길 때는 pybind11/functional.h 의 자동
// 변환이 처리해준다 - vision() 자신이 나중에 pybind 에 등록되면 그대로 동작한다.
// flow_manager_args.hpp::AlarmFn 과 동일 타입 — 이 파일 전역에서 bare `AlarmFn` 으로 쓰는
// 곳이 많아(rb_vision_util 네임스페이스 밖 포함) 별칭을 그대로 두되 정의는 공용 쪽에 맡긴다.
using AlarmFn = ::AlarmFn;

// ---------------------------------------------------------------------------
// RBManipulateVisionSDK 가 쓰는 공통 유틸 모음: rb_utils/program.py 대응 최소 인라인 포팅,
// PFM 공통 유틸(원래 클래스 안에 있었지만 vision 벤더와 무관한 범용 로직이라 옮김), 그리고
// vision 벤더 Pose 타입(mechmind::Pose/photoneo::Pose/pickit3d::Pose)에 묶여있는 헬퍼까지
// 한 네임스페이스에 모아둔다. (TODO: 공용 헤더로 분리)
// ---------------------------------------------------------------------------
namespace rb_vision_util {

// rb_utils/program.py 대응 공용 헬퍼는 순수 C++ core 계약으로 합쳤다. using-선언으로 끌어와서
// 아래 rb_vision_util::xxx(...) 형태의 기존 호출부를 그대로 둔다.
// require/resolve_option_of/timeout_ms_of: struct 필드(interface_payload_schema.hpp) 기반 "필수인데
// 없음" 검증 — 자동 dict<->struct 캐스터는 타입 변환만 하고 이 검증은 안 해준다.
using ::AlarmFn;
using ::get_task_id;
using ::resolve_interface_flow;
using rb_glue::require;
using rb_glue::resolve_option_of;
using rb_glue::timeout_ms_of;

// vision 쪽 connect() 함수들은 timeout 을 초 단위 그대로 네이티브 config(MechMindConfig/
// PhotoneoConfig/PickitConfig::timeout, 전부 double 초 단위)에 넘긴다 — timeout_ms_of 를 그대로
// 쓰면 안 된다(1000배 부풀려짐). Python 원본(manipulate_vision.py)도 Photoneo/Pickit 은
// get_timeout_sec() 결과(ms)를 `timeout_ms / 1000.0` 으로 다시 나눠서 쓴다 — 그 패턴을 그대로 따른다.
inline double timeout_sec_of(const std::optional<double>& value, double default_sec) {
  return timeout_ms_of(value, default_sec) / 1000.0;
}

// vision 인터페이스 함수들은 성공 시 (변수명 -> 값) 쌍을 FlowVariables 로 채우고,
// 성공 tail 에서 flow_manager_args->context().update_local_variables(...) 로 반영한다
// (flow_manager_args.hpp, program 쪽과 공유).

inline int get_calib_method(const std::optional<int>& value, const std::string& error_prefix) {
  return require(value, "calib_method", error_prefix);
}

inline int get_calib_camera_mount(const std::optional<int>& value, const std::string& error_prefix) {
  return require(value, "calib_camera_mount", error_prefix);
}

// 네이티브 API 는 조인트 값을 std::array<double,6> 으로 받는다(mechmind::trigger 의 joint_positions,
// photoneo::initialize_vision_system 의 start/end_joints). 6개가 아니면 여기서 바로 에러를 낸다
// (컴파일 타임 고정 크기 배열이라 원본 python 코드처럼 임의 길이를 그냥 넘길 수 없다).
inline std::array<double, 6> to_array6(const std::vector<float>& values, const std::string& error_prefix) {
  if (values.size() != 6) {
    throw std::runtime_error(error_prefix + ": expected 6 values, got " + std::to_string(values.size()));
  }
  std::array<double, 6> out{};
  for (size_t i = 0; i < 6; ++i)
    out[i] = values[i];
  return out;
}

// returnValue != 0 이면 실패로 간주해 alarm_fn 으로 알람을 보내고 예외를 던진다.
inline void raise_and_alarm_on_move_failure(const IPC::Response_FunctionsT& payload, const std::string& call_name,
                                            const std::string& error_prefix, AlarmFn alarm_fn) {
  int return_value = payload.return_value;
  if (return_value == 0)
    return;

  std::string message = error_prefix + ": " + call_name + " failed (returnValue=" + std::to_string(return_value) + ")";
  if (alarm_fn) {
    alarm_fn("Vision(Photoneo) Move Failed", message);
  }
  throw std::runtime_error(message);
}

// 세 벤더의 네이티브 Pose 구조체(mechmind::Pose/photoneo::Pose/pickit3d::Pose)는 필드가
// 동일(x,y,z,rx,ry,rz double)하지만 타입이 달라 반환 타입에 템플릿을 건다.
template <typename PoseT>
inline PoseT build_pose_from_carte_x_ref(const IPC::State_CoreT& stat_core, const std::string& error_prefix) {
  const auto& carte_x_ref = stat_core.carte_x_ref;
  if (carte_x_ref.size() < 6) {
    throw std::runtime_error(error_prefix +
                             ": stat_core.carteXRef must contain at least 6 values (x,y,z,rx,ry,rz), got " +
                             std::to_string(carte_x_ref.size()));
  }
  return PoseT{carte_x_ref[0], carte_x_ref[1], carte_x_ref[2], carte_x_ref[3], carte_x_ref[4], carte_x_ref[5]};
}

template <typename PoseT>
inline PoseT build_tcp_offset_from_tool_tcp(const IPC::State_CoreT& stat_core, const std::string& error_prefix) {
  return PoseT{stat_core.tool_tcp_x,  stat_core.tool_tcp_y,  stat_core.tool_tcp_z,
               stat_core.tool_tcp_rx, stat_core.tool_tcp_ry, stat_core.tool_tcp_rz};
}

inline std::vector<float> build_joint_positions_without_index_2(const IPC::State_CoreT& stat_core,
                                                                const std::string& error_prefix) {
  const auto& joint_q_ref = stat_core.joint_q_ref;
  if (joint_q_ref.size() < 2) {
    throw std::runtime_error(error_prefix + ": stat_core.jointQRef must contain at least 2 values, got " +
                             std::to_string(joint_q_ref.size()));
  }
  // 인덱스 2(세 번째 요소)를 제외하고 float 배열로 전달한다.
  std::vector<float> result;
  for (size_t i = 0; i < joint_q_ref.size(); ++i) {
    if (i != 2)
      result.push_back(joint_q_ref[i]);
  }
  return result;
}

inline std::vector<float> to_six_axis_joints(const std::vector<double>& values) {
  std::vector<float> points;
  points.reserve(values.size());
  for (double v : values)
    points.push_back(static_cast<float>(v));
  if (points.size() >= 7) {
    // 7축 이상으로 들어오면 인덱스 2(세 번째 요소)를 제외하고 6개로 맞춘다.
    std::vector<float> filtered;
    for (size_t i = 0; i < points.size(); ++i) {
      if (i != 2)
        filtered.push_back(points[i]);
    }
    points.assign(filtered.begin(), filtered.begin() + std::min<size_t>(6, filtered.size()));
  }
  return points;
}

// Photoneo trajectory 는 항상 6축이라, 로봇의 실제 축 수에 맞게 변환한다.
// - 방어적으로 6축으로 축소 (7축 이상 들어오면 index 2 제외, to_six_axis_joints 와 동일)
// - 로봇이 7축이면 index 2(세 번째)에 0을 채워 넣어 다시 7축으로 확장
inline std::vector<float> to_robot_axis_joints(const std::vector<double>& values, int robot_axis_count) {
  std::vector<float> points = to_six_axis_joints(values);
  if (robot_axis_count >= 7) {
    std::vector<float> expanded;
    size_t head = std::min<size_t>(2, points.size());
    expanded.insert(expanded.end(), points.begin(), points.begin() + head);
    expanded.push_back(0.0f);
    expanded.insert(expanded.end(), points.begin() + head, points.end());
    return expanded;
  }
  return points;
}

// -----------------------------------------------------------------------
// MechMind 전용
// -----------------------------------------------------------------------
namespace mechmind_util {

inline std::vector<std::vector<double>> poses_to_values(const std::vector<mechmind::Pose>& poses) {
  std::vector<std::vector<double>> out;
  out.reserve(poses.size());
  for (const auto& p : poses)
    out.push_back({p.x, p.y, p.z, p.rx, p.ry, p.rz});
  return out;
}

}  // namespace mechmind_util

// -----------------------------------------------------------------------
// Photoneo 전용
// -----------------------------------------------------------------------
namespace photoneo_util {

inline FlowVariableValue pose_to_value(const std::optional<photoneo::AnyPose>& pose) {
  if (!pose)
    return FlowVariableValue{};
  return std::visit(
      [](auto&& p) -> FlowVariableValue {
        using T = std::decay_t<decltype(p)>;
        if constexpr (std::is_same_v<T, photoneo::QuaternionPose>) {
          return FlowVariableValue{std::vector<double>{p.x, p.y, p.z, p.qx, p.qy, p.qz, p.qw}};
        } else {
          return FlowVariableValue{std::vector<double>{p.x, p.y, p.z, p.rx, p.ry, p.rz}};
        }
      },
      *pose);
}

inline std::vector<float> resolve_joint_target(const muscat::PhotoneoJointTargetT& target,
                                               const std::string& error_prefix) {
  std::vector<float> tar_values =
      to_six_axis_joints(rb_vision_util::require(target.tar_values, "tar_values", error_prefix));

  int input_method_i = target.input_method.value_or(0);
  if (input_method_i != 1)
    return tar_values;

  // PyFM 이 ref_point 변수를 이미 값으로 치환해서 넘겨준다 (여기서 조회 불필요). 치환이 안 돼
  // 문자열이 그대로 들어오면 type_caster<std::vector<double>> 단계에서 이미 에러가 난다
  // (원본 is_joint_value_sequence str 체크와 동등).
  return to_six_axis_joints(rb_vision_util::require(target.ref_point, "ref_point", error_prefix));
}

}  // namespace photoneo_util

// -----------------------------------------------------------------------
// Pickit3D 전용
// -----------------------------------------------------------------------
namespace pickit_util {

// 네이티브 pickit3d::Pose 는 Euler(x,y,z,rx,ry,rz) 필드만 있고 AngleAxis/Quaternion 변형이 없다
// (PickitClient 공개 API 가 노출하지 않음 - pickit_client.hpp 주석 참고). Rainbow Robotics 는 항상
// EULER_ZYX 만 쓰므로 원본 python 코드의 AngleAxisPose/QuaternionPose 분기는 여기서 자연히 없어진다.
inline std::vector<double> pose_to_values(const pickit3d::Pose& pose) {
  return {pose.x, pose.y, pose.z, pose.rx, pose.ry, pose.rz};
}

// Pickit 의 look_for_objects / look_for_objects_with_retries / next_object / process_image 는
// 모두 (pick_point_name, remaining_count_name, model_id_or_type_name) 세 변수 셋을 채우는
// 동일한 모양이라 공통 헬퍼로 묶었다.
inline FlowVariables detection_variables(const pickit3d::ObjectDetection& detection, const std::string& pick_point_name,
                                         const std::string& remaining_count_name,
                                         const std::string& model_id_or_type_name) {
  FlowVariables variables;
  variables.emplace(pick_point_name, FlowVariableValue{pose_to_values(detection.pose)});
  variables.emplace(remaining_count_name, FlowVariableValue{static_cast<int64_t>(detection.remaining_count)});
  variables.emplace(model_id_or_type_name, FlowVariableValue{static_cast<int64_t>(detection.model_id_or_type)});
  return variables;
}

}  // namespace pickit_util

}  // namespace rb_vision_util

class RBManipulateVisionSDK : public RBBaseSDK {
 public:
  RBManipulateVisionSDK() {}

  // before_close() 는 RBBaseSDK::close() 가 자기 자신의 소멸자에서 불릴 때만 가상 디스패치로
  // override 가 걸린다(base.hpp::before_close() 주석 참고) — 그래서 close() 를 직접 부르는
  // 소멸자를 여기 따로 선언해야 mechmind/photoneo/pickit 클라이언트가 실제로 정리된다.
  ~RBManipulateVisionSDK() override { close(); }

  static std::string type_name() { return "RBManipulateVisionSDK"; }

  // Python manipulate_vision.py::before_close() 대응. base.hpp::close() 는 더 이상 vision
  // registry 를 하드코딩해서 정리하지 않는다 — 이 registry 를 실제로 쓰는 서브클래스가 정리
  // 책임을 진다.
  void before_close() override {
    mechmind_clients_.disconnect_all();
    photoneo_clients_.disconnect_all();
    pickit_clients_.disconnect_all();
  }

 private:
  // robot_model 의 state_core 를 조회한다. flow_manager_args 없이도(단독 SDK 사용) 호출 가능.
  // Python 원본은 async def 지만, zenoh 왕복은 base.hpp 의 receive_one() 이 GIL 해제 후 블로킹하므로
  // C++ 쪽은 그냥 동기 메서드로 둔다.
  IPC::State_CoreT _get_state_core(const std::string& robot_model) {
    return receive_one<IPC::State_Core>(robot_model + "/state_core");
  }

  // -----------------------------------------------------------------------
  // 벤더 공통 run-call helper. 세 벤더 클라이언트 모두 실패 시 이미 예외(ErrorT)를 던지므로
  // (mechmind::MechMindError / photoneo::PhotoneoError / pickit3d::PickitError, 전부
  // std::runtime_error 파생), 여기서는 연결 여부 사전 체크 + 예외 처리 + ctx 변수 반영만 한다.
  // 벤더 고유 예외가 아닌 다른 예외는 그대로 전파한다(진짜 버그를 SKIP/STOP/ASK 로 삼키지 않기 위함).
  // -----------------------------------------------------------------------
  template <typename ErrorT, typename ResultT, typename ClientT>
  ResultT _run_vision_call(ClientT* client, const std::string& resolve_option, FlowManagerArgsPtr flow_manager_args,
                           AlarmFn alarm_fn, const std::string& error_prefix, const char* vendor_label,
                           const std::function<std::pair<ResultT, FlowVariables>()>& call_fn) {
    if (client == nullptr || !client->is_connected()) {
      rb_vision_util::resolve_interface_flow(error_prefix + ": " + vendor_label + " client is not connected",
                                             resolve_option, flow_manager_args, alarm_fn, error_prefix);
      return ResultT{};
    }

    ResultT result{};
    FlowVariables variables;
    try {
      auto [res, vars] = call_fn();
      result = res;
      variables = vars;
    } catch (const ErrorT& e) {
      std::cerr << error_prefix << ": " << vendor_label << " client operation failed with exception: " << e.what()
                << std::endl;
      rb_vision_util::resolve_interface_flow(e.what(), resolve_option, flow_manager_args, alarm_fn, error_prefix);
      return result;
    }

    if (flow_manager_args)
      flow_manager_args->context().update_local_variables(variables);
    if (flow_manager_args)
      flow_manager_args->done();
    return result;
  }

 public:
  // -----------------------------------------------------------------------
  // MechMind
  // -----------------------------------------------------------------------

  /**
   * @brief Connects to a MechMind vision server and registers the client under @p module_name.
   *
   * Reads connection parameters from @p data (server_ip, server_port, an
   * optional timeout_sec defaulting to 10 seconds, an optional project_id
   * defaulting to 1) and opens a MechMind TCP connection, storing the
   * resulting client in the per-module connection registry so later calls
   * (trigger, get_poses, ...) can look it up by the same @p module_name.
   *
   * @param module_name Registry key for the connection, normally the PyFM
   *        task id resolved from @p flow_manager_args.
   * @param data Connect payload. Must contain server_ip and server_port;
   *        timeout_sec and project_id are optional.
   * @param flow_manager_args Optional PyFM step context. When provided,
   *        `flow_manager_args.done()` is called unconditionally once the
   *        connection attempt finishes, even if it failed.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p data's resolve_option is "ASK".
   *
   * @return Pointer to the connected @c mechmind::MechMindClient, owned by
   *         the SDK's connection registry (do not delete it). May be
   *         null, or non-null but not connected, if the attempt failed.
   *
   * @throws std::runtime_error If server_ip or server_port is missing, or
   *         if resolve_option is invalid; and, if resolve_option is
   *         "STOP", if the native connect call throws.
   *
   * @note If the native connect call fails without throwing (client
   *       non-null but not connected), that failure is only logged to
   *       stdout — it does not go through resolve_option's SKIP/STOP/ASK
   *       handling, unlike an actual vendor exception.
   *
   * @note Calling this again with the same @p module_name transparently
   *       disconnects the previous client for that module before opening
   *       the new connection.
   */
  mechmind::MechMindClient* execute_mechmind_connect(const std::string& module_name,
                                                     muscat::InterfaceMechMindPayloadT data,
                                                     FlowManagerArgsPtr flow_manager_args, AlarmFn alarm_fn) {
    const std::string error_prefix = "MechMind Interface Connect failed";

    std::string server_ip = rb_vision_util::require(data.server_ip, "server_ip", error_prefix);
    int server_port = rb_vision_util::require(data.server_port, "server_port", error_prefix);
    double timeout_sec = rb_vision_util::timeout_sec_of(data.timeout_sec, 10.0);
    int project_id = data.project_id.value_or(1);
    std::string resolve_option = rb_vision_util::resolve_option_of(data.resolve_option, error_prefix);

    mechmind::MechMindConfig config;
    config.host = server_ip;
    config.port = server_port;
    config.project_id = project_id;
    config.timeout = timeout_sec;

    mechmind::MechMindClient* client = nullptr;
    try {
      client = &mechmind_clients_.connect(module_name, config);
    } catch (const mechmind::MechMindError& e) {
      rb_vision_util::resolve_interface_flow(e.what(), resolve_option, flow_manager_args, alarm_fn, error_prefix);
    }

    if (client == nullptr || !client->is_connected()) {
      std::cout << error_prefix << ": connection attempt failed without exception, treating as failed connection"
                << std::endl;
    }
    if (flow_manager_args)
      flow_manager_args->done();

    return client;
  }

  /**
   * @brief Triggers a MechMind capture + recognition and reads the detected poses in one round-trip.
   *
   * Standalone equivalent of function_code=0 ("Trigger And Get Poses") of
   * the MechMind READ interface. When @p position is "EYE_TO_HAND" the
   * camera is fixed off the robot, so no robot-pose correction is sent.
   * Otherwise (@p position is "EYE_IN_HEAD") the camera is mounted on the
   * robot, so the current TCP pose, joint positions and tool TCP offset
   * (all derived from @p state_core) are sent so the vendor can correct
   * for the arm's current pose.
   *
   * @param client Connected MechMind client, e.g. from @c execute_mechmind_connect.
   * @param project_id MechMind project id to trigger against.
   * @param position "EYE_TO_HAND" or "EYE_IN_HEAD" — selects whether
   *        robot-pose correction is sent, see above.
   * @param return_variable_name PyFM variable name that will receive the
   *        detected poses as a list of [x, y, z, rx, ry, rz] entries.
   * @param state_core Robot state snapshot used for pose correction.
   *        Required when @p position is not "EYE_TO_HAND".
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a MechMind
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        @p return_variable_name is written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return mechmind::VisionResponse with the detected poses. A
   *         default-constructed (empty) response if @p client is null,
   *         not connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error If @p position is not "EYE_TO_HAND" and
   *         @p state_core is not provided; and, under "STOP", if the
   *         native call throws.
   */
  mechmind::VisionResponse execute_mechmind_trigger_and_get_poses(
      mechmind::MechMindClient* client, int project_id, const std::string& position,
      const std::string& return_variable_name, std::optional<IPC::State_CoreT> state_core = std::nullopt,
      const std::string& resolve_option = "SKIP", FlowManagerArgsPtr flow_manager_args = nullptr,
      AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "MechMind Interface Trigger And Get Poses failed";

    auto call = [&]() -> std::pair<mechmind::VisionResponse, FlowVariables> {
      mechmind::VisionResponse result;
      if (position == "EYE_TO_HAND") {
        result = client->trigger_and_get_poses(std::nullopt, std::nullopt, /*recipe_id=*/0, project_id, std::nullopt);
      } else {
        if (!state_core) {
          throw std::runtime_error(error_prefix + ": state_core is required when position is not EYE_TO_HAND");
        }
        mechmind::Pose robot_pose =
            rb_vision_util::build_pose_from_carte_x_ref<mechmind::Pose>(*state_core, error_prefix);
        auto joint_positions = rb_vision_util::to_array6(
            rb_vision_util::build_joint_positions_without_index_2(*state_core, error_prefix), error_prefix);
        mechmind::Pose tcp_offset =
            rb_vision_util::build_tcp_offset_from_tool_tcp<mechmind::Pose>(*state_core, error_prefix);
        result = client->trigger_and_get_poses(robot_pose, joint_positions, /*recipe_id=*/0, project_id, tcp_offset);
      }
      FlowVariables variables;
      variables.emplace(return_variable_name,
                        FlowVariableValue{rb_vision_util::mechmind_util::poses_to_values(result.poses)});
      return {result, variables};
    };

    return _run_vision_call<mechmind::MechMindError, mechmind::VisionResponse>(
        client, resolve_option, flow_manager_args, alarm_fn, error_prefix, "MechMind", call);
  }

  /**
   * @brief Reads the poses detected by the most recent MechMind trigger.
   *
   * Standalone equivalent of function_code=2 ("Get Poses") of the
   * MechMind READ interface. Unlike @c execute_mechmind_trigger_and_get_poses,
   * this does not trigger a new capture — it only re-reads the result of
   * whichever trigger (via @c execute_mechmind_trigger or
   * @c execute_mechmind_trigger_and_get_poses) ran most recently for
   * @p project_id.
   *
   * @param client Connected MechMind client.
   * @param project_id MechMind project id to read poses for.
   * @param return_variable_name PyFM variable name that will receive the
   *        detected poses as a list of [x, y, z, rx, ry, rz] entries.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a MechMind
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        @p return_variable_name is written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return mechmind::VisionResponse with the detected poses. A
   *         default-constructed (empty) response if @p client is null,
   *         not connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  mechmind::VisionResponse execute_mechmind_get_poses(mechmind::MechMindClient* client, int project_id,
                                                      const std::string& return_variable_name,
                                                      const std::string& resolve_option = "SKIP",
                                                      FlowManagerArgsPtr flow_manager_args = nullptr,
                                                      AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "MechMind Interface Get Poses failed";

    auto call = [&]() -> std::pair<mechmind::VisionResponse, FlowVariables> {
      mechmind::VisionResponse result = client->get_poses(project_id);
      FlowVariables variables;
      variables.emplace(return_variable_name,
                        FlowVariableValue{rb_vision_util::mechmind_util::poses_to_values(result.poses)});
      return {result, variables};
    };

    return _run_vision_call<mechmind::MechMindError, mechmind::VisionResponse>(
        client, resolve_option, flow_manager_args, alarm_fn, error_prefix, "MechMind", call);
  }

 private:
  void _execute_mechmind_read(mechmind::MechMindClient* client, muscat::InterfaceMechMindPayloadT data,
                              const IPC::State_CoreT& stat_core, FlowManagerArgsPtr flow_manager_args,
                              AlarmFn alarm_fn) {
    const std::string error_prefix = "MechMind Interface Read failed";
    int function_code = rb_vision_util::require(data.function_code, "function_code", error_prefix);

    if (function_code == 0 || function_code == 2) {
      // Python 원본: flow_manager_args.args["data"]["return_variable_name"] 에서 꺼낸다
      // (data 파라미터 자체가 아니라 FM 이 넘겨준 raw args 쪽에서 읽는 게 원본 동작이다 — PyFM 의
      // 변수 치환이 이 필드까지 값 내용만 보고 덮어쓸 수 있어서다, flow_manager_args.hpp::raw_data_field
      // 주석 참고).
      if (!flow_manager_args) {
        throw std::runtime_error(error_prefix + ": flow_manager_args is required to resolve return_variable_name");
      }
      std::optional<std::string> return_variable_name_opt =
          (flow_manager_args ? flow_manager_args->raw_data_field("return_variable_name") : std::nullopt);
      if (!return_variable_name_opt) {
        throw std::runtime_error(error_prefix +
                                 ": return_variable_name is required. when using MechMind Interface Read");
      }
      std::string return_variable_name = *return_variable_name_opt;

      int project_id = data.project_id.value_or(1);
      std::string resolve_option = rb_vision_util::resolve_option_of(data.resolve_option, error_prefix);

      if (function_code == 0) {
        execute_mechmind_trigger_and_get_poses(
            client, project_id, rb_vision_util::require(data.position, "position", error_prefix), return_variable_name,
            stat_core, resolve_option, flow_manager_args, alarm_fn);
      } else {
        execute_mechmind_get_poses(client, project_id, return_variable_name, resolve_option, flow_manager_args,
                                   alarm_fn);
      }
      return;
    }
    throw std::runtime_error(error_prefix + ": invalid function_code");
  }

 public:
  /**
   * @brief Triggers a MechMind capture + recognition without reading the resulting poses.
   *
   * Standalone equivalent of function_code=1 ("Trigger") of the MechMind
   * WRITE interface. Same @p position/robot-pose-correction rule as
   * @c execute_mechmind_trigger_and_get_poses: no robot pose is sent for
   * "EYE_TO_HAND", otherwise it is derived from @p stat_core. Call
   * @c execute_mechmind_get_poses afterwards to read the detection
   * result.
   *
   * @param client Connected MechMind client.
   * @param project_id MechMind project id to trigger against.
   * @param expected_count Expected number of objects to detect; passed
   *        through to the native trigger call.
   * @param position "EYE_TO_HAND" or "EYE_IN_HEAD" — selects whether
   *        robot-pose correction is sent.
   * @param stat_core Robot state snapshot used for pose correction.
   *        Required when @p position is not "EYE_TO_HAND".
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a MechMind
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK" (the native call
   *         itself always returns true when it doesn't throw).
   *
   * @throws std::runtime_error If @p position is not "EYE_TO_HAND" and
   *         @p stat_core is not provided; and, under "STOP", if the
   *         native call throws.
   */
  bool execute_mechmind_trigger(mechmind::MechMindClient* client, int project_id, int expected_count,
                                const std::string& position, std::optional<IPC::State_CoreT> stat_core = std::nullopt,
                                const std::string& resolve_option = "SKIP",
                                FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "MechMind Interface Trigger failed";

    auto call = [&]() -> std::pair<bool, FlowVariables> {
      bool success;
      if (position == "EYE_TO_HAND") {
        success =
            client->trigger(expected_count, std::nullopt, std::nullopt, /*pose_type=*/-1, project_id, std::nullopt);
      } else {
        if (!stat_core) {
          throw std::runtime_error(error_prefix + ": stat_core is required when position is not EYE_TO_HAND");
        }
        mechmind::Pose robot_pose =
            rb_vision_util::build_pose_from_carte_x_ref<mechmind::Pose>(*stat_core, error_prefix);
        auto joint_positions = rb_vision_util::to_array6(
            rb_vision_util::build_joint_positions_without_index_2(*stat_core, error_prefix), error_prefix);
        mechmind::Pose tcp_offset =
            rb_vision_util::build_tcp_offset_from_tool_tcp<mechmind::Pose>(*stat_core, error_prefix);
        success =
            client->trigger(expected_count, robot_pose, joint_positions, /*pose_type=*/-1, project_id, tcp_offset);
      }
      return {success, {}};
    };

    return _run_vision_call<mechmind::MechMindError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                           error_prefix, "MechMind", call);
  }

  /**
   * @brief Switches the active MechMind recipe for a project.
   *
   * Standalone equivalent of function_code=3 ("Set Recipe") of the
   * MechMind WRITE interface.
   *
   * @param client Connected MechMind client.
   * @param project_id MechMind project id to switch the recipe on.
   * @param recipe_id Recipe id to activate.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a MechMind
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_mechmind_set_recipe(mechmind::MechMindClient* client, int project_id, int recipe_id,
                                   const std::string& resolve_option = "SKIP",
                                   FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "MechMind Interface Set Recipe failed";

    auto call = [&]() -> std::pair<bool, FlowVariables> {
      bool success = client->set_recipe(recipe_id, project_id);
      return {success, {}};
    };

    return _run_vision_call<mechmind::MechMindError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                           error_prefix, "MechMind", call);
  }

 private:
  void _execute_mechmind_write(mechmind::MechMindClient* client, muscat::InterfaceMechMindPayloadT data,
                               const IPC::State_CoreT& stat_core, FlowManagerArgsPtr flow_manager_args,
                               AlarmFn alarm_fn) {
    const std::string error_prefix = "MechMind Interface Write failed";
    int function_code = rb_vision_util::require(data.function_code, "function_code", error_prefix);
    std::string resolve_option = rb_vision_util::resolve_option_of(data.resolve_option, error_prefix);

    if (function_code == 1) {
      execute_mechmind_trigger(client, data.project_id.value_or(1), data.expected_count.value_or(0),
                               rb_vision_util::require(data.position, "position", error_prefix), stat_core,
                               resolve_option, flow_manager_args, alarm_fn);
    } else if (function_code == 3) {
      execute_mechmind_set_recipe(client, data.project_id.value_or(1),
                                  rb_vision_util::require(data.recipe_id, "recipe_id", error_prefix), resolve_option,
                                  flow_manager_args, alarm_fn);
    } else {
      throw std::runtime_error(error_prefix + ": invalid function_code");
    }
  }

 public:
  // -----------------------------------------------------------------------
  // Photoneo
  // -----------------------------------------------------------------------

  /**
   * @brief Connects to a Photoneo Bin Picking Studio (BPS) server and registers the client under @p module_name.
   *
   * Reads connection parameters from @p data (server_ip, server_port, an
   * optional timeout_sec defaulting to 10 seconds) and opens a Photoneo
   * TCP connection, storing the resulting client in the per-module
   * connection registry so later calls (initialize, scan, ...) can look
   * it up by the same @p module_name.
   *
   * @param module_name Registry key for the connection, normally the PyFM
   *        task id resolved from @p flow_manager_args.
   * @param data Connect payload. Must contain server_ip and server_port;
   *        timeout_sec is optional.
   * @param flow_manager_args Optional PyFM step context. When provided,
   *        `flow_manager_args.done()` is called unconditionally once the
   *        connection attempt finishes, even if it failed.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p data's resolve_option is "ASK".
   *
   * @return Pointer to the connected @c photoneo::PhotoneoClient, owned by
   *         the SDK's connection registry (do not delete it). May be
   *         null, or non-null but not connected, if the attempt failed.
   *
   * @throws std::runtime_error If server_ip or server_port is missing, or
   *         if resolve_option is invalid; and, if resolve_option is
   *         "STOP", if the native connect call throws.
   *
   * @note If the native connect call fails without throwing (client
   *       non-null but not connected), that failure is only logged to
   *       stdout — it does not go through resolve_option's SKIP/STOP/ASK
   *       handling, unlike an actual vendor exception.
   *
   * @note Calling this again with the same @p module_name transparently
   *       disconnects the previous client for that module before opening
   *       the new connection.
   */
  photoneo::PhotoneoClient* execute_photoneo_connect(const std::string& module_name,
                                                     muscat::InterfacePhotoneoPayloadT data,
                                                     FlowManagerArgsPtr flow_manager_args, AlarmFn alarm_fn) {
    const std::string error_prefix = "Vision(Photoneo) Interface Connect failed";

    std::string server_ip = rb_vision_util::require(data.server_ip, "server_ip", error_prefix);
    int server_port = rb_vision_util::require(data.server_port, "server_port", error_prefix);
    double timeout_sec = rb_vision_util::timeout_sec_of(data.timeout_sec, 10.0);
    std::string resolve_option = rb_vision_util::resolve_option_of(data.resolve_option, error_prefix);

    photoneo::PhotoneoConfig config;
    config.host = server_ip;
    config.request_port = server_port;
    config.timeout = timeout_sec;

    photoneo::PhotoneoClient* client = nullptr;
    try {
      client = &photoneo_clients_.connect(module_name, config);
    } catch (const photoneo::PhotoneoError& e) {
      rb_vision_util::resolve_interface_flow(e.what(), resolve_option, flow_manager_args, alarm_fn, error_prefix);
    }

    if (client == nullptr || !client->is_connected()) {
      std::cout << error_prefix << ": connection attempt failed without exception, treating as failed connection"
                << std::endl;
    }
    if (flow_manager_args)
      flow_manager_args->done();

    return client;
  }

  /**
   * @brief Initializes a Photoneo vision system with its scan-approach start/end joint targets.
   *
   * Standalone equivalent of function_code=0 ("Initialize") of the
   * Photoneo WRITE interface.
   *
   * @param client Connected Photoneo client.
   * @param vision_system_id Photoneo vision system id to initialize.
   *        0 uses the client's configured default.
   * @param start_joint Joint target dict with a required "tar_values"
   *        entry (6 joint angles in degrees; 7-axis input is reduced to 6
   *        by dropping the third element). If "input_method" is 1, the
   *        target actually used is instead the required "ref_point" entry
   *        (a resolved list of joint values, not a variable name — PyFM
   *        already substitutes it before this call); "tar_values" is
   *        still required to be present but is ignored in that case.
   * @param end_joint Same shape as @p start_joint, for the scan's end
   *        joint target.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::AckResponse. A default-constructed (error_code=0)
   *         response if @p client is null, not connected, or the call
   *         failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error If either joint dict is missing
   *         "tar_values" (or "ref_point" when input_method=1), or does
   *         not resolve to exactly 6 joint values; and, under "STOP", if
   *         the native call throws.
   */
  photoneo::AckResponse execute_photoneo_initialize(photoneo::PhotoneoClient* client, uint32_t vision_system_id,
                                                    muscat::PhotoneoJointTargetT start_joint,
                                                    muscat::PhotoneoJointTargetT end_joint,
                                                    const std::string& resolve_option = "SKIP",
                                                    FlowManagerArgsPtr flow_manager_args = nullptr,
                                                    AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Photoneo) Interface Initialize failed";

    auto call = [&]() -> std::pair<photoneo::AckResponse, FlowVariables> {
      auto start_joints = rb_vision_util::to_array6(
          rb_vision_util::photoneo_util::resolve_joint_target(start_joint, error_prefix), error_prefix);
      auto end_joints = rb_vision_util::to_array6(
          rb_vision_util::photoneo_util::resolve_joint_target(end_joint, error_prefix), error_prefix);
      photoneo::AckResponse result = client->initialize_vision_system(vision_system_id, start_joints, end_joints);
      return {result, {}};
    };

    return _run_vision_call<photoneo::PhotoneoError, photoneo::AckResponse>(client, resolve_option, flow_manager_args,
                                                                            alarm_fn, error_prefix, "Photoneo", call);
  }

  /**
   * @brief Triggers a Photoneo scan at the robot's current pose.
   *
   * Standalone equivalent of function_code=1 ("Scan") of the Photoneo
   * WRITE interface. This is a Hand-Eye scan: the robot's current TCP
   * pose and tool TCP offset (both derived from @p stat_core) are sent so
   * the vendor can compute the flange pose the scan was taken from.
   *
   * @param client Connected Photoneo client.
   * @param vision_system_id Photoneo vision system id to scan with. 0
   *        uses the client's configured default.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::AckResponse. A default-constructed (error_code=0)
   *         response if @p client is null, not connected, or the call
   *         failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  photoneo::AckResponse execute_photoneo_scan(photoneo::PhotoneoClient* client, uint32_t vision_system_id,
                                              const IPC::State_CoreT& stat_core,
                                              const std::string& resolve_option = "SKIP",
                                              FlowManagerArgsPtr flow_manager_args = nullptr,
                                              AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Photoneo) Interface Scan failed";

    auto call = [&]() -> std::pair<photoneo::AckResponse, FlowVariables> {
      photoneo::Pose tcp_pose = rb_vision_util::build_pose_from_carte_x_ref<photoneo::Pose>(stat_core, error_prefix);
      photoneo::Pose tool_offset =
          rb_vision_util::build_tcp_offset_from_tool_tcp<photoneo::Pose>(stat_core, error_prefix);
      photoneo::AckResponse result = client->scan(vision_system_id, tcp_pose, tool_offset);
      return {result, {}};
    };

    return _run_vision_call<photoneo::PhotoneoError, photoneo::AckResponse>(client, resolve_option, flow_manager_args,
                                                                            alarm_fn, error_prefix, "Photoneo", call);
  }

  /**
   * @brief Switches the active Photoneo solution.
   *
   * Standalone equivalent of function_code=4 ("Solution Change") of the
   * Photoneo WRITE interface.
   *
   * @param client Connected Photoneo client.
   * @param solution_id Solution id to switch to.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::AckResponse. A default-constructed (error_code=0)
   *         response if @p client is null, not connected, or the call
   *         failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  photoneo::AckResponse execute_photoneo_solution_change(photoneo::PhotoneoClient* client, uint32_t solution_id,
                                                         const std::string& resolve_option = "SKIP",
                                                         FlowManagerArgsPtr flow_manager_args = nullptr,
                                                         AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Photoneo) Interface Solution Change failed";

    auto call = [&]() -> std::pair<photoneo::AckResponse, FlowVariables> {
      return {client->change_solution(solution_id), {}};
    };

    return _run_vision_call<photoneo::PhotoneoError, photoneo::AckResponse>(client, resolve_option, flow_manager_args,
                                                                            alarm_fn, error_prefix, "Photoneo", call);
  }

  /**
   * @brief Starts the currently active Photoneo solution.
   *
   * Standalone equivalent of function_code=5 ("Solution Start") of the
   * Photoneo WRITE interface.
   *
   * @param client Connected Photoneo client.
   * @param solution_id Solution id to start.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::AckResponse. A default-constructed (error_code=0)
   *         response if @p client is null, not connected, or the call
   *         failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  photoneo::AckResponse execute_photoneo_solution_start(photoneo::PhotoneoClient* client, uint32_t solution_id,
                                                        const std::string& resolve_option = "SKIP",
                                                        FlowManagerArgsPtr flow_manager_args = nullptr,
                                                        AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Photoneo) Interface Solution Start failed";

    auto call = [&]() -> std::pair<photoneo::AckResponse, FlowVariables> {
      return {client->start_solution(solution_id), {}};
    };

    return _run_vision_call<photoneo::PhotoneoError, photoneo::AckResponse>(client, resolve_option, flow_manager_args,
                                                                            alarm_fn, error_prefix, "Photoneo", call);
  }

  /**
   * @brief Stops the currently running Photoneo solution.
   *
   * Standalone equivalent of function_code=6 ("Solution Stop") of the
   * Photoneo WRITE interface.
   *
   * @param client Connected Photoneo client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::AckResponse. A default-constructed (error_code=0)
   *         response if @p client is null, not connected, or the call
   *         failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  photoneo::AckResponse execute_photoneo_solution_stop(photoneo::PhotoneoClient* client,
                                                       const std::string& resolve_option = "SKIP",
                                                       FlowManagerArgsPtr flow_manager_args = nullptr,
                                                       AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Photoneo) Interface Solution Stop failed";

    auto call = [&]() -> std::pair<photoneo::AckResponse, FlowVariables> {
      return {client->stop_solution(), {}};
    };

    return _run_vision_call<photoneo::PhotoneoError, photoneo::AckResponse>(client, resolve_option, flow_manager_args,
                                                                            alarm_fn, error_prefix, "Photoneo", call);
  }

 private:
  void _execute_photoneo_write(photoneo::PhotoneoClient* client, muscat::InterfacePhotoneoPayloadT data,
                               const IPC::State_CoreT& stat_core, FlowManagerArgsPtr flow_manager_args,
                               AlarmFn alarm_fn) {
    const std::string error_prefix = "Vision(Photoneo) Interface Write failed";
    int function_code = rb_vision_util::require(data.function_code, "function_code", error_prefix);
    std::string resolve_option = rb_vision_util::resolve_option_of(data.resolve_option, error_prefix);

    if (function_code == 0) {
      execute_photoneo_initialize(
          client,
          static_cast<uint32_t>(rb_vision_util::require(data.vision_system_id, "vision_system_id", error_prefix)),
          rb_vision_util::require(data.start_joint, "start_joint", error_prefix),
          rb_vision_util::require(data.end_joint, "end_joint", error_prefix), resolve_option, flow_manager_args,
          alarm_fn);
    } else if (function_code == 1) {
      execute_photoneo_scan(
          client,
          static_cast<uint32_t>(rb_vision_util::require(data.vision_system_id, "vision_system_id", error_prefix)),
          stat_core, resolve_option, flow_manager_args, alarm_fn);
    } else if (function_code == 4) {
      execute_photoneo_solution_change(
          client, static_cast<uint32_t>(rb_vision_util::require(data.solution_id, "solution_id", error_prefix)),
          resolve_option, flow_manager_args, alarm_fn);
    } else if (function_code == 5) {
      execute_photoneo_solution_start(
          client, static_cast<uint32_t>(rb_vision_util::require(data.solution_id, "solution_id", error_prefix)),
          resolve_option, flow_manager_args, alarm_fn);
    } else if (function_code == 6) {
      execute_photoneo_solution_stop(client, resolve_option, flow_manager_args, alarm_fn);
    } else {
      throw std::runtime_error(error_prefix + ": invalid function_code");
    }
  }

 public:
  /**
   * @brief Reads the object pose found by the most recent Photoneo scan.
   *
   * Standalone equivalent of function_code=2 ("Get Object Pose") of the
   * Photoneo READ interface. Requires a prior successful scan (via
   * @c execute_photoneo_scan) on @p vision_system_id.
   *
   * @param client Connected Photoneo client.
   * @param vision_system_id Photoneo vision system id to read the object
   *        pose from. 0 uses the client's configured default.
   * @param point_variable_name PyFM variable name that will receive the
   *        detected pose — a 6-element [x, y, z, rx, ry, rz] list for the
   *        Euler-family formalism, a 7-element
   *        [x, y, z, qx, qy, qz, qw] list for the Quaternion formalism, or
   *        None if no pose is available.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        @p point_variable_name is written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::ObjectPoseResponse with the detected pose. A
   *         default-constructed (no pose) response if @p client is null,
   *         not connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  photoneo::ObjectPoseResponse execute_photoneo_get_object_pose(photoneo::PhotoneoClient* client,
                                                                uint32_t vision_system_id,
                                                                const std::string& point_variable_name,
                                                                const std::string& resolve_option = "SKIP",
                                                                FlowManagerArgsPtr flow_manager_args = nullptr,
                                                                AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Photoneo) Interface Get Object Pose failed";

    auto call = [&]() -> std::pair<photoneo::ObjectPoseResponse, FlowVariables> {
      photoneo::ObjectPoseResponse result = client->get_object_pose(vision_system_id);
      FlowVariables variables;
      variables.emplace(point_variable_name, rb_vision_util::photoneo_util::pose_to_value(result.pose));
      return {result, variables};
    };

    return _run_vision_call<photoneo::PhotoneoError, photoneo::ObjectPoseResponse>(
        client, resolve_option, flow_manager_args, alarm_fn, error_prefix, "Photoneo", call);
  }

  /**
   * @brief Reads the 4-stage pick trajectory computed by the most recent Photoneo scan.
   *
   * Standalone equivalent of function_code=3 ("Get Trajectory") of the
   * Photoneo READ interface. Requires a prior successful scan (via
   * @c execute_photoneo_scan) on @p vision_system_id. The trajectory is
   * split into exactly four stages — Start->Approach, Approach->Grasp,
   * Grasp->Deapproach, Deapproach->End — and each stage's joint waypoints
   * are written into its own PyFM variable.
   *
   * @param client Connected Photoneo client.
   * @param vision_system_id Photoneo vision system id to read the
   *        trajectory from. 0 uses the client's configured default.
   * @param trajectory_start_to_approach PyFM variable name that will
   *        receive the Start->Approach stage's waypoints, each a list of
   *        joint values.
   * @param trajectory_approach_to_grasp Same, for Approach->Grasp.
   * @param trajectory_grasp_to_deapproach Same, for Grasp->Deapproach.
   * @param trajectory_deapproach_to_end Same, for Deapproach->End.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success, the
   *        four stage variables above are written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::TrajectoryResponse with the raw response. A
   *         default-constructed (empty) response if @p client is null,
   *         not connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error If the response does not contain exactly
   *         4 trajectory segments; and, under "STOP", if the native call
   *         throws.
   *
   * @note Any gripper-action entries interleaved in the raw trajectory,
   *       and the AI Picking INFO values (target bounding-box
   *       dimensions), are not extracted by this function — only the 4
   *       segments' joint waypoints are exposed.
   */
  photoneo::TrajectoryResponse execute_photoneo_get_trajectory(
      photoneo::PhotoneoClient* client, uint32_t vision_system_id, const std::string& trajectory_start_to_approach,
      const std::string& trajectory_approach_to_grasp, const std::string& trajectory_grasp_to_deapproach,
      const std::string& trajectory_deapproach_to_end, const std::string& resolve_option = "SKIP",
      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Photoneo) Interface Get Trajectory failed";

    auto call = [&]() -> std::pair<photoneo::TrajectoryResponse, FlowVariables> {
      std::array<std::string, 4> variable_names = {trajectory_start_to_approach, trajectory_approach_to_grasp,
                                                   trajectory_grasp_to_deapproach, trajectory_deapproach_to_end};
      photoneo::TrajectoryResponse result = client->get_trajectory(vision_system_id);

      std::vector<photoneo::TrajectorySegment> segments = result.segments();
      if (segments.size() != 4) {
        throw std::runtime_error(
            error_prefix +
            ": expected 4 trajectory segments (Start->Approach, Approach->Grasp, Grasp->Deapproach, "
            "Deapproach->End), got " +
            std::to_string(segments.size()));
      }

      FlowVariables variables;
      for (size_t i = 0; i < 4; ++i) {
        std::vector<std::vector<double>> waypoints_out;
        for (const auto& wp : segments[i].waypoints) {
          waypoints_out.emplace_back(wp.joints.begin(), wp.joints.end());
        }
        variables.emplace(variable_names[i], FlowVariableValue{std::move(waypoints_out)});
      }
      return {result, variables};
    };

    return _run_vision_call<photoneo::PhotoneoError, photoneo::TrajectoryResponse>(
        client, resolve_option, flow_manager_args, alarm_fn, error_prefix, "Photoneo", call);
  }

  /**
   * @brief Reads the id of the currently running Photoneo solution.
   *
   * Standalone equivalent of function_code=7 ("Solution Ask") of the
   * Photoneo READ interface.
   *
   * @param client Connected Photoneo client.
   * @param current_solution_id PyFM variable name that will receive the
   *        running solution's id, or None if none is running.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Photoneo
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        @p current_solution_id is written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return photoneo::SolutionResponse with the running solution id. A
   *         default-constructed (no id) response if @p client is null,
   *         not connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  photoneo::SolutionResponse execute_photoneo_solution_ask(photoneo::PhotoneoClient* client,
                                                           const std::string& current_solution_id,
                                                           const std::string& resolve_option = "SKIP",
                                                           FlowManagerArgsPtr flow_manager_args = nullptr,
                                                           AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Photoneo) Interface Solution Ask failed";

    auto call = [&]() -> std::pair<photoneo::SolutionResponse, FlowVariables> {
      photoneo::SolutionResponse result = client->get_running_solution();
      FlowVariables variables;
      variables.emplace(current_solution_id, result.solution_id.has_value()
                                                 ? FlowVariableValue{static_cast<int64_t>(*result.solution_id)}
                                                 : FlowVariableValue{});
      return {result, variables};
    };

    return _run_vision_call<photoneo::PhotoneoError, photoneo::SolutionResponse>(
        client, resolve_option, flow_manager_args, alarm_fn, error_prefix, "Photoneo", call);
  }

 private:
  void _execute_photoneo_read(photoneo::PhotoneoClient* client, muscat::InterfacePhotoneoPayloadT data,
                              FlowManagerArgsPtr flow_manager_args, AlarmFn alarm_fn) {
    const std::string error_prefix = "Vision(Photoneo) Interface Read failed";
    int function_code = rb_vision_util::require(data.function_code, "function_code", error_prefix);
    std::string resolve_option = rb_vision_util::resolve_option_of(data.resolve_option, error_prefix);

    if (function_code == 2) {
      execute_photoneo_get_object_pose(
          client,
          static_cast<uint32_t>(rb_vision_util::require(data.vision_system_id, "vision_system_id", error_prefix)),
          rb_vision_util::require(data.point_variable_name, "point_variable_name", error_prefix), resolve_option,
          flow_manager_args, alarm_fn);
    } else if (function_code == 3) {
      execute_photoneo_get_trajectory(
          client,
          static_cast<uint32_t>(rb_vision_util::require(data.vision_system_id, "vision_system_id", error_prefix)),
          rb_vision_util::require(data.trajectory_start_to_approach, "trajectory_start_to_approach", error_prefix),
          rb_vision_util::require(data.trajectory_approach_to_grasp, "trajectory_approach_to_grasp", error_prefix),
          rb_vision_util::require(data.trajectory_grasp_to_deapproach, "trajectory_grasp_to_deapproach", error_prefix),
          rb_vision_util::require(data.trajectory_deapproach_to_end, "trajectory_deapproach_to_end", error_prefix),
          resolve_option, flow_manager_args, alarm_fn);
    } else if (function_code == 7) {
      execute_photoneo_solution_ask(
          client, rb_vision_util::require(data.current_solution_id, "current_solution_id", error_prefix),
          resolve_option, flow_manager_args, alarm_fn);
    } else {
      throw std::runtime_error(error_prefix + ": invalid function_code");
    }
  }

 public:
  /**
   * @brief Moves the robot through an already-resolved list of joint waypoints via a JB (joint-blend) move.
   *
   * Unlike the vendor-facing @c execute_photoneo_* functions above, this
   * does not talk to a Photoneo client at all — it drives the robot
   * itself through @p waypoints using
   * @c RBManipulateMoveSDK::call_move_jb_clr / call_move_jb_add /
   * call_move_jb_run (clear the pending blend queue, add each waypoint,
   * then run). It is the execution half of function_code=8 ("Move (JB)")
   * of the Photoneo interface; callers that already have a resolved
   * waypoint list (as opposed to a PyFM trajectory variable name) can
   * call it directly instead of going through @c vision().
   *
   * Each waypoint is converted from Photoneo's fixed 6-axis trajectory
   * format to the robot's actual @p robot_axis_count: reduced to 6 axes
   * if given more (dropping the third element), then, if the robot has 7
   * or more axes, expanded back to 7 by inserting 0 at index 2.
   *
   * @param waypoints Non-empty list of joint-value sequences (a Python
   *        list/tuple or numpy 2D array is accepted), in Photoneo's
   *        6-axis trajectory order.
   * @param robot_model Name of the robot model to move.
   * @param robot_axis_count Number of axes the target robot actually has;
   *        controls the 6-to-N axis expansion described above.
   * @param pnt_type Blend type for every waypoint: 0 = Percentage,
   *        1 = Distance.
   * @param pnt_para Blend parameter for every waypoint, in the unit
   *        implied by @p pnt_type (percent, or millimeters).
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called once after the final
   *        move request (call_move_jb_run) is accepted — not after the
   *        robot physically finishes the move.
   * @param alarm_fn Optional (title, content) callback fired, with title
   *        "Vision(Photoneo) Move Failed", if any of the clr/add/run
   *        requests reports a nonzero return value.
   *
   * @throws std::runtime_error If @p waypoints is empty, or if any
   *         clr/add/run request reports a nonzero return value (the
   *         first such failure stops the sequence immediately — later
   *         waypoints are never sent).
   *
   * @note Every waypoint is sent with a fixed tar_frame=-1 (Joint Space)
   *       and tar_unit=0 (degree) — this is not currently configurable
   *       through this function.
   *
   * @note Unlike the vendor-facing execute_* functions, there is no
   *       resolve_option here: any move failure always raises (and fires
   *       @p alarm_fn, if provided) rather than being SKIP/STOP/ASK-gated.
   */
  void execute_photoneo_move_waypoints(std::vector<std::vector<double>> waypoints, const std::string& robot_model,
                                       int robot_axis_count, int pnt_type, float pnt_para,
                                       FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Photoneo) Interface Move failed";

    if (waypoints.empty())
      throw std::runtime_error(error_prefix + ": waypoints is empty");

    _run_photoneo_waypoints_core(waypoints, robot_model, robot_axis_count, pnt_type, pnt_para, flow_manager_args,
                                 alarm_fn);
  }

 private:
  // 해석이 끝난 waypoint 리스트로 JB 이동(clr->add*N->run)을 실행하는 순수 C++ core.
  // execute_photoneo_move_waypoints(py 경로) 와 _execute_photoneo_move(trajectory_name 해석) 가 공유한다.
  void _run_photoneo_waypoints_core(const std::vector<std::vector<double>>& waypoints, const std::string& robot_model,
                                    int robot_axis_count, int pnt_type, float pnt_para,
                                    FlowManagerArgsPtr flow_manager_args, AlarmFn alarm_fn) {
    const std::string error_prefix = "Vision(Photoneo) Interface Move failed";

    IPC::Response_FunctionsT clr_payload = manipulate_move_sdk_.call_move_jb_clr(robot_model);
    rb_vision_util::raise_and_alarm_on_move_failure(clr_payload, "call_move_jb_clr", error_prefix, alarm_fn);

    // tar_frame/tar_unit: 현재 payload 에 노출되지 않아 고정값 사용 (tar_frame=-1: Joint Space, tar_unit=0: degree)
    for (const auto& waypoint : waypoints) {
      IPC::MoveInput_TargetT target{
          .tar_values = rb_vision_util::to_robot_axis_joints(waypoint, robot_axis_count),
          .tar_frame = -1,
          .tar_unit = 0,
      };
      IPC::MoveInput_TypeT blend_type{.pnt_type = pnt_type, .pnt_para = pnt_para};

      IPC::Response_FunctionsT add_payload =
          manipulate_move_sdk_.call_move_jb_add(robot_model, target, std::nullopt, std::nullopt, blend_type);
      rb_vision_util::raise_and_alarm_on_move_failure(add_payload, "call_move_jb_add", error_prefix, alarm_fn);
    }

    IPC::Response_FunctionsT run_payload = manipulate_move_sdk_.call_move_jb_run(robot_model);
    rb_vision_util::raise_and_alarm_on_move_failure(run_payload, "call_move_jb_run", error_prefix, alarm_fn);

    if (flow_manager_args)
      flow_manager_args->done();
  }

  // private/unbound 헬퍼. trajectory_name 이 ctx 변수 "이름"으로 올 때 flow_manager_args 로
  // 조회해야 한다(FlowManagerContext::get_waypoint_variable).
  void _execute_photoneo_move(muscat::InterfacePhotoneoPayloadT data, FlowManagerArgsPtr flow_manager_args,
                              AlarmFn alarm_fn, const std::string& robot_model, const IPC::State_CoreT& stat_core) {
    const std::string error_prefix = "Vision(Photoneo) Interface Move failed";

    const muscat::TrajectoryNameInputT& tn =
        rb_vision_util::require(data.trajectory_name, "trajectory_name", error_prefix);
    std::vector<std::vector<double>> waypoints;

    if (!tn.variable_name.empty()) {
      // PFM 경로: trajectory_name 은 ctx 변수 이름이라 flow_manager_args 로 조회해야 한다.
      const std::string& name = tn.variable_name;
      if (!flow_manager_args) {
        throw std::runtime_error(error_prefix +
                                 ": flow_manager_args is required to resolve trajectory_name by variable name");
      }
      std::optional<std::vector<std::vector<double>>> resolved;
      try {
        resolved = flow_manager_args->context().get_waypoint_variable(name);
      } catch (const std::exception&) {
        throw std::runtime_error(error_prefix + ": trajectory_name '" + name + "' variable not found");
      }
      if (!resolved) {
        throw std::runtime_error(error_prefix + ": trajectory_name '" + name +
                                 "' must resolve to a list of joint waypoints");
      }
      waypoints = std::move(*resolved);
      if (waypoints.empty()) {
        throw std::runtime_error(error_prefix + ": trajectory_name '" + name + "' resolved to an empty waypoint list");
      }
    } else {
      // 단독(PFM 없이) 사용: waypoint 리스트를 자리에 직접 전달받았다 (caster 가 이미 행별로 파싱).
      waypoints.reserve(tn.waypoints.size());
      for (const auto& waypoint : tn.waypoints) {
        if (waypoint)
          waypoints.push_back(waypoint->values);
      }
      if (waypoints.empty()) {
        throw std::runtime_error(error_prefix + ": trajectory_name resolved to an empty waypoint list");
      }
    }

    int robot_axis_count = static_cast<int>(stat_core.joint_q_ref.size());
    if (robot_axis_count == 0)
      robot_axis_count = 6;

    int pnt_type = rb_vision_util::require(data.pnt_type, "pnt_type", error_prefix);
    float pnt_para = static_cast<float>(rb_vision_util::require(data.pnt_para, "pnt_para", error_prefix));

    _run_photoneo_waypoints_core(waypoints, robot_model, robot_axis_count, pnt_type, pnt_para, flow_manager_args,
                                 alarm_fn);
  }

 public:
  // -----------------------------------------------------------------------
  // Pickit3D
  // -----------------------------------------------------------------------

  /**
   * @brief Connects to a Pickit3D vision server and registers the client under @p module_name.
   *
   * Reads connection parameters from @p data (server_ip, server_port, an
   * optional timeout_sec defaulting to 10 seconds) and opens a Pickit3D
   * TCP connection, storing the resulting client in the per-module
   * connection registry so later calls (look_for_objects, configure, ...)
   * can look it up by the same @p module_name.
   *
   * @param module_name Registry key for the connection, normally the PyFM
   *        task id resolved from @p flow_manager_args.
   * @param data Connect payload. Must contain server_ip and server_port;
   *        timeout_sec is optional.
   * @param flow_manager_args Optional PyFM step context. When provided,
   *        `flow_manager_args.done()` is called unconditionally once the
   *        connection attempt finishes, even if it failed.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p data's resolve_option is "ASK".
   *
   * @return Pointer to the connected @c pickit3d::PickitClient, owned by
   *         the SDK's connection registry (do not delete it). May be
   *         null, or non-null but not connected, if the attempt failed.
   *
   * @throws std::runtime_error If server_ip or server_port is missing, or
   *         if resolve_option is invalid; and, if resolve_option is
   *         "STOP", if the native connect call throws.
   *
   * @note If the native connect call fails without throwing (client
   *       non-null but not connected), that failure is only logged to
   *       stdout — it does not go through resolve_option's SKIP/STOP/ASK
   *       handling, unlike an actual vendor exception.
   *
   * @note Calling this again with the same @p module_name transparently
   *       disconnects the previous client for that module before opening
   *       the new connection.
   */
  pickit3d::PickitClient* execute_pickit_connect(const std::string& module_name, muscat::InterfacePickitPayloadT data,
                                                 FlowManagerArgsPtr flow_manager_args, AlarmFn alarm_fn) {
    const std::string error_prefix = "Vision(Pickit) Interface Connect failed";

    std::string server_ip = rb_vision_util::require(data.server_ip, "server_ip", error_prefix);
    int server_port = rb_vision_util::require(data.server_port, "server_port", error_prefix);
    double timeout_sec = rb_vision_util::timeout_sec_of(data.timeout_sec, 10.0);
    std::string resolve_option = rb_vision_util::resolve_option_of(data.resolve_option, error_prefix);

    pickit3d::PickitConfig config;
    config.host = server_ip;
    config.port = server_port;
    config.timeout = timeout_sec;

    pickit3d::PickitClient* client = nullptr;
    try {
      client = &pickit_clients_.connect(module_name, config);
    } catch (const pickit3d::PickitError& e) {
      rb_vision_util::resolve_interface_flow(e.what(), resolve_option, flow_manager_args, alarm_fn, error_prefix);
    }

    if (client == nullptr || !client->is_connected()) {
      std::cout << error_prefix << ": connection attempt failed without exception, treating as failed connection"
                << std::endl;
    }
    if (flow_manager_args)
      flow_manager_args->done();

    return client;
  }

  /**
   * @brief Sends the robot's current TCP pose to Pickit3D for connection-liveness and 3D-view display.
   *
   * Standalone equivalent of function_code=0 ("Update Robot Pose") of the
   * Pickit WRITE interface. This is not required for detection accuracy
   * (the detection calls below carry their own robot pose) — it is used
   * by Pickit only for liveness detection and its web interface's 3D
   * view. It is safe to call periodically (Pickit's own guidance is
   * roughly 10 Hz) from a separate control loop.
   *
   * @param client Connected Pickit client.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true if the update either sent successfully or was skipped
   *         (see @note below); false only if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   *
   * @note The native call itself can return false when a write from
   *       another thread (e.g. a concurrent detection call) is already
   *       in progress and this update was skipped for the cycle. That
   *       return value is intentionally ignored here and never treated
   *       as a failure — only an actual exception is.
   */
  bool execute_pickit_update_robot_pose(pickit3d::PickitClient* client, const IPC::State_CoreT& stat_core,
                                        const std::string& resolve_option = "SKIP",
                                        FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Update Robot Pose failed";

    auto call = [&]() -> std::pair<bool, FlowVariables> {
      pickit3d::Pose tcp_pose = rb_vision_util::build_pose_from_carte_x_ref<pickit3d::Pose>(stat_core, error_prefix);
      pickit3d::Pose tcp_offset =
          rb_vision_util::build_tcp_offset_from_tool_tcp<pickit3d::Pose>(stat_core, error_prefix);
      // update_robot_pose() 의 실제 반환값(false=동시 write로 이번 사이클엔 못 보냄)은 무시한다 -
      // 원본 python 코드도 이걸 인터페이스 실패로 취급하지 않았다(라이브 니스 체크용일 뿐).
      client->update_robot_pose(tcp_pose, tcp_offset);
      return {true, {}};
    };

    return _run_vision_call<pickit3d::PickitError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                         error_prefix, "Pickit", call);
  }

  /**
   * @brief Reads Pickit3D's current operating mode.
   *
   * Standalone equivalent of function_code=1 ("Check Mode") of the Pickit
   * READ interface.
   *
   * @param client Connected Pickit client.
   * @param pickit_mode PyFM variable name that will receive the raw mode
   *        code: 0 = Robot Mode, 1 = Idle Mode. This value is itself the
   *        information being requested, not a success/failure signal.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        @p pickit_mode is written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return The mode code (0 or 1). 0 if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK" — which is
   *         numerically indistinguishable from a genuine Robot Mode
   *         reading; check the client/exception path if that matters.
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  int execute_pickit_check_mode(pickit3d::PickitClient* client, const std::string& pickit_mode,
                                const std::string& resolve_option = "SKIP",
                                FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Check Mode failed";

    auto call = [&]() -> std::pair<int, FlowVariables> {
      int mode = client->check_mode();
      FlowVariables variables;
      variables.emplace(pickit_mode, FlowVariableValue{mode});
      return {mode, variables};
    };

    return _run_vision_call<pickit3d::PickitError, int>(client, resolve_option, flow_manager_args, alarm_fn,
                                                        error_prefix, "Pickit", call);
  }

  /**
   * @brief Shuts down the Pickit3D vision system.
   *
   * Standalone equivalent of function_code=2 ("Shutdown System") of the
   * Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_shutdown_system(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Shutdown System failed";
    auto call = [&]() -> std::pair<bool, FlowVariables> {
      return {client->shutdown_system(), {}};
    };
    return _run_vision_call<pickit3d::PickitError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                         error_prefix, "Pickit", call);
  }

  /**
   * @brief Locates the calibration plate for Pickit3D robot-camera calibration.
   *
   * Standalone equivalent of function_code=3 ("Find Calib Plate") of the
   * Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_find_calib_plate(pickit3d::PickitClient* client, const IPC::State_CoreT& stat_core,
                                       const std::string& resolve_option = "SKIP",
                                       FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Find Calib Plate failed";

    auto call = [&]() -> std::pair<bool, FlowVariables> {
      pickit3d::Pose tcp_pose = rb_vision_util::build_pose_from_carte_x_ref<pickit3d::Pose>(stat_core, error_prefix);
      pickit3d::Pose tcp_offset =
          rb_vision_util::build_tcp_offset_from_tool_tcp<pickit3d::Pose>(stat_core, error_prefix);
      return {client->find_calib_plate(tcp_pose, tcp_offset), {}};
    };

    return _run_vision_call<pickit3d::PickitError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                         error_prefix, "Pickit", call);
  }

  /**
   * @brief Configures the Pickit3D robot-camera calibration procedure.
   *
   * Standalone equivalent of function_code=4 ("Configure Calib") of the
   * Pickit WRITE interface. The robot TCP pose and tool TCP offset
   * (derived from @p stat_core) are always sent, but are only meaningful
   * to Pickit for the SINGLE_POSE/MANUAL calibration methods — other
   * methods ignore them.
   *
   * @param client Connected Pickit client.
   * @param calib_method Pickit calibration method id — see @c
   *        pickit3d::CalibrationMethod (constants.hpp), payload[0] of the
   *        native RC_PICKIT_CONFIGURE_CALIB(11) command: 0=SINGLE_POSE,
   *        1=MULTI_POSE, 2=MANUAL, 3=DEFAULT. The caller (program step) may
   *        also pass the matching label string ("SINGLE_POSE",
   *        "MULTI_POSE", "MANUAL", "DEFAULT") — @c
   *        rb_vision_util::get_calib_method resolves it to this id before
   *        the call reaches here.
   * @param calib_camera_mount Camera mount id —
   *        0=FIXED (Eye-to-Hand — camera fixed in the cell, sees the whole
   *        scene) or 1=ON_ROBOT (Eye-in-Hand — camera mounted on the robot
   *        flange, moves with it). The caller may also pass "EYE_TO_HAND"/
   *        "FIXED" or "EYE_IN_HAND"/"ON_ROBOT" — @c
   *        rb_vision_util::get_calib_camera_mount resolves the label to
   *        this id. Must match how the camera is physically mounted on
   *        this cell; this is the same setting that decides whether
   *        detection uses @c execute_pickit_look_for_objects (FIXED) or @c
   *        execute_pickit_capture_image + @c execute_pickit_process_image
   *        (ON_ROBOT).
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws a
   *         Pickit exception.
   * @throws std::invalid_argument If @p calib_method is SINGLE_POSE and
   *         @p calib_camera_mount is ON_ROBOT (an unsupported
   *         combination). This is not a Pickit protocol exception, so it
   *         is not caught by the resolve_option handling above — it
   *         always propagates directly to the caller.
   */
  bool execute_pickit_configure_calib(pickit3d::PickitClient* client, int calib_method, int calib_camera_mount,
                                      const IPC::State_CoreT& stat_core, const std::string& resolve_option = "SKIP",
                                      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Configure Calib failed";

    auto call = [&]() -> std::pair<bool, FlowVariables> {
      pickit3d::Pose tcp_pose = rb_vision_util::build_pose_from_carte_x_ref<pickit3d::Pose>(stat_core, error_prefix);
      pickit3d::Pose tcp_offset =
          rb_vision_util::build_tcp_offset_from_tool_tcp<pickit3d::Pose>(stat_core, error_prefix);
      return {client->configure_calib(calib_method, calib_camera_mount, tcp_pose, tcp_offset), {}};
    };

    return _run_vision_call<pickit3d::PickitError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                         error_prefix, "Pickit", call);
  }

  /**
   * @brief Computes the Pickit3D robot-camera calibration from the poses collected so far.
   *
   * Standalone equivalent of function_code=5 ("Compute Calib") of the
   * Pickit WRITE interface. Requires a prior @c execute_pickit_configure_calib.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_compute_calib(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                    FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Compute Calib failed";
    auto call = [&]() -> std::pair<bool, FlowVariables> {
      return {client->compute_calib(), {}};
    };
    return _run_vision_call<pickit3d::PickitError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                         error_prefix, "Pickit", call);
  }

  /**
   * @brief Validates the most recently computed Pickit3D robot-camera calibration.
   *
   * Standalone equivalent of function_code=6 ("Validate Calib") of the
   * Pickit WRITE interface. Requires a prior @c execute_pickit_compute_calib.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_validate_calib(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                     FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Validate Calib failed";
    auto call = [&]() -> std::pair<bool, FlowVariables> {
      return {client->validate_calib(), {}};
    };
    return _run_vision_call<pickit3d::PickitError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                         error_prefix, "Pickit", call);
  }

  /**
   * @brief Triggers a Pickit3D capture + object detection run.
   *
   * Standalone equivalent of function_code=7 ("Look For Objects") of the
   * Pickit READ interface. The robot TCP pose and tool TCP offset
   * (derived from @p stat_core) are sent so Pickit can locate the object
   * relative to the robot.
   *
   * @param client Connected Pickit client.
   * @param pick_point_name PyFM variable name that will receive the
   *        detected object's pose as a 6-element [x, y, z, rx, ry, rz]
   *        list.
   * @param remaining_count_name PyFM variable name that will receive the
   *        number of remaining detectable objects.
   * @param model_id_or_type_name PyFM variable name that will receive the
   *        detected object's model id or type.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success, the
   *        three variables above are written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return pickit3d::ObjectDetection with the detection result. A
   *         default-constructed (empty) result if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  pickit3d::ObjectDetection execute_pickit_look_for_objects(
      pickit3d::PickitClient* client, const std::string& pick_point_name, const std::string& remaining_count_name,
      const std::string& model_id_or_type_name, const IPC::State_CoreT& stat_core,
      const std::string& resolve_option = "SKIP", FlowManagerArgsPtr flow_manager_args = nullptr,
      AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Look For Objects failed";

    auto call = [&]() -> std::pair<pickit3d::ObjectDetection, FlowVariables> {
      pickit3d::Pose tcp_pose = rb_vision_util::build_pose_from_carte_x_ref<pickit3d::Pose>(stat_core, error_prefix);
      pickit3d::Pose tcp_offset =
          rb_vision_util::build_tcp_offset_from_tool_tcp<pickit3d::Pose>(stat_core, error_prefix);
      pickit3d::ObjectDetection detection = client->look_for_objects(tcp_pose, tcp_offset);
      return {detection, rb_vision_util::pickit_util::detection_variables(detection, pick_point_name,
                                                                          remaining_count_name, model_id_or_type_name)};
    };

    return _run_vision_call<pickit3d::PickitError, pickit3d::ObjectDetection>(client, resolve_option, flow_manager_args,
                                                                              alarm_fn, error_prefix, "Pickit", call);
  }

  /**
   * @brief Triggers a Pickit3D capture + object detection run, retrying internally on empty results.
   *
   * Standalone equivalent of function_code=8 ("Look For Objects With
   * Retries") of the Pickit READ interface. Same behavior as
   * @c execute_pickit_look_for_objects, except the native call retries up
   * to @p retry_count times internally when the result is NO_OBJECTS
   * (not when the search area is merely empty). Vendor documentation
   * does not specify a delay between retries or an overall timeout.
   *
   * @param client Connected Pickit client.
   * @param retry_count Maximum number of internal retries on NO_OBJECTS.
   * @param pick_point_name PyFM variable name that will receive the
   *        detected object's pose as a 6-element [x, y, z, rx, ry, rz]
   *        list.
   * @param remaining_count_name PyFM variable name that will receive the
   *        number of remaining detectable objects.
   * @param model_id_or_type_name PyFM variable name that will receive the
   *        detected object's model id or type.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success, the
   *        three variables above are written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return pickit3d::ObjectDetection with the detection result. A
   *         default-constructed (empty) result if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  pickit3d::ObjectDetection execute_pickit_look_for_objects_with_retries(
      pickit3d::PickitClient* client, int retry_count, const std::string& pick_point_name,
      const std::string& remaining_count_name, const std::string& model_id_or_type_name,
      const IPC::State_CoreT& stat_core, const std::string& resolve_option = "SKIP",
      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Look For Objects With Retries failed";

    auto call = [&]() -> std::pair<pickit3d::ObjectDetection, FlowVariables> {
      pickit3d::Pose tcp_pose = rb_vision_util::build_pose_from_carte_x_ref<pickit3d::Pose>(stat_core, error_prefix);
      pickit3d::Pose tcp_offset =
          rb_vision_util::build_tcp_offset_from_tool_tcp<pickit3d::Pose>(stat_core, error_prefix);
      pickit3d::ObjectDetection detection = client->look_for_objects_with_retries(retry_count, tcp_pose, tcp_offset);
      return {detection, rb_vision_util::pickit_util::detection_variables(detection, pick_point_name,
                                                                          remaining_count_name, model_id_or_type_name)};
    };

    return _run_vision_call<pickit3d::PickitError, pickit3d::ObjectDetection>(client, resolve_option, flow_manager_args,
                                                                              alarm_fn, error_prefix, "Pickit", call);
  }

  /**
   * @brief Reads the next detected object from the most recent Pickit3D detection run.
   *
   * Standalone equivalent of function_code=9 ("Next Object") of the
   * Pickit READ interface. Only valid after a prior
   * @c execute_pickit_look_for_objects or
   * @c execute_pickit_look_for_objects_with_retries call.
   *
   * @param client Connected Pickit client.
   * @param pick_point_name PyFM variable name that will receive the
   *        detected object's pose as a 6-element [x, y, z, rx, ry, rz]
   *        list.
   * @param remaining_count_name PyFM variable name that will receive the
   *        number of remaining detectable objects.
   * @param model_id_or_type_name PyFM variable name that will receive the
   *        detected object's model id or type.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success, the
   *        three variables above are written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return pickit3d::ObjectDetection with the detection result. A
   *         default-constructed (empty) result if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  pickit3d::ObjectDetection execute_pickit_next_object(
      pickit3d::PickitClient* client, const std::string& pick_point_name, const std::string& remaining_count_name,
      const std::string& model_id_or_type_name, const IPC::State_CoreT& stat_core,
      const std::string& resolve_option = "SKIP", FlowManagerArgsPtr flow_manager_args = nullptr,
      AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Next Object failed";

    auto call = [&]() -> std::pair<pickit3d::ObjectDetection, FlowVariables> {
      pickit3d::Pose tcp_pose = rb_vision_util::build_pose_from_carte_x_ref<pickit3d::Pose>(stat_core, error_prefix);
      pickit3d::Pose tcp_offset =
          rb_vision_util::build_tcp_offset_from_tool_tcp<pickit3d::Pose>(stat_core, error_prefix);
      pickit3d::ObjectDetection detection = client->next_object(tcp_pose, tcp_offset);
      return {detection, rb_vision_util::pickit_util::detection_variables(detection, pick_point_name,
                                                                          remaining_count_name, model_id_or_type_name)};
    };

    return _run_vision_call<pickit3d::PickitError, pickit3d::ObjectDetection>(client, resolve_option, flow_manager_args,
                                                                              alarm_fn, error_prefix, "Pickit", call);
  }

  /**
   * @brief Captures an image for the Pickit3D Eye-in-Hand detection workflow.
   *
   * Standalone equivalent of function_code=10 ("Capture Image") of the
   * Pickit WRITE interface. Part of the Eye-in-Hand workflow: this only
   * captures the image and reports a status code — call
   * @c execute_pickit_process_image afterwards to actually run detection
   * on it. The robot TCP pose and tool TCP offset (derived from
   * @p stat_core) are sent, same as the other detection calls.
   *
   * @param client Connected Pickit client.
   * @param stat_core Robot state snapshot the TCP pose and tool TCP
   *        offset are derived from.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws —
   *         which, unlike the other Pickit detection calls, includes the
   *         image genuinely not having been captured (NO_IMAGE_CAPTURED
   *         means failure here, not "nothing found" as it does for
   *         @c execute_pickit_look_for_objects).
   */
  bool execute_pickit_capture_image(pickit3d::PickitClient* client, const IPC::State_CoreT& stat_core,
                                    const std::string& resolve_option = "SKIP",
                                    FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Capture Image failed";

    auto call = [&]() -> std::pair<bool, FlowVariables> {
      pickit3d::Pose tcp_pose = rb_vision_util::build_pose_from_carte_x_ref<pickit3d::Pose>(stat_core, error_prefix);
      pickit3d::Pose tcp_offset =
          rb_vision_util::build_tcp_offset_from_tool_tcp<pickit3d::Pose>(stat_core, error_prefix);
      return {client->capture_image(tcp_pose, tcp_offset), {}};
    };

    return _run_vision_call<pickit3d::PickitError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                         error_prefix, "Pickit", call);
  }

  /**
   * @brief Runs Pickit3D object detection on the image captured by @c execute_pickit_capture_image.
   *
   * Standalone equivalent of function_code=11 ("Process Image") of the
   * Pickit READ interface. The second half of the Eye-in-Hand workflow —
   * this is where the actual detection result (object pose, dimensions,
   * remaining count) comes from, not from
   * @c execute_pickit_capture_image (which only reports a status code).
   * Takes no robot pose — the pose already sent to
   * @c execute_pickit_capture_image is what the detection is based on.
   *
   * @param client Connected Pickit client.
   * @param pick_point_name PyFM variable name that will receive the
   *        detected object's pose as a 6-element [x, y, z, rx, ry, rz]
   *        list.
   * @param remaining_count_name PyFM variable name that will receive the
   *        number of remaining detectable objects.
   * @param model_id_or_type_name PyFM variable name that will receive the
   *        detected object's model id or type.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success, the
   *        three variables above are written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return pickit3d::ObjectDetection with the detection result. A
   *         default-constructed (empty) result if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  pickit3d::ObjectDetection execute_pickit_process_image(
      pickit3d::PickitClient* client, const std::string& pick_point_name, const std::string& remaining_count_name,
      const std::string& model_id_or_type_name, const std::string& resolve_option = "SKIP",
      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Process Image failed";

    auto call = [&]() -> std::pair<pickit3d::ObjectDetection, FlowVariables> {
      pickit3d::ObjectDetection detection = client->process_image();
      return {detection, rb_vision_util::pickit_util::detection_variables(detection, pick_point_name,
                                                                          remaining_count_name, model_id_or_type_name)};
    };

    return _run_vision_call<pickit3d::PickitError, pickit3d::ObjectDetection>(client, resolve_option, flow_manager_args,
                                                                              alarm_fn, error_prefix, "Pickit", call);
  }

  /**
   * @brief Reads the gripper pose computed from the most recent Pickit3D detection.
   *
   * Standalone equivalent of function_code=12 ("Get Pick Point Data") of
   * the Pickit READ interface. Takes no robot pose of its own — the
   * client automatically reuses the detected object's pose cached by the
   * most recent successful @c execute_pickit_look_for_objects,
   * @c execute_pickit_look_for_objects_with_retries,
   * @c execute_pickit_next_object, or @c execute_pickit_process_image
   * call. The gripper pose is computed by composing that cached
   * detection pose with the response's offset pose; if no detection pose
   * is cached, the gripper pose is not available.
   *
   * @param client Connected Pickit client.
   * @param gripper_pose_name PyFM variable name that will receive the
   *        computed gripper pose as a 6-element [x, y, z, rx, ry, rz]
   *        list, or None if no cached detection pose is available.
   * @param reference_pick_point_id_name PyFM variable name that will
   *        receive the reference pick point id from the response.
   * @param stat_core Robot state snapshot the tool TCP offset is derived
   *        from (no TCP pose is sent — see above).
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success, the
   *        two variables above are written into its context and
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return pickit3d::PickPointData with the pick point result. A
   *         default-constructed (empty) result if @p client is null, not
   *         connected, or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  pickit3d::PickPointData execute_pickit_get_pick_point_data(pickit3d::PickitClient* client,
                                                             const std::string& gripper_pose_name,
                                                             const std::string& reference_pick_point_id_name,
                                                             const IPC::State_CoreT& stat_core,
                                                             const std::string& resolve_option = "SKIP",
                                                             FlowManagerArgsPtr flow_manager_args = nullptr,
                                                             AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Get Pick Point Data failed";

    auto call = [&]() -> std::pair<pickit3d::PickPointData, FlowVariables> {
      pickit3d::Pose tcp_offset =
          rb_vision_util::build_tcp_offset_from_tool_tcp<pickit3d::Pose>(stat_core, error_prefix);
      pickit3d::PickPointData pick_point = client->get_pick_point_data(tcp_offset);
      FlowVariables variables;
      variables.emplace(gripper_pose_name,
                        pick_point.grip_pose
                            ? FlowVariableValue{rb_vision_util::pickit_util::pose_to_values(*pick_point.grip_pose)}
                            : FlowVariableValue{});
      variables.emplace(reference_pick_point_id_name, FlowVariableValue{pick_point.reference_pick_point_id});
      return {pick_point, variables};
    };

    return _run_vision_call<pickit3d::PickitError, pickit3d::PickPointData>(client, resolve_option, flow_manager_args,
                                                                            alarm_fn, error_prefix, "Pickit", call);
  }

  /**
   * @brief Selects the active Pickit3D setup and product.
   *
   * Standalone equivalent of function_code=13 ("Configure") of the
   * Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param setup_id Setup id to activate. A negative value falls back to
   *        the client's configured default setup id.
   * @param product_id Product id to activate. A negative value falls
   *        back to the client's configured default product id.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_configure(pickit3d::PickitClient* client, int setup_id, int product_id,
                                const std::string& resolve_option = "SKIP",
                                FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Configure failed";
    auto call = [&]() -> std::pair<bool, FlowVariables> {
      return {client->configure(setup_id, product_id), {}};
    };
    return _run_vision_call<pickit3d::PickitError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                         error_prefix, "Pickit", call);
  }

  /**
   * @brief Sets the expected cylinder dimensions for Pickit3D's cylinder detection model.
   *
   * Standalone equivalent of function_code=14 ("Set Cylinder Dim") of the
   * Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param cylinder_length Expected cylinder length, in millimeters.
   * @param cylinder_diameter Expected cylinder diameter, in millimeters.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_set_cylinder_dim(pickit3d::PickitClient* client, float cylinder_length, float cylinder_diameter,
                                       const std::string& resolve_option = "SKIP",
                                       FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Set Cylinder Dim failed";
    auto call = [&]() -> std::pair<bool, FlowVariables> {
      return {client->set_cylinder_dim(cylinder_length, cylinder_diameter), {}};
    };
    return _run_vision_call<pickit3d::PickitError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                         error_prefix, "Pickit", call);
  }

  /**
   * @brief Persists the currently active Pickit3D setup.
   *
   * Standalone equivalent of function_code=15 ("Save Active Setup") of
   * the Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_save_active_setup(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                        FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Save Active Setup failed";
    auto call = [&]() -> std::pair<bool, FlowVariables> {
      return {client->save_active_setup(), {}};
    };
    return _run_vision_call<pickit3d::PickitError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                         error_prefix, "Pickit", call);
  }

  /**
   * @brief Persists the currently active Pickit3D product.
   *
   * Standalone equivalent of function_code=16 ("Save Active Product") of
   * the Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_save_active_product(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                          FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Save Active Product failed";
    auto call = [&]() -> std::pair<bool, FlowVariables> {
      return {client->save_active_product(), {}};
    };
    return _run_vision_call<pickit3d::PickitError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                         error_prefix, "Pickit", call);
  }

  /**
   * @brief Rebuilds Pickit3D's background model from the current scene.
   *
   * Standalone equivalent of function_code=17 ("Build Background") of the
   * Pickit WRITE interface. Used to (re)learn what counts as empty
   * background so later detections can distinguish objects from it.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_build_background(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                       FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Build Background failed";
    auto call = [&]() -> std::pair<bool, FlowVariables> {
      return {client->build_background(), {}};
    };
    return _run_vision_call<pickit3d::PickitError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                         error_prefix, "Pickit", call);
  }

  /**
   * @brief Saves a diagnostic snapshot of Pickit3D's current scene.
   *
   * Standalone equivalent of function_code=18 ("Save Snapshot") of the
   * Pickit WRITE interface.
   *
   * @param client Connected Pickit client.
   * @param resolve_option How to handle a client-side failure — client
   *        not connected, or the native call throwing a Pickit
   *        exception: "SKIP" continues without effect, "STOP" raises
   *        immediately, "ASK" fires @p alarm_fn and pauses the PyFM
   *        context (requires @p flow_manager_args). Defaults to "SKIP".
   * @param flow_manager_args Optional PyFM step context. On success,
   *        `flow_manager_args.done()` is called.
   * @param alarm_fn Optional (title, content) callback used only when
   *        @p resolve_option is "ASK".
   *
   * @return true on success; false if @p client is null, not connected,
   *         or the call failed under "SKIP"/"ASK".
   *
   * @throws std::runtime_error Under "STOP", if the native call throws.
   */
  bool execute_pickit_save_snapshot(pickit3d::PickitClient* client, const std::string& resolve_option = "SKIP",
                                    FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr) {
    const std::string error_prefix = "Vision(Pickit) Interface Save Snapshot failed";
    auto call = [&]() -> std::pair<bool, FlowVariables> {
      return {client->save_snapshot(), {}};
    };
    return _run_vision_call<pickit3d::PickitError, bool>(client, resolve_option, flow_manager_args, alarm_fn,
                                                         error_prefix, "Pickit", call);
  }

 private:
  void _execute_pickit_write(pickit3d::PickitClient* client, muscat::InterfacePickitPayloadT data,
                             const IPC::State_CoreT& stat_core, FlowManagerArgsPtr flow_manager_args,
                             AlarmFn alarm_fn) {
    const std::string error_prefix = "Vision(Pickit) Interface Write failed";
    int function_code = rb_vision_util::require(data.function_code, "function_code", error_prefix);
    std::string resolve_option = rb_vision_util::resolve_option_of(data.resolve_option, error_prefix);

    switch (function_code) {
      case 0:
        execute_pickit_update_robot_pose(client, stat_core, resolve_option, flow_manager_args, alarm_fn);
        return;
      case 2:
        execute_pickit_shutdown_system(client, resolve_option, flow_manager_args, alarm_fn);
        return;
      case 3:
        execute_pickit_find_calib_plate(client, stat_core, resolve_option, flow_manager_args, alarm_fn);
        return;
      case 4:
        execute_pickit_configure_calib(client, rb_vision_util::get_calib_method(data.calib_method, error_prefix),
                                       rb_vision_util::get_calib_camera_mount(data.calib_camera_mount, error_prefix),
                                       stat_core, resolve_option, flow_manager_args, alarm_fn);
        return;
      case 5:
        execute_pickit_compute_calib(client, resolve_option, flow_manager_args, alarm_fn);
        return;
      case 6:
        execute_pickit_validate_calib(client, resolve_option, flow_manager_args, alarm_fn);
        return;
      case 10:
        execute_pickit_capture_image(client, stat_core, resolve_option, flow_manager_args, alarm_fn);
        return;
      case 13:
        execute_pickit_configure(client, rb_vision_util::require(data.setup_id, "setup_id", error_prefix),
                                 rb_vision_util::require(data.product_id, "product_id", error_prefix), resolve_option,
                                 flow_manager_args, alarm_fn);
        return;
      case 14: {
        float cylinder_length =
            static_cast<float>(rb_vision_util::require(data.cylinder_length, "cylinder_length", error_prefix));
        float cylinder_diameter =
            static_cast<float>(rb_vision_util::require(data.cylinder_diameter, "cylinder_diameter", error_prefix));
        execute_pickit_set_cylinder_dim(client, cylinder_length, cylinder_diameter, resolve_option, flow_manager_args,
                                        alarm_fn);
        return;
      }
      case 15:
        execute_pickit_save_active_setup(client, resolve_option, flow_manager_args, alarm_fn);
        return;
      case 16:
        execute_pickit_save_active_product(client, resolve_option, flow_manager_args, alarm_fn);
        return;
      case 17:
        execute_pickit_build_background(client, resolve_option, flow_manager_args, alarm_fn);
        return;
      case 18:
        execute_pickit_save_snapshot(client, resolve_option, flow_manager_args, alarm_fn);
        return;
      default:
        throw std::runtime_error(error_prefix + ": invalid function_code");
    }
  }

  void _execute_pickit_read(pickit3d::PickitClient* client, muscat::InterfacePickitPayloadT data,
                            const IPC::State_CoreT& stat_core, FlowManagerArgsPtr flow_manager_args, AlarmFn alarm_fn) {
    const std::string error_prefix = "Vision(Pickit) Interface Read failed";
    int function_code = rb_vision_util::require(data.function_code, "function_code", error_prefix);
    std::string resolve_option = rb_vision_util::resolve_option_of(data.resolve_option, error_prefix);

    switch (function_code) {
      case 1:
        execute_pickit_check_mode(client, rb_vision_util::require(data.pickit_mode, "pickit_mode", error_prefix),
                                  resolve_option, flow_manager_args, alarm_fn);
        return;
      case 7:
        execute_pickit_look_for_objects(
            client, rb_vision_util::require(data.pick_point_name, "pick_point_name", error_prefix),
            rb_vision_util::require(data.remaining_count_name, "remaining_count_name", error_prefix),
            rb_vision_util::require(data.model_id_or_type_name, "model_id_or_type_name", error_prefix), stat_core,
            resolve_option, flow_manager_args, alarm_fn);
        return;
      case 8:
        execute_pickit_look_for_objects_with_retries(
            client, rb_vision_util::require(data.retry_count, "retry_count", error_prefix),
            rb_vision_util::require(data.pick_point_name, "pick_point_name", error_prefix),
            rb_vision_util::require(data.remaining_count_name, "remaining_count_name", error_prefix),
            rb_vision_util::require(data.model_id_or_type_name, "model_id_or_type_name", error_prefix), stat_core,
            resolve_option, flow_manager_args, alarm_fn);
        return;
      case 9:
        execute_pickit_next_object(
            client, rb_vision_util::require(data.pick_point_name, "pick_point_name", error_prefix),
            rb_vision_util::require(data.remaining_count_name, "remaining_count_name", error_prefix),
            rb_vision_util::require(data.model_id_or_type_name, "model_id_or_type_name", error_prefix), stat_core,
            resolve_option, flow_manager_args, alarm_fn);
        return;
      case 11:
        execute_pickit_process_image(
            client, rb_vision_util::require(data.pick_point_name, "pick_point_name", error_prefix),
            rb_vision_util::require(data.remaining_count_name, "remaining_count_name", error_prefix),
            rb_vision_util::require(data.model_id_or_type_name, "model_id_or_type_name", error_prefix), resolve_option,
            flow_manager_args, alarm_fn);
        return;
      case 12:
        execute_pickit_get_pick_point_data(
            client, rb_vision_util::require(data.gripper_pose_name, "gripper_pose_name", error_prefix),
            rb_vision_util::require(data.reference_pick_point_id_name, "reference_pick_point_id_name", error_prefix),
            stat_core, resolve_option, flow_manager_args, alarm_fn);
        return;
      default:
        throw std::runtime_error(error_prefix + ": invalid function_code");
    }
  }

 public:
  // -----------------------------------------------------------------------
  // Top-level entry point
  // -----------------------------------------------------------------------

  /**
   * @brief Single dispatch entry point for all MechMind / Photoneo / Pickit3D vision interface calls.
   *
   * This is the function a PyFM vision-interface step actually calls;
   * every function above (connect / execute_* / trigger / etc.) is one of
   * this function's dispatch targets and can also be called directly by
   * SDK users who already hold a client and don't need the @p data-driven
   * dispatch. Which sub-function runs is chosen by @p option and, for
   * Photoneo/Pickit, a "function_code" field inside @p data (MechMind
   * instead uses a "type" field, see below):
   *
   * - "MECHMIND_INTERFACE": @p data["type"] selects "CONNECT"
   *   (@c execute_mechmind_connect), "READ" (function_code 0 = Trigger And
   *   Get Poses via @c execute_mechmind_trigger_and_get_poses, 2 = Get
   *   Poses via @c execute_mechmind_get_poses), or "WRITE" (function_code
   *   1 = Trigger via @c execute_mechmind_trigger, 3 = Set Recipe via
   *   @c execute_mechmind_set_recipe).
   * - "PHOTONEO_INTERFACE": @p data["function_code"] selects 99 = Create
   *   Connection (@c execute_photoneo_connect), 0/1/4/5/6 = Initialize /
   *   Scan / Solution Change / Solution Start / Solution Stop (WRITE),
   *   2/3/7 = Get Object Pose / Get Trajectory / Solution Ask (READ), or
   *   8 = Move (JB) through a stored trajectory
   *   (@c execute_photoneo_move_waypoints, resolving the trajectory by
   *   PyFM variable name or an inline waypoint list).
   * - "PICKIT_INTERFACE": @p data["function_code"] selects 99 = Create
   *   Connection (@c execute_pickit_connect), one of
   *   0/2/3/4/5/6/10/13/14/15/16/17/18 for the WRITE-family calls
   *   (update robot pose, shutdown, calibration, configure, capture
   *   image, ...), or one of 1/7/8/9/11/12 for the READ-family calls
   *   (check mode, look for objects (with retries), next object, process
   *   image, get pick point data).
   *
   * See each dispatch target's own docstring above for its payload
   * fields, return value and failure handling — this function only picks
   * which one runs and supplies it with the connection's client, plus a
   * robot state snapshot for calls that need pose correction.
   *
   * @param robot_model Name of the robot model whose state and vision
   *        connection this call applies to.
   * @param option Vision vendor: "MECHMIND_INTERFACE",
   *        "PHOTONEO_INTERFACE", or "PICKIT_INTERFACE".
   * @param data Interface payload; its shape depends on @p option and the
   *        selected type/function_code, see above.
   * @param alarm_fn Optional (title, content) callback used by any
   *        dispatch target whose resolve_option is "ASK".
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything — if omitted, returns immediately without
   *        dispatching to any target (unlike the individual execute_*
   *        functions below, which work standalone; call one of those
   *        directly instead of vision() if PyFM isn't in play). When
   *        provided, it's forwarded as-is to the selected dispatch target.
   *
   * @throws std::runtime_error If @p data["server_ip"] is falsy/missing
   *         (required for every call, not just CONNECT — see @note
   *         below), if @p option is not one of the three vendors, or if
   *         the selected type/function_code is not recognized; and
   *         whatever the selected dispatch target itself throws.
   *
   * @note @p data["server_ip"] is required and validated even for calls
   *       that reuse an already-open connection (READ/WRITE/etc.) and
   *       never use its value — this matches the Python original's
   *       behavior, not a porting oversight.
   *
   * @note If @p alarm_fn is not provided and @p flow_manager_args is,
   *       this function resolves it by looking up "rb_program_sdk.alarm"
   *       in the PyFM context's SDK function registry. If that lookup
   *       also fails, or @p flow_manager_args is not provided either, any
   *       "ASK" resolve_option downstream effectively behaves like
   *       "SKIP" (no alarm is fired, since @p alarm_fn stays null).
   */
  void vision(const std::string& robot_model, const std::string& option, muscat::VisionInterfacePayloadUnion data,
              AlarmFn alarm_fn = nullptr, FlowManagerArgsPtr flow_manager_args = nullptr) {

    if (!flow_manager_args)
      return;
    if (!alarm_fn)
      alarm_fn = flow_manager_args->context().alarm_callback(robot_model);

    std::string module_name = rb_vision_util::get_task_id(flow_manager_args);

    if (option == "MECHMIND_INTERFACE") {
      auto* typed_payload = data.AsInterfaceMechMindPayload();
      if (!typed_payload)
        throw std::runtime_error("Vision(MechMind) Interface failed: payload type mismatch");
      muscat::InterfaceMechMindPayloadT& payload = *typed_payload;
      rb_vision_util::require(payload.server_ip, "server_ip", "Vision(MechMind) Interface failed");
      std::string op_type = payload.type;

      if (op_type == "READ") {
        IPC::State_CoreT stat_core = _get_state_core(robot_model);
        _execute_mechmind_read(mechmind_clients_.get(module_name), payload, stat_core, flow_manager_args, alarm_fn);
      } else if (op_type == "WRITE") {
        IPC::State_CoreT stat_core = _get_state_core(robot_model);
        _execute_mechmind_write(mechmind_clients_.get(module_name), payload, stat_core, flow_manager_args, alarm_fn);
      } else if (op_type == "CONNECT") {
        execute_mechmind_connect(module_name, payload, flow_manager_args, alarm_fn);
      } else {
        throw std::runtime_error("Vision(MechMind) Interface failed: type must be READ, WRITE, or CONNECT");
      }
    } else if (option == "PHOTONEO_INTERFACE") {
      auto* typed_payload = data.AsInterfacePhotoneoPayload();
      if (!typed_payload)
        throw std::runtime_error("Vision(Photoneo) Interface failed: payload type mismatch");
      muscat::InterfacePhotoneoPayloadT& payload = *typed_payload;
      rb_vision_util::require(payload.server_ip, "server_ip", "Vision(Photoneo) Interface failed");
      int function_code =
          rb_vision_util::require(payload.function_code, "function_code", "Vision(Photoneo) Interface failed");

      if (function_code == 99) {  // Create Connection
        execute_photoneo_connect(module_name, payload, flow_manager_args, alarm_fn);
      } else if (function_code == 0 || function_code == 1 || function_code == 4 || function_code == 5 ||
                 function_code == 6) {  // Initialize/Scan/Solution Change/Start/Stop
        IPC::State_CoreT stat_core = _get_state_core(robot_model);
        _execute_photoneo_write(photoneo_clients_.get(module_name), payload, stat_core, flow_manager_args, alarm_fn);
      } else if (function_code == 2 || function_code == 3 || function_code == 7) {
        // Get Object Pose/Get Trajectory/Solution Ask. point_variable_name/current_solution_id 는
        // "결과를 어디에 쓸지" 지정하는 변수-이름 필드라, 위 dict 캐스팅을 거친(PyFM 의 변수 치환이
        // 이미 적용된) payload 값을 그대로 쓰면 안 된다 — 원본(raw) args 값으로 덮어써서
        // _execute_photoneo_read 가 다른 필드처럼 그냥 믿고 쓰게 한다(flow_manager_args.hpp::
        // raw_data_field 주석 참고). Initialize/Move 등 다른 function_code 는 이 필드를 안 쓰므로
        // 이 분기 안에서만 덮어쓴다.
        if (flow_manager_args) {
          if (auto raw = (flow_manager_args ? flow_manager_args->raw_data_field("point_variable_name") : std::nullopt))
            payload.point_variable_name = *raw;
          if (auto raw = (flow_manager_args ? flow_manager_args->raw_data_field("current_solution_id") : std::nullopt))
            payload.current_solution_id = *raw;
        }

        _execute_photoneo_read(photoneo_clients_.get(module_name), payload, flow_manager_args, alarm_fn);
      } else if (function_code == 8) {  // Move (JB) through a stored trajectory
        IPC::State_CoreT stat_core = _get_state_core(robot_model);
        _execute_photoneo_move(payload, flow_manager_args, alarm_fn, robot_model, stat_core);
      } else {
        throw std::runtime_error("Vision(Photoneo) Interface failed: unsupported function_code=" +
                                 std::to_string(function_code));
      }
    } else if (option == "PICKIT_INTERFACE") {
      auto* typed_payload = data.AsInterfacePickitPayload();
      if (!typed_payload)
        throw std::runtime_error("Vision(Pickit) Interface failed: payload type mismatch");
      muscat::InterfacePickitPayloadT& payload = *typed_payload;
      rb_vision_util::require(payload.server_ip, "server_ip", "Vision(Pickit) Interface failed");
      int function_code =
          rb_vision_util::require(payload.function_code, "function_code", "Vision(Pickit) Interface failed");

      if (function_code == 99) {  // Create Connection
        execute_pickit_connect(module_name, payload, flow_manager_args, alarm_fn);
      } else if (function_code == 0 || function_code == 2 || function_code == 3 || function_code == 4 ||
                 function_code == 5 || function_code == 6 || function_code == 10 || function_code == 13 ||
                 function_code == 14 || function_code == 15 || function_code == 16 || function_code == 17 ||
                 function_code == 18) {
        IPC::State_CoreT stat_core = _get_state_core(robot_model);
        _execute_pickit_write(pickit_clients_.get(module_name), payload, stat_core, flow_manager_args, alarm_fn);
      } else if (function_code == 1 || function_code == 7 || function_code == 8 || function_code == 9 ||
                 function_code == 11 || function_code == 12) {
        // pick_point_name/remaining_count_name/model_id_or_type_name/gripper_pose_name/
        // reference_pick_point_id_name 은 전부 "결과를 어디에 쓸지" 지정하는 변수-이름 필드라, 위
        // dict 캐스팅을 거친(PyFM 의 변수 치환이 이미 적용된) payload 값을 그대로 쓰면 안 된다 —
        // 원본(raw) args 값으로 덮어써서 _execute_pickit_read 가 다른 필드처럼 그냥 믿고 쓰게 한다
        // (flow_manager_args.hpp::raw_data_field 주석 참고). Configure/Check Mode 등 다른
        // function_code 는 이 필드들을 안 쓰므로 이 분기 안에서만 덮어쓴다.
        if (flow_manager_args) {
          if (auto raw = (flow_manager_args ? flow_manager_args->raw_data_field("pick_point_name") : std::nullopt))
            payload.pick_point_name = *raw;
          if (auto raw = (flow_manager_args ? flow_manager_args->raw_data_field("remaining_count_name") : std::nullopt))
            payload.remaining_count_name = *raw;
          if (auto raw =
                  (flow_manager_args ? flow_manager_args->raw_data_field("model_id_or_type_name") : std::nullopt))
            payload.model_id_or_type_name = *raw;
          if (auto raw = (flow_manager_args ? flow_manager_args->raw_data_field("gripper_pose_name") : std::nullopt))
            payload.gripper_pose_name = *raw;
          if (auto raw = (flow_manager_args ? flow_manager_args->raw_data_field("reference_pick_point_id_name")
                                            : std::nullopt))
            payload.reference_pick_point_id_name = *raw;
        }

        IPC::State_CoreT stat_core = _get_state_core(robot_model);
        _execute_pickit_read(pickit_clients_.get(module_name), payload, stat_core, flow_manager_args, alarm_fn);
      } else {
        throw std::runtime_error("Vision(Pickit) Interface failed: unsupported function_code=" +
                                 std::to_string(function_code));
      }
    } else {
      throw std::runtime_error("Vision Interface failed: unsupported option=" + option);
    }
  }

 private:
  RBManipulateMoveSDK manipulate_move_sdk_;
};
