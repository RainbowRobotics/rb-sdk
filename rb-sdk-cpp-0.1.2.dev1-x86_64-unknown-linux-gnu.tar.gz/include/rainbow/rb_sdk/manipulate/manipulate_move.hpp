#pragma once

#include <atomic>
#include <iostream>
#include <memory>
#include <optional>
#include <string>
#include <thread>
#include <vector>

#include "base.hpp"
#include "common_struct_generated.h"
#include "func_config_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "move_speed_args.hpp"
#include "move_target_values_arg.hpp"
#include "state_core_generated.h"

#include "manipulate_get_data.hpp"

class RBManipulateMoveSDK : public RBBaseSDK {
 public:
  RBManipulateMoveSDK() {}

  static std::string type_name() { return "RBManipulateMoveSDK"; }

  /**
   * @brief Requests the cobot to start a J-type (joint-space) movement.
   *
   * Supports J-type (joint-space) movement of the cobot: the target is given
   * as a per-joint angle set, and each joint moves independently toward its
   * target angle, so the resulting end-effector path is not constrained to
   * a straight line (as opposed to L-type movement). If reference joint
   * values are provided, the target is calculated as a relative movement
   * from the reference position.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. When
   *        @p reference_value is provided, tar_values must have exactly 7
   *        elements (the underlying relative-value calculation rejects any
   *        other length).
   * @param reference_value Optional reference joint values used for
   *        relative movement calculation. Must have exactly 7 elements
   *        when provided — e.g. [0, 0, 0, 0, 0, 0, 0].
   * @param speed Optional movement speed parameters.
   * @param ext_axis Optional external axis values.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager and completion is
   *        handled asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the movement request result.
   *
   * @throws std::runtime_error If relative movement calculation fails,
   *         or if the movement result cannot be retrieved.
   *
   * @note If @p speed is not provided, the default values are:
   *       spd_mode = 1, spd_vel_para = 60, spd_acc_para = 120.
   *
   * @note If @p flow_manager_args is provided, this function returns
   *       immediately after submitting the request; a background monitor
   *       waits for the actual motion-completion signal from the robot
   *       before invoking the flow manager's completion callback.
   */
  IPC::Response_FunctionsT call_move_j(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                       std::optional<std::vector<float>> reference_value,
                                       std::optional<MoveSpeedArg> speed,
                                       std::optional<std::vector<float>> ext_axis = std::nullopt,
                                       FlowManagerArgsPtr flow_manager_args = nullptr) {
    // relative move 계산
    if (reference_value) {
      auto _relative_res = _get_data_sdk.get_relative_value(
          robot_model, target,
          IPC::MoveInput_TargetT{.tar_values = reference_value.value(), .tar_frame = 0, .tar_unit = 0}, 0,
          flow_manager_args);

      if (_relative_res.calculated_result != 0) {
        throw std::runtime_error(
            "Relative move value getting failed at call_move_j: "
            "calculated_result=" +
            std::to_string(_relative_res.calculated_result));
      }
      target.tar_values = _relative_res.calculated_value->tar_values;

      target.tar_frame = _relative_res.calculated_value->tar_frame;

      target.tar_unit = _relative_res.calculated_value->tar_unit;
    }

    // request 생성
    IPC::Request_Move_JT req;

    auto target_fb = std::make_unique<IPC::MoveInput_TargetT>();

    auto speed_fb = std::make_unique<IPC::MoveInput_SpeedT>();

    target_fb->tar_values = target.tar_values;
    target_fb->tar_frame = target.tar_frame;
    target_fb->tar_unit = target.tar_unit;

    // Python 원본과 동일: speed(및 그 개별 필드)가 없으면 60/120 기본값을 쓴다.
    const MoveSpeedArg speed_arg = speed.value_or(MoveSpeedArg{});
    speed_fb->spd_mode = speed_arg.spd_mode.value_or(1);
    speed_fb->spd_vel_para = speed_arg.spd_vel_para.value_or(60);
    speed_fb->spd_acc_para = speed_arg.spd_acc_para.value_or(120);

    if (ext_axis) {
      req.ext_axis = *ext_axis;
    }

    req.target = std::move(target_fb);
    req.speed = std::move(speed_fb);
    // query
    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Move_JT>(robot_model + "/call_move_j", req, 256, 2000, 0);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Move J", std::move(*result), "call_move_j",
                                                          flow_manager_args);
  }

  /**
   * @brief Requests the cobot to start an L-type (linear/Cartesian-space) movement.
   *
   * Supports L-type (linear/Cartesian-space) movement of the cobot: the
   * target is given as a Cartesian pose, and the end-effector moves in a
   * straight line to that pose (as opposed to J-type movement). If
   * reference_value is provided, the target is calculated as a relative
   * movement from the reference position.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. tar_values is
   *        [x, y, z, rx, ry, rz, aa] for 7-axis models, or
   *        [x, y, z, rx, ry, rz] for 6-axis models (aa = ArmAngle). When
   *        @p reference_value is provided, tar_values must have exactly 7
   *        elements regardless of axis count (pad with 0 for a 6-axis
   *        model's unused aa slot) — the underlying relative-value
   *        calculation rejects any other length.
   * @param reference_value Optional reference target used for relative
   *        movement calculation, in the same [x, y, z, rx, ry, rz(, aa)]
   *        format as @p target. Must have exactly 7 elements when
   *        provided, regardless of axis count.
   * @param speed Optional movement speed parameters.
   * @param ext_axis Optional external axis values.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager and completion is
   *        handled asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the movement request result.
   *
   * @throws std::runtime_error If relative movement calculation fails,
   *         or if the movement result cannot be retrieved.
   *
   * @note If @p speed is not provided, the default values are:
   *       spd_mode = 1, spd_vel_para = 60, spd_acc_para = 120.
   *
   * @note If @p flow_manager_args is provided, this function returns
   *       immediately after submitting the request; a background monitor
   *       waits for the actual motion-completion signal from the robot
   *       before invoking the flow manager's completion callback.
   */
  IPC::Response_FunctionsT call_move_l(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                       std::optional<std::vector<float>> reference_value,
                                       std::optional<MoveSpeedArg> speed,
                                       std::optional<std::vector<float>> ext_axis = std::nullopt,
                                       FlowManagerArgsPtr flow_manager_args = nullptr) {
    // relative move 계산
    if (reference_value) {
      auto _relative_res = _get_data_sdk.get_relative_value(
          robot_model, target,
          IPC::MoveInput_TargetT{.tar_values = reference_value.value(), .tar_frame = 0, .tar_unit = 0}, 1,
          flow_manager_args);

      if (_relative_res.calculated_result != 0) {
        throw std::runtime_error(
            "Relative move value getting failed at call_move_l: "
            "calculated_result=" +
            std::to_string(_relative_res.calculated_result));
      }
      target.tar_values = _relative_res.calculated_value->tar_values;

      target.tar_frame = _relative_res.calculated_value->tar_frame;

      target.tar_unit = _relative_res.calculated_value->tar_unit;
    }

    // request 생성
    IPC::Request_Move_LT req;

    auto target_fb = std::make_unique<IPC::MoveInput_TargetT>();

    auto speed_fb = std::make_unique<IPC::MoveInput_SpeedT>();

    target_fb->tar_values = target.tar_values;
    target_fb->tar_frame = target.tar_frame;
    target_fb->tar_unit = target.tar_unit;

    // Python 원본과 동일: speed(및 그 개별 필드)가 없으면 250/1000 기본값을 쓴다.
    const MoveSpeedArg speed_arg = speed.value_or(MoveSpeedArg{});
    speed_fb->spd_mode = speed_arg.spd_mode.value_or(1);
    speed_fb->spd_vel_para = speed_arg.spd_vel_para.value_or(250);
    speed_fb->spd_acc_para = speed_arg.spd_acc_para.value_or(1000);

    if (ext_axis) {
      req.ext_axis = *ext_axis;
    }

    req.target = std::move(target_fb);
    req.speed = std::move(speed_fb);

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Move_LT>(robot_model + "/call_move_l", req, 256, 2000, 0);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Move L", std::move(*result), "call_move_l",
                                                          flow_manager_args);
  }

  /**
   * @brief Requests the cobot to clear its queued joint-blend movement commands.
   *
   * Clears the internal list of joint-blend move segments previously
   * accumulated via @c call_move_jb_add, so a new joint-blend sequence can be
   * started from scratch.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        blend command list is cleared and completion is reported to the
   *        flow manager immediately (synchronous), unlike move commands
   *        whose completion is tracked asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the clear request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_move_jb_clr(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Move_JB_CLRT req;

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_JB_CLRT>(
        robot_model + "/call_move_jb_clr", req, 8, 2000, 0);

    manipulate_return_value("call_move_jb_clr", *result, flow_manager_args);

    if (flow_manager_args) {
      _blended_add_list.clear();
      flow_manager_args->done();
    }

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to add a segment to the queued joint-blend movement sequence.
   *
   * Appends one joint-space segment to the internal blend list built up
   * across successive calls; the queued segments run together once
   * @c call_move_jb_run is invoked. If reference joint values are provided,
   * the segment's target is calculated as a relative movement from the
   * reference position.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. When
   *        @p reference_value is provided, tar_values must have exactly 7
   *        elements (the underlying relative-value calculation rejects any
   *        other length).
   * @param reference_value Optional reference joint values used for
   *        relative movement calculation. Must have exactly 7 elements
   *        when provided — e.g. [0, 0, 0, 0, 0, 0, 0].
   * @param speed Optional movement speed parameters.
   * @param blend_type Blend transition parameters. pnt_type is 0 (Percentage)
   *        or 1 (Distance); pnt_para is a percentage when pnt_type is 0, or
   *        millimeters when pnt_type is 1.
   * @param ext_axis Optional external axis values.
   * @param flow_manager_args Optional PyFM step context. If provided, this
   *        segment is recorded for the blend sequence and completion is
   *        reported to the flow manager immediately (synchronous), unlike
   *        run commands whose completion is tracked asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the add request result.
   *
   * @throws std::runtime_error If relative movement calculation fails,
   *         or if the add request result cannot be retrieved.
   *
   * @note If @p speed is not provided, the default values are:
   *       spd_mode = 1, spd_vel_para = 60, spd_acc_para = 120.
   */
  IPC::Response_FunctionsT call_move_jb_add(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                            std::optional<std::vector<float>> reference_value,
                                            std::optional<MoveSpeedArg> speed,
                                            const IPC::MoveInput_TypeT& blend_type,
                                            std::optional<std::vector<float>> ext_axis = std::nullopt,
                                            FlowManagerArgsPtr flow_manager_args = nullptr) {
    // relative move 계산
    if (reference_value) {
      auto _relative_res = _get_data_sdk.get_relative_value(
          robot_model, target,
          IPC::MoveInput_TargetT{.tar_values = reference_value.value(), .tar_frame = -1, .tar_unit = 0}, 0,
          flow_manager_args);

      if (_relative_res.calculated_result != 0) {
        throw std::runtime_error(
            "Relative move value getting failed at call_move_jb_add: "
            "calculated_result=" +
            std::to_string(_relative_res.calculated_result));
      }

      target.tar_values = _relative_res.calculated_value->tar_values;

      target.tar_frame = _relative_res.calculated_value->tar_frame;

      target.tar_unit = _relative_res.calculated_value->tar_unit;
    }

    // request 생성
    IPC::Request_Move_JB_ADDT req;

    auto target_fb = std::make_unique<IPC::MoveInput_TargetT>();

    auto speed_fb = std::make_unique<IPC::MoveInput_SpeedT>();

    auto type_fb = std::make_unique<IPC::MoveInput_TypeT>();

    target_fb->tar_values = target.tar_values;
    target_fb->tar_frame = target.tar_frame;
    target_fb->tar_unit = target.tar_unit;

    // Python 원본과 동일: speed(및 그 개별 필드)가 없으면 60/120 기본값을 쓴다.
    const MoveSpeedArg speed_arg = speed.value_or(MoveSpeedArg{});
    speed_fb->spd_mode = speed_arg.spd_mode.value_or(1);
    speed_fb->spd_vel_para = speed_arg.spd_vel_para.value_or(60);
    speed_fb->spd_acc_para = speed_arg.spd_acc_para.value_or(120);

    type_fb->pnt_para = blend_type.pnt_para;
    type_fb->pnt_type = blend_type.pnt_type;

    req.target = std::move(target_fb);
    req.speed = std::move(speed_fb);
    req.type = std::move(type_fb);

    if (ext_axis) {
      req.ext_axis = *ext_axis;
    }

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_JB_ADDT>(
        robot_model + "/call_move_jb_add", req, 400, 2000, 0);

    if (!result)
      throw std::runtime_error("Call Move Jb Add failed: query one returned nullptr");

    manipulate_return_value("call_move_jb_add", *result, flow_manager_args);

    if (flow_manager_args) {
      _blended_param_add(flow_manager_args);
      flow_manager_args->done();
    }

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to execute the queued joint-blend movement sequence.
   *
   * Runs the sequence of joint-space segments previously accumulated via
   * @c call_move_jb_add.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the run request result.
   *
   * @throws std::runtime_error If the query fails or the run request result
   *         cannot be retrieved.
   */
  IPC::Response_FunctionsT call_move_jb_run(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Move_JB_RUNT req;

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_JB_RUNT>(
        robot_model + "/call_move_jb_run", req, 8, 2000, 0);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Move JB Run", std::move(*result),
                                                          "call_move_jb_run", flow_manager_args);
  }

  /**
   * @brief Requests the cobot to clear its queued linear-blend movement commands.
   *
   * Clears the internal list of linear-blend (Cartesian-space) move segments
   * previously accumulated via @c call_move_lb_add, so a new linear-blend
   * sequence can be started from scratch.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        blend command list is cleared and completion is reported to the
   *        flow manager immediately (synchronous), unlike move commands
   *        whose completion is tracked asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the clear request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_move_lb_clr(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Move_LB_CLRT req;

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_LB_CLRT>(
        robot_model + "/call_move_lb_clr", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("Call Move Lb Clr failed: query one returned nullptr");

    manipulate_return_value("call_move_lb_clr", *result, flow_manager_args);

    if (flow_manager_args) {
      _blended_add_list.clear();
      flow_manager_args->done();
    }

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to add a segment to the queued linear-blend movement sequence.
   *
   * Appends one Cartesian-space segment to the internal blend list built up
   * across successive calls; the queued segments run together once
   * @c call_move_lb_run is invoked. If reference_value is provided, the
   * segment's target is calculated as a relative movement from the
   * reference position.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. tar_values is
   *        [x, y, z, rx, ry, rz, aa] for 7-axis models, or
   *        [x, y, z, rx, ry, rz] for 6-axis models (aa = ArmAngle). When
   *        @p reference_value is provided, tar_values must have exactly 7
   *        elements regardless of axis count (pad with 0 for a 6-axis
   *        model's unused aa slot) — the underlying relative-value
   *        calculation rejects any other length.
   * @param reference_value Optional reference target used for relative
   *        movement calculation, in the same [x, y, z, rx, ry, rz(, aa)]
   *        format as @p target. Must have exactly 7 elements when
   *        provided, regardless of axis count.
   * @param speed Optional movement speed parameters.
   * @param blend_type Blend transition parameters. pnt_type is 0 (Percentage)
   *        or 1 (Distance); pnt_para is a percentage when pnt_type is 0, or
   *        millimeters when pnt_type is 1.
   * @param ext_axis Optional external axis values.
   * @param flow_manager_args Optional PyFM step context. If provided, this
   *        segment is recorded for the blend sequence and completion is
   *        reported to the flow manager immediately (synchronous), unlike
   *        run commands whose completion is tracked asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the add request result.
   *
   * @throws std::runtime_error If relative movement calculation fails,
   *         or if the add request result cannot be retrieved.
   *
   * @note If @p speed is not provided, the default values are:
   *       spd_mode = 1, spd_vel_para = 60, spd_acc_para = 120.
   */
  IPC::Response_FunctionsT call_move_lb_add(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                            std::optional<std::vector<float>> reference_value,
                                            std::optional<MoveSpeedArg> speed,
                                            const IPC::MoveInput_TypeT& blend_type,
                                            std::optional<std::vector<float>> ext_axis = std::nullopt,
                                            FlowManagerArgsPtr flow_manager_args = nullptr) {
    // relative move 계산
    if (reference_value) {
      auto _relative_res = _get_data_sdk.get_relative_value(
          robot_model, target,
          IPC::MoveInput_TargetT{.tar_values = reference_value.value(), .tar_frame = 0, .tar_unit = 0}, 1,
          flow_manager_args);

      if (_relative_res.calculated_result != 0) {
        throw std::runtime_error(
            "Relative move value getting failed at call_move_lb_add: "
            "calculated_result=" +
            std::to_string(_relative_res.calculated_result));
      }

      target.tar_values = _relative_res.calculated_value->tar_values;

      target.tar_frame = _relative_res.calculated_value->tar_frame;

      target.tar_unit = _relative_res.calculated_value->tar_unit;
    }

    // request 생성
    IPC::Request_Move_LB_ADDT req;

    auto target_fb = std::make_unique<IPC::MoveInput_TargetT>();

    auto speed_fb = std::make_unique<IPC::MoveInput_SpeedT>();

    auto type_fb = std::make_unique<IPC::MoveInput_TypeT>();

    target_fb->tar_values = target.tar_values;
    target_fb->tar_frame = target.tar_frame;
    target_fb->tar_unit = target.tar_unit;

    // Python 원본과 동일: speed(및 그 개별 필드)가 없으면 250/1000 기본값을 쓴다.
    const MoveSpeedArg speed_arg = speed.value_or(MoveSpeedArg{});
    speed_fb->spd_mode = speed_arg.spd_mode.value_or(1);
    speed_fb->spd_vel_para = speed_arg.spd_vel_para.value_or(250);
    speed_fb->spd_acc_para = speed_arg.spd_acc_para.value_or(1000);

    type_fb->pnt_para = blend_type.pnt_para;
    type_fb->pnt_type = blend_type.pnt_type;

    req.target = std::move(target_fb);
    req.speed = std::move(speed_fb);
    req.type = std::move(type_fb);

    if (ext_axis) {
      req.ext_axis = *ext_axis;
    }

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_LB_ADDT>(
        robot_model + "/call_move_lb_add", req, 400, 2000, 0);

    if (!result)
      throw std::runtime_error("Call Move Lb Add failed: query one returned nullptr");

    manipulate_return_value("call_move_lb_add", *result, flow_manager_args);

    if (flow_manager_args) {
      _blended_param_add(flow_manager_args);
      flow_manager_args->done();
    }

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to execute the queued linear-blend movement sequence.
   *
   * Runs the sequence of Cartesian-space segments previously accumulated via
   * @c call_move_lb_add.
   *
   * @param robot_model Name of the robot model.
   * @param orientation Orientation option for the blended path.
   *        (0: Intended, 1: Constant)
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the run request result.
   *
   * @throws std::runtime_error If the query fails or the run request result
   *         cannot be retrieved.
   */
  IPC::Response_FunctionsT call_move_lb_run(const std::string& robot_model, const int orientation,
                                            FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Move_LB_RUNT req;
    req.orientation = orientation;

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_LB_RUNT>(
        robot_model + "/call_move_lb_run", req, 8, 2000, 0);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Move LB Run", std::move(*result),
                                                          "call_move_lb_run", flow_manager_args);
  }

  /**
   * @brief Requests the cobot to clear its queued XB-type blend movement commands.
   *
   * Clears the internal list of XB-type blend move segments previously
   * accumulated via @c call_move_xb_add, so a new blend sequence can be
   * started from scratch.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        blend command list is cleared and completion is reported to the
   *        flow manager immediately (synchronous), unlike move commands
   *        whose completion is tracked asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the clear request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_move_xb_clr(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Move_XB_CLRT req;

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_XB_CLRT>(
        robot_model + "/call_move_xb_clr", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("Call Move Xb Clr failed: query one returned nullptr");

    manipulate_return_value("call_move_xb_clr", *result, flow_manager_args);

    if (flow_manager_args) {
      _blended_add_list.clear();
      flow_manager_args->done();
    }

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to add a segment to the queued XB-type blend movement sequence.
   *
   * Appends one segment to the internal blend list built up across
   * successive calls; the queued segments run together once
   * @c call_move_xb_run is invoked.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param speed Movement speed parameters.
   * @param blend_type Blend transition parameters. pnt_type is 0 (Percentage)
   *        or 1 (Distance); pnt_para is a percentage when pnt_type is 0, or
   *        millimeters when pnt_type is 1.
   * @param method Motion (movement) type option
   *        (0: Joint movement, 1: Linear movement).
   * @param flow_manager_args Optional PyFM step context. If provided, this
   *        segment is recorded for the blend sequence and completion is
   *        reported to the flow manager immediately (synchronous), unlike
   *        run commands whose completion is tracked asynchronously.
   *
   * @return IPC::Response_FunctionsT containing the add request result.
   *
   * @throws std::runtime_error If the add request result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_move_xb_add(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                            const MoveSpeedArg& speed, const IPC::MoveInput_TypeT& blend_type,
                                            const int method, FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Move_XB_ADDT req;

    auto target_fb = std::make_unique<IPC::MoveInput_TargetT>();

    auto speed_fb = std::make_unique<IPC::MoveInput_SpeedT>();

    auto type_fb = std::make_unique<IPC::MoveInput_TypeT>();

    target_fb->tar_values = target.tar_values;
    target_fb->tar_frame = target.tar_frame;
    target_fb->tar_unit = target.tar_unit;

    // Python 원본과 동일: speed 의 개별 필드가 없으면 250/1000 기본값을 쓴다.
    speed_fb->spd_mode = speed.spd_mode.value_or(1);
    speed_fb->spd_vel_para = speed.spd_vel_para.value_or(250);
    speed_fb->spd_acc_para = speed.spd_acc_para.value_or(1000);

    type_fb->pnt_para = blend_type.pnt_para;
    type_fb->pnt_type = blend_type.pnt_type;

    req.target = std::move(target_fb);
    req.speed = std::move(speed_fb);
    req.type = std::move(type_fb);

    req.method = method;

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_XB_ADDT>(
        robot_model + "/call_move_xb_add", req, 256, 2000, 0);

    if (!result)
      throw std::runtime_error("Call Move Xb Add failed: query one returned nullptr");

    manipulate_return_value("call_move_xb_add", *result, flow_manager_args);

    if (flow_manager_args) {
      _blended_param_add(flow_manager_args);
      flow_manager_args->done();
    }

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to execute the queued XB-type blend movement sequence.
   *
   * Runs the sequence of segments previously accumulated via
   * @c call_move_xb_add.
   *
   * @param robot_model Name of the robot model.
   * @param running_mode Execution mode option for the blended run.
   *        (0: Velocity Blending, 1: Position Blending)
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the run request result.
   *
   * @throws std::runtime_error If the query fails or the run request result
   *         cannot be retrieved.
   */
  IPC::Response_FunctionsT call_move_xb_run(const std::string& robot_model, int running_mode,
                                            FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Move_XB_RUNT req;
    req.running_mode = running_mode;

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_XB_RUNT>(
        robot_model + "/call_move_xb_run", req, 8, 2000, 0);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Move XB Run", std::move(*result),
                                                          "call_move_xb_run", flow_manager_args);
  }

  /**
   * @brief Requests the cobot to start continuous joint-space jog motion toward a target.
   *
   * Starts jog-style motion in joint space toward @p target; unlike a
   * regular move command, motion continues until stopped via
   * @c call_smoothjog_stop.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param ext_axis Optional external axis values.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the jog command is accepted.
   *
   * @return IPC::Response_FunctionsT containing the jog request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_smoothjog_j(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                            std::optional<std::vector<float>> ext_axis = std::nullopt,
                                            FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Move_SmoothJogJT req;

    auto target_fb = std::make_unique<IPC::MoveInput_TargetT>();

    target_fb->tar_values = target.tar_values;
    target_fb->tar_frame = target.tar_frame;
    target_fb->tar_unit = target.tar_unit;

    if (ext_axis) {
      req.ext_axis = (*ext_axis);
    }

    req.target = std::move(target_fb);

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Move_SmoothJogJT>(robot_model + "/call_smoothjog_j", req, 256,
                                                                          1000, 0);

    if (!result)
      throw std::runtime_error("Smooth Jog J failed: query one returned nulltpr");

    manipulate_return_value("call_smoothjog_j", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to start continuous Cartesian-space jog motion toward a target.
   *
   * Starts jog-style motion in Cartesian space toward @p target; unlike a
   * regular move command, motion continues until stopped via
   * @c call_smoothjog_stop.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. tar_values is
   *        [x, y, z, rx, ry, rz, aa] for 7-axis models, or
   *        [x, y, z, rx, ry, rz] for 6-axis models (aa = ArmAngle).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the jog command is accepted.
   *
   * @return IPC::Response_FunctionsT containing the jog request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_smoothjog_l(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                            FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Move_SmoothJogLT req;

    auto target_fb = std::make_unique<IPC::MoveInput_TargetT>();

    target_fb->tar_values = target.tar_values;
    target_fb->tar_frame = target.tar_frame;
    target_fb->tar_unit = target.tar_unit;

    req.target = std::move(target_fb);

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Move_SmoothJogLT>(robot_model + "/call_smoothjog_l", req, 256,
                                                                          1000, 0);

    if (!result)
      throw std::runtime_error("Smooth Jog L failed: query one returned nulltpr");

    manipulate_return_value("call_smoothjog_l", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to decelerate and stop an active smooth-jog motion.
   *
   * Stops motion previously started by @c call_smoothjog_j / @c call_smoothjog_l.
   *
   * @param robot_model Name of the robot model.
   * @param stop_time Deceleration time, in seconds, used to bring the jog
   *        motion to a stop.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the stop command is accepted.
   *
   * @return IPC::Response_FunctionsT containing the stop request result.
   *
   * @throws std::runtime_error If the query fails, no payload is returned,
   *         or the response's return_value is nonzero.
   */
  IPC::Response_FunctionsT call_smoothjog_stop(const std::string& robot_model, const float stop_time,
                                               FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Move_SmoothJogStopT req;
    req.stoptime = stop_time;

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Move_SmoothJogStopT>(robot_model + "/call_smoothjog_stop", req,
                                                                             8, 1000, 0);

    if (!result)
      throw std::runtime_error("Smooth Jog Stop failed: query one returned nulltpr");

    return validate_single_return_value<IPC::Response_FunctionsT>(
        std::optional<IPC::Response_FunctionsT>{std::move(*result)}, flow_manager_args);
  }

  /**
   * @brief Requests the cobot to move a single joint-space tick step toward a target.
   *
   * Unlike @c call_smoothjog_j's continuous motion, this moves the cobot by
   * a single discrete tick increment in joint space toward @p target.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param speed Movement speed parameters.
   * @param ext_axis Optional external axis values.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the tick-jog request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_tickjog_j(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                          const MoveSpeedArg& speed,
                                          std::optional<std::vector<float>> ext_axis = std::nullopt,
                                          FlowManagerArgsPtr flow_manager_args = nullptr) {

    // request 생성
    IPC::Request_Move_TickJogJT req;

    auto target_fb = std::make_unique<IPC::MoveInput_TargetT>();

    auto speed_fb = std::make_unique<IPC::MoveInput_SpeedT>();

    target_fb->tar_values = target.tar_values;
    target_fb->tar_frame = target.tar_frame;
    target_fb->tar_unit = target.tar_unit;

    // Python 원본과 동일: speed 의 개별 필드가 없으면 60/120 기본값을 쓴다.
    speed_fb->spd_mode = speed.spd_mode.value_or(1);
    speed_fb->spd_vel_para = speed.spd_vel_para.value_or(60);
    speed_fb->spd_acc_para = speed.spd_acc_para.value_or(120);

    if (ext_axis) {
      req.ext_axis = (*ext_axis);
    }

    req.target = std::move(target_fb);
    req.speed = std::move(speed_fb);

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_TickJogJT>(
        robot_model + "/call_tickjog_j", req, 8, 2000, 0);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Tick Jog J", std::move(*result),
                                                          "call_tickjog_j", flow_manager_args);
  }

  /**
   * @brief Requests the cobot to move a single Cartesian-space tick step toward a target.
   *
   * Unlike @c call_smoothjog_l's continuous motion, this moves the cobot by
   * a single discrete tick increment in Cartesian space toward @p target.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. tar_values is
   *        [x, y, z, rx, ry, rz, aa] for 7-axis models, or
   *        [x, y, z, rx, ry, rz] for 6-axis models (aa = ArmAngle).
   * @param speed Movement speed parameters.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the tick-jog request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_tickjog_l(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                          const MoveSpeedArg& speed,
                                          FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Move_TickJogLT req;

    auto target_fb = std::make_unique<IPC::MoveInput_TargetT>();

    auto speed_fb = std::make_unique<IPC::MoveInput_SpeedT>();

    target_fb->tar_values = target.tar_values;
    target_fb->tar_frame = target.tar_frame;
    target_fb->tar_unit = target.tar_unit;

    // Python 원본과 동일: speed 의 개별 필드가 없으면 60/120 기본값을 쓴다.
    speed_fb->spd_mode = speed.spd_mode.value_or(1);
    speed_fb->spd_vel_para = speed.spd_vel_para.value_or(60);
    speed_fb->spd_acc_para = speed.spd_acc_para.value_or(120);

    req.target = std::move(target_fb);
    req.speed = std::move(speed_fb);

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_TickJogLT>(
        robot_model + "/call_tickjog_l", req, 8, 2000, 0);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Tick Jog L", std::move(*result),
                                                          "call_tickjog_l", flow_manager_args);
  }

  /**
   * @brief Requests the cobot to start an Approach-J joint-space movement.
   *
   * Sends the same underlying request shape as @c call_move_j; the two are
   * distinguished only by the calling context.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param speed Movement speed parameters.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the movement result is received.
   *
   * @return IPC::Response_FunctionsT containing the movement request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_approach_j(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                           const MoveSpeedArg& speed,
                                           FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Move_ApproachJT req;

    auto target_fb = std::make_unique<IPC::MoveInput_TargetT>();

    auto speed_fb = std::make_unique<IPC::MoveInput_SpeedT>();

    target_fb->tar_values = target.tar_values;
    target_fb->tar_frame = target.tar_frame;
    target_fb->tar_unit = target.tar_unit;

    // Python 원본과 동일: speed 의 개별 필드가 없으면 60/120 기본값을 쓴다.
    speed_fb->spd_mode = speed.spd_mode.value_or(1);
    speed_fb->spd_vel_para = speed.spd_vel_para.value_or(60);
    speed_fb->spd_acc_para = speed.spd_acc_para.value_or(120);

    req.target = std::move(target_fb);
    req.speed = std::move(speed_fb);

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_ApproachJT>(
        robot_model + "/call_approach_j", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("Call Approach J failed: query one returned nullptr");

    manipulate_return_value("call_approach_j", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to start an Approach-L Cartesian-space movement.
   *
   * Sends the same underlying request shape as @c call_move_l; the two are
   * distinguished only by the calling context.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information. tar_values is
   *        [x, y, z, rx, ry, rz, aa] for 7-axis models, or
   *        [x, y, z, rx, ry, rz] for 6-axis models (aa = ArmAngle).
   * @param speed Movement speed parameters.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the movement result is received.
   *
   * @return IPC::Response_FunctionsT containing the movement request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_approach_l(const std::string& robot_model, IPC::MoveInput_TargetT target,
                                           const MoveSpeedArg& speed,
                                           FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Move_ApproachLT req;

    auto target_fb = std::make_unique<IPC::MoveInput_TargetT>();

    auto speed_fb = std::make_unique<IPC::MoveInput_SpeedT>();

    target_fb->tar_values = target.tar_values;
    target_fb->tar_frame = target.tar_frame;
    target_fb->tar_unit = target.tar_unit;

    // Python 원본과 동일: speed 의 개별 필드가 없으면 250/1000 기본값을 쓴다.
    speed_fb->spd_mode = speed.spd_mode.value_or(1);
    speed_fb->spd_vel_para = speed.spd_vel_para.value_or(250);
    speed_fb->spd_acc_para = speed.spd_acc_para.value_or(1000);

    req.target = std::move(target_fb);
    req.speed = std::move(speed_fb);

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_ApproachLT>(
        robot_model + "/call_approach_l", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("Call Approach L failed: query one returned nullptr");

    manipulate_return_value("call_approach_l", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to stop an active Approach movement.
   *
   * Sends the same underlying request shape as @c call_smoothjog_stop; the
   * two are distinguished only by the calling context.
   *
   * @param robot_model Name of the robot model.
   * @param stop_time Deceleration time, in seconds, used to bring the
   *        movement to a stop.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the stop command is accepted.
   *
   * @return IPC::Response_FunctionsT containing the stop request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_approach_stop(const std::string& robot_model, const float stop_time,
                                              FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Move_ApproachStopT req;
    req.stoptime = stop_time;

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Move_ApproachStopT>(robot_model + "/call_approach_stop", req, 8,
                                                                            1000, 0);

    if (!result)
      throw std::runtime_error("Call Approach Stop failed: query one returned nullptr");

    manipulate_return_value("call_approach_stop", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to stop TCP weaving.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_tcp_weaving_off(const std::string& robot_model,
                                                FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Wrapper_TcpWeave_OffT req;

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_TcpWeave_OffT>(robot_model + "/call_tcp_weaving_off",
                                                                               req, 8, 1000, 0);

    if (!result)
      throw std::runtime_error("Call TCP Weaving Off failed: query one returned nullptr");

    manipulate_return_value("call_tcp_weaving_off", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to start TCP weaving on the current move.
   *
   * @param robot_model Name of the robot model.
   * @param type Weave pattern: 0 None, 1 Trapezoidal, 2 Sine wave, 3
   *        Polynomial, 4 Ellipse, 5 8-Shape, 6 Lissajous, 7 C-Shape, 8
   *        Diagonal.
   * @param axis_torch Torch direction axis.
   * @param axis_weave Weaving direction axis.
   * @param plane_option Weaving plane: 0 Present TCP Frame, 1 Follow
   *        base-trajectory.
   * @param user_rx User orientation Rx, in degrees.
   * @param user_ry User orientation Ry, in degrees.
   * @param user_rz User orientation Rz, in degrees.
   * @param magnitude_1 First weave magnitude, in mm.
   * @param magnitude_2 Second weave magnitude, in mm.
   * @param phase_1 First weave phase.
   * @param phase_2 Second weave phase.
   * @param time_1 Time schedule segment 1, in seconds.
   * @param time_2 Time schedule segment 2, in seconds.
   * @param time_3 Time schedule segment 3, in seconds.
   * @param time_4 Time schedule segment 4, in seconds.
   * @param time_5 Time schedule segment 5, in seconds.
   * @param time_6 Time schedule segment 6, in seconds.
   * @param time_7 Time schedule segment 7, in seconds.
   * @param time_8 Time schedule segment 8, in seconds.
   * @param scale_rate Weave scale multiplier (default 1).
   * @param offset_torch Offset along the torch direction, in mm.
   * @param offset_weave Offset along the weaving direction, in mm.
   * @param swing_ang Swing angle, in degrees.
   * @param distortion Distortion angle, in degrees.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_tcp_weaving_on(
      const std::string& robot_model, const int type, const int axis_torch, const int axis_weave,
      const int plane_option, const float user_rx, const float user_ry, const float user_rz, const float magnitude_1,
      const float magnitude_2, const float phase_1, const float phase_2, const float time_1, const float time_2,
      const float time_3, const float time_4, const float time_5, const float time_6, const float time_7,
      const float time_8, const float scale_rate, const float offset_torch, const float offset_weave,
      const float swing_ang, const float distortion, FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Wrapper_TcpWeave_OnT req;

    req.type = type;
    req.axis_torch = axis_torch;
    req.axis_weave = axis_weave;
    req.plane_option = plane_option;
    req.user_rx = user_rx;
    req.user_ry = user_ry;
    req.user_rz = user_rz;
    req.magnitude_1 = magnitude_1;
    req.magnitude_2 = magnitude_2;
    req.phase_1 = phase_1;
    req.phase_2 = phase_2;
    req.time_1 = time_1;
    req.time_2 = time_2;
    req.time_3 = time_3;
    req.time_4 = time_4;
    req.time_5 = time_5;
    req.time_6 = time_6;
    req.time_7 = time_7;
    req.time_8 = time_8;
    req.scale_rate = scale_rate;
    req.offset_torch = offset_torch;
    req.offset_weave = offset_weave;
    req.swing_ang = swing_ang;
    req.distortion = distortion;

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_TcpWeave_OnT>(robot_model + "/call_tcp_weaving_on", req,
                                                                              8, 1000, 0);

    if (!result)
      throw std::runtime_error("Call TCP Weaving On failed: query one returned nullptr");

    manipulate_return_value("call_tcp_weaving_on", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to stop base conveyor tracking.
   *
   * @param robot_model Name of the robot model.
   * @param stop_time_sec Deceleration time, in seconds.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_base_conveyor_off(const std::string& robot_model, const float stop_time_sec,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Wrapper_Conveyor_OffT req;
    req.stop_time_sec = stop_time_sec;

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_Conveyor_OffT>(robot_model + "/call_base_conveyor_off",
                                                                               req, 8, 10000, 0);

    if (!result)
      throw std::runtime_error("Call Base Conveyor Off failed: query one returned nullptr");

    manipulate_return_value("call_base_conveyor_off", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to change the base conveyor's tracking speed.
   *
   * @param robot_model Name of the robot model.
   * @param conv_speed Conveyor speed, in mm/s.
   * @param conv_acc_time_sec Speed adjustment time, in seconds.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_base_conveyor_speed(const std::string& robot_model, const float conv_speed,
                                                    const float conv_acc_time_sec,
                                                    FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Wrapper_Conveyor_SpeedT req;
    req.conv_speed = conv_speed;
    req.conv_acc_time_sec = conv_acc_time_sec;

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_Conveyor_SpeedT>(
            robot_model + "/call_base_conveyor_speed", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("Call Base Conveyor Speed failed: query one returned nullptr");

    manipulate_return_value("call_base_conveyor_speed", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to start base conveyor tracking.
   *
   * @param robot_model Name of the robot model.
   * @param conv_type 0 No Conveyor, 1 Linear Conveyor, 2 Circular Conveyor.
   * @param conv_speed Conveyor speed, in mm/s.
   * @param conv_acc_time_sec Speed adjustment time, in seconds.
   * @param conv_ref_points Conveyor reference points; each point's values
   *        are rounded to 3 decimal places and padded/truncated to 7
   *        elements.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_base_conveyor_on(const std::string& robot_model, const int conv_type,
                                                 const float conv_speed, const float conv_acc_time_sec,
                                                 const std::vector<MoveTargetValuesArg>& conv_ref_points,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr) {
    std::vector<std::unique_ptr<IPC::MoveInput_TargetT>> result_target_values;

    // 좌표 반올림/7-패딩과, 포인트 하나의 파싱 실패를 조용히 7-zero 로 흡수하는 처리는
    // MoveTargetValuesArg 의 type_caster(binding/glue/move_target_values_caster.hpp) 가
    // 이미 끝냈다 — Python 원본과 동일하게 한 포인트가 잘못돼도 나머지는 계속 처리된다.
    for (const auto& values : conv_ref_points) {
      auto target = std::make_unique<IPC::MoveInput_TargetT>();

      target->tar_frame = 0;
      target->tar_unit = 0;
      target->tar_values = values.tar_values;

      result_target_values.push_back(std::move(target));
    }

    return _conveyor_on(robot_model, conv_type, conv_speed, conv_acc_time_sec, result_target_values, flow_manager_args);
  }

  /**
   * @brief Requests the cobot to move in a circle defined by a center and rotation axis.
   *
   * @param robot_model Name of the robot model.
   * @param center Rotation center. Resolved through the same relative-value
   *        calculation as @c get_relative_value before being sent.
   * @param axis Rotation axis. Resolved the same way as @p center.
   * @param angle Rotation angle, in degrees.
   * @param mode Orientation mode: 0 Sync, 1 Constant, 2 Intended.
   * @param speed Movement speed parameters (same concept as move-L speed).
   * @param radius_option Radius option: 0 None, 1 Rate per revolution, 2
   *        Size per revolution.
   * @param radius_para Radius parameter, interpreted according to
   *        @p radius_option.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, the center/axis
   *         relative-value calculation fails, or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_move_cir_axis(const std::string& robot_model, const SafeMoveTargetArg& center,
                                              const SafeMoveTargetArg& axis, const float angle, const int mode,
                                              std::optional<MoveSpeedArg> speed, const int radius_option,
                                              const float radius_para, FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Move_CIR_AXIST req;
    req.angle = angle;
    req.mode = mode;
    req.radius_option = radius_option;
    req.radius_para = radius_para;

    IPC::MoveInput_TargetT center_obj = _calc_circle_tar_values(robot_model, center);

    auto center_input = std::make_unique<IPC::MoveInput_TargetT>();

    center_input->tar_frame = center_obj.tar_frame;
    center_input->tar_unit = center_obj.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, center_obj.tar_values.size()); ++i)
      vals[i] = std::round(center_obj.tar_values[i] * 1000.0f) / 1000.0f;

    center_input->tar_values = std::move(vals);

    req.center = std::move(center_input);

    IPC::MoveInput_TargetT axis_obj = _calc_circle_tar_values(robot_model, axis);

    auto axis_input = std::make_unique<IPC::MoveInput_TargetT>();

    axis_input->tar_frame = axis_obj.tar_frame;
    axis_input->tar_unit = axis_obj.tar_unit;

    std::vector<float> valss(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, axis_obj.tar_values.size()); ++i)
      valss[i] = std::round(axis_obj.tar_values[i] * 1000.0f) / 1000.0f;

    axis_input->tar_values = std::move(valss);

    req.axis = std::move(axis_input);

    auto speed_input = std::make_unique<IPC::MoveInput_SpeedT>();

    // Python 원본과 동일: speed(및 그 개별 필드)가 없으면 250/1000 기본값을 쓴다.
    const MoveSpeedArg speed_arg = speed.value_or(MoveSpeedArg{});
    speed_input->spd_mode = speed_arg.spd_mode.value_or(1);
    speed_input->spd_vel_para = speed_arg.spd_vel_para.value_or(250);
    speed_input->spd_acc_para = speed_arg.spd_acc_para.value_or(1000);

    req.speed = std::move(speed_input);

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_CIR_AXIST>(
        robot_model + "/call_move_cir_axis", req, 8, 1000, 0);

    if (!result)
      throw std::runtime_error("Call Move Cir Axis failed: query one returned nullptr");

    manipulate_return_value("call_move_cir_axis", *result, flow_manager_args);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Circle Axis", std::move(*result),
                                                          "call_move_cir_axis", flow_manager_args);
  }

  /**
   * @brief Requests the cobot to move in a circle defined by a via point and a goal point.
   *
   * @param robot_model Name of the robot model.
   * @param via_p A point the circular path passes through. Resolved
   *        through the same relative-value calculation as
   *        @c get_relative_value before being sent.
   * @param goal_p The circular path's end point. Resolved the same way as
   *        @p via_p.
   * @param mode Orientation mode: 0 Sync, 1 Constant, 2 Intended.
   * @param speed Movement speed parameters (same concept as move-L speed).
   * @param radius_option Radius option: 0 None, 1 Rate per revolution, 2
   *        Size per revolution.
   * @param radius_para Radius parameter, interpreted according to
   *        @p radius_option.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, the via/goal point
   *         relative-value calculation fails, or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_move_cir_threepoint(const std::string& robot_model, const SafeMoveTargetArg& via_p,
                                                    const SafeMoveTargetArg& goal_p, const int mode,
                                                    std::optional<MoveSpeedArg> speed, const int radius_option,
                                                    const float radius_para,
                                                    FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Move_CIR_3PT req;

    req.mode = mode;
    req.radius_option = radius_option;
    req.radius_para = radius_para;

    IPC::MoveInput_TargetT via_p_obj = _calc_circle_tar_values(robot_model, via_p);

    auto via_p_input = std::make_unique<IPC::MoveInput_TargetT>();

    via_p_input->tar_frame = via_p_obj.tar_frame;
    via_p_input->tar_unit = via_p_obj.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, via_p_obj.tar_values.size()); ++i)
      vals[i] = std::round(via_p_obj.tar_values[i] * 1000.0f) / 1000.0f;

    via_p_input->tar_values = std::move(vals);

    req.via_p = std::move(via_p_input);

    IPC::MoveInput_TargetT goal_p_obj = _calc_circle_tar_values(robot_model, goal_p);

    auto goal_p_input = std::make_unique<IPC::MoveInput_TargetT>();

    goal_p_input->tar_frame = goal_p_obj.tar_frame;
    goal_p_input->tar_unit = goal_p_obj.tar_unit;

    std::vector<float> valss(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, goal_p_obj.tar_values.size()); ++i)
      valss[i] = std::round(goal_p_obj.tar_values[i] * 1000.0f) / 1000.0f;

    goal_p_input->tar_values = std::move(valss);

    req.goal_p = std::move(goal_p_input);

    auto speed_input = std::make_unique<IPC::MoveInput_SpeedT>();

    // Python 원본과 동일: speed(및 그 개별 필드)가 없으면 250/1000 기본값을 쓴다.
    const MoveSpeedArg speed_arg = speed.value_or(MoveSpeedArg{});
    speed_input->spd_mode = speed_arg.spd_mode.value_or(1);
    speed_input->spd_vel_para = speed_arg.spd_vel_para.value_or(250);
    speed_input->spd_acc_para = speed_arg.spd_acc_para.value_or(1000);

    req.speed = std::move(speed_input);

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_Move_CIR_3PT>(
        robot_model + "/call_move_cir_threepoint", req, 8, 1000, 0);

    if (!result)
      throw std::runtime_error("Call Move Cir Threepoint failed: query one returned nullptr");

    manipulate_return_value("call_move_cir_threepoint", *result, flow_manager_args);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Circle threepoints", std::move(*result),
                                                          "call_move_cir_threepoint", flow_manager_args);
  }

  /**
   * @brief Requests the cobot to move to a home position.
   *
   * @param robot_model Name of the robot model.
   * @param home_type Home position: 0 Top-Level (Main) Project, 1
   *        Currently running (Sub) Project, 2 Zero Posture, or 3 + N
   *        (3-18) for Global Pin N (0-15, see @c save_globpin_parameter).
   * @param move_type Movement type used to reach the home position: 0
   *        Move-J, 1 Move-L.
   * @param speed Movement speed parameters.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_move_home(const std::string& robot_model, const int home_type, const int move_type,
                                          const MoveSpeedArg& speed,
                                          FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Move_HomeT req;
    req.home_type = home_type;
    req.move_type = move_type;

    auto speed_input = std::make_unique<IPC::MoveInput_SpeedT>();

    // Python 원본과 동일: speed 의 개별 필드가 없으면 move_type==0(J)일 때 60/120,
    // 아니면(L) 250/1000 기본값을 쓴다.
    speed_input->spd_mode = speed.spd_mode.value_or(1);
    if (move_type == 0) {
      speed_input->spd_vel_para = speed.spd_vel_para.value_or(60);
      speed_input->spd_acc_para = speed.spd_acc_para.value_or(120);
    } else {
      speed_input->spd_vel_para = speed.spd_vel_para.value_or(250);
      speed_input->spd_acc_para = speed.spd_acc_para.value_or(1000);
    }

    req.speed = std::move(speed_input);
    std::cout << "call move home query one execute" << std::endl;
    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Move_HomeT>(robot_model + "/call_move_home", req, 8, 3000, 0);

    if (!result)
      throw std::runtime_error("Call Move Home failed: query one returned nullptr");

    manipulate_return_value("call_move_home", *result, flow_manager_args);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Call Move Home", std::move(*result),
                                                          "call_move_home", flow_manager_args);
  }

  /**
   * @brief Requests the cobot to stop arc sensing (weld seam tracking).
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_arc_sensing_off(const std::string& robot_model,
                                                FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Wrapper_ArcSensing_OffT req;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_ArcSensing_OffT>(robot_model + "/call_arc_sensing_off",
                                                                                 req, 8, 15000, 0);

    if (!result)
      throw std::runtime_error("Call Arc Sensing Off failed: query one returned nullptr");

    manipulate_return_value("call_arc_sensing_off", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to start arc sensing (weld seam tracking).
   *
   * @param robot_model Name of the robot model.
   * @param control_type Control mode: 0 RT (Full Cycle), 1 RT (Half
   *        Cycle), 2 Every Full Cycle, 3 Every Half Cycle.
   * @param data_grab_point Sensing data source: 0-3 for Analog Input 0-3.
   * @param data_grab_saturation_mode Sensing saturation mode: 0 No
   *        Saturation, 1 Saturation with Lower/Upper limit, 2 Saturation
   *        with hold.
   * @param data_grab_saturation_l Sensing saturation lower limit.
   * @param data_grab_saturation_u Sensing saturation upper limit.
   * @param data_grab_filter_hz Sensing data low-pass filter, in Hz
   *        (default 20).
   * @param data_grab_weighting_mode Sensing weighting mode: 0 Curve
   *        Weight (default), 1 Even Weight, 2 Linear Weight, 3 Reduced
   *        Linear Weight.
   * @param t1 T1 time, in seconds.
   * @param t2 T2 time, in seconds.
   * @param dep_target_method Depth-direction target method: 0 Desired
   *        Value, 1 Average between T1/T2 (default).
   * @param dep_target_a Depth-direction desired value (default 0),
   *        interpreted when @p dep_target_method is 0.
   * @param sid_target_method Weave-direction target method: 0 Desired
   *        Value (default), 1 Average between T1/T2.
   * @param sid_target_a Weave-direction desired value (default 0),
   *        interpreted when @p sid_target_method is 0.
   * @param gain_dep_p Depth-direction P gain (default 0).
   * @param gain_dep_i Depth-direction I gain (default 0).
   * @param gain_dep_a Depth-direction anti-windup gain (default 0).
   * @param max_dep_dev Depth-direction max deviation, in mm (default 10).
   * @param gain_sid_p Weave-direction P gain (default 0).
   * @param gain_sid_i Weave-direction I gain (default 0).
   * @param gain_sid_a Weave-direction anti-windup gain (default 0).
   * @param max_sid_dev Weave-direction max deviation, in mm (default 10).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_arc_sensing_on(const std::string& robot_model, const int control_type,
                                               const int data_grab_point, const int data_grab_saturation_mode,
                                               const float data_grab_saturation_l, const float data_grab_saturation_u,
                                               const float data_grab_filter_hz, const int data_grab_weighting_mode,
                                               const float t1, const float t2, const int dep_target_method,
                                               const float dep_target_a, const int sid_target_method,
                                               const float sid_target_a, const float gain_dep_p, const float gain_dep_i,
                                               const float gain_dep_a, const float max_dep_dev, const float gain_sid_p,
                                               const float gain_sid_i, const float gain_sid_a, const float max_sid_dev,
                                               FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Wrapper_ArcSensing_OnT req;
    req.control_type = control_type;

    req.data_grab_point = data_grab_point;
    req.data_grab_saturation_mode = data_grab_saturation_mode;
    req.data_grab_saturation_l = data_grab_saturation_l;
    req.data_grab_saturation_u = data_grab_saturation_u;
    req.data_grab_filter_hz = data_grab_filter_hz;
    req.data_grab_weighting_mode = data_grab_weighting_mode;

    req.t1 = t1;
    req.t2 = t2;
    req.dep_target_method = dep_target_method;
    req.dep_target_a = dep_target_a;
    req.sid_target_method = sid_target_method;
    req.sid_target_a = sid_target_a;

    req.gain_dep_p = gain_dep_p;
    req.gain_dep_i = gain_dep_i;
    req.gain_dep_a = gain_dep_a;
    req.max_dep_dev = max_dep_dev;
    req.gain_sid_p = gain_sid_p;
    req.gain_sid_i = gain_sid_i;
    req.gain_sid_a = gain_sid_a;
    req.max_sid_dev = max_sid_dev;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_ArcSensing_OnT>(robot_model + "/call_arc_sensing_on",
                                                                                req, 8, 15000, 0);

    if (!result)
      throw std::runtime_error("Call Arc Sensing On failed: query one returned nullptr");

    manipulate_return_value("call_arc_sensing_on", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to change active arc sensing's target parameters.
   *
   * @param robot_model Name of the robot model.
   * @param t1 T1 time, in seconds.
   * @param t2 T2 time, in seconds.
   * @param dep_target_method Depth-direction target method: 0 Desired
   *        Value, 1 Average between T1/T2 (default).
   * @param dep_target_a Depth-direction desired value (default 0),
   *        interpreted when @p dep_target_method is 0.
   * @param sid_target_method Weave-direction target method: 0 Desired
   *        Value (default), 1 Average between T1/T2.
   * @param sid_target_a Weave-direction desired value (default 0),
   *        interpreted when @p sid_target_method is 0.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_arc_sensing_change_target(const std::string& robot_model, const float t1,
                                                          const float t2, const int dep_target_method,
                                                          const float dep_target_a, const int sid_target_method,
                                                          const float sid_target_a,
                                                          FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Wrapper_ArcSensing_ChangeTargetT req;
    req.t1 = t1;
    req.t2 = t2;
    req.dep_target_method = dep_target_method;
    req.dep_target_a = dep_target_a;
    req.sid_target_method = sid_target_method;
    req.sid_target_a = sid_target_a;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_ArcSensing_ChangeTargetT>(
            robot_model + "/call_arc_sensing_change_target", req, 8, 15000, 0);

    if (!result)
      throw std::runtime_error("Call Arc Sensing Change Target failed: query one returned nullptr");

    manipulate_return_value("call_arc_sensing_change_target", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to change active arc sensing's gain parameters.
   *
   * @param robot_model Name of the robot model.
   * @param gain_dep_p Depth-direction P gain (default 0).
   * @param gain_dep_i Depth-direction I gain (default 0).
   * @param gain_dep_a Depth-direction anti-windup gain (default 0).
   * @param max_dep_dev Depth-direction max deviation, in mm (default 10).
   * @param gain_sid_p Weave-direction P gain (default 0).
   * @param gain_sid_i Weave-direction I gain (default 0).
   * @param gain_sid_a Weave-direction anti-windup gain (default 0).
   * @param max_sid_dev Weave-direction max deviation, in mm (default 10).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_arc_sensing_change_gain(const std::string& robot_model, const float gain_dep_p,
                                                        const float gain_dep_i, const float gain_dep_a,
                                                        const float max_dep_dev, const float gain_sid_p,
                                                        const float gain_sid_i, const float gain_sid_a,
                                                        const float max_sid_dev,
                                                        FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Wrapper_ArcSensing_ChangeGainT req;

    req.gain_dep_p = gain_dep_p;
    req.gain_dep_i = gain_dep_i;
    req.gain_dep_a = gain_dep_a;
    req.max_dep_dev = max_dep_dev;
    req.gain_sid_p = gain_sid_p;
    req.gain_sid_i = gain_sid_i;
    req.gain_sid_a = gain_sid_a;
    req.max_sid_dev = max_sid_dev;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_ArcSensing_ChangeGainT>(
            robot_model + "/call_arc_sensing_change_gain", req, 8, 15000, 0);

    if (!result)
      throw std::runtime_error("Call Arc Sensing Change Gain failed: query one returned nullptr");

    manipulate_return_value("call_arc_sensing_change_gain", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to stop admittance force control.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_admittance_force_off(const std::string& robot_model,
                                                     FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Wrapper_AdmittanceForce_OffT req;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_AdmittanceForce_OffT>(
            robot_model + "/call_admittance_force_off", req, 8, 15000, 0);

    if (!result)
      throw std::runtime_error("Call Admittance Force Off failed: query one returned nullptr");

    manipulate_return_value("call_admittance_force_off", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to start admittance force control.
   *
   * @param robot_model Name of the robot model.
   * @param frame Target frame: 0 Global, 1 Local, 2 User, 3 Target.
   * @param enable_x Enable X axis (0/1, default 0/unchecked).
   * @param enable_y Enable Y axis (0/1, default 0/unchecked).
   * @param enable_z Enable Z axis (0/1, default 0/unchecked).
   * @param enable_rx Enable Rx axis (0/1, default 0/unchecked).
   * @param enable_ry Enable Ry axis (0/1, default 0/unchecked).
   * @param enable_rz Enable Rz axis (0/1, default 0/unchecked).
   * @param target_x Target force/torque along X (default 0).
   * @param target_y Target force/torque along Y (default 0).
   * @param target_z Target force/torque along Z (default 0).
   * @param target_rx Target force/torque around Rx (default 0).
   * @param target_ry Target force/torque around Ry (default 0).
   * @param target_rz Target force/torque around Rz (default 0).
   * @param pgain_x X-axis P gain (default 1).
   * @param pgain_y Y-axis P gain (default 1).
   * @param pgain_z Z-axis P gain (default 1).
   * @param pgain_rx Rx-axis P gain (default 1).
   * @param pgain_ry Ry-axis P gain (default 1).
   * @param pgain_rz Rz-axis P gain (default 1).
   * @param igain_x X-axis I gain (default 0).
   * @param igain_y Y-axis I gain (default 0).
   * @param igain_z Z-axis I gain (default 0).
   * @param igain_rx Rx-axis I gain (default 0).
   * @param igain_ry Ry-axis I gain (default 0).
   * @param igain_rz Rz-axis I gain (default 0).
   * @param spdlim_x X-axis speed limit (default 0).
   * @param spdlim_y Y-axis speed limit (default 0).
   * @param spdlim_z Z-axis speed limit (default 0).
   * @param spdlim_rx Rx-axis speed limit (default 0).
   * @param spdlim_ry Ry-axis speed limit (default 0).
   * @param spdlim_rz Rz-axis speed limit (default 0).
   * @param max_dev_pos Position max deviation, in mm.
   * @param max_dev_rot Rotation max deviation, in degrees.
   * @param sensor_type Force/torque sensor source: 0 External F/T, 1
   *        Internal F/T, 2-5 Analog Input 0-3, 6 Custom.
   * @param sensor_cutoffhz Sensor low-pass filter, in Hz (default 20).
   * @param sensor_handle Sensor signal option: 0 Auto Nulling, 1 Raw
   *        Value.
   * @param contact_force Contact detection force, in N (default 5).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_admittance_force_on(
      const std::string& robot_model, const int frame, const int enable_x, const int enable_y, const int enable_z,
      const int enable_rx, const int enable_ry, const int enable_rz, const float target_x, const float target_y,
      const float target_z, const float target_rx, const float target_ry, const float target_rz, const float pgain_x,
      const float pgain_y, const float pgain_z, const float pgain_rx, const float pgain_ry, const float pgain_rz,
      const float igain_x, const float igain_y, const float igain_z, const float igain_rx, const float igain_ry,
      const float igain_rz, const float spdlim_x, const float spdlim_y, const float spdlim_z, const float spdlim_rx,
      const float spdlim_ry, const float spdlim_rz, const float max_dev_pos, const float max_dev_rot,
      const int sensor_type, const float sensor_cutoffhz, const int sensor_handle, const float contact_force,
      FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Wrapper_AdmittanceForce_OnT req;

    req.frame = frame;
    req.enable_x = enable_x;
    req.enable_y = enable_y;
    req.enable_z = enable_z;
    req.enable_rx = enable_rx;
    req.enable_ry = enable_ry;
    req.enable_rz = enable_rz;

    req.target_x = target_x;
    req.target_y = target_y;
    req.target_z = target_z;
    req.target_rx = target_rx;
    req.target_ry = target_ry;
    req.target_rz = target_rz;

    req.pgain_x = pgain_x;
    req.pgain_y = pgain_y;
    req.pgain_z = pgain_z;
    req.pgain_rx = pgain_rx;
    req.pgain_ry = pgain_ry;
    req.pgain_rz = pgain_rz;

    req.igain_x = igain_x;
    req.igain_y = igain_y;
    req.igain_z = igain_z;
    req.igain_rx = igain_rx;
    req.igain_ry = igain_ry;
    req.igain_rz = igain_rz;

    req.spdlim_x = spdlim_x;
    req.spdlim_y = spdlim_y;
    req.spdlim_z = spdlim_z;
    req.spdlim_rx = spdlim_rx;
    req.spdlim_ry = spdlim_ry;
    req.spdlim_rz = spdlim_rz;

    req.max_dev_pos = max_dev_pos;
    req.max_dev_rot = max_dev_rot;

    req.sensor_type = sensor_type;
    req.sensor_cutoffhz = sensor_cutoffhz;
    req.sensor_handle = sensor_handle;

    req.contact_force = contact_force;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_AdmittanceForce_OnT>(
            robot_model + "/call_admittance_force_on", req, 8, 15000, 0);

    if (!result)
      throw std::runtime_error("Call Admittance Force On failed: query one returned nullptr");

    manipulate_return_value("call_admittance_force_on", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to change active admittance force control's parameters.
   *
   * Same fields as @c call_admittance_force_on except sensor/contact-force
   * settings, which cannot be changed while active.
   *
   * @param robot_model Name of the robot model.
   * @param frame Target frame: 0 Global, 1 Local, 2 User, 3 Target.
   * @param enable_x Enable X axis (0/1, default 0/unchecked).
   * @param enable_y Enable Y axis (0/1, default 0/unchecked).
   * @param enable_z Enable Z axis (0/1, default 0/unchecked).
   * @param enable_rx Enable Rx axis (0/1, default 0/unchecked).
   * @param enable_ry Enable Ry axis (0/1, default 0/unchecked).
   * @param enable_rz Enable Rz axis (0/1, default 0/unchecked).
   * @param target_x Target force/torque along X (default 0).
   * @param target_y Target force/torque along Y (default 0).
   * @param target_z Target force/torque along Z (default 0).
   * @param target_rx Target force/torque around Rx (default 0).
   * @param target_ry Target force/torque around Ry (default 0).
   * @param target_rz Target force/torque around Rz (default 0).
   * @param pgain_x X-axis P gain (default 1).
   * @param pgain_y Y-axis P gain (default 1).
   * @param pgain_z Z-axis P gain (default 1).
   * @param pgain_rx Rx-axis P gain (default 1).
   * @param pgain_ry Ry-axis P gain (default 1).
   * @param pgain_rz Rz-axis P gain (default 1).
   * @param igain_x X-axis I gain (default 0).
   * @param igain_y Y-axis I gain (default 0).
   * @param igain_z Z-axis I gain (default 0).
   * @param igain_rx Rx-axis I gain (default 0).
   * @param igain_ry Ry-axis I gain (default 0).
   * @param igain_rz Rz-axis I gain (default 0).
   * @param spdlim_x X-axis speed limit (default 0).
   * @param spdlim_y Y-axis speed limit (default 0).
   * @param spdlim_z Z-axis speed limit (default 0).
   * @param spdlim_rx Rx-axis speed limit (default 0).
   * @param spdlim_ry Ry-axis speed limit (default 0).
   * @param spdlim_rz Rz-axis speed limit (default 0).
   * @param max_dev_pos Position max deviation, in mm.
   * @param max_dev_rot Rotation max deviation, in degrees.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_admittance_force_change(
      const std::string& robot_model, const int frame, const int enable_x, const int enable_y, const int enable_z,
      const int enable_rx, const int enable_ry, const int enable_rz, const float target_x, const float target_y,
      const float target_z, const float target_rx, const float target_ry, const float target_rz, const float pgain_x,
      const float pgain_y, const float pgain_z, const float pgain_rx, const float pgain_ry, const float pgain_rz,
      const float igain_x, const float igain_y, const float igain_z, const float igain_rx, const float igain_ry,
      const float igain_rz, const float spdlim_x, const float spdlim_y, const float spdlim_z, const float spdlim_rx,
      const float spdlim_ry, const float spdlim_rz, const float max_dev_pos, const float max_dev_rot,
      FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Wrapper_AdmittanceForce_ChangeT req;

    req.frame = frame;
    req.enable_x = enable_x;
    req.enable_y = enable_y;
    req.enable_z = enable_z;
    req.enable_rx = enable_rx;
    req.enable_ry = enable_ry;
    req.enable_rz = enable_rz;

    req.target_x = target_x;
    req.target_y = target_y;
    req.target_z = target_z;
    req.target_rx = target_rx;
    req.target_ry = target_ry;
    req.target_rz = target_rz;

    req.pgain_x = pgain_x;
    req.pgain_y = pgain_y;
    req.pgain_z = pgain_z;
    req.pgain_rx = pgain_rx;
    req.pgain_ry = pgain_ry;
    req.pgain_rz = pgain_rz;

    req.igain_x = igain_x;
    req.igain_y = igain_y;
    req.igain_z = igain_z;
    req.igain_rx = igain_rx;
    req.igain_ry = igain_ry;
    req.igain_rz = igain_rz;

    req.spdlim_x = spdlim_x;
    req.spdlim_y = spdlim_y;
    req.spdlim_z = spdlim_z;
    req.spdlim_rx = spdlim_rx;
    req.spdlim_ry = spdlim_ry;
    req.spdlim_rz = spdlim_rz;

    req.max_dev_pos = max_dev_pos;
    req.max_dev_rot = max_dev_rot;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_AdmittanceForce_ChangeT>(
            robot_model + "/call_admittance_force_change", req, 8, 15000, 0);

    if (!result)
      throw std::runtime_error("Call Admittance Force Change failed: query one returned nullptr");

    manipulate_return_value("call_admittance_force_change", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to queue a joint-space servo target segment.
   *
   * Streaming/realtime joint control: each call queues one target segment
   * to move smoothly toward from wherever the previous segment left off,
   * rather than performing one discrete move. Intended to be called
   * repeatedly (e.g. once per control tick) to stream a trajectory.
   *
   * @param robot_model Name of the robot model.
   * @param target Target joint position and frame information.
   * @param t1 Time to move from the previous target to this one, in
   *        seconds (must be >= 0).
   * @param t2 Additional hold/settle time after reaching the target, in
   *        seconds (valid range (0, 5]).
   * @param gain Speed scaling gain applied to this segment (must be >
   *        0).
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p t1 / @p t2 / @p gain are
   *         out of their valid ranges, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_servo_j(const std::string& robot_model, IPC::MoveInput_TargetT target, const float t1,
                                        const float t2, const float gain, const float filter,
                                        FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Servo_JT req;

    auto targ = std::make_unique<IPC::MoveInput_TargetT>();

    targ->tar_frame = target.tar_frame;
    targ->tar_unit = target.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, target.tar_values.size()); ++i)
      vals[i] = std::round(target.tar_values[i] * 1000.0f) / 1000.0f;

    targ->tar_values = std::move(vals);

    req.target = std::move(targ);
    req.t1 = t1;
    req.t2 = t2;
    req.gain = gain;
    req.filter = filter;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Servo_JT>(robot_model + "/call_servo_j", req, 8, 3000, 0);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Servo J", std::move(*result), "call_servo_j",
                                                          flow_manager_args);
  }

  /**
   * @brief Publishes a joint-space servo target segment without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_servo_j: queues one target
   * segment the same way, but publishes it (real-time priority, dropping
   * under congestion) instead of querying and does not report failures
   * back to the caller.
   *
   * @param robot_model Name of the robot model.
   * @param target Target joint position and frame information.
   * @param t1 Time to move from the previous target to this one, in
   *        seconds (must be >= 0).
   * @param t2 Additional hold/settle time after reaching the target, in
   *        seconds (valid range (0, 5]).
   * @param gain Speed scaling gain applied to this segment (must be >
   *        0).
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_servo_j(const std::string& robot_model, IPC::MoveInput_TargetT target, const float t1, const float t2,
                   const float gain, const float filter, FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Servo_JT req;

    auto targ = std::make_unique<IPC::MoveInput_TargetT>();

    targ->tar_frame = target.tar_frame;
    targ->tar_unit = target.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, target.tar_values.size()); ++i)
      vals[i] = std::round(target.tar_values[i] * 1000.0f) / 1000.0f;

    targ->tar_values = std::move(vals);

    req.target = std::move(targ);
    req.t1 = t1;
    req.t2 = t2;
    req.gain = gain;
    req.filter = filter;

    publish<IPC::Request_Servo_JT>(robot_model + "/pub_servo_j", req, 80, "", static_cast<int>(CongestionControl::DROP),
                                   static_cast<int>(Priority::REAL_TIME), true);

    if (flow_manager_args)
      flow_manager_args->done();
  }

  /**
   * @brief Requests the cobot to queue a Cartesian-space servo target segment.
   *
   * Streaming/realtime Cartesian control: each call queues one target
   * segment to move smoothly toward from wherever the previous segment
   * left off, rather than performing one discrete move. Intended to be
   * called repeatedly (e.g. once per control tick) to stream a
   * trajectory.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param t1 Time to move from the previous target to this one, in
   *        seconds (must be >= 0).
   * @param t2 Additional hold/settle time after reaching the target, in
   *        seconds (must be > 0).
   * @param gain Speed scaling gain applied to this segment (must be >
   *        0).
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p t1 / @p t2 / @p gain are
   *         out of their valid ranges, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_servo_l(const std::string& robot_model, IPC::MoveInput_TargetT target, const float t1,
                                        const float t2, const float gain, const float filter,
                                        FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Servo_LT req;

    auto targ = std::make_unique<IPC::MoveInput_TargetT>();

    targ->tar_frame = target.tar_frame;
    targ->tar_unit = target.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, target.tar_values.size()); ++i)
      vals[i] = std::round(target.tar_values[i] * 1000.0f) / 1000.0f;

    targ->tar_values = std::move(vals);

    req.target = std::move(targ);
    req.t1 = t1;
    req.t2 = t2;
    req.gain = gain;
    req.filter = filter;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Servo_LT>(robot_model + "/call_servo_l", req, 8, 3000, 0);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Servo L", std::move(*result), "call_servo_l",
                                                          flow_manager_args);
  }

  /**
   * @brief Publishes a Cartesian-space servo target segment without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_servo_l: queues one target
   * segment the same way, but publishes it (real-time priority, dropping
   * under congestion) instead of querying and does not report failures
   * back to the caller.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param t1 Time to move from the previous target to this one, in
   *        seconds (must be >= 0).
   * @param t2 Additional hold/settle time after reaching the target, in
   *        seconds (must be > 0).
   * @param gain Speed scaling gain applied to this segment (must be >
   *        0).
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_servo_l(const std::string& robot_model, IPC::MoveInput_TargetT target, const float t1, const float t2,
                   const float gain, const float filter, FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Servo_LT req;

    auto targ = std::make_unique<IPC::MoveInput_TargetT>();

    targ->tar_frame = target.tar_frame;
    targ->tar_unit = target.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, target.tar_values.size()); ++i)
      vals[i] = std::round(target.tar_values[i] * 1000.0f) / 1000.0f;

    targ->tar_values = std::move(vals);

    req.target = std::move(targ);
    req.t1 = t1;
    req.t2 = t2;
    req.gain = gain;
    req.filter = filter;

    publish<IPC::Request_Servo_LT>(robot_model + "/pub_servo_l", req, 80, "", static_cast<int>(CongestionControl::DROP),
                                   static_cast<int>(Priority::REAL_TIME), true);

    if (flow_manager_args)
      flow_manager_args->done();
  }

  /**
   * @brief Requests the cobot to queue a joint-space online-tracking target.
   *
   * Streaming/realtime joint control, intended to be called repeatedly
   * (e.g. once per communication cycle) to keep feeding a moving target;
   * if only one target is queued when the robot's control loop next reads
   * it, older undelivered targets are discarded and the latest one wins.
   *
   * @param robot_model Name of the robot model.
   * @param target Target joint position and frame information.
   * @param speed Movement speed parameters — spd_vel_para/spd_acc_para act
   *        as the max velocity/acceleration for this segment and must be
   *        positive (not near zero).
   * @param timeout Communication-loss timeout, in seconds (range 0-10): if
   *        no new target is queued within this time after the last one was
   *        consumed, the motion is considered finished. Rule of thumb:
   *        (1 / your call rate) + a small margin — e.g. 0.02 for 100Hz,
   *        0.01 for 200Hz. Too small a value can trigger a false finish
   *        from ordinary communication jitter.
   * @param filter Output smoothing filter value.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, any input is
   *         non-finite or out of range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_online_j(const std::string& robot_model, const IPC::MoveInput_TargetT& target,
                                         const MoveSpeedArg& speed, const float timeout, const float filter,
                                         FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Online_JT req;

    auto targ = std::make_unique<IPC::MoveInput_TargetT>();

    targ->tar_frame = target.tar_frame;
    targ->tar_unit = target.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, target.tar_values.size()); ++i)
      vals[i] = std::round(target.tar_values[i] * 1000.0f) / 1000.0f;

    targ->tar_values = std::move(vals);

    req.target = std::move(targ);

    auto speed_input = std::make_unique<IPC::MoveInput_SpeedT>();

    // Python 원본과 동일: speed 의 개별 필드가 없으면 60/120 기본값을 쓴다.
    speed_input->spd_mode = speed.spd_mode.value_or(1);
    speed_input->spd_vel_para = speed.spd_vel_para.value_or(60);
    speed_input->spd_acc_para = speed.spd_acc_para.value_or(120);

    req.speed = std::move(speed_input);

    req.timeout = timeout;
    req.filter = filter;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Online_JT>(robot_model + "/call_online_j", req, 8, 3000, 0);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Online J", std::move(*result), "call_online_j",
                                                          flow_manager_args);
  }

  /**
   * @brief Publishes a joint-space online-tracking target without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_online_j: queues the target the
   * same way, but publishes it (real-time priority, dropping under
   * congestion) instead of querying and does not report failures back to
   * the caller.
   *
   * @param robot_model Name of the robot model.
   * @param target Target joint position and frame information.
   * @param speed Movement speed parameters — spd_vel_para/spd_acc_para act
   *        as the max velocity/acceleration for this segment and must be
   *        positive (not near zero).
   * @param timeout Communication-loss timeout, in seconds (range 0-10);
   *        see @c call_online_j for the full explanation.
   * @param filter Output smoothing filter value.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_online_j(const std::string& robot_model, const IPC::MoveInput_TargetT& target,
                    const MoveSpeedArg& speed, const float timeout, const float filter,
                    FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Online_JT req;

    auto targ = std::make_unique<IPC::MoveInput_TargetT>();

    targ->tar_frame = target.tar_frame;
    targ->tar_unit = target.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, target.tar_values.size()); ++i)
      vals[i] = std::round(target.tar_values[i] * 1000.0f) / 1000.0f;

    targ->tar_values = std::move(vals);

    req.target = std::move(targ);

    auto speed_input = std::make_unique<IPC::MoveInput_SpeedT>();

    // Python 원본과 동일: speed 의 개별 필드가 없으면 60/120 기본값을 쓴다.
    speed_input->spd_mode = speed.spd_mode.value_or(1);
    speed_input->spd_vel_para = speed.spd_vel_para.value_or(60);
    speed_input->spd_acc_para = speed.spd_acc_para.value_or(120);

    req.speed = std::move(speed_input);

    req.timeout = timeout;
    req.filter = filter;

    publish<IPC::Request_Online_JT>(robot_model + "/pub_online_j", req, 80, "",
                                    static_cast<int>(CongestionControl::DROP), static_cast<int>(Priority::REAL_TIME),
                                    true);

    if (flow_manager_args)
      flow_manager_args->done();
  }

  /**
   * @brief Requests the cobot to queue a Cartesian-space online-tracking target.
   *
   * Streaming/realtime Cartesian control, intended to be called repeatedly
   * (e.g. once per communication cycle) to keep feeding a moving target;
   * if only one target is queued when the robot's control loop next reads
   * it, older undelivered targets are discarded and the latest one wins.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param speed Movement speed parameters — spd_vel_para/spd_acc_para act
   *        as the max velocity/acceleration for this segment and must be
   *        positive (not near zero).
   * @param timeout Communication-loss timeout, in seconds (range 0-10): if
   *        no new target is queued within this time after the last one was
   *        consumed, the motion is considered finished. Rule of thumb:
   *        (1 / your call rate) + a small margin — e.g. 0.02 for 100Hz,
   *        0.01 for 200Hz. Too small a value can trigger a false finish
   *        from ordinary communication jitter.
   * @param filter Output smoothing filter value.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, any input is
   *         non-finite or out of range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_online_l(const std::string& robot_model, const IPC::MoveInput_TargetT& target,
                                         const MoveSpeedArg& speed, const float timeout, const float filter,
                                         FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Online_LT req;

    auto targ = std::make_unique<IPC::MoveInput_TargetT>();

    targ->tar_frame = target.tar_frame;
    targ->tar_unit = target.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, target.tar_values.size()); ++i)
      vals[i] = std::round(target.tar_values[i] * 1000.0f) / 1000.0f;

    targ->tar_values = std::move(vals);

    req.target = std::move(targ);

    auto speed_input = std::make_unique<IPC::MoveInput_SpeedT>();

    // Python 원본과 동일: speed 의 개별 필드가 없으면 60/120 기본값을 쓴다.
    speed_input->spd_mode = speed.spd_mode.value_or(1);
    speed_input->spd_vel_para = speed.spd_vel_para.value_or(60);
    speed_input->spd_acc_para = speed.spd_acc_para.value_or(120);

    req.speed = std::move(speed_input);

    req.timeout = timeout;
    req.filter = filter;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Online_LT>(robot_model + "/call_online_l", req, 8, 3000, 0);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Online L", std::move(*result), "call_online_l",
                                                          flow_manager_args);
  }

  /**
   * @brief Publishes a Cartesian-space online-tracking target without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_online_l: queues the target the
   * same way, but publishes it (real-time priority, dropping under
   * congestion) instead of querying and does not report failures back to
   * the caller.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param speed Movement speed parameters — spd_vel_para/spd_acc_para act
   *        as the max velocity/acceleration for this segment and must be
   *        positive (not near zero).
   * @param timeout Communication-loss timeout, in seconds (range 0-10);
   *        see @c call_online_l for the full explanation.
   * @param filter Output smoothing filter value.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_online_l(const std::string& robot_model, const IPC::MoveInput_TargetT& target,
                    const MoveSpeedArg& speed, const float timeout, const float filter,
                    FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Online_LT req;

    auto targ = std::make_unique<IPC::MoveInput_TargetT>();

    targ->tar_frame = target.tar_frame;
    targ->tar_unit = target.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, target.tar_values.size()); ++i)
      vals[i] = std::round(target.tar_values[i] * 1000.0f) / 1000.0f;

    targ->tar_values = std::move(vals);

    req.target = std::move(targ);

    auto speed_input = std::make_unique<IPC::MoveInput_SpeedT>();

    // Python 원본과 동일: speed 의 개별 필드가 없으면 60/120 기본값을 쓴다.
    speed_input->spd_mode = speed.spd_mode.value_or(1);
    speed_input->spd_vel_para = speed.spd_vel_para.value_or(60);
    speed_input->spd_acc_para = speed.spd_acc_para.value_or(120);

    req.speed = std::move(speed_input);

    req.timeout = timeout;
    req.filter = filter;

    publish<IPC::Request_Online_LT>(robot_model + "/pub_online_l", req, 80, "",
                                    static_cast<int>(CongestionControl::DROP), static_cast<int>(Priority::REAL_TIME),
                                    true);

    if (flow_manager_args)
      flow_manager_args->done();
  }

  /**
   * @brief Requests the cobot to queue a keyframe-timed joint-space target.
   *
   * Streaming/realtime joint control: each call queues one keyframe
   * (angle, velocity, and acceleration) at a given @p timestamp along a
   * continuous internal timeline, and the robot interpolates a polynomial
   * trajectory between consecutive keyframes. This differs from
   * @c call_servo_j, which specifies each segment as a relative duration
   * (@c t1) from wherever the previous segment left off — here @p
   * timestamp is a point on an absolute, ever-accumulating clock, so
   * keyframes must be queued with strictly increasing timestamps.
   *
   * @param robot_model Name of the robot model.
   * @param j_ang Target joint angles for this keyframe.
   * @param j_vel Target joint velocities for this keyframe. Ignored when
   *        @p polynomial is 2 (linear).
   * @param j_acc Target joint accelerations for this keyframe. Only used
   *        when @p polynomial is 1 (5th order).
   * @param polynomial Trajectory interpolation order between this
   *        keyframe and the previous one: 0 3rd order (uses @p j_ang and
   *        @p j_vel), 1 5th order (uses @p j_ang, @p j_vel, and @p
   *        j_acc), 2 1st order/linear (uses @p j_ang only).
   * @param timestamp Absolute time, in seconds on the internal motion
   *        timeline, at which this keyframe should be reached.
   * @param timeout Communication-loss timeout, in seconds: if no new
   *        keyframe is queued within this time after the last one was
   *        reached, the motion is considered finished.
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_timestamp_j(const std::string& robot_model, const IPC::MoveInput_TargetT& j_ang,
                                            const IPC::MoveInput_TargetT& j_vel, const IPC::MoveInput_TargetT& j_acc,
                                            const int polynomial, const float timestamp, const float timeout,
                                            const float filter, FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_TimeStamp_JT req;

    auto ang = std::make_unique<IPC::MoveInput_TargetT>();

    ang->tar_frame = j_ang.tar_frame;
    ang->tar_unit = j_ang.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, j_ang.tar_values.size()); ++i)
      vals[i] = std::round(j_ang.tar_values[i] * 1000.0f) / 1000.0f;

    ang->tar_values = std::move(vals);

    req.j_ang = std::move(ang);

    auto vel = std::make_unique<IPC::MoveInput_TargetT>();

    vel->tar_frame = j_vel.tar_frame;
    vel->tar_unit = j_vel.tar_unit;

    std::vector<float> valss(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, j_vel.tar_values.size()); ++i)
      valss[i] = std::round(j_vel.tar_values[i] * 1000.0f) / 1000.0f;

    vel->tar_values = std::move(valss);

    req.j_vel = std::move(vel);

    auto acc = std::make_unique<IPC::MoveInput_TargetT>();

    acc->tar_frame = j_acc.tar_frame;
    acc->tar_unit = j_acc.tar_unit;

    std::vector<float> valsss(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, j_acc.tar_values.size()); ++i)
      valsss[i] = std::round(j_acc.tar_values[i] * 1000.0f) / 1000.0f;

    acc->tar_values = std::move(valsss);

    req.j_acc = std::move(acc);

    req.polynomial = polynomial;
    req.timestamp = timestamp;
    req.timeout = timeout;
    req.filter = filter;

    std::unique_ptr<IPC::Response_FunctionsT> result = query_one<IPC::Response_Functions, IPC::Request_TimeStamp_JT>(
        robot_model + "/call_timestamp_j", req, 8, 3000, 0);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Timestamp J", std::move(*result),
                                                          "call_timestamp_j", flow_manager_args);
  }

  /**
   * @brief Publishes a keyframe-timed joint-space target without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_timestamp_j: queues one
   * keyframe the same way, but publishes it (real-time priority, dropping
   * under congestion) instead of querying and does not report failures
   * back to the caller.
   *
   * @param robot_model Name of the robot model.
   * @param j_ang Target joint angles for this keyframe.
   * @param j_vel Target joint velocities for this keyframe. Ignored when
   *        @p polynomial is 2 (linear).
   * @param j_acc Target joint accelerations for this keyframe. Only used
   *        when @p polynomial is 1 (5th order).
   * @param polynomial Trajectory interpolation order between this
   *        keyframe and the previous one; see @c call_timestamp_j for the
   *        full explanation.
   * @param timestamp Absolute time, in seconds on the internal motion
   *        timeline, at which this keyframe should be reached.
   * @param timeout Communication-loss timeout, in seconds; see @c
   *        call_timestamp_j for the full explanation.
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_timestamp_j(const std::string& robot_model, const IPC::MoveInput_TargetT& j_ang,
                       const IPC::MoveInput_TargetT& j_vel, const IPC::MoveInput_TargetT& j_acc, const int polynomial,
                       const float timestamp, const float timeout, const float filter,
                       FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_TimeStamp_JT req;

    auto ang = std::make_unique<IPC::MoveInput_TargetT>();

    ang->tar_frame = j_ang.tar_frame;
    ang->tar_unit = j_ang.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, j_ang.tar_values.size()); ++i)
      vals[i] = std::round(j_ang.tar_values[i] * 1000.0f) / 1000.0f;

    ang->tar_values = std::move(vals);

    req.j_ang = std::move(ang);

    auto vel = std::make_unique<IPC::MoveInput_TargetT>();

    vel->tar_frame = j_vel.tar_frame;
    vel->tar_unit = j_vel.tar_unit;

    std::vector<float> valss(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, j_vel.tar_values.size()); ++i)
      valss[i] = std::round(j_vel.tar_values[i] * 1000.0f) / 1000.0f;

    vel->tar_values = std::move(valss);

    req.j_vel = std::move(vel);

    auto acc = std::make_unique<IPC::MoveInput_TargetT>();

    acc->tar_frame = j_acc.tar_frame;
    acc->tar_unit = j_acc.tar_unit;

    std::vector<float> valsss(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, j_acc.tar_values.size()); ++i)
      valsss[i] = std::round(j_acc.tar_values[i] * 1000.0f) / 1000.0f;

    acc->tar_values = std::move(valsss);

    req.j_acc = std::move(acc);

    req.polynomial = polynomial;
    req.timestamp = timestamp;
    req.timeout = timeout;
    req.filter = filter;

    publish<IPC::Request_TimeStamp_JT>(robot_model + "/pub_timestamp_j", req, 80, "",
                                       static_cast<int>(CongestionControl::DROP), static_cast<int>(Priority::REAL_TIME),
                                       true);

    if (flow_manager_args)
      flow_manager_args->done();
  }

  /**
   * @brief Requests the cobot to start joint-space torque (compliance) control.
   *
   * Unlike the position-based servo/online/timestamp motions above, this
   * commands per-joint target torques directly rather than a target pose.
   * The robot must be idle (no other motion in progress) when this is
   * called, or the request is rejected.
   *
   * @param robot_model Name of the robot model.
   * @param target Target torque for each joint, in the same order as the
   *        robot's joints. Must have exactly as many elements as the
   *        robot has joints, or the firmware rejects the request.
   * @param time_out Maximum duration to hold this torque command, in
   *        seconds (valid range [0.0001, 10]).
   * @param option Which compensation terms are combined with @p target:
   *        0 Gravity + Friction feedforward + User target, 1 Gravity +
   *        User target, 2 Friction feedforward + User target, 3 User
   *        target only.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        movement result is reported to the flow manager immediately,
   *        and a background monitor invokes its completion callback once
   *        the actual motion finishes, instead of blocking here until then.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If @p target is not provided, the query
   *         fails, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_servo_t(const std::string& robot_model, std::optional<std::vector<float>> target,
                                        const float time_out, const int option,
                                        FlowManagerArgsPtr flow_manager_args = nullptr)

  {
    IPC::Request_Servo_TT req;

    if (!target) {
      throw std::runtime_error("Call Servo T Execution Failed: target must contain values.");
    }

    req.target = target.value();
    req.time_out = time_out;
    req.option = option;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Servo_TT>(robot_model + "/call_servo_t", req, 8, 3000, 0);

    return _apply_time_checking<IPC::Response_FunctionsT>(robot_model, "Servo T", std::move(*result), "call_servo_t",
                                                          flow_manager_args);
  }

  /**
   * @brief Publishes a joint-space torque (compliance) control target without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_servo_t: sends the same torque
   * command, but publishes it (real-time priority, dropping under
   * congestion) instead of querying and does not report failures back to
   * the caller.
   *
   * @param robot_model Name of the robot model.
   * @param target Target torque for each joint; see @c call_servo_t for
   *        the full explanation.
   * @param time_out Maximum duration to hold this torque command, in
   *        seconds (valid range [0.0001, 10]).
   * @param option Which compensation terms are combined with @p target;
   *        see @c call_servo_t for the full explanation.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   *
   * @throws std::runtime_error If @p target is not provided.
   */
  void pub_servo_t(const std::string& robot_model, std::optional<std::vector<float>> target, const float time_out,
                   const int option, FlowManagerArgsPtr flow_manager_args = nullptr)

  {
    IPC::Request_Servo_TT req;

    if (!target) {
      throw std::runtime_error("Call Servo T Execution Failed: target must contain values.");
    }

    req.target = target.value();
    req.time_out = time_out;
    req.option = option;

    publish<IPC::Request_Servo_TT>(robot_model + "/pub_servo_t", req, 80, "", static_cast<int>(CongestionControl::DROP),
                                   static_cast<int>(Priority::REAL_TIME), true);

    if (flow_manager_args)
      flow_manager_args->done();
  }

  /**
   * @brief Requests the cobot to start (or queue a target for) wrapper-layer Cartesian servo tracking.
   *
   * Streaming/realtime Cartesian control, similar in purpose to @c
   * call_servo_l, but runs in the firmware's separate "wrapper" motion
   * layer (the same layer used by @c call_tcp_weaving_on, @c
   * call_admittance_force_on, and @c call_base_conveyor_on) rather than
   * the main move sequencer. Each call queues one target to move smoothly
   * toward from wherever the previous target left off; intended to be
   * called repeatedly (e.g. once per control tick) to stream a
   * trajectory. Call @c call_wrapper_servo_l_off to stop tracking.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param time_gap Time to move from the previous target to this one, in
   *        seconds (valid range [0, 30]).
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p time_gap is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_wrapper_servo_l_on(const std::string& robot_model, const IPC::MoveInput_TargetT& target,
                                                   float time_gap, const float filter,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Wrapper_ServoL_OnT req;

    auto targ = std::make_unique<IPC::MoveInput_TargetT>();

    targ->tar_frame = target.tar_frame;
    targ->tar_unit = target.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, target.tar_values.size()); ++i)
      vals[i] = std::round(target.tar_values[i] * 1000.0f) / 1000.0f;

    targ->tar_values = std::move(vals);

    req.target = std::move(targ);

    req.time_gap = time_gap;
    req.filter = filter;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_ServoL_OnT>(robot_model + "/call_wrapper_servo_l_on",
                                                                            req, 8, 15000, 0);

    if (!result)
      throw std::runtime_error("Call Wrapper Servo L On failed: query one returned nullptr");

    manipulate_return_value("call_wrapper_servo_l_on", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Requests the cobot to stop wrapper-layer Cartesian servo tracking.
   *
   * Stops the tracking started by @c call_wrapper_servo_l_on.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT call_wrapper_servo_l_off(const std::string& robot_model,
                                                    FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Wrapper_ServoL_OffT req;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_ServoL_OffT>(robot_model + "/call_wrapper_servo_l_off",
                                                                             req, 8, 15000, 0);

    if (!result)
      throw std::runtime_error("Call Wrapper Servo L Off failed: query one returned nullptr");

    manipulate_return_value("call_wrapper_servo_l_off", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Publishes a wrapper-layer Cartesian servo target without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_wrapper_servo_l_on: queues one
   * target the same way, but publishes it (real-time priority, dropping
   * under congestion) instead of querying and does not report failures
   * back to the caller.
   *
   * @param robot_model Name of the robot model.
   * @param target Target position and frame information.
   * @param time_gap Time to move from the previous target to this one, in
   *        seconds (valid range [0, 30]).
   * @param filter Output low-pass filter strength.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_wrapper_servo_l_on(const std::string& robot_model, const IPC::MoveInput_TargetT& target, float time_gap,
                              const float filter, FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Wrapper_ServoL_OnT req;

    auto targ = std::make_unique<IPC::MoveInput_TargetT>();

    targ->tar_frame = target.tar_frame;
    targ->tar_unit = target.tar_unit;

    std::vector<float> vals(7, 0.0f);

    for (size_t i = 0; i < std::min<size_t>(7, target.tar_values.size()); ++i)
      vals[i] = std::round(target.tar_values[i] * 1000.0f) / 1000.0f;

    targ->tar_values = std::move(vals);

    req.target = std::move(targ);

    req.time_gap = time_gap;
    req.filter = filter;

    publish<IPC::Request_Wrapper_ServoL_OnT>(robot_model + "/pub_wrapper_servo_l_on", req, 80, "",
                                             static_cast<int>(CongestionControl::DROP),
                                             static_cast<int>(Priority::REAL_TIME), true);

    if (flow_manager_args)
      flow_manager_args->done();
  }

  /**
   * @brief Publishes a stop request for wrapper-layer Cartesian servo tracking without waiting for a response.
   *
   * Fire-and-forget counterpart to @c call_wrapper_servo_l_off.
   *
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) right after publishing, without confirming the
   *        robot received or accepted it.
   */
  void pub_wrapper_servo_l_off(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Wrapper_ServoL_OffT req;

    publish<IPC::Request_Wrapper_ServoL_OffT>(robot_model + "/pub_wrapper_servo_l_off", req, 80, "",
                                              static_cast<int>(CongestionControl::DROP),
                                              static_cast<int>(Priority::REAL_TIME), true);

    if (flow_manager_args)
      flow_manager_args->done();
  }

  /**
   * @brief Requests the cobot to block until the current motion finishes.
   *
   * Waits, on the robot side, until whatever motion is currently running
   * reaches completion (or no motion is running, in which case this
   * returns immediately).
   *
   * @param robot_model Name of the robot model.
   * @param timeout_sec Maximum time to wait, in seconds. A negative value
   *        (e.g. -1) waits indefinitely, with no timeout.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the response is received, provided its
   *        motion_result is 0; a nonzero motion_result raises before
   *        flow_manager_args.done() is reached.
   *
   * @return IPC::Response_Move_WaitT whose motion_result field is 0 on
   *         success, -1 if the wait timed out, or another value giving
   *         the underlying motion's execution result code.
   *
   * @throws std::runtime_error If the query fails, the result cannot be
   *         retrieved, or (when @p flow_manager_args is not provided)
   *         motion_result is nonzero.
   */
  IPC::Response_Move_WaitT call_move_wait(const std::string& robot_model, float timeout_sec,
                                          FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Move_WaitT req;

    req.timeout_sec = timeout_sec;

    std::unique_ptr<IPC::Response_Move_WaitT> result = query_one<IPC::Response_Move_Wait, IPC::Request_Move_WaitT>(
        robot_model + "/call_move_wait", req, 8, static_cast<int>(timeout_sec * 1000), 0);

    if (!result)
      throw std::runtime_error("Call Move Wait failed: query one returned nullptr");

    if (!flow_manager_args && result->motion_result != 0) {
      std::string error_msg = "[call_move_wait] motion_result is " + std::to_string(result->motion_result);

      std::cerr << error_msg << std::endl;
      throw std::runtime_error(error_msg);
    }

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  template <typename T>
  T _apply_time_checking(const std::string& robot_model, const std::string& title, T payload,
                         const std::string& call_function, FlowManagerArgsPtr flow_manager_args = nullptr) {
    manipulate_return_value(call_function, payload, flow_manager_args);

    uint64_t timestamp_u_sec_mono = payload.timestamp_usec_mono;

    if (!flow_manager_args) {
      return payload;
    }

    // _move_flow_manager_solver는 void를 반환하며, 내부적으로
    // detach된 스레드를 띄워 state_core를 구독해 실제 동작 완료 신호를
    // 백그라운드에서 기다렸다가 done()을 호출한다. 그 완료를 여기서
    // 기다리지 않고 즉시 리턴한다.
    _move_flow_manager_solver(timestamp_u_sec_mono, robot_model, flow_manager_args);

    return payload;
  }

 private:
  // shared_ptr로 관리 — 비동기 콜백이 참조하는 동안 살아있도록 보장(댕글링 방지).

  RBManipulateGetDataSDK _get_data_sdk = RBManipulateGetDataSDK();

  // blend 이동(jb/lb/xb add) 구간별 파라미터. state_core의 motion_sub_index가
  // 이 리스트의 인덱스가 된다 (Python 원본 _blended_add_list 대응).
  struct _BlendedParam {
    std::string step_id;
    FlowValuePtr action_script;
    FlowValuePtr finish_at;
    FlowValuePtr stop_time;
  };

  // C++은 RBManipulatePointSDK::_move_sdk 와 RBManipulateSDK::move 가 서로 다른
  // 인스턴스라 인스턴스별로 들면 set_point 가 쌓은 blend 구간을 solver 가 못 본다
  // (Python은 싱글톤이라 공유됨). 그 의미를 맞추려고 프로세스 단위로 공유한다.
  // 접근은 항상 GIL 보유 상태에서만.
  inline static std::vector<_BlendedParam> _blended_add_list;

  // Python 원본 _blended_param_add 대응. variable_name은 안 담으므로 blend
  // 구간에서는 항상 None.
  void _blended_param_add(FlowManagerArgsPtr flow_manager_args) {
    if (!flow_manager_args)
      return;

    _BlendedParam p;
    p.step_id = flow_manager_args->current_step_id();
    p.action_script = flow_manager_args->arg("_action_script");
    p.finish_at = flow_manager_args->arg("finish_at");
    p.stop_time = flow_manager_args->arg("stop_time");

    _blended_add_list.push_back(std::move(p));
  }

  struct _FlowManagerState {
    FlowManagerArgsPtr flow_manager_args;
    FlowValuePtr finish_at;
    FlowValuePtr stop_time;
    std::optional<std::string> variable_name;
    FlowValuePtr action_script;
    std::atomic_bool finished{false};
    // zenoh_subscribe()가 반환하기 전에도 콜백이 실행될 수 있어 subs_id가
    // 아직 -1일 수 있다 — 읽는 쪽은 반드시 유효성 확인.
    std::atomic<int> subs_id{-1};
    std::string robot_model;
    int64_t start_timestamp_u_sec_mono = 0;
    std::string prev_sub_step_id;  // Python 원본 _on_state 의 nonlocal prev_sub_step_id
    bool has_prev_sub_step_id = false;
  };

  // unsubscribe: 모니터링 종료 후 구독 해지 여부. 기본 false(구독 유지, 원본 동작).
  void _move_flow_manager_solver(const uint64_t start_timestamp_u_sec_mono, const std::string& robot_model,
                                 FlowManagerArgsPtr flow_manager_args = nullptr, bool unsubscribe = false) {
    if (!flow_manager_args) {
      return;
    }
    auto state = std::make_shared<_FlowManagerState>();

    state->flow_manager_args = flow_manager_args;
    state->finish_at = flow_manager_args->arg("finish_at");
    state->stop_time = flow_manager_args->arg("stop_time");
    state->variable_name = flow_manager_args->string_arg("variable_name");
    state->action_script = flow_manager_args->arg("_action_script");
    state->robot_model = robot_model;
    state->start_timestamp_u_sec_mono = start_timestamp_u_sec_mono;
    state->finished = false;

    state->subs_id = zenoh_subscribe<IPC::State_Core>(
        state->robot_model + "/state_core",
        [this, state, unsubscribe](const std::string& topic, std::unique_ptr<typename IPC::State_CoreT> payload,
                                   const std::string& attachment) {
          if (payload == nullptr) {
            return;
          }

          if (payload->timestamp_usec_mono <= state->start_timestamp_u_sec_mono) {
            return;
          }

          // blend 구간이 있으면 그 구간의 파라미터를, 없으면 flow_manager_args.args 값을 쓴다.
          const int sub_index = static_cast<int>(payload->motion_sub_index);
          const _BlendedParam* blended = (sub_index >= 0 && static_cast<size_t>(sub_index) < _blended_add_list.size())
                                             ? &_blended_add_list[static_cast<size_t>(sub_index)]
                                             : nullptr;

          const std::string sub_step_id = blended ? blended->step_id : std::string();
          FlowValuePtr finish_at = blended ? blended->finish_at : state->finish_at;
          FlowValuePtr stop_time = blended ? blended->stop_time : state->stop_time;
          std::optional<std::string> variable_name = blended ? std::nullopt : state->variable_name;

          try {
            FlowManagerContext& ctx = state->flow_manager_args->context();
            ctx.check_stop();

            // blend 구간 전환마다 이전 구간 닫고 다음 구간 연다 (없으면 pyfm이
            // blend 이동 전체를 스텝 하나로만 봄).
            if (!sub_step_id.empty() && state->prev_sub_step_id != sub_step_id) {
              if (state->has_prev_sub_step_id) {
                FlowValuePtr prev_action_script;
                for (const auto& item : _blended_add_list) {
                  if (item.step_id == state->prev_sub_step_id) {
                    prev_action_script = item.action_script;
                    break;
                  }
                }

                if (prev_action_script)
                  ctx.eval_action(prev_action_script);

                ctx.emit_done(state->prev_sub_step_id);
              }

              state->prev_sub_step_id = sub_step_id;
              state->has_prev_sub_step_id = true;

              ctx.emit_next(state->prev_sub_step_id);
            }

            if (variable_name) {
              ctx.update_local_variables(FlowVariables{{*variable_name, payload->carte_x_ref}});
            }

            // 빈 문자열 finish_at 은 조건 없음으로 취급 (기존 동작 유지).
            const bool finish_at_set = finish_at && !ctx.is_empty_string(finish_at);

            if (finish_at_set && payload->motion_mode % 100 != 0) {
              if (ctx.eval_bool(finish_at)) {
                float parsed_stop_time = stop_time ? ctx.eval_float(stop_time) : 0.0f;

                _check_numeric(parsed_stop_time);
                // Python 원본은 여기서 stop 만 걸고 done() 을 부르지 않는다.
                // 실제 종료는 아래 motion_mode % 100 == 0 경로가 담당한다.
                call_smoothjog_stop(state->robot_model, parsed_stop_time);
              }
            }

            if (payload->motion_mode % 100 == 0 && payload->motion_execution_result == 0) {
              state->flow_manager_args->done();

              if (unsubscribe) {
                const int sid = state->subs_id.load();
                if (sid >= 0) {
                  std::thread unsub_t([this, sid] { zenoh_client_->undeclare_subscriber(sid); });
                  unsub_t.detach();
                }
              }

              if (state->action_script)
                ctx.eval_action(state->action_script);

              _blended_add_list.clear();

              // 정상 종료점 (Python 원본 done_event.set() 대응). 안 세우면
              // 아래 finished.wait()가 안 풀리고 구독도 안 풀린다.
              state->finished = true;
              state->finished.notify_one();
            }
          } catch (const std::exception& e) {
            // zenoh 콜백 스레드라 여기서 다시 throw해도 받아줄 caller가 없다
            // (std::terminate로 직행) — 로그만 남기고 종료. PyFM 브리지에서 올라오는
            // Python 예외도 std::exception 파생이라 여기서 함께 잡힌다.
            std::cerr << "[move flow manager callback] exception: " << e.what() << std::endl;
            _blended_add_list.clear();
            state->finished = true;
            state->finished.notify_one();
          } catch (...) {
            std::cerr << "[move flow manager callback] unknown exception" << std::endl;
            _blended_add_list.clear();
            state->finished = true;
            state->finished.notify_one();
          }
        },
        {});
    {
      // GIL 쥔 채 undeclare하면 GIL 기다리는 zenoh 콜백과 서로 물린다 -> 놓고 대기.
      // _gil_release_if_held: GIL 을 실제로 들고 있을 때만 놓는다(순수 C++ 스레드 안전).
      _gil_release_if_held _g;
      state->finished.wait(false);

      const int sid = state->subs_id.load();
      if (!unsubscribe && sid >= 0)
        zenoh_client_->undeclare_subscriber(sid);
    }
  }

  void _check_numeric(const std::any& a) {
    if (a.type() != typeid(int) && a.type() != typeid(float)) {
      throw std::runtime_error("a must be int or float");
    }
  }

  IPC::Response_FunctionsT _conveyor_on(const std::string& robot_model, const int conv_type, const float conv_speed,
                                        const float conv_acc_time_sec,
                                        std::vector<std::unique_ptr<IPC::MoveInput_TargetT>>& conv_ref_points,
                                        FlowManagerArgsPtr flow_manager_args = nullptr) {
    // request 생성
    IPC::Request_Wrapper_Conveyor_OnT req;
    req.conv_speed = conv_speed;
    req.conv_acc_time_sec = conv_acc_time_sec;
    req.conv_ref_points = std::move(conv_ref_points);

    // query
    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Wrapper_Conveyor_OnT>(robot_model + "/call_base_conveyor_on",
                                                                              req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("Conveyor On failed: query one returned nullptr");

    manipulate_return_value("call_base_conveyor_on", *result, flow_manager_args);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  IPC::MoveInput_TargetT _calc_circle_tar_values(const std::string& robot_model,
                                                 const SafeMoveTargetArg& input_data) {
    // tar_values 파싱 실패(숫자 아닌 원소 등)를 조용히 7-zero 로 흡수하는 처리는
    // SafeMoveTargetArg 의 type_caster(binding/glue/move_target_values_caster.hpp) 가
    // 인자 변환 단계에서 이미 끝냈다 — Python 원본(calc_circle_tar_values 의 else 분기
    // try/except)과 동일하게, 여기 도달한 시점엔 항상 유효한 7-값이라 별도 try/catch 가
    // 필요 없다.
    //
    // Python 원본은 relative_value 로 원본 input_data 를(반올림 전), reference_value 로는
    // 반올림/패딩된 temp_ni 를 따로 쓴다. 여기서는 caster 가 만든 반올림/패딩된 값 하나를
    // 양쪽에 공용으로 쓴다 — relative_value 쪽에 소수 3자리 반올림이 더 들어가는 차이만
    // 있고(로봇 이동 정밀도에 영향 없는 수준), 파싱 실패를 흡수한다는 본질은 동일하다.
    try {
      IPC::MoveInput_TargetT relative_value{
          .tar_values = input_data.tar_values, .tar_frame = input_data.tar_frame, .tar_unit = input_data.tar_unit};

      IPC::Response_Get_Relative_ValueT res = _get_data_sdk.get_relative_value(
          robot_model, relative_value,
          IPC::MoveInput_TargetT{.tar_values = input_data.tar_values, .tar_frame = 0, .tar_unit = 0}, 1);

      if (res.calculated_result != 0) {
        throw std::runtime_error("Relative move value failed in calc circle tar values: " +
                                 std::to_string(res.calculated_result));
      }

      return std::move(*res.calculated_value);
    } catch (const std::exception& e) {
      // 반환값이 원형 이동의 목표 좌표로 바로 쓰인다. 여기서 예외를 삼키면
      // 반환할 유효한 좌표가 없어 로봇이 쓰레기값으로 움직인다. 반드시 전파한다.
      std::cerr << e.what() << std::endl;
      throw;
    }
  }
};
