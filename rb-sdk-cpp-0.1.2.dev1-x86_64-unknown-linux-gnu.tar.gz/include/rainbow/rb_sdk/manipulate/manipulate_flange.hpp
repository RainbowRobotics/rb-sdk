#pragma once

#include "common_struct_generated.h"

#include "base.hpp"
#include "func_flage_generated.h"

class RBManipulateFlangeSDK : public RBBaseSDK {
 public:
  RBManipulateFlangeSDK() {}

  static std::string type_name() { return "RBManipulateFlangeSDK"; }

  /**
   * @brief Saves the tool number to be automatically mounted on the
            flange at boot-up.
   *
   * Configures which tool (from the saved tool list) is automatically
   * mounted on the flange when the controller boots up.
   *
   * @param robot_model Name of the robot model.
   * @param tool_num Tool number to mount at boot-up (0~7).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the result of the request.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_flange_bootup_mount_tool(const std::string& robot_model, const int tool_num,
                                                         FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Save_Flange_Boot_ToolListT req;
    req.tool_num = tool_num;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Save_Flange_Boot_ToolListT>(
            robot_model + "/save_flange_bootup_mount_tool", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("save_flange_bootup_mount_tool failed");

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the tool flange's boot-up DC power output voltage.
   *
   * Configures the DC voltage supplied through the tool flange when the
   * controller boots up.
   *
   * @param robot_model Name of the robot model.
   * @param voltage_value Boot-up DC voltage setting (0: 0V, 1: 12V, 2: 24V).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the result of the request.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_flange_bootup_dc_voltage(const std::string& robot_model, const int voltage_value,
                                                         FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Save_Flange_Boot_DCvoltageT req;
    req.voltage_value = voltage_value;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Save_Flange_Boot_DCvoltageT>(
            robot_model + "/save_flange_bootup_dc_voltage", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("save_flange_bootup_dc_voltage failed");

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the role/usage setting of the tool flange's direct
            teaching button.
   *
   * Configures whether the direct teaching button mounted on the tool
   * flange is enabled for use.
   *
   * @param robot_model Name of the robot model.
   * @param working_mode Usage setting (0: Use, 1: Not use).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the result of the request.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_flange_dt_button_role(const std::string& robot_model, const int working_mode,
                                                      FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Save_Flange_DTbutton_RoleT req;
    req.working_mode = working_mode;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Save_Flange_DTbutton_RoleT>(
            robot_model + "/save_flange_dt_button_role", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("save_flange_dt_button_role failed");

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }

  /**
   * @brief Saves the usage setting of the tool flange's vibration sensor.
   *
   * Configures whether the vibration sensor mounted on the tool flange
   * is enabled for use.
   *
   * @param robot_model Name of the robot model.
   * @param working_mode Usage setting (0: Use, 1: Not use).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the result of the request.
   *
   * @throws std::runtime_error If the query fails or the result cannot be
   *         retrieved.
   */
  IPC::Response_FunctionsT save_flange_vibration_sensor(const std::string& robot_model, const int working_mode,
                                                        FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Save_Flange_Vibration_SensorT req;
    req.working_mode = working_mode;

    std::unique_ptr<IPC::Response_FunctionsT> result =
        query_one<IPC::Response_Functions, IPC::Request_Save_Flange_Vibration_SensorT>(
            robot_model + "/save_flange_vibration_sensor", req, 8, 2000, 0);

    if (!result)
      throw std::runtime_error("save_flange_vibration_sensor failed");

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }
};
