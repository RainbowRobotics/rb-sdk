#pragma once

#include "base.hpp"
#include "common_struct_generated.h"
#include "func_config_generated.h"
#include "func_get_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "state_core_generated.h"

using Response_get_core_data_variant = std::variant<float, std::vector<float>, std::optional<std::string>>;

// IPC::Response_Get_ValueT (set_pin_point_or_joint 반환)는 func_get.fbs 의
// Response_Get_Value 테이블에서 생성된다 — dict <-> struct 변환은 rb_fbs_casters.hpp
// 의 자동 type_caster 가 담당하므로 여기서 손 caster 를 두지 않는다.

class RBManipulateGetDataSDK : public RBBaseSDK {
 public:
  RBManipulateGetDataSDK() {}

  static std::string type_name() { return "RBManipulateGetDataSDK"; }

  /**
   * @brief Computes the coordinate a relative move would resolve to.
   *
   * Given @p reference_value as the starting point, computes the absolute
   * target that moving by @p relative_value from it resolves to. Used
   * internally by the move-family functions' relative-move calculation
   * (e.g. @c call_move_j / @c call_move_l).
   *
   * @p relative_value and @p reference_value do not need the same
   * tar_frame: if one is Joint Space (tar_frame -1) and the other isn't,
   * the robot converts one to match the other (forward/inverse kinematics)
   * before combining them, then converts the combined result again if
   * needed to match @p move_type. This conversion can itself fail (e.g. an
   * unreachable target), which surfaces as a nonzero calculated_result.
   *
   * @param robot_model Name of the robot model.
   * @param relative_value Relative offset target and frame information.
   *        tar_values must have exactly 7 elements — this SDK passes it
   *        through unmodified, so callers must pad to 7 themselves (e.g.
   *        with 0 for a 6-axis model's unused ArmAngle slot).
   * @param reference_value Reference target and frame information.
   *        tar_values must resolve to exactly 7 elements after this SDK
   *        truncates it to at most 7 — supplying fewer than 7 will not be
   *        padded and will fail the same way as an oversized/undersized
   *        @p relative_value.
   * @param move_type 0 for the move-J family (joint-space), 1 for the
   *        move-L family (Cartesian-space).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_Get_Relative_ValueT with calculated_result (0 on
   *         success) and calculated_value (the computed absolute target).
   *         If either tar_values doesn't resolve to exactly 7 elements,
   *         the robot rejects the request before any calculation runs:
   *         calculated_result is nonzero and calculated_value is left
   *         unset.
   *
   * @note This function does not throw on calculation failure —
   *       calculated_result nonzero must be checked by the caller (as the
   *       move-family functions do).
   *
   * @throws std::runtime_error If the query itself fails (e.g. no reply).
   */
  IPC::Response_Get_Relative_ValueT get_relative_value(const std::string& robot_model,
                                                       const IPC::MoveInput_TargetT& relative_value,
                                                       const IPC::MoveInput_TargetT& reference_value, int move_type,
                                                       FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::Request_Get_Relative_ValueT req;

    req.relative_value = std::make_unique<IPC::MoveInput_TargetT>();
    req.reference_value = std::make_unique<IPC::MoveInput_TargetT>();

    req.relative_value->tar_values = relative_value.tar_values;
    req.relative_value->tar_frame = relative_value.tar_frame;
    req.relative_value->tar_unit = relative_value.tar_unit;

    req.reference_value->tar_values.assign(
        reference_value.tar_values.begin(),
        reference_value.tar_values.begin() + std::min<size_t>(7, reference_value.tar_values.size()));

    req.reference_value->tar_frame = reference_value.tar_frame;

    req.reference_value->tar_unit = reference_value.tar_unit;

    req.move_type = move_type;

    auto result = query_one<IPC::Response_Get_Relative_Value, IPC::Request_Get_Relative_ValueT>(
        robot_model + "/get_relative_value", req, 256, 1000, 0);

    if (flow_manager_args) {
      flow_manager_args->done();
    }

    return std::move(*result);
  }

  /**
   * @brief Looks up a named runtime variable/system value on the robot.
   *
   * @param robot_model Name of the robot model.
   * @param name Variable name to query.
   *
   * @return The variable's value as a float, a list of floats, or a
   *         string, depending on its reported type; std::nullopt if the
   *         response's type doesn't match any of those.
   *
   * @note Unlike the Python original, this does not check the response's
   *       "valid" field. An unknown/invalid @p name is expected to make
   *       the robot report valid=0, but this implementation ignores that
   *       and still returns whatever payload matches the reported type —
   *       it will not reliably signal an invalid lookup with std::nullopt.
   *
   * @throws std::runtime_error If the query itself fails (e.g. no reply).
   */
  Response_get_core_data_variant get_variable(const std::string& robot_model, const std::string& name) {
    IPC::Request_Get_Core_DataT req;
    req.option = 0;
    req.name = name;

    auto result = query_one<IPC::Response_Get_Core_Data, IPC::Request_Get_Core_DataT>(robot_model + "/get_core_data",
                                                                                      req, 256, 1000, 0);

    IPC::Response_Get_Core_DataT res = *result;

    if (res.type == 0)
      return res.payload_num;
    else if (res.type == 1)
      return res.payload_arr;
    else if (res.type == 2)
      return res.payload_str;
    else
      return std::nullopt;
  }

  /**
   * @brief Computes the absolute coordinate a reference target resolves to.
   *
   * Used internally for absolute (non-relative) target resolution, e.g. by
   * @c set_pin_point_or_joint when no reference_target offset is given.
   * @p reference_value's tar_frame does not need to match @p move_type:
   * the robot always converts it (forward/inverse kinematics as needed) to
   * the frame matching @p move_type. This conversion can itself fail (e.g.
   * an unreachable target), which surfaces as a nonzero calculated_result.
   *
   * @param robot_model Name of the robot model.
   * @param reference_value Reference target and frame information.
   *        tar_values must resolve to exactly 7 elements — this SDK
   *        truncates it to at most 7, so supplying fewer than 7 will not
   *        be padded and the request will be rejected.
   * @param move_type 0 for the move-J / pin-joint family (joint-space), 1
   *        for the move-L / pin-point family (Cartesian-space).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_Get_Absolute_ValueT with calculated_result (0 on
   *         success) and calculated_value (the computed absolute target).
   *         If tar_values doesn't resolve to exactly 7 elements, the robot
   *         rejects the request before any calculation runs:
   *         calculated_result is nonzero and calculated_value is left
   *         unset.
   *
   * @note This function does not throw on calculation failure —
   *       calculated_result nonzero must be checked by the caller.
   *
   * @throws std::runtime_error If the query itself fails (e.g. no reply).
   */
  IPC::Response_Get_Absolute_ValueT get_absolute_value(const std::string& robot_model,
                                                       const IPC::MoveInput_TargetT& reference_value, int move_type,
                                                       FlowManagerArgsPtr flow_manager_args = nullptr) {
    auto req_reference_move_input_target = std::make_unique<IPC::MoveInput_TargetT>();
    req_reference_move_input_target->tar_values = reference_value.tar_values;
    req_reference_move_input_target->tar_frame = reference_value.tar_frame;
    req_reference_move_input_target->tar_unit = reference_value.tar_unit;

    IPC::Request_Get_Absolute_ValueT req_get_absolute_value;
    req_get_absolute_value.reference_value = std::move(req_reference_move_input_target);
    req_get_absolute_value.move_type = move_type;

    auto result = query_one<IPC::Response_Get_Absolute_Value, IPC::Request_Get_Absolute_ValueT>(
        robot_model + "/get_absolute_value", req_get_absolute_value, 256, 1000, 0);

    if (flow_manager_args)
      flow_manager_args->done();

    return std::move(*result);
  }
};
