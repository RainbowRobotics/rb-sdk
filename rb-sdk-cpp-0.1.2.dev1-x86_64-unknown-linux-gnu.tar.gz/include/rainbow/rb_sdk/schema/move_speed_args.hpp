#pragma once

#include <optional>

// call_move_j/l 등 이동 계열 함수의 speed 인자 전용 순수 C++ 인자.
// 자동 caster(dict->struct, rb_fbs_casters.hpp 의 IPC::MoveInput_SpeedT)는 dict 에 없는
// 필드를 struct 자체 기본값(0)으로 채운다. Python 원본은 함수마다 다른 non-zero 기본값
// (예: call_move_j 는 60/120, call_move_l 은 250/1000)을 개별 필드 단위로 적용하므로,
// 그 caster 를 그대로 쓰면 speed dict 를 일부 필드만 채워 보낼 때 나머지가 조용히 0이 되어
// 로봇에 정지/미정의 속도가 나갈 수 있다.
//
// 필드가 "왔는지 안 왔는지"를 여기서 std::optional 로 보존하고, 각 호출부
// (manipulate_move.hpp/manipulate_service.hpp)가 자기 함수의 Python 기본값으로
// .value_or(...) 해석한다 — vibration_motion_arg.hpp/program_setting_args.hpp 와 동일한 분리.
struct MoveSpeedArg {
  std::optional<int32_t> spd_mode;
  std::optional<float> spd_vel_para;
  std::optional<float> spd_acc_para;
};
