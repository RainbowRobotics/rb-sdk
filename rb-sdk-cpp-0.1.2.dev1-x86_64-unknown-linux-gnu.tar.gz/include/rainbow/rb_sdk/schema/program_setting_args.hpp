#pragma once

#include <array>

#include "common_struct_generated.h"

// setting(option="USER_FRAME_SELECTION" / "TARGET_SHIFT_LANDMARK") 전용 순수 C++ 인자.
// 자동 caster(dict->struct)는 모르는 키를 조용히 버리고 없는 필드를 0 으로 채운다.
// 기존 program args 는 Python SDK 시절 스키마(target_user_frame_num, 좌표 7-값 리스트)를
// 그대로 들고 있어서 그 caster 로는 엉뚱한 0 이 로봇에 나간다. 두 형식을 모두 해석하는
// 전용 type_caster (binding/glue/program_setting_caster.hpp) 를 바인딩 경계에 두고,
// SDK 코어(manipulate_program.hpp)는 아래 struct 만 본다.

struct UserFrameSelectionArg {
  int user_frame_num = 0;
};

struct ShiftLandMarkArg {
  int shift_mode = 0;
  float tolerance = 0.0f;
  // reference_point_1..3, present_point_1..3 순서.
  std::array<IPC::MoveInput_TargetT, 6> points{};
};
