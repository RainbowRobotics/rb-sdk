#pragma once

#include "func_move_generated.h"

// setting(option="VIBRATION_MOTION_BASED") 전용 순수 C++ 인자.
// dict(On/Off 판별 + On 이면 10개 파라미터 존재 검증)->struct 변환은 바인딩
// 경계의 type_caster (binding/glue/vibration_motion_caster.hpp) 가 담당한다.
// SDK 코어(manipulate_program.hpp)가 py::dict 를 직접 다루지 않게 하려는 분리.
struct VibrationMotionBasedArg {
  bool motion_on = false;
  IPC::Request_Wrapper_VibrationMotion_OnT on{};  // motion_on == true 일 때만 유효
};
