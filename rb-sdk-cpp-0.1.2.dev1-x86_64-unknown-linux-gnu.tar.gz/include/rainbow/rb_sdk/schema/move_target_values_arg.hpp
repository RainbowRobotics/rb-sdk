#pragma once

#include <vector>

// call_move_macro/call_pattern_on 등이 받는 좌표 포인트(corner_pnts/random_pnts/anchor_pnt)
// 전용 순수 C++ 인자. 항상 길이 7, 3자리 반올림으로 정규화된다.
//
// Python 원본은 각 포인트를 개별적으로 파싱하며, 값이 숫자로 변환되지 않는 등 파싱이
// 실패하면 그 포인트만 조용히 [0.0]*7 로 대체하고 나머지 포인트는 계속 처리한다
// (manipulate_service.py 의 call_move_macro/call_pattern_on 참고). std::vector<float> 를
// 함수 인자로 그대로 받으면 pybind 의 자동 리스트 caster 가 원소 하나만 잘못돼도 인자
// 변환 단계에서 통째로 예외를 던져 요청 전체가 실패한다 — Python 과 다른 동작이다.
// 그래서 이 struct 전용 type_caster(binding/glue/move_target_values_caster.hpp) 가
// 파싱 실패를 절대 실패로 취급하지 않고 대신 7-zero 로 흡수한다.
struct MoveTargetValuesArg {
  std::vector<float> tar_values;  // 항상 길이 7
};

// call_move_cir_axis(center/axis)/call_move_cir_threepoint(via_p/goal_p) 등 원 이동 계열이
// 받는 {tar_values, tar_frame, tar_unit} 형태 포인트 전용. tar_values 는 MoveTargetValuesArg
// 와 동일하게 파싱 실패를 절대 실패로 취급하지 않고 7-zero 로 흡수한다
// (manipulate_move.py 의 calc_circle_tar_values 의 else 분기 try/except 참고) — 자동
// IPC::MoveInput_TargetT caster 는 tar_values 캐스팅이 실패하면 인자 변환 단계에서 통째로
// 예외를 던져, 함수 안에 있던 기존 try/catch 가 도달 불가능한 죽은 코드가 되는 문제가 있었다.
struct SafeMoveTargetArg {
  std::vector<float> tar_values;  // 항상 길이 7
  int32_t tar_frame = 0;
  int32_t tar_unit = 0;
};
