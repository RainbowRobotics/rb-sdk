#pragma once

// zenoh 왕복(query_one/receive_one)이나 구독 정리는 응답/완료를 기다리며 C++ 레벨에서
// 블로킹한다. Python 에서 진입해 GIL 을 쥔 채 기다리면 같은 프로세스의 다른 zenoh
// 콜백(바인딩 어댑터에서 GIL 을 획득)과 서로 물린다 — Python 원본 SDK 는 이 자리에서
// await 로 양보했다.
//
// 코어(base.hpp / manipulate/*)는 pybind 를 알지 않는다(rb_zenoh 의 "isolate pybind
// callbacks from zenoh core" 와 동일 원칙). pybind 로 빌드되는 TU 만 RB_SDK_WITH_PYTHON
// 를 정의(CMake target_compile_definitions)하고, 그때만 실제로 GIL 을 놓는다.
// 순수 C++ 빌드에서는 빈 구조체 = no-op (인터프리터도 GIL 도 없음).
//
// 왜 flow_manager_args.hpp 처럼 virtual 브릿지/훅 주입이 아니라 컴파일 매크로인가:
//  - flow_manager_args 는 per-call 다형성 상태(ExecutionContext)가 있고, caster 등록을
//    빠뜨리면 *컴파일* 에러로 잡힌다.
//  - GIL 해제는 프로세스 전역 capability 이고 correctness-critical(놓치면 부하 시 데드락)
//    이다. 훅(std::function) 주입으로 하면 install 을 빠뜨렸을 때 조용히 no-op → 진단
//    어려운 런타임 데드락. 매크로는 "pybind 타겟이면 해제 코드가 무조건 컴파일된다" 를
//    보장해 빠뜨릴 자리 자체를 없앤다. 런타임 비용도 0.
//  - #ifdef 안에서만 pybind 를 include 하므로 순수 C++ 빌드는 pybind 라인을 아예 컴파일
//    하지 않는다("pybind-optional", 옛 무조건 include 와 다름). 진짜 목표("순수 C++
//    빌드가 pybind 를 필요로 하지 않는다")는 그대로 충족.
// => 두 파일이 메커니즘이 다른 건 문제가 달라서지 실수가 아니다. 재검토 금지.

#ifdef RB_SDK_WITH_PYTHON
#include <pybind11/pybind11.h>  // pybind11::gil_scoped_release, <Python.h> (PyGILState_Check)

#include <optional>
#endif

namespace rb_sdk {

// GIL 을 실제로 들고 있을 때만 놓는다(순수 C++ 스레드에서 불려도 안전). 스코프 종료 시
// 원상복구. RB_SDK_WITH_PYTHON 미정의 시 아무것도 안 한다.
struct gil_release_if_held {
#ifdef RB_SDK_WITH_PYTHON
  std::optional<pybind11::gil_scoped_release> guard_;

  gil_release_if_held() {
    if (PyGILState_Check())
      guard_.emplace();
  }
#else
  gil_release_if_held() {}  // user-provided: -Wunused-variable 억제
#endif
};

}  // namespace rb_sdk
