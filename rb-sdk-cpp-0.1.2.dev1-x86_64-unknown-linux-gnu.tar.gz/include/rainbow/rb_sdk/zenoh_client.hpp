#pragma once

#include "zenoh_core.hpp"
#include "zenoh_exception.hpp"

#include <flatbuffers/flatbuffers.h>

#include <atomic>
#include <chrono>
#include <future>
#include <memory>
#include <mutex>
#include <optional>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace rb_zenoh {

// ── FlatBuffer concept (namespace scope — concepts can't be inside a class) ───
template<typename T>
concept FlatBufferTClass = requires(const T obj, flatbuffers::FlatBufferBuilder fbb) {
    typename T::TableType;
    { T::TableType::Pack(fbb, &obj) };
};

// Query exceptions (ZenohNoReply / ZenohReplyError / ZenohQueryException) are
// defined in zenoh_exception.hpp — "무응답"과 "error reply"를 타입으로 구분해
// 호출자가 둘을 다르게 처리할 수 있게 한다(예: SDK 의 call_program_before/after
// 는 두 경우만 로그 후 통과하고 그 외는 전파).

// ── ZenohClient ───────────────────────────────────────────────────────────────
//
//   - Owns a ZenohCore session
//   - Generates sender_id (UUIDv4) at construction
//   - Builds zenoh config from env / runtime endpoint config (dev vs peer modes)
//   - Auto-attaches "sender=...;sender_id=..." to every publish
//   - Has a retry loop around session open
//
// This class is the unit that gets exposed to Python via pybind11 as the
// canonical client surface. C++ consumers (rb_sdk_cpp etc.) can include this
// header directly without going through Python.
//
// FlatBuffer overloads (publish<TObj>, query_one<FBSType>, etc.) are available
// directly from this header.
class ZenohClient {
public:
    explicit ZenohClient(std::string name = "", std::string sender = "RRS");
    ~ZenohClient();

    // ── Singleton ────────────────────────────────────────────────────────────
    // Most callers use get_instance() with NO arguments — this is the
    // process-wide default session (equivalent to Python ZenohClient()).
    // The session is opened automatically from env vars (SERVICE, IS_DEV, etc.)
    // on first call and reused from then on.
    //
    // The optional `name` param is for the rare case where you need a SECOND
    // independent session in the same process (e.g. flow executor child processes
    // that must not share state with the parent's session). Normal code never
    // needs it.
    //
    // Fork-safe: if owner PID doesn't match current PID a fresh instance is
    // created automatically (multiprocessing children get their own session).
    static std::shared_ptr<ZenohClient> get_instance(const std::string& name = "");

    // Registry lookup/creation WITHOUT opening the session. Callers that want to
    // supply their own connect() arguments (Python facade: sender, retry policy,
    // explicit config pairs) use this and then connect() only when the returned
    // instance is not connected yet. Together with get_instance() this keeps
    // exactly ONE session per (pid, name) no matter who asks first — a process
    // that opens a second session picks up the "common" listen-only profile,
    // fails to bind the already-taken port and ends up with zero links.
    static std::shared_ptr<ZenohClient> get_or_create(const std::string& name = "",
                                                      const std::string& sender = "RRS");

    // Builds the zenoh config_pairs from environment variables + runtime config.
    //   service   : "common" | "manipulate" | ... | "host" | ""
    //   is_dev    : IS_DEV
    //   is_child  : multiprocessing child (forces "client" / peer connect mode)
    // Reads env vars:
    //   ZENOH_PEER_CONNECT_ENDPOINTS, ZENOH_PEER_LISTEN_ENDPOINTS,
    //   ZENOH_COMMON_LISTEN_ENDPOINTS, ZENOH_EXTRA_LISTEN_ENDPOINTS,
    //   RB_ZENOH_LISTEN_ENDPOINTS_CONFIG_FILE
    static std::vector<std::pair<std::string, std::string>>
    build_config(const std::string& service, bool is_dev, bool is_child);

    // Retry policy for connect.
    // Defaults match the previous hard-coded behaviour (8 attempts, 0.5→3s
    // exponential backoff) — existing callers see no change.  Override these
    // when you want different semantics (e.g. FrsClient's "try once and let
    // the outer loop retry").
    //
    // The struct has an explicit default constructor — using `{}` as a
    // function default argument with `gnu++2a` on gcc 10.x does not accept
    // bare aggregate default-member-init, so we provide the values via a
    // user-declared ctor instead.
    struct ConnectRetryPolicy {
        int    max_attempts;
        double initial_delay_s;
        double max_delay_s;

        ConnectRetryPolicy()
            : max_attempts(8), initial_delay_s(0.5), max_delay_s(3.0) {}
        ConnectRetryPolicy(int attempts, double initial, double max_delay)
            : max_attempts(attempts), initial_delay_s(initial), max_delay_s(max_delay) {}
    };

    // Open the session.
    // If pairs is non-empty it is used as-is; otherwise build_config() derives
    // the config from service/is_dev/is_child and env vars.
    void connect(const std::string& service = "",
                 bool is_dev = false,
                 bool is_child = false,
                 ConnectRetryPolicy retry = ConnectRetryPolicy{},
                 const std::vector<std::pair<std::string, std::string>>& pairs = {});

    void close();
    bool is_alive() const;

    // close() 후 호출 시 std::runtime_error를 던진다.
    // publish / declare_subscriber / get 진입부에서 호출.
    void check_not_closed() const;

    // ── Publish ───────────────────────────────────────────────────────────────
    // publish() automatically appends sender attachment.
    // If the caller provides extra_attachment (e.g. additional headers),
    // it is concatenated AFTER the sender fields with a ';' separator.
    void publish(const std::string& topic,
                 const std::vector<uint8_t>& payload,
                 const std::string& extra_attachment = "",
                 int congestion_control = 1,  // zenoh-c: 1 = DROP
                 int priority = 5,
                 bool express = false);

    // publish<TObj>: FlatBuffer T-class overload — auto-packed to bytes.
    // Only enabled when TObj has a Pack(FlatBufferBuilder&) method.
    //   ManipulateCmdT cmd; cmd.type = CmdType_Move;
    //   cli->publish("robot/cmd", cmd);
    template<typename TObj> requires FlatBufferTClass<TObj>
    void publish(const std::string& topic,
                 const TObj& obj,
                 size_t initial_size = 512,
                 const std::string& extra_attachment = "",
                 int congestion_control = 1,  // zenoh-c: 1 = DROP
                 int priority = 5,
                 bool express = false) {
        flatbuffers::FlatBufferBuilder fbb(initial_size);
        fbb.Finish(TObj::TableType::Pack(fbb, &obj));
        auto* data = fbb.GetBufferPointer();
        publish(topic, std::vector<uint8_t>(data, data + fbb.GetSize()),
                extra_attachment, congestion_control, priority, express);
    }

    // ── Subscribe ─────────────────────────────────────────────────────────────
    int  declare_subscriber(const std::string& topic,
                            SubCallback callback,
                            CppSubscribeOptions opts = {});
    void undeclare_subscriber(int sub_id);

    // Topic-keyed lookup + undeclare (Python parity).
    // Tracks sub_id by topic internally — last declare_subscriber for that
    // topic wins. For multi-callback fan-out, callers should layer that on top.
    void unsubscribe_topic(const std::string& topic);
    void unsubscribe_all();
    bool has_subscriber(const std::string& topic) const;

    // subscribe() — Python API parity alias for declare_subscriber().
    int subscribe(const std::string& topic,
                  SubCallback callback,
                  CppSubscribeOptions opts = {}) {
        return declare_subscriber(topic, std::move(callback), opts);
    }

    // declare_subscriber<FBSType>: callback receives decoded T-class instead of raw bytes.
    //   cli->declare_subscriber<ManipulateState>("robot/state",
    //       [](const std::string& topic, std::unique_ptr<ManipulateStateT> obj,
    //          const std::string& attachment) { ... });
    template<typename FBSType>
    int declare_subscriber(
            const std::string& topic,
            std::function<void(const std::string&,
                               std::unique_ptr<typename FBSType::NativeTableType>,
                               const std::string&)> callback,
            CppSubscribeOptions opts = {}) {
        return declare_subscriber(
            topic,
            [cb = std::move(callback)](const std::string& key,
                                       const std::vector<uint8_t>& data,
                                       const std::string& attachment) {
                if (data.empty()) return;
                cb(key,
                   std::unique_ptr<typename FBSType::NativeTableType>(
                       flatbuffers::GetRoot<FBSType>(data.data())->UnPack()),
                   attachment);
            },
            opts);
    }

    // receive_one: blocking one-shot receive, raw bytes. Subscribes to `topic`,
    // waits up to timeout_ms for the first sample (optionally filtering out
    // `self_sender_id`, same semantics as CppSubscribeOptions::self_sender_id),
    // undeclares the subscriber, and returns it. Throws std::runtime_error on
    // timeout — mirrors query_one()'s raw-bytes interface/timeout behaviour.
    QueuedSample receive_one(const std::string& topic,
                             int timeout_ms = 1000,
                             const std::string& self_sender_id = "") {
        auto promise = std::make_shared<std::promise<QueuedSample>>();
        auto future  = promise->get_future();
        auto done    = std::make_shared<std::atomic<bool>>(false);

        CppSubscribeOptions opts;
        opts.self_sender_id = self_sender_id;

        int sub_id = declare_subscriber(
            topic,
            [promise, done](const std::string& key,
                            const std::vector<uint8_t>& payload,
                            const std::string& attachment) {
                if (done->exchange(true)) return;
                promise->set_value(QueuedSample{key, payload, attachment});
            },
            opts);

        auto status = future.wait_for(std::chrono::milliseconds(timeout_ms));
        undeclare_subscriber(sub_id);
        if (status != std::future_status::ready) {
            throw ZenohNoReply(topic, static_cast<double>(timeout_ms) / 1000.0);
                }
        return future.get();
    }

    // receive_one<FBSType>: raw payload → decoded T-class. Mirrors
    // query_one<FBSType>'s raw-payload overload.
    //   auto state = cli->receive_one<ManipulateState>("robot/state");
    //   auto state = cli->receive_one<ManipulateState>("robot/state", 2000);
    template<typename FBSType>
    typename FBSType::NativeTableType receive_one(const std::string& topic,
                                                   int timeout_ms = 1000,
                                                   const std::string& self_sender_id = "") {
        QueuedSample sample = receive_one(topic, timeout_ms, self_sender_id);
        std::unique_ptr<typename FBSType::NativeTableType> obj(
            flatbuffers::GetRoot<FBSType>(sample.payload.data())->UnPack());
        return std::move(*obj);
    }

    // subscribe<FBSType>() — Python API parity alias for declare_subscriber<FBSType>().
    template<typename FBSType>
    int subscribe(
            const std::string& topic,
            std::function<void(const std::string&,
                               std::unique_ptr<typename FBSType::NativeTableType>,
                               const std::string&)> callback,
            CppSubscribeOptions opts = {}) {
        return declare_subscriber<FBSType>(topic, std::move(callback), opts);
    }

    // ── Queryable ─────────────────────────────────────────────────────────────
    int  declare_queryable(const std::string& topic, QueryHandler handler);
    void undeclare_queryable(int queryable_id);
    // Topic-keyed undeclare (Python parity).
    void undeclare_queryable_by_topic(const std::string& topic);

    int  declare_liveliness_token(const std::string& keyexpr);
    void undeclare_liveliness_token(int token_id);
    int  declare_liveliness_subscriber(const std::string& keyexpr,
                                       LivelinessCallback callback,
                                       bool history = false);
    void undeclare_liveliness_subscriber(int sub_id);

    // ── Query ─────────────────────────────────────────────────────────────────
    std::vector<RawReply> get(const std::string& topic,
                              const std::optional<std::vector<uint8_t>>& payload,
                              int timeout_ms,
                              int target = 0);

    // query / query_one / query_all — Python parity. Raw bytes interface;
    // FlatBuffer overloads below.
    //   query     → all replies
    //   query_one → first non-error reply; throws ZenohNoReply if none
    //   query_all → all non-error replies (error replies filtered out)
    std::vector<RawReply> query(const std::string& topic,
                                const std::optional<std::vector<uint8_t>>& payload,
                                int timeout_ms,
                                int target = 0);
    RawReply query_one(const std::string& topic,
                       const std::optional<std::vector<uint8_t>>& payload,
                       int timeout_ms,
                       int target = 0);
    std::vector<RawReply> query_all(const std::string& topic,
                                    const std::optional<std::vector<uint8_t>>& payload,
                                    int timeout_ms,
                                    int target = 0);

    // ── FlatBuffer query overloads ────────────────────────────────────────────
    //
    // Template arg: FBSType = FlatBuffer table type (e.g. ManipulateState,
    //               not the T-class ManipulateStateT).
    // Return type: unique_ptr<FBSType::NativeTableType> (i.e. ManipulateStateT).
    //
    // Non-template (raw bytes) versions are still callable as-is; these overloads
    // are chosen only when explicit template args are provided:
    //   cli->query_one(...)           → RawReply  (non-template, as before)
    //   cli->query_one<FBSType>(...)  → unique_ptr<T>  (template below)

    // query_one<FBSType>: raw payload → decoded T-class.
    //   auto state = cli->query_one<ManipulateState>("robot/state");
    //   auto state = cli->query_one<ManipulateState>("robot/state", raw_payload, 2000);
    template<typename FBSType>
    std::unique_ptr<typename FBSType::NativeTableType>
    query_one(const std::string& topic,
              const std::optional<std::vector<uint8_t>>& payload = std::nullopt,
              int timeout_ms = 1000,
              int target = 0) {
        // Non-template query_one is preferred when called without <> — no recursion.
        RawReply reply = query_one(topic, payload, timeout_ms, target);
        if (reply.payload.empty()) {
            throw ZenohReplyError("query_one: empty reply for topic: " + topic);
        }
        return std::unique_ptr<typename FBSType::NativeTableType>(
            flatbuffers::GetRoot<FBSType>(reply.payload.data())->UnPack());
    }

    // query_one<FBSType>(topic, req): T-class request → decoded T-class response.
    // ReqT is deduced from req — user only specifies FBSType:
    //   ReqMoveT req; req.x = 1.0;
    //   auto res = cli->query_one<ResMove>("robot/move", req);
    template<typename FBSType, typename ReqT> requires FlatBufferTClass<ReqT>
    std::unique_ptr<typename FBSType::NativeTableType>
    query_one(const std::string& topic,
              const ReqT& req,
              size_t req_buf_size = 512,
              int timeout_ms = 1000,
              int target = 0) {
        flatbuffers::FlatBufferBuilder fbb(req_buf_size);
        fbb.Finish(ReqT::TableType::Pack(fbb, &req));
        auto* data = fbb.GetBufferPointer();
        return query_one<FBSType>(
            topic,
            std::optional<std::vector<uint8_t>>(std::vector<uint8_t>(data, data + fbb.GetSize())),
            timeout_ms, target);
    }

    // query_all<FBSType>: raw payload → vector of decoded T-class.
    //   auto states = cli->query_all<ManipulateState>("robots/**");
    template<typename FBSType>
    std::vector<std::unique_ptr<typename FBSType::NativeTableType>>
    query_all(const std::string& topic,
              const std::optional<std::vector<uint8_t>>& payload = std::nullopt,
              int timeout_ms = 1000,
              int target = 0) {
        auto replies = query_all(topic, payload, timeout_ms, target);
        std::vector<std::unique_ptr<typename FBSType::NativeTableType>> results;
        results.reserve(replies.size());
        for (auto& reply : replies) {
            if (!reply.payload.empty()) {
                results.push_back(std::unique_ptr<typename FBSType::NativeTableType>(
                    flatbuffers::GetRoot<FBSType>(reply.payload.data())->UnPack()));
            }
        }
        return results;
    }

    // query_all<FBSType>(topic, req): T-class request → vector of decoded T-class.
    //   auto results = cli->query_all<ScanResult>("robot/scan", req);
    template<typename FBSType, typename ReqT> requires FlatBufferTClass<ReqT>
    std::vector<std::unique_ptr<typename FBSType::NativeTableType>>
    query_all(const std::string& topic,
              const ReqT& req,
              size_t req_buf_size = 512,
              int timeout_ms = 1000,
              int target = 0) {
        flatbuffers::FlatBufferBuilder fbb(req_buf_size);
        fbb.Finish(ReqT::TableType::Pack(fbb, &req));
        auto* data = fbb.GetBufferPointer();
        return query_all<FBSType>(
            topic,
            std::optional<std::vector<uint8_t>>(std::vector<uint8_t>(data, data + fbb.GetSize())),
            timeout_ms, target);
    }

    // ── Stats / identity ──────────────────────────────────────────────────────
    std::optional<QueuedSample> get_latest(const std::string& topic) const;
    SubStats                    get_sub_stats(int sub_id) const;
    ZenohCore::GlobalStats      global_stats() const;

    // Identity accessors (needed by Python-side adapters when they build
    // attachments manually, e.g. for queryable replies).
    const std::string& name() const noexcept      { return name_; }
    const std::string& sender() const noexcept    { return sender_; }
    const std::string& sender_id() const noexcept { return sender_id_; }
    std::string        sender_attachment() const;  // "sender=RRS;sender_id=<uuid>"

    // PID at construction time (Python multiprocessing fork detection).
    int64_t owner_pid() const noexcept { return owner_pid_; }

    // True if close() was called explicitly (cleared by connect()).
    // Exposed to Python so the facade layer can decide not to auto-reconnect.
    bool is_manually_closed() const noexcept { return manually_closed_.load(); }

    // True once connect() has opened the session (cleared by close()).
    bool is_connected() const noexcept { return connected_.load(); }

    // Direct access to underlying core (for advanced cases like keyexpr utils).
    ZenohCore&       core() noexcept       { return core_; }
    const ZenohCore& core() const noexcept { return core_; }

private:
    std::string name_;
    std::string sender_;
    std::string sender_id_;
    int64_t     owner_pid_{0};

    ZenohCore core_;

    // close() 후 auto-reconnect 방지 플래그.
    // connect() 명시 호출 시 클리어, close() 시 set.
    std::atomic<bool> manually_closed_{false};

    // connect() 성공 시 set, close() 시 clear. 공유 인스턴스를 두 번 열지 않으려고 본다.
    std::atomic<bool> connected_{false};

    // Topic → sub_id (for unsubscribe_topic). Last declare wins.
    mutable std::mutex                  subs_by_topic_mutex_;
    std::unordered_map<std::string, int> subs_by_topic_;

    // Topic → queryable_id (for undeclare_queryable_by_topic).
    mutable std::mutex                  qbls_by_topic_mutex_;
    std::unordered_map<std::string, int> qbls_by_topic_;

    // Per-name singleton registry (PID-aware via owner_pid_).
    static std::mutex                                                   instances_mutex_;
    static std::unordered_map<std::string, std::shared_ptr<ZenohClient>> instances_;
};

}  // namespace rb_zenoh
