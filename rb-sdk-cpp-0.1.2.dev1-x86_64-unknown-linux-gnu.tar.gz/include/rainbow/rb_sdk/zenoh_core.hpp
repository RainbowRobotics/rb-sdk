#pragma once

#include <zenoh.h>

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <deque>
#include <functional>
#include <mutex>
#include <optional>
#include <shared_mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <utility>
#include <vector>

namespace rb_zenoh {

// 통신 타입

struct RawReply {
    std::string          key;
    std::vector<uint8_t> payload;
    std::string          attachment;
    std::string          encoding;   // MIME type
    bool                 is_error;
};

// 큐에 저장되는 샘플
struct QueuedSample {
    std::string          key;
    std::vector<uint8_t> payload;
    std::string          attachment;
};

// 콜백 타입

// Dispatch worker에서 호출
using SubCallback =
    std::function<void(std::string key, std::vector<uint8_t> payload, std::string attachment)>;

// 응답 콜백
using ReplyFn = std::function<void(const std::string& key,
                                   const std::vector<uint8_t>& payload,
                                   const std::string& attachment,
                                   const std::string& content_type,
                                   bool is_error)>;

// 응답 삭제 콜백
using DelFn = std::function<void()>;

// Queryable handler
using QueryHandler = std::function<void(std::string key,
                                        std::string params,
                                        std::optional<std::vector<uint8_t>> payload,
                                        std::string attachment,
                                        ReplyFn reply_fn,
                                        DelFn del_fn)>;

// Liveliness callback
using LivelinessCallback = std::function<void(std::string key, std::string kind)>;

// 구독 옵션

enum class OverflowPolicy : int {
    DropOldest = 0,  // 오래된 항목 삭제
    DropNewest = 1,  // 새 항목 삭제
    LatestOnly = 2,  // 최신 항목 유지
};

enum class DispatchMode : int {
    Immediate = 0,  // 수신 스레드에서 즉시 호출
    Queue     = 1,  // 큐 + 전용 dispatch worker
};

struct CppSubscribeOptions {
    size_t         queue_size       = 8;
    OverflowPolicy overflow         = OverflowPolicy::LatestOnly;
    DispatchMode   dispatch         = DispatchMode::Queue;
    std::string    self_sender_id;        // 자기 메시지 필터
    bool           cache_latest     = false;  // 최신 값 캐시
    double         callback_rate_hz = 0.0;    // 0이면 제한 없음
    bool           rate_limit_by_origin_topic = false;
};

// TX 큐

// 송신 대기 항목
struct TxItem {
    std::string          topic;
    std::vector<uint8_t> payload;
    std::string          attachment;
    uint8_t              congestion_control = 1;  // zenoh-c: 1 = DROP (기본, Python put과 동일)
    uint8_t              priority           = 5;
    bool                 express            = false;
};

// 구독자 통계
struct SubStats {
    uint64_t rx_count              = 0;
    uint64_t drop_count            = 0;
    uint64_t queue_depth           = 0;
    uint64_t python_callback_count = 0;
};

// ZenohCore

class ZenohCore {
public:
    explicit ZenohCore(std::string name);
    ~ZenohCore();

    // 프로세스 종료 상태
    // 종료 중에는 소멸자의 close()를 건너뛴다.
    static void mark_process_exiting();
    static bool process_exiting();

    // (key, JSON5 value) 목록
    void connect(const std::vector<std::pair<std::string, std::string>>& config_pairs);
    void close();
    std::string zid();

    // 논블로킹 TX. 실제 z_put은 TX worker가 수행한다.
    void put(std::string topic,
             std::vector<uint8_t> payload,
             std::string attachment,
             int congestion_control = 1,  // zenoh-c: 1 = DROP
             int priority           = 5,
             bool express           = false);

    // 구독자 ID 반환
    int  declare_subscriber(const std::string& topic,
                            SubCallback callback,
                            CppSubscribeOptions opts = {});
    void undeclare_subscriber(int sub_id);

    // 최신 캐시 반환
    std::optional<QueuedSample> get_latest(const std::string& topic) const;

    // 구독자 통계 반환
    SubStats get_sub_stats(int sub_id) const;

    // 블로킹 query
    std::vector<RawReply> get(const std::string& topic,
                              const std::optional<std::vector<uint8_t>>& payload,
                              int timeout_ms,
                              int target = 0);

    // Queryable ID 반환
    int  declare_queryable(const std::string& topic, QueryHandler handler);
    void undeclare_queryable(int queryable_id);

    int  declare_liveliness_token(const std::string& keyexpr);
    void undeclare_liveliness_token(int token_id);
    int  declare_liveliness_subscriber(const std::string& keyexpr,
                                       LivelinessCallback callback,
                                       bool history = false);
    void undeclare_liveliness_subscriber(int sub_id);

    static bool keyexpr_intersects(const std::string& ke1, const std::string& ke2);

    // 전역 통계
    struct GlobalStats {
        uint64_t tx_count              = 0;
        uint64_t rx_total              = 0;
        uint64_t drop_total            = 0;
        uint64_t python_callback_total = 0;
        uint64_t tx_dropped            = 0;  // 큐 오버플로 또는 세션 종료 중 publish
        uint64_t tx_failed             = 0;  // z_put 실패
        uint64_t tx_queue_depth        = 0;
        uint64_t tx_max_depth          = 0;
    };
    GlobalStats global_stats() const;

    // C callback helper
    static std::vector<uint8_t> read_zbytes(const z_loaned_bytes_t* b);
    static std::string          read_zstring(const z_loaned_string_t* s);
    static std::string          read_zbytes_as_str(const z_loaned_bytes_t* b);
    static std::string          parse_sender_id(const std::string& attachment);

private:
    // 세션 상태
    std::string           name_;
    z_owned_session_t     session_;
    std::atomic<bool>     session_open_{false};
    std::atomic<bool>     closing_{false};

    // reader: 동시 접근, writer: 배타 접근
    mutable std::shared_mutex session_rw_mutex_;

    std::atomic<int> next_id_{1};

    // 진행 중인 get() 추적
    std::atomic<int>         get_inflight_{0};
    std::mutex               get_cv_mutex_;
    std::condition_variable  get_cv_;

public:
    // close() 전 Queryable 작업 완료 대기용
    std::atomic<int>         qbl_inflight_{0};
    std::mutex               qbl_cv_mutex_;
    std::condition_variable  qbl_cv_;

    // Queryable worker 작업. handler는 worker와 closure가 수명을 공유한다.
    // Python 객체의 GIL 안전 수명 관리는 bindings.cpp의 어댑터가 담당한다.
    struct QblTask {
        std::shared_ptr<QueryHandler> handler;
        std::string     key;
        z_owned_query_t owned_query;
    };

    // Queryable callback은 clone 후 worker에 전달
    void enqueue_qbl_task(std::shared_ptr<QueryHandler> handler, std::string key,
                          z_owned_query_t&& owned_query);

    // 구독자 컨텍스트
    // C callback shim에서 접근하므로 public
    // Dispatch worker는 ZenohCore당 1개
    struct SubContext {
        // 식별자
        std::string         origin_topic;
        SubCallback         callback;
        CppSubscribeOptions opts;
        ZenohCore*          owner{nullptr};  // 통계용 owner

        // 구독자 큐
        mutable std::mutex       queue_mutex;
        std::deque<QueuedSample> queue;

        // 최신 값 캐시
        std::optional<QueuedSample> latest_slot;
        std::unordered_map<std::string, QueuedSample> latest_slots_by_key;

        // 수명 상태
        std::atomic<bool> stopped{false};

        // pending 중복 등록 방지
        std::atomic<bool> in_pending{false};

        // callback 실행 중인 작업 수
        std::atomic<int>        inflight{0};
        std::mutex              inflight_mtx;
        std::condition_variable inflight_cv;

        // 속도 제한 상태. ingress 는 token bucket — min-interval 게이트는
        // 발행 주기 == limit 인 스트림의 jitter 샘플을 버려 100ms 구멍을 만든다.
        struct IngressBucket {
            double                                tokens{0.0};
            std::chrono::steady_clock::time_point last_refill{};
        };
        std::chrono::steady_clock::time_point last_callback_at{};
        IngressBucket                         ingress_bucket;
        std::unordered_map<std::string, std::chrono::steady_clock::time_point> last_callback_at_by_key;
        std::unordered_map<std::string, IngressBucket> ingress_bucket_by_key;

        // 구독자 통계
        std::atomic<uint64_t> rx_count{0};
        std::atomic<uint64_t> drop_count{0};
        std::atomic<uint64_t> python_callback_count{0};

        ~SubContext();
    };

    // ── 익명 네임스페이스 C 콜백이 접근하는 전역 통계 → public ────────
    std::atomic<uint64_t> rx_total_{0};
    std::atomic<uint64_t> drop_total_{0};
    std::atomic<uint64_t> python_cb_total_{0};

    // Queue 모드에서 호출되는 callback shim
    void enqueue_pending(SubContext* ctx);

    struct LivelinessSubContext {
        LivelinessCallback callback;
    };

private:
    struct SubEntry {
        std::unique_ptr<z_owned_subscriber_t> sub;
        SubContext* ctx{nullptr};  // 수명은 zenoh-c drop handler가 관리
    };
    std::unordered_map<int, SubEntry> subs_;

    struct LivelinessTokenEntry {
        std::unique_ptr<z_owned_liveliness_token_t> token;
    };
    std::unordered_map<int, LivelinessTokenEntry> liveliness_tokens_;

    struct LivelinessSubEntry {
        std::unique_ptr<z_owned_subscriber_t> sub;
        LivelinessSubContext* ctx{nullptr};
    };
    std::unordered_map<int, LivelinessSubEntry> liveliness_subs_;

    // Queryable 컨텍스트
    struct QueryableEntry {
        std::unique_ptr<z_owned_queryable_t> qbl;
        QueryHandler                         handler;
    };
    std::unordered_map<int, QueryableEntry> queryables_;

    // 전역 통계
    std::atomic<uint64_t> tx_count_{0};

    // 공용 dispatch worker
    std::thread                 dispatch_thread_;
    std::atomic<bool>           dispatch_stop_{false};
    std::mutex                  pending_mutex_;
    std::condition_variable     pending_cv_;
    std::deque<SubContext*>     pending_subs_;       // 새 샘플이 있는 구독자 FIFO

    void dispatch_worker();

    // TX worker. 단일 FIFO로 전송 순서를 유지한다.
    static constexpr size_t kTxCapacity = 4096;  // 약 4MB @ 1KB/msg
    static constexpr size_t kTxBatch    = 64;    // lock당 최대 z_put 수

    std::deque<TxItem>          tx_queue_;
    mutable std::mutex          tx_mutex_;
    std::condition_variable     tx_cv_;
    std::thread                 tx_thread_;
    std::atomic<bool>           tx_stop_{false};
    std::atomic<bool>           tx_accepting_{true};
    std::atomic<uint64_t>       tx_dropped_{0};
    std::atomic<uint64_t>       tx_failed_{0};
    std::atomic<uint64_t>       tx_max_depth_{0};

    void tx_worker();
    // 실제 z_put
    void tx_send_locked(const TxItem& item);

    // Queryable worker pool. 요청을 병렬 처리한다.
    std::deque<QblTask>      qbl_pending_;
    std::mutex                qbl_pending_mutex_;
    std::condition_variable   qbl_pending_cv_;
    std::vector<std::thread>  qbl_worker_threads_;
    std::atomic<bool>         qbl_worker_stop_{false};

    void qbl_worker_loop();
    static int qbl_worker_count();

    // z_close timeout(ms). 환경변수로 조절 가능.
    static int close_timeout_ms();
};

}  // namespace rb_zenoh
