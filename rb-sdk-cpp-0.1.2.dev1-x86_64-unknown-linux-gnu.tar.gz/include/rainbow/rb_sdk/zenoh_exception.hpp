#pragma once

#include <optional>
#include <stdexcept>
#include <string>
#include <utility>

namespace rb_zenoh {

class ZenohQueryException : public std::runtime_error {
public:
  using std::runtime_error::runtime_error;
};

class ZenohReplyError : public ZenohQueryException {
public:
  explicit ZenohReplyError(std::string message, std::string attachment = "")
      : ZenohQueryException(std::move(message)), attachment_(std::move(attachment)) {}

  const std::string& attachment() const noexcept { return attachment_; }

private:
  std::string attachment_;
};

class ZenohNoReply : public ZenohQueryException {
public:
  ZenohNoReply(std::string topic, std::optional<double> timeout_s)
      : ZenohQueryException(make_message(topic, timeout_s)), topic_(std::move(topic)), timeout_s_(timeout_s) {}

  const std::string& topic() const noexcept { return topic_; }
  std::optional<double> timeout_s() const noexcept { return timeout_s_; }

private:
  static std::string make_message(const std::string& topic, std::optional<double> timeout_s) {
    std::string message = "zenoh query_one: no successful reply for " + topic;
    if (timeout_s) {
      message += " (timeout=" + std::to_string(*timeout_s) + "s)";
    }
    return message;
  }

  std::string topic_;
  std::optional<double> timeout_s_;
};

class ZenohTransportError : public ZenohQueryException {
public:
  using ZenohQueryException::ZenohQueryException;
};

}  // namespace rb_zenoh
