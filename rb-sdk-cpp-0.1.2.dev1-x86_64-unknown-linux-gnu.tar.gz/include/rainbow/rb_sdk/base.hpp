#pragma once

#include <arpa/inet.h>
#include <curl/curl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <algorithm>
#include <any>
#include <atomic>
#include <condition_variable>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>
#include <memory>
#include <mutex>
#include <nlohmann/json.hpp>
#include <optional>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <typeinfo>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "binding/glue/gil_release.hpp"
#include "flow_manager_args.hpp"
#include "zenoh_client.hpp"
#include "zenoh_core.hpp"
#include "zenoh_exception.hpp"  // rb_zenoh::ZenohNoReply / ZenohTransportError (query 재시도에서 사용)

#include "common_struct_generated.h"  // IPC::MoveInput_{Target,Speed,Type}T
#include "host_pcan_generated.h"      // IPC::Request/ResponseCAN* (connect_can/disconnect_can/transmit_can)
#include "program_generated.h"        // muscat::RB_Program_LogT (log() 에서 사용, 모든 도메인 공용)

// lib/Vision 벤더 프로토콜 클라이언트 (CMakeLists.txt RB_VISION_SOURCES 로 rb_sdk 타겟에 이미 링크됨).
// RBBaseSDK 를 상속받는 모든 SDK 클래스(manipulate, 차후 amr 등)가 VisionClientRegistry 를
// 통해 module_name 별로 여러 비전 서버에 동시 접속할 수 있도록 여기서 타입만 끌어온다.
#include "mechmind/mechmind_client.hpp"
#include "photoneo/photoneo_client.hpp"
// photoneo_client.hpp 는 (mechmind/pickit3d client 헤더와 달리) exceptions.hpp 를 스스로 include
// 하지 않는다 - photoneo::PhotoneoError 등을 catch 하려면 명시적으로 필요하다.
#include "photoneo/exceptions.hpp"
#include "pickit3d/pickit_client.hpp"

enum class ServerType { AMR, MANIPULATE };

enum class HttpMethod { GET, POST, PUT, DELETE };

using HttpHeaders = std::map<std::string, std::string>;

enum class CongestionControl : int {
  DROP = 0,
  BLOCK = 1,
  DROP_LATEST = 2,  // same as BLOCK in practice
};

enum class Priority : int {
  REAL_TIME = 1,
  INTERACTIVE_HIGH = 2,
  INTERACTIVE_LOW = 3,
  DATA_HIGH = 4,
  DATA = 5,
  DATA_LOW = 6,
  BACKGROUND = 7,
};

struct MoveType {
  inline static constexpr std::string_view J = "J";
  inline static constexpr std::string_view L = "L";
  inline static constexpr std::string_view JB = "JB";
  inline static constexpr std::string_view LB = "LB";
  inline static constexpr std::string_view XB = "XB";
};

struct ConnectOptions {
  std::string token;
  std::string host;

  std::optional<int> zenoh_port;

  int ttl = 5;

  std::optional<double> heartbeat;
  std::optional<double> mesh_timeout;

  double mesh_probe_timeout = 1.0;
  double mesh_probe_interval = 0.5;
};

inline std::string get_env(const std::string& name, const std::string& default_value) {
  if (const char* value = std::getenv(name.c_str())) {
    return value;
  }
  return default_value;
}

static bool getenv_bool(const char* name, bool default_value = false) {
  if (const char* p = std::getenv(name)) {
    std::string s = p;
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return std::tolower(c); });
    return s == "true";
  }
  return default_value;
}

inline std::string get_process_name() {
  std::ifstream f("/proc/self/comm");
  std::string name;
  std::getline(f, name);
  return name;
}

// module_name(PFM 의 task_id) 별로 독립된 벤더 비전 클라이언트를 소유/관리한다.
// 같은 module_name 으로 다시 connect() 하면 기존 연결을 정리하고 새로 만든다.
template <typename ClientT, typename ConfigT>
class VisionClientRegistry {
 public:
  ClientT* get(const std::string& module_name) {
    auto it = clients_.find(module_name);
    return it == clients_.end() ? nullptr : it->second.get();
  }

  ClientT& connect(const std::string& module_name, const ConfigT& config) {
    auto it = clients_.find(module_name);
    if (it != clients_.end() && it->second->is_connected())
      it->second->disconnect();

    auto client = std::make_unique<ClientT>(config);
    client->connect();
    ClientT& ref = *client;
    clients_[module_name] = std::move(client);
    return ref;
  }

  void disconnect_all() {
    for (auto& [module_name, client] : clients_) {
      try {
        if (client && client->is_connected())
          client->disconnect();
      } catch (const std::exception& e) {
        std::cerr << "[VisionClientRegistry] disconnect failed: module=" << module_name << ", err=" << e.what()
                  << std::endl;
      }
    }
  }

 private:
  std::unordered_map<std::string, std::unique_ptr<ClientT>> clients_;
};

class RBBaseSDK {
 public:
  static RBBaseSDK& instance() {
    static RBBaseSDK obj;
    // zenoh_client_ = rb_zenoh::ZenohClient::get_instance("test_p");
    return obj;
  }

  // copy 방지
  RBBaseSDK(const RBBaseSDK&) = delete;
  RBBaseSDK& operator=(const RBBaseSDK&) = delete;

  // move 방지
  RBBaseSDK(RBBaseSDK&&) = delete;
  RBBaseSDK& operator=(RBBaseSDK&&) = delete;

 protected:
  inline static bool use_directly_ = false;

  inline static bool is_alive_ = true;

  inline static int pid_ = 0;

  inline static bool closing_ = false;

  inline static std::shared_ptr<rb_zenoh::ZenohClient> zenoh_client_;

  inline static std::recursive_mutex lock_;

  inline static std::mutex mutex_;

  inline static std::optional<std::string> peer_id_;

  inline static std::optional<std::string> peer_common_url_;

  inline static std::optional<std::string> peer_token_;

  inline static std::thread heartbeat_thread_;

  inline static std::atomic<bool> heartbeat_stop_{false};

  // 살아있는 SDK 수. base.py 의 _total_ref_counts[pid] 대응 —
  // 0 이 될 때만 공유 세션을 닫는다(close() 참고).
  inline static int ref_count_ = 0;
  inline static int ref_count_pid_ = 0;

  // 인스턴스 단위 중복 close 가드 (closing_ 은 static 이라 못 쓴다).
  bool instance_closed_ = false;

  static void _acquire_sdk_ref() {
    std::lock_guard<std::recursive_mutex> guard(lock_);
    const int pid = getpid();
    if (ref_count_pid_ != pid) {  // fork 자식 — 부모 카운트는 버린다
      ref_count_pid_ = pid;
      ref_count_ = 0;
    }
    ++ref_count_;
  }

  // 남은 SDK 수 반환.
  static int _release_sdk_ref() {
    std::lock_guard<std::recursive_mutex> guard(lock_);
    if (ref_count_pid_ != getpid())
      return 0;
    if (ref_count_ > 0)
      --ref_count_;
    return ref_count_;
  }

  std::string sender = "";

  std::optional<std::string> name;

  std::unordered_set<std::string> zenoh_queryables;

  std::unordered_set<std::string> zenoh_subscribes;

  std::string SERVICE = get_env("SERVICE", "unknown");

  bool IS_DEV = getenv_bool("IS_DEV");

  RBBaseSDK(std::optional<ServerType> server = std::nullopt, bool use_directly = false) {
    RBBaseSDK::pid_ = getpid();
    RBBaseSDK::_acquire_sdk_ref();
    RBBaseSDK::_refresh_zenoh_client_for_pid();
  }

  // 외부 삭제 방지. base.py __del__ 대응 — disconnect() 아니라 close().
  // virtual: before_close() 가 가상함수라 클래스에 처음 vtable 이 생겼다 — 가상함수가 하나라도
  // 있으면 소멸자도 가상이어야 한다는 표준 관례를 따른다(RBBaseSDK* 로 delete 되는 경우 안전).
  virtual ~RBBaseSDK() { close(); }

 public:
  std::optional<std::string> connect(const ConnectOptions& options) {
    // 이 함수와 하위 경로(_http_json / _wait_for_zenoh_echo /
    // _reconnect_shared_zenoh_for_remote_peer)는 Python 객체를 만지지 않으므로 놓아도 안전하다.
    _gil_release_if_held _g;

    if (_is_same_host(options.host)) {
      std::cout << "[SDK] connect() skipped: common is on the same host, already in the mesh" << std::endl;
      return std::nullopt;
    } else {
    }
    if (peer_id_) {
      std::cout << "[SDK] already connected as peer. peer_id: " << peer_id_.value() << std::endl;
      return peer_id_;
    }

    int port = options.zenoh_port != std::nullopt ? options.zenoh_port.value() : _find_free_port();
    peer_common_url_ = "http://" + options.host + ":8000";
    peer_token_ = options.token;
    std::string local_ip = _detect_local_ip(options.host);
    std::cout << "[SDK] local IP=" << local_ip << ", zenoh port=" << std::to_string(port) << std::endl;

    _reconnect_shared_zenoh_for_remote_peer(port);

    HttpHeaders headers{{"Authorization", "Bearer " + options.token}, {"Content-Type", "application/json"}};

    nlohmann::json payload{{"ip", local_ip}, {"port", port}, {"ttl", options.ttl}};

    auto resp_data = _http_json(HttpMethod::POST, peer_common_url_.value() + "/zenoh/peer", &payload, headers, 1000);

    std::string peer_id = resp_data["peer_id"].get<std::string>();
    peer_id_ = peer_id;

    double interval = options.heartbeat ? options.heartbeat.value() : std::max(1.0, options.ttl / 2.0);
    const int ttl = options.ttl;
    heartbeat_thread_ = std::thread([this, peer_id, ttl, interval]() { heartbeat_loop(peer_id, ttl, interval); });

    if (_wait_for_zenoh_echo("muscat/zenoh/echo_req", "muscat/zenoh/echo_res", options.mesh_timeout.value_or(10.0),
                             options.mesh_probe_timeout, options.mesh_probe_interval)) {
      std::cout << "[SDK] connected as zenoh peer " << peer_id << " → " << peer_common_url_.value()
                << "  my=" << local_ip << ":" << std::to_string(port) << "  ttl=" << ttl << "s" << "  hb=" << interval
                << "s" << std::endl;

    } else {
      heartbeat_stop_ = true;
      _http_json(HttpMethod::DELETE, peer_common_url_.value() + "/zenoh/peer/" + peer_id, nullptr, headers, 1000);
      peer_id_ = std::nullopt;
      peer_common_url_ = std::nullopt;
      peer_token_ = std::nullopt;
      std::cout << "[SDK] zenoh echo failed. so delete peer" << std::endl;
    }

    return peer_id_;
  }

  int zenoh_subscribe(const std::string& topic, rb_zenoh::SubCallback callback,
                      rb_zenoh::CppSubscribeOptions opts = {}) {
    _gil_release_if_held _g;
    std::lock_guard<std::mutex> guard(mutex_);

    int sub_id_ = RBBaseSDK::zenoh_client_->declare_subscriber(topic, callback, opts);
    zenoh_subscribes.insert(topic);

    return sub_id_;
  }

  template <typename FBSType>
  int zenoh_subscribe(
      const std::string& topic,
      std::function<void(const std::string&, std::unique_ptr<typename FBSType::NativeTableType>, const std::string&)>
          callback,
      rb_zenoh::CppSubscribeOptions opts = {}) {
    _gil_release_if_held _g;
    std::lock_guard<std::mutex> guard(mutex_);
    try {
      int sub_id_ = RBBaseSDK::zenoh_client_->declare_subscriber<FBSType>(topic, callback, opts);
      zenoh_subscribes.insert(topic);

      return sub_id_;
    } catch (const std::exception& e) {
      std::cout << "error at zenoh_subscribe()" << std::endl;
      std::cerr << e.what() << '\n';
    }

    // 구독 실패. 유효한 subscriber id 가 없음을 -1 로 알린다
    // (_FlowManagerState::subs_id 기본값과 동일).
    return -1;
  }

  void zenoh_queryable(const std::string& topic, rb_zenoh::QueryHandler handler) {
    _gil_release_if_held _g;
    std::lock_guard<std::mutex> guard(mutex_);

    // base.py 와 동일하게 같은 keyexpr 를 두 번 declare 하지 않는다.
    if (zenoh_queryables.count(topic)) {
      std::cout << "⚠️  Queryable already declared: " << topic << std::endl;
      return;
    }

    auto queryable = zenoh_client_->declare_queryable(topic, handler);
    zenoh_queryables.insert(topic);
  }

  void disconnect() {
    if (peer_id_ == std::nullopt)
      return;

    // 유지 스레드 먼저 정지.
    heartbeat_stop_ = true;
    if (heartbeat_thread_.joinable())
      heartbeat_thread_.join();

    const auto peer_id = peer_id_;
    const auto url = peer_common_url_;
    const auto token = peer_token_;
    peer_id_ = std::nullopt;
    peer_common_url_ = std::nullopt;
    peer_token_ = std::nullopt;

    if (peer_id && url && token) {
      HttpHeaders headers{{"Authorization", "Bearer " + token.value()}, {"Content-Type", "application/json"}};
      try {
        _http_json(HttpMethod::DELETE, url.value() + "/zenoh/peer/" + peer_id.value(), nullptr, headers, 5000);
      } catch (const std::exception& e) {
        std::cerr << "[SDK] peer delete failed: " << e.what() << std::endl;
      }
    }

    std::cout << "[SDK] disconnected zenoh peer " << peer_id.value_or("(not registered)") << std::endl;

    _zenoh_unsubscribe_mine();
    _zenoh_unqueryable_mine();

    // 무조건 닫는다 — ref-count 판단은 close() 쪽.
    if (RBBaseSDK::zenoh_client_)
      RBBaseSDK::zenoh_client_->close();
  }

  // base.py RBBaseSDK._cleanup_resources() 의 `getattr(self, "before_close", None)` 동적 훅 대응.
  // 빈 기본 구현(optional hook) — 서브클래스가 정리할 자원이 있으면 override 한다
  // (예: RBProgramSDK::before_close(), 각자 close() 를 부르는 자기 소멸자와 함께).
  //
  // 주의: 이 가상함수는 close() 가 자기 소멸자(예: ~RBProgramSDK())에서 불릴 때만 override 로
  // 디스패치된다. ~RBBaseSDK() 자신의 소멸자 본문에서 close() 가 불리는 시점엔 이미 vtable 이
  // RBBaseSDK 로 되돌아가 있어(C++ 표준상 파생 클래스가 이미 부분 소멸된 뒤 그쪽 가상함수를
  // 부르는 걸 막기 위함) before_close() 가 항상 이 빈 기본 구현으로 떨어진다 — 그래서
  // before_close() 를 override 하는 서브클래스는 반드시 자기 소멸자에서 close() 를 명시적으로
  // 불러야 한다(멱등이라 그 뒤 ~RBBaseSDK() 가 또 불러도 안전).
  virtual void before_close() {}

  // base.py RBBaseSDK.close() 대응: 중복 가드 → 참조 카운트 감소 →
  // (peer 붙어있으면 disconnect) → 자기 리소스 정리 → 마지막 SDK일 때만
  // 공유 세션 close. zenoh_client_ 는 프로세스 공유라 무조건 닫으면 다른
  // SDK 의 구독/queryable 까지 끊긴다.
  void close() {
    if (getpid() != RBBaseSDK::pid_)
      return;  // fork 자식의 인스턴스는 건드리지 않는다

    if (instance_closed_)
      return;
    instance_closed_ = true;

    // vision 벤더 클라이언트(mechmind_clients_ 등) 정리는 여기서 하드코딩하지 않는다 — 이 registry
    // 들은 base 가 소유하지만(어떤 RBBaseSDK 파생 클래스든 재사용 가능하도록), 실제로 disconnect_all()
    // 을 부를지는 그 registry 를 실제로 쓰는 서브클래스(RBManipulateVisionSDK 등)가 before_close()
    // 를 override 해서 결정한다 — Python 원본 구조(서브클래스가 before_close 를 정의)와 동일.
    //
    // Python 원본과 동일하게 예외를 삼키고 로그만 남긴다 — 소멸자 경로에서 예외가 새어나가면
    // std::terminate 위험이 있다.
    try {
      before_close();
    } catch (const std::exception& e) {
      std::cerr << "[SDK Base] Error in before_close: " << e.what() << std::endl;
    } catch (...) {
      std::cerr << "[SDK Base] Error in before_close: unknown exception" << std::endl;
    }

    const int remaining = RBBaseSDK::_release_sdk_ref();

    if (peer_id_ != std::nullopt) {
      disconnect();  // 리소스 정리 + 세션 close 까지 포함
      return;
    }

    _zenoh_unsubscribe_mine();
    _zenoh_unqueryable_mine();

    if (remaining <= 0 && RBBaseSDK::zenoh_client_) {
      RBBaseSDK::zenoh_client_->close();
    }
  }

  // base.py _wrap_with_safe_handler 의 zenoh 재시도 대응(축약판): query 계열이 ZenohNoReply /
  // ZenohTransportError 로 실패하면 세션을 재확인/재연결하고 딱 한 번 다시 시도한다. Transport
  // 오류는 세션 자체가 깨진 것으로 보고 강제 재연결한다(base.py force_reconnect 와 동일).
  template <typename Fn>
  auto _zenoh_call_with_retry(const char* op, Fn&& fn) -> decltype(fn()) {
    try {
      return fn();
    } catch (const rb_zenoh::ZenohTransportError& e) {
      std::cerr << "[" << op << "] zenoh transport error: " << e.what() << " -> reconnect and retry once" << std::endl;
      _refresh_zenoh_client_for_pid(/*force=*/true);
      return fn();
    } catch (const rb_zenoh::ZenohNoReply& e) {
      std::cerr << "[" << op << "] zenoh no-reply: " << e.what() << " -> reconnect and retry once" << std::endl;
      _refresh_zenoh_client_for_pid(/*force=*/false);
      return fn();
    }
  }

  std::vector<rb_zenoh::RawReply> query(const std::string& topic, const std::optional<std::vector<uint8_t>>& payload,
                                        int timeout_ms, int target = 0) {
    return _zenoh_call_with_retry("query",
                                  [&] { return RBBaseSDK::zenoh_client_->query(topic, payload, timeout_ms, target); });
  }

  // zenoh 왕복(query_one/receive_one)은 응답이 올 때까지 C++ 레벨에서 블로킹한다.
  // Python 진입 시 GIL 을 쥔 채 기다리면 다른 zenoh 콜백과 서로 물리므로 실제로 GIL 을
  // 들고 있을 때만 놓는다. pybind 의존은 binding/glue/gil_release.hpp 안에 RB_SDK_WITH_PYTHON 로
  // 격리돼 있고, 순수 C++ 빌드에서는 no-op 이다.
  using _gil_release_if_held = rb_sdk::gil_release_if_held;

  rb_zenoh::RawReply query_one(const std::string& topic, const std::optional<std::vector<uint8_t>>& payload,
                               int timeout_ms, int target = 0) {
    _gil_release_if_held _g;
    return _zenoh_call_with_retry(
        "query_one", [&] { return RBBaseSDK::zenoh_client_->query_one(topic, payload, timeout_ms, target); });
  }

  template <typename FBSType>
  std::unique_ptr<typename FBSType::NativeTableType> query_one(
      const std::string& topic, const std::optional<std::vector<uint8_t>>& payload = std::nullopt,
      int timeout_ms = 1000, int target = 0) {
    _gil_release_if_held _g;
    return _zenoh_call_with_retry(
        "query_one", [&] { return RBBaseSDK::zenoh_client_->query_one<FBSType>(topic, payload, timeout_ms, target); });
  }

  template <typename FBSType, typename ReqT>
  requires rb_zenoh::FlatBufferTClass<ReqT> std::unique_ptr<typename FBSType::NativeTableType> query_one(
      const std::string& topic, const ReqT& req, size_t req_buf_size = 512, int timeout_ms = 1000, int target = 0) {
    _gil_release_if_held _g;
    return _zenoh_call_with_retry("query_one", [&] {
      return RBBaseSDK::zenoh_client_->query_one<FBSType, ReqT>(topic, req, req_buf_size, timeout_ms, target);
    });
  }

  std::vector<rb_zenoh::RawReply> query_all(const std::string& topic,
                                            const std::optional<std::vector<uint8_t>>& payload, int timeout_ms,
                                            int target = 0) {
    return _zenoh_call_with_retry(
        "query_all", [&] { return RBBaseSDK::zenoh_client_->query_all(topic, payload, timeout_ms, target); });
  }

  template <typename FBSType>
  std::vector<std::unique_ptr<typename FBSType::NativeTableType>> query_all(
      const std::string& topic, const std::optional<std::vector<uint8_t>>& payload = std::nullopt,
      int timeout_ms = 1000, int target = 0) {
    return _zenoh_call_with_retry(
        "query_all", [&] { return RBBaseSDK::zenoh_client_->query_all<FBSType>(topic, payload, timeout_ms, target); });
  }

  template <typename FBSType, typename ReqT>
  requires rb_zenoh::FlatBufferTClass<ReqT> std::vector<std::unique_ptr<typename FBSType::NativeTableType>> query_all(
      const std::string& topic, const ReqT& req, size_t req_buf_size = 512, int timeout_ms = 1000, int target = 0) {
    return _zenoh_call_with_retry("query_all", [&] {
      return RBBaseSDK::zenoh_client_->query_all<FBSType, ReqT>(topic, req, req_buf_size, timeout_ms, target);
    });
  }

  void publish(const std::string& topic, const std::vector<uint8_t>& payload, const std::string& extra_attachment = "",
               int congestion_control = 1 /* zenoh-c: DROP */, int priority = 5, bool express = false) {
    RBBaseSDK::zenoh_client_->publish(topic, payload, extra_attachment, congestion_control, priority, express);
  }

  template <typename TObj>
  requires rb_zenoh::FlatBufferTClass<TObj> void publish(const std::string& topic, const TObj& obj,
                                                         size_t initial_size = 512,
                                                         const std::string& extra_attachment = "",
                                                         int congestion_control = 1 /* zenoh-c: DROP */,
                                                         int priority = 5, bool express = false) {
    RBBaseSDK::zenoh_client_->publish(topic, obj, initial_size, extra_attachment, congestion_control, priority,
                                      express);
  }

  template <typename FBSType>
  typename FBSType::NativeTableType receive_one(const std::string& topic) {
    _gil_release_if_held _g;
    return RBBaseSDK::zenoh_client_->receive_one<FBSType>(topic);
  }

  // Python base.py::RBBaseSDK.log() 대응. program_sdk 뿐 아니라 이 클래스를 상속하는 모든 SDK
  // (RBManipulateSDK 포함)가 공용으로 쓴다 — muscat/program/log 토픽은 도메인과 무관하게 동일.
  // program_sdk 마이그레이션(rb_program_sdk.hpp) 때 처음 필요해져서 여기로 포팅했다.
  void log(const std::string& content, const std::string& robot_model,
           const std::string& level /* INFO|WARNING|ERROR|USER|DEBUG|GENERAL */, bool disable_db = false,
           FlowManagerArgsPtr flow_manager_args = nullptr) {
    (void)disable_db;  // Python 원본에서도 미사용 (그대로 유지)

    muscat::RB_Program_LogT req;
    req.content = content;
    req.robot_model = robot_model;

    if (level == "INFO")
      req.type = muscat::RB_Program_Log_Type_INFO;
    else if (level == "WARNING")
      req.type = muscat::RB_Program_Log_Type_WARNING;
    else if (level == "ERROR")
      req.type = muscat::RB_Program_Log_Type_ERROR;
    else if (level == "USER")
      req.type = muscat::RB_Program_Log_Type_USER;
    else if (level == "DEBUG")
      req.type = muscat::RB_Program_Log_Type_DEBUG;
    else if (level == "GENERAL")
      req.type = muscat::RB_Program_Log_Type_GENERAL;

    publish("muscat/log/write", req, 256);

    if (flow_manager_args)
      flow_manager_args->done();
  }

  // base.py RBBaseSDK.manipulate_return_value 대응: PyFM 실행 중(flow_manager_args 존재)일 때만
  // return_value != 0 을 에러로 간주해 예외를 던진다. 직접 호출(flow_manager_args 없음)에서는
  // Python 과 동일하게 return_value 를 무시한다. done() 은 호출부에서 별도로 부른다(Python 과 동일).
  // return_value 필드가 없는 응답 타입은 Python 의 hasattr 체크처럼 조용히 통과시킨다.
  template <typename T>
  void manipulate_return_value(const std::string& func_name, const T& obj_payload,
                               FlowManagerArgsPtr flow_manager_args = nullptr) {
    if constexpr (requires(const T& t) { t.return_value; }) {
      if (flow_manager_args && obj_payload.return_value != 0) {
        std::string error_msg = "[" + func_name + "] return value is " + std::to_string(obj_payload.return_value);

        std::cerr << error_msg << std::endl;
        throw std::runtime_error(error_msg);
      }
    }
  }

  template <typename T>
  T validate_single_return_value(const std::optional<T>& obj_payload, FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!obj_payload)
      throw std::runtime_error("validate_single_return value got no payload");

    if constexpr (requires(const T& t) { t.return_value; }) {
      if (obj_payload.value().return_value != 0)
        throw std::runtime_error("return value is not 0: " + std::to_string(obj_payload.value().return_value));
    }

    if (flow_manager_args)
      flow_manager_args->done();

    return obj_payload.value();
  }

  // ---------------------------------------------------------------------
  // CAN (host_pcan 서비스) — base.py RBBaseSDK.connect_can/disconnect_can/transmit_can 대응.
  // muscat/can/* 토픽은 도메인과 무관하므로 log() 처럼 base 에 둔다. flow_manager_args 가 있으면
  // 응답 success 여부로 done() / 예외를 가른다(Python 원본과 동일).
  // ---------------------------------------------------------------------

  IPC::ResponseCANConnectT connect_can(const std::string& channel, uint32_t bitrate, bool fd = false,
                                       uint32_t data_bitrate = 0, bool receive_own_messages = false,
                                       const std::string& interface = "pcan",
                                       FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::RequestCANConnectT req;
    req.interface = interface;
    req.bitrate = bitrate;
    req.channel = channel;
    req.data_bitrate = data_bitrate;
    req.fd = fd;
    req.receive_own_messages = receive_own_messages;

    const std::string topic = "muscat/can/connect";
    auto result = query_one<IPC::ResponseCANConnect, IPC::RequestCANConnectT>(topic, req, 2048, 1000);
    if (!result)
      throw std::runtime_error("Call " + topic + " failed: obj_payload is None");

    if (flow_manager_args) {
      if (result->success)
        flow_manager_args->done();
      else
        throw std::runtime_error(result->message);
    }
    return std::move(*result);
  }

  IPC::ResponseCANDisconnectT disconnect_can(const std::string& channel,
                                             FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::RequestCANDisconnectT req;
    req.channel = channel;

    const std::string topic = "muscat/can/disconnect";
    auto result = query_one<IPC::ResponseCANDisconnect, IPC::RequestCANDisconnectT>(topic, req, 512, 1000);
    if (!result)
      throw std::runtime_error("Call " + topic + " failed: obj_payload is None");

    if (flow_manager_args) {
      if (result->success)
        flow_manager_args->done();
      else
        throw std::runtime_error(result->message);
    }
    return std::move(*result);
  }

  IPC::ResponseCANTransmitT transmit_can(const std::string& channel, uint32_t arbitration_id,
                                         const std::vector<uint8_t>& data = {}, uint8_t dlc = 0,
                                         bool is_extended_id = false, bool is_remote_frame = false, bool is_fd = false,
                                         bool bitrate_switch = false, bool is_error_frame = false,
                                         bool error_state_indicator = false, double timestamp = 0.0,
                                         FlowManagerArgsPtr flow_manager_args = nullptr) {
    IPC::RequestCANTransmitT req;
    req.channel = channel;

    auto message = std::make_unique<IPC::CANMessageT>();
    message->arbitration_id = arbitration_id;
    message->data = data;
    message->dlc = dlc;
    message->is_extended_id = is_extended_id;
    message->is_remote_frame = is_remote_frame;
    message->is_fd = is_fd;
    message->bitrate_switch = bitrate_switch;
    message->is_error_frame = is_error_frame;
    message->error_state_indicator = error_state_indicator;
    message->timestamp = timestamp;
    req.message = std::move(message);

    const std::string topic = "muscat/can/transmit";
    auto result = query_one<IPC::ResponseCANTransmit, IPC::RequestCANTransmitT>(topic, req, 512, 1000);
    if (!result)
      throw std::runtime_error("Call " + topic + " failed: obj_payload is None");

    if (flow_manager_args) {
      if (result->success)
        flow_manager_args->done();
      else
        throw std::runtime_error(result->message);
    }
    return std::move(*result);
  }

  // ---------------------------------------------------------------------
  // lib/Vision 벤더 프로토콜 클라이언트. RBBaseSDK 를 상속받는 SDK 클래스는
  // (manipulate 뿐 아니라 차후 amr 등도) module_name 별로 여러 비전 서버에
  // 동시 접속할 수 있다 - PFM 이 Task(module_name) 마다 독립된 비전 연결을
  // 요구하기 때문에 인스턴스를 하나만 두지 않고 registry 로 관리한다.
  // ---------------------------------------------------------------------

  VisionClientRegistry<mechmind::MechMindClient, mechmind::MechMindConfig> mechmind_clients_;
  VisionClientRegistry<photoneo::PhotoneoClient, photoneo::PhotoneoConfig> photoneo_clients_;
  VisionClientRegistry<pickit3d::PickitClient, pickit3d::PickitConfig> pickit_clients_;

 private:
  void _connect(const std::optional<std::vector<std::pair<std::string, std::string>>>& pairs = std::nullopt,
                const std::optional<std::string>& sender = std::nullopt, const int max_attempts = 8,
                const float initial_delay_s = 0.5, const float max_delay_s = 3.0) {
    if (!zenoh_client_)
      return;
    if (sender.has_value())
      RBBaseSDK::sender = sender.value();

    std::string process_name = get_process_name();

    std::cout << "process name: " << process_name << " pid=" << getpid() << " ppid=" << getppid() << std::endl;

    // rb_sdk_cpp 는 zenoh_client.cpp 를 정적 편입해 레지스트리 사본을 따로 가지므로
    // rb_zenoh 세션과 합쳐지지 않는다. 허브(listen 7447)는 rb_zenoh 세션 몫이고,
    // SDK 까지 허브 프로파일로 열면 7447 경쟁에 진 쪽이 링크 0 개로 고립된다. leaf 고정.
    constexpr bool kLeaf = true;

    auto client = rb_zenoh::ZenohClient::get_or_create(RBBaseSDK::name.value_or(""));

    try {
      if (!client->is_connected()) {
        std::cout << "[zenoh connect] pid=" << getpid() << " SERVICE=" << SERVICE << " IS_DEV=" << IS_DEV
                  << " leaf=1" << std::endl;
        if (pairs.has_value())
          client->connect(SERVICE, IS_DEV, kLeaf, {max_attempts, initial_delay_s, max_delay_s}, pairs.value());
        else
          client->connect(SERVICE, IS_DEV, kLeaf, {max_attempts, initial_delay_s, max_delay_s}, {});
      }
    } catch (const std::exception& e) {
      std::cout << "error at _connect()" << std::endl;
      std::cerr << e.what() << '\n';
    }

    zenoh_client_ = client;
  }

  void _zenoh_unsubscribe_mine() {
    _gil_release_if_held _g;
    std::lock_guard<std::mutex> guard(mutex_);
    for (const auto& _tpc : zenoh_subscribes) {
      RBBaseSDK::zenoh_client_->unsubscribe_topic(_tpc);
    }
    zenoh_subscribes.clear();
  }

  void _zenoh_unqueryable_mine() {
    _gil_release_if_held _g;
    std::lock_guard<std::mutex> guard(mutex_);

    for (const auto& _tpc : zenoh_queryables) {
      RBBaseSDK::zenoh_client_->undeclare_queryable_by_topic(_tpc);
    }
    zenoh_queryables.clear();
  }

  static bool _is_client_session_alive(const std::shared_ptr<rb_zenoh::ZenohClient>& client) {
    return client != nullptr && !client->is_manually_closed();
  }

  std::shared_ptr<rb_zenoh::ZenohClient> _refresh_zenoh_client_for_pid(bool force = false) {
    std::lock_guard<std::recursive_mutex> guard(lock_);

    // 없으면 생성 후 연결
    if (!RBBaseSDK::zenoh_client_) {
      RBBaseSDK::zenoh_client_ = std::make_shared<rb_zenoh::ZenohClient>();
      _connect();
    } else if (force || RBBaseSDK::zenoh_client_->is_manually_closed()) {
      // 있는데 껐으면 다시 연결
      // force: transport 오류 후 강제 재연결(base.py force_reconnect). 그 외: 명시적으로
      // 닫힌 세션만 되살린다. 정상 세션은 건드리지 않는다.
      _connect();
    }
    return RBBaseSDK::zenoh_client_;
  }

  std::string _generate_nonce() {
    static thread_local std::mt19937_64 rng{std::random_device{}()};

    std::stringstream ss;

    for (int i = 0; i < 2; ++i) {
      ss << std::hex << std::setw(16) << std::setfill('0') << rng();
    }

    return ss.str();
  }

  // libcurl WRITEFUNCTION 콜백. libcurl 이 응답 바디를 조각(chunk)으로 넘겨줄 때마다 불린다.
  // (ptr, size*nmemb) 를 userdata(=std::string*) 뒤에 이어 붙이고, 처리한 바이트 수를 돌려줘야
  // 한다(리턴값 != size*nmemb 이면 libcurl 이 전송 오류로 간주해 중단한다).
  static size_t _curl_write_cb(char* ptr, size_t size, size_t nmemb, void* userdata) {
    static_cast<std::string*>(userdata)->append(ptr, size * nmemb);
    return size * nmemb;
  }

  // base.py 의 urllib 기반 _http_json 대응. cpr 을 걷어내고 libcurl(curl_easy_*)을 직접 호출하는
  // 헤더 전용 구현. common 서비스로의 평문 HTTP(peer 등록/heartbeat/해제)만 쓰므로 TLS 불필요.
  // 호출 빈도가 낮아(연결당 1회 + ttl/2 초마다 heartbeat) easy 핸들 재사용/커넥션 풀은 두지 않는다.
  nlohmann::json _http_json(HttpMethod method, const std::string& url, const nlohmann::json* data,
                            const HttpHeaders& headers, int timeout_ms = 10000) {
    // curl_easy_init 은 global 상태가 없으면 지연 초기화하는데 그게 스레드-세이프하지 않다.
    // 함수 지역 static 초기화(C++11: 정확히 1회, 스레드-세이프)로 최초 진입 시 선점한다.
    // 2회차부터는 가드 변수 acquire-load 1개라 사실상 공짜. cleanup 은 장수 프로세스라 생략.
    static const bool _curl_global_ok = [] {
      return curl_global_init(CURL_GLOBAL_DEFAULT) == CURLE_OK;
    }();
    if (!_curl_global_ok)
      throw std::runtime_error("curl_global_init failed");

    CURL* curl = curl_easy_init();  // 요청 1건당 easy 핸들 1개
    if (!curl)
      throw std::runtime_error("curl_easy_init failed");

    const std::string body = data ? data->dump() : std::string();  // JSON body 를 문자열로 직렬화
    std::string response;                                          // 응답 바디 누적 버퍼(위 콜백이 채움)

    // 요청 헤더: HttpHeaders(map) 를 "Key: Value" 문자열 리스트로 변환.
    // 호출부가 Content-Type/Authorization 을 이미 채워 넘기므로 여기서 추가로 손대지 않는다.
    curl_slist* header_list = nullptr;
    for (const auto& [key, value] : headers)
      header_list = curl_slist_append(header_list, (key + ": " + value).c_str());

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, header_list);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, static_cast<long>(timeout_ms));  // 전체(connect+transfer) 상한
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);  // 멀티스레드 안전: SIGALRM 기반 DNS 타임아웃 비활성
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, &_curl_write_cb);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);  // 콜백의 userdata 로 전달됨

    // 메서드별 설정. 매 호출 새 핸들이라 사실 GET 이 기본이지만, 의도를 명시적으로 남긴다.
    switch (method) {
      case HttpMethod::GET:
        curl_easy_setopt(curl, CURLOPT_HTTPGET, 1L);
        break;
      case HttpMethod::POST:
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, static_cast<long>(body.size()));  // body 에 '\0' 가능성 대비
        break;
      case HttpMethod::PUT:
        // PUT + 바디: READFUNCTION 대신 POSTFIELDS 를 쓰고 메서드만 PUT 으로 덮어쓴다(현재 미사용 경로).
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, static_cast<long>(body.size()));
        break;
      case HttpMethod::DELETE:
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "DELETE");  // 바디 없음
        break;
    }

    const CURLcode rc = curl_easy_perform(curl);  // 블로킹 — 응답이 다 오거나 타임아웃까지
    long status_code = 0;
    if (rc == CURLE_OK)
      curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status_code);  // HTTP status line 코드

    // 성공/실패와 무관하게 리소스부터 해제(예외를 던지기 전에).
    curl_slist_free_all(header_list);
    curl_easy_cleanup(curl);

    // base.py _http_json 과 동일한 에러 규약: 전송 실패 / 4xx·5xx 를 RuntimeError 로 올린다.
    if (rc != CURLE_OK)
      throw std::runtime_error(std::string("Network error: ") + curl_easy_strerror(rc));
    if (status_code >= 400)
      throw std::runtime_error("HTTP " + std::to_string(status_code) + ": " + response);
    if (response.empty())
      return nlohmann::json::object();  // 204 No Content 등 — 빈 객체로 취급(호출부가 .value()/[] 로 접근)
    return nlohmann::json::parse(response);
  }

  std::string _detect_local_ip(const std::string& host) {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);

    if (sock < 0) {
      throw std::runtime_error("socket failed");
    }

    sockaddr_in remote{};

    remote.sin_family = AF_INET;
    remote.sin_port = htons(80);

    inet_pton(AF_INET, host.c_str(), &remote.sin_addr);

    ::connect(sock, reinterpret_cast<sockaddr*>(&remote), sizeof(remote));

    sockaddr_in local{};
    socklen_t len = sizeof(local);

    getsockname(sock, reinterpret_cast<sockaddr*>(&local), &len);

    char ip[INET_ADDRSTRLEN];

    inet_ntop(AF_INET, &local.sin_addr, ip, sizeof(ip));

    ::close(sock);  // 멤버 close() 와 이름 겹침 — 전역 close

    return ip;
  }

  bool _is_same_host(const std::string& host) {
    if (host == "127.0.0.1" || host == "localhost" || host == "::1") {
      return true;
    }

    try {
      std::string my_ip = _detect_local_ip(host);

      struct addrinfo hints{};
      struct addrinfo* result = nullptr;

      hints.ai_family = AF_INET;

      if (getaddrinfo(host.c_str(), nullptr, &hints, &result) != 0) {
        return false;
      }

      char ip[INET_ADDRSTRLEN];

      auto* addr = reinterpret_cast<sockaddr_in*>(result->ai_addr);

      inet_ntop(AF_INET, &(addr->sin_addr), ip, sizeof(ip));

      freeaddrinfo(result);

      return my_ip == ip;
    } catch (...) {
      return false;
    }
  }

  uint16_t _find_free_port() {
    int sock = ::socket(AF_INET, SOCK_STREAM, 0);

    if (sock < 0) {
      throw std::runtime_error("socket() failed");
    }

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(0);

    if (::bind(sock, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
      ::close(sock);
      throw std::runtime_error("bind() failed");
    }

    sockaddr_in assigned{};
    socklen_t len = sizeof(assigned);

    if (::getsockname(sock, reinterpret_cast<sockaddr*>(&assigned), &len) < 0) {
      ::close(sock);
      throw std::runtime_error("getsockname() failed");
    }

    uint16_t port = ntohs(assigned.sin_port);

    ::close(sock);

    return port;
  }

  static std::string _trim(const std::string& s) {
    const auto begin = s.find_first_not_of(" \t\r");
    if (begin == std::string::npos) {
      return "";
    }

    const auto end = s.find_last_not_of(" \t\r");

    return s.substr(begin, end - begin + 1);
  }

  static std::vector<std::string> _split_endpoint_env(const std::optional<std::string>& value) {
    if (!value || value->empty()) {
      return {};
    }

    std::string normalized = *value;

    std::replace(normalized.begin(), normalized.end(), '\n', ',');

    std::vector<std::string> result;

    std::stringstream ss(normalized);

    std::string item;

    while (std::getline(ss, item, ',')) {
      item = _trim(item);

      if (!item.empty()) {
        result.push_back(item);
      }
    }

    return result;
  }

  void _merge_endpoint_env(const std::string& name, const std::string& endpoint) {
    const char* env = std::getenv(name.c_str());

    auto endpoints = _split_endpoint_env(env ? std::optional<std::string>(env) : std::nullopt);

    if (std::find(endpoints.begin(), endpoints.end(), endpoint) == endpoints.end()) {
      endpoints.push_back(endpoint);
    }

    std::string merged;

    for (size_t i = 0; i < endpoints.size(); ++i) {
      if (i > 0) {
        merged += ",";
      }

      merged += endpoints[i];
    }
    setenv(name.c_str(), merged.c_str(), 1);
  }

  void _reconnect_shared_zenoh_for_remote_peer(int listen_port) {
    RBBaseSDK::zenoh_client_->close();
    _merge_endpoint_env("ZENOH_PEER_LISTEN_ENDPOINTS", "tcp/0.0.0.0:" + std::to_string(listen_port));
    {
      std::lock_guard<std::recursive_mutex> guard(lock_);
      _refresh_zenoh_client_for_pid();
    }
  }

  void heartbeat_loop(const std::string& peer_id, int ttl, double interval_sec) {

    HttpHeaders headers{{"Authorization", "Bearer " + *peer_token_}, {"Content-Type", "application/json"}};
    nlohmann::json payload{{"ttl", ttl}};

    while (!heartbeat_stop_) {
      std::this_thread::sleep_for(std::chrono::duration<double>(interval_sec));

      if (heartbeat_stop_) {
        break;
      }

      if (!peer_common_url_ || !peer_token_) {
        break;
      }

      try {
        auto resp_data = _http_json(HttpMethod::POST, *peer_common_url_ + "/zenoh/peer/" + peer_id + "/heartbeat",
                                    &payload, headers, 5000);

        bool ok = resp_data.value("ok", false);

        if (!ok) {
          std::cerr << "[SDK] heartbeat rejected for peer " << peer_id << ", closing session" << std::endl;

          // disconnect();
          heartbeat_stop_ = true;
          if (heartbeat_thread_.joinable()) {
            heartbeat_thread_.join();
          }

          return;
        } else {
        }
      } catch (const std::exception& e) {
        std::cerr << "[SDK] heartbeat error for peer " << peer_id << ": " << e.what() << std::endl;
      }
    }
  }

  bool _wait_for_zenoh_echo(const std::string& req_keyexpr, const std::string& res_keyexpr,
                            std::optional<double> timeout, double probe_timeout, double interval) {
    std::mutex mtx;
    std::condition_variable cv;

    bool received = false;
    bool matched = false;

    std::string expected_nonce;
    std::string received_nonce;

    int handle = RBBaseSDK::zenoh_client_->declare_subscriber(
        res_keyexpr,
        [&](const std::string& topic, const std::vector<uint8_t>& payload, const std::string& attachment) {
          {
            std::lock_guard<std::mutex> lock(mtx);
            received_nonce.assign(payload.begin(), payload.end());
            received = true;
          }
          cv.notify_one();
        },
        {});

    auto start = std::chrono::steady_clock::now();

    try {
      while (!matched) {
        expected_nonce = _generate_nonce();

        {
          std::lock_guard lock(mtx);

          received = false;
          received_nonce.clear();
        }
        std::vector<uint8_t> payload(expected_nonce.begin(), expected_nonce.end());
        RBBaseSDK::publish(req_keyexpr, payload);

        {
          std::unique_lock lock(mtx);

          bool ok = cv.wait_for(lock, std::chrono::duration<double>(probe_timeout), [&] { return received; });

          if (ok && received_nonce == expected_nonce) {
            std::cout << "[SDK] zenoh echo verified: " << req_keyexpr << " -> " << res_keyexpr << std::endl;
            matched = true;
            // return true;
          } else {
          }
        }

        if (timeout) {
          auto elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();

          if (elapsed >= *timeout) {
            std::cout << "[SDK] zenoh echo still warming up" << std::endl;

            break;
          }
        }

        std::this_thread::sleep_for(std::chrono::duration<double>(interval));
      }
    }

    catch (...) {
      zenoh_client_->unsubscribe_topic(res_keyexpr);
      std::cout << "unsubs caught" << std::endl;
      throw;
    }

    zenoh_client_->unsubscribe_topic(res_keyexpr);

    return matched;
  }
};

// template<typename T>
// class RBBaseSDK_Singletone : public RBBaseSDK
// {
// public:
//     RBBaseSDK_Singletone()
//     {
//         RBBaseSDK::instance();
//         Registry::instance().add(T::type_name());
//     }
// };
