# Rainbow RB SDK C++

This package provides the C++ RB SDK development files.

Typical CMake usage:

```cmake
find_package(rb_sdk REQUIRED)
target_link_libraries(my_plugin PRIVATE rb_sdk::rb_sdk)
```

The `rainbow-rb-sdk-dev` package must be built and used with the exact matching
`rainbow-rb-sdk` runtime package version. The Debian package dependency enforces
this with `rainbow-rb-sdk (= <version>)`.

Do not load `librb_sdk.so.<version>` and the Python package `rainbow.rb_sdk` in
the same process. Both paths embed native networking/runtime libraries, and the
supported process model is one SDK runtime path per process.
