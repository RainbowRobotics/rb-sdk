#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "rb_sdk::rb_sdk" for configuration "Release"
set_property(TARGET rb_sdk::rb_sdk APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(rb_sdk::rb_sdk PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/librb_sdk.so.0.1.2.1"
  IMPORTED_SONAME_RELEASE "librb_sdk.so.0.1.2.1"
  )

list(APPEND _IMPORT_CHECK_TARGETS rb_sdk::rb_sdk )
list(APPEND _IMPORT_CHECK_FILES_FOR_rb_sdk::rb_sdk "${_IMPORT_PREFIX}/lib/librb_sdk.so.0.1.2.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
