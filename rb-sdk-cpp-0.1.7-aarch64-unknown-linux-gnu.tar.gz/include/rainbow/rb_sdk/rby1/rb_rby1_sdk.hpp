#pragma once

#include <array>
#include <cstdint>
#include <ctime>
#include <map>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "base.hpp"
#include "rby1_runtime.hpp"

/**
 * @brief RBRby1SDK::get_system_time 결과 (공식 GetSystemTime 의 tuple 그대로).
 *
 * Python 에서는 공식 바인딩(robot.get_system_time)과 같은 (datetime, local_time) 튜플로 변환된다.
 */
struct RBRby1SystemTime {
  timespec utc_time{};     // UTC 시각
  std::string time_zone;   // 로봇 타임존 (IANA 이름)
  std::string local_time;  // 로봇 로컬 시간 문자열
};

/**
 * @brief RBRby1SDK::set_system_time 인자 (Python 은 datetime.datetime, C++ 은 timespec 을 그대로 넘긴다).
 */
struct RBRby1Timestamp {
  timespec ts{};
  RBRby1Timestamp() = default;
  RBRby1Timestamp(const timespec& t) : ts(t) {}  // NOLINT(google-explicit-constructor)
};

/**
 * @brief RBRby1SDK::download_file 결과 (Python 에서는 bytes).
 */
struct RBRby1Bytes {
  std::string data;  // 파일 내용
};

/// 명령 빌더 참조: Python 의 rby1.RobotCommandBuilder 객체를 호출이 끝날 때까지 쥔다 (공식 빌더는 복사 불가).
using RBRby1CommandBuilderRef = std::shared_ptr<const rb::RobotCommandBuilder>;

/**
 * @brief 로봇 명령 핸들 (RBRby1SDK.send_command 결과, 공식 RobotCommandHandler 래퍼).
 *
 * 블로킹 메서드(wait/get)는 기본 async, ``handle.sync.<method>`` 는 동기다.
 * **핸들을 버리면 명령이 취소된다** (공식 소멸자 = Cancel) — 명령이 끝날 때까지 핸들을 쥐고 있어야 한다.
 * async wait/get 을 기다리던 쪽이 취소되면(Task.cancel, asyncio.wait_for 타임아웃, 루프 종료) 결과만 버리지 않고
 * 로봇 명령도 취소한다 (cancel()). 이때 flow_manager_args.done() 은 부르지 않는다.
 * disconnect_robot 뒤에도 이미 보낸 명령의 wait/get/is_done/cancel 은 그 명령에 대해 동작한다.
 * fork 자식에서는 부모의 핸들을 쓸 수 없다 (RBY1ConnectionError, cancel 은 할 일 없음).
 */
class RB_SDK_API RBRby1CommandHandle {
 public:
  using Slot = rby1_rt::HandleSlot<rby1_rt::CommandHandlerVar>;
  explicit RBRby1CommandHandle(std::shared_ptr<Slot> slot) : slot_(std::move(slot)) {}
  RBRby1CommandHandle(const RBRby1CommandHandle&) = default;
  RBRby1CommandHandle(RBRby1CommandHandle&&) = default;
  RBRby1CommandHandle& operator=(const RBRby1CommandHandle&) = default;
  RBRby1CommandHandle& operator=(RBRby1CommandHandle&&) = default;
  ~RBRby1CommandHandle();

  /**
   * @brief 명령이 끝날 때까지 기다린다.
   * @param timeout_ms 최대 대기(ms). None 이면 끝날 때까지.
   * @param flow_manager_args Optional PyFM step context. 명령이 끝났으면(True) done() 을 호출한다.
   * @return 끝났으면 True, 타임아웃이면 False.
   * @throws RBY1ConnectionError fork 자식에서 부모 핸들 사용.
   */
  bool wait(std::optional<int> timeout_ms = std::nullopt, FlowManagerArgsPtr flow_manager_args = nullptr) const;
  /**
   * @brief 명령이 끝날 때까지 기다려 최종 피드백을 받는다.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return rby1.RobotCommandFeedback (공식 타입). 성공 여부는 finish_code 로 확인한다.
   * @throws RBY1Error gRPC 실패(취소됨·연결 끊김 등). RBY1ConnectionError fork 자식에서 부모 핸들 사용.
   */
  rb::RobotCommandFeedback get(FlowManagerArgsPtr flow_manager_args = nullptr) const;
  /**
   * @brief 명령을 취소한다 (기다리지 않는다). 이미 끝났거나 fork 로 버려진 핸들이면 아무것도 하지 않는다.
   */
  void cancel() const;
  /**
   * @brief 명령이 끝났는지 (완료·취소·실패 모두).
   * @return 끝났으면 True.
   * @throws RBY1ConnectionError fork 자식에서 부모 핸들 사용.
   */
  bool is_done() const;
  /**
   * @brief 끝난 명령의 gRPC 상태.
   * @return gRPC 호출이 성공했으면 True (취소·연결 실패면 False, 진행 중이면 True).
   * @throws RBY1ConnectionError fork 자식에서 부모 핸들 사용.
   */
  bool get_status() const;

 private:
  std::shared_ptr<Slot> slot_;
};

/**
 * @brief 명령 스트림 핸들 (RBRby1SDK.create_command_stream 결과, 공식 RobotCommandStreamHandler 래퍼).
 *
 * 한 연결로 명령을 연이어 보낸다. 블로킹 메서드는 기본 async, ``stream.sync.<method>`` 는 동기다.
 * **핸들을 버리면 스트림이 취소된다** (공식 소멸자). async 호출을 기다리던 쪽이 취소되면 스트림도 취소한다.
 * disconnect_robot / connect_robot 뒤에는 새 명령(send_command/request_feedback)을 보내지 않는다
 * (RBY1ConnectionError) — wait/cancel/is_done 은 계속 동작한다.
 */
class RB_SDK_API RBRby1CommandStream {
 public:
  using Slot = rby1_rt::HandleSlot<rby1_rt::CommandStreamVar>;
  explicit RBRby1CommandStream(std::shared_ptr<Slot> slot) : slot_(std::move(slot)) {}
  RBRby1CommandStream(const RBRby1CommandStream&) = default;
  RBRby1CommandStream(RBRby1CommandStream&&) = default;
  RBRby1CommandStream& operator=(const RBRby1CommandStream&) = default;
  RBRby1CommandStream& operator=(RBRby1CommandStream&&) = default;
  ~RBRby1CommandStream();

  /**
   * @brief 스트림으로 명령을 보내고 제어기 피드백을 받는다 (명령 완료가 아니라 현재 상태).
   * @param builder rby1.RobotCommandBuilder (공식 타입).
   * @param timeout_ms 피드백 대기(ms). 넘기면 공식 SDK 가 스트림을 취소한다.
   * @return rby1.RobotCommandFeedback (공식 타입).
   * @throws RBY1Error 스트림 만료·타임아웃·이전 명령 진행 중. RBY1ConnectionError 연결이 바뀜/끊김.
   */
  rb::RobotCommandFeedback send_command(RBRby1CommandBuilderRef builder, int timeout_ms = 1000) const;
  /**
   * @brief 진행 중인 명령의 제어기 피드백을 요청한다 (send_command 뒤에만).
   * @param timeout_ms 피드백 대기(ms).
   * @return rby1.RobotCommandFeedback (공식 타입).
   * @throws RBY1Error 스트림 만료·타임아웃·명령 전. RBY1ConnectionError 연결이 바뀜/끊김.
   */
  rb::RobotCommandFeedback request_feedback(int timeout_ms = 1000) const;
  /**
   * @brief 스트림이 끝날(닫히거나 취소될) 때까지 기다린다.
   * @param timeout_ms 최대 대기(ms). None 이면 끝날 때까지.
   * @return 끝났으면 True, 타임아웃이면 False.
   * @throws RBY1ConnectionError fork 자식에서 부모 핸들 사용.
   */
  bool wait(std::optional<int> timeout_ms = std::nullopt) const;
  /**
   * @brief 스트림을 취소한다 (기다리지 않는다). fork 로 버려진 핸들이면 아무것도 하지 않는다.
   */
  void cancel() const;
  /**
   * @brief 스트림이 끝났는지.
   * @return 끝났으면 True.
   * @throws RBY1ConnectionError fork 자식에서 부모 핸들 사용.
   */
  bool is_done() const;

 private:
  std::shared_ptr<Slot> slot_;
};

/**
 * @brief 로봇 시리얼 장치 스트림 (RBRby1SDK.open_serial_stream 결과, 공식 SerialStream 래퍼).
 *
 * connect() 후 write() 로 보내고, 받은 데이터는 open_serial_stream 의 callback(data: bytes) 으로 온다.
 * 콜백은 수신 전용 스레드에서 순서대로 한 번에 하나씩 불린다 (gRPC 수신은 막히지 않는다 — 콜백이 느리면
 * 1024 chunk 까지 쌓고, 넘치면 오래된 것부터 버린다: read_stats 의 dropped). 콜백이 awaitable 을 돌려주면
 * 등록 시점의 이벤트 루프에서 실행하고 끝날 때까지 다음 chunk 를 넘기지 않는다. 콜백 예외는 stderr 로 출력한다.
 * 블로킹 메서드는 기본 async, ``stream.sync.<method>`` 는 동기다. async 호출을 기다리던 쪽이 취소되면 스트림을
 * 끊는다 (cancel()). **핸들을 버리면 스트림이 끊긴다** (공식 소멸자).
 * disconnect_robot / connect_robot 뒤에는 connect/write 를 보내지 않는다 (RBY1ConnectionError).
 */
class RB_SDK_API RBRby1SerialStream {
 public:
  using Slot = rby1_rt::HandleSlot<rby1_rt::SerialHandle>;
  explicit RBRby1SerialStream(std::shared_ptr<Slot> slot) : slot_(std::move(slot)) {}
  RBRby1SerialStream(const RBRby1SerialStream&) = default;
  RBRby1SerialStream(RBRby1SerialStream&&) = default;
  RBRby1SerialStream& operator=(const RBRby1SerialStream&) = default;
  RBRby1SerialStream& operator=(RBRby1SerialStream&&) = default;
  ~RBRby1SerialStream();

  /**
   * @brief 시리얼 장치를 연다 (open_serial_stream 의 설정으로).
   * @param verbose 실패 이유를 stderr 로 출력 (공식 SDK).
   * @return True.
   * @throws RBY1Error 열기 실패(이미 열림·끊긴 스트림·로봇 거부·타임아웃). RBY1ConnectionError 연결이 바뀜/끊김.
   */
  bool connect(bool verbose = false) const;
  /**
   * @brief 데이터를 보낸다.
   * @param data 보낼 bytes (str 이면 UTF-8).
   * @return True.
   * @throws RBY1Error 쓰기 실패(열리지 않음·끊김·타임아웃). RBY1ConnectionError 연결이 바뀜/끊김.
   */
  bool write(const std::string& data) const;
  /**
   * @brief 스트림이 끝날(끊기거나 취소될) 때까지 기다린다.
   * @param timeout_ms 최대 대기(ms). None 이면 끝날 때까지.
   * @return 끝났으면 True, 타임아웃이면 False.
   * @throws RBY1ConnectionError fork 자식에서 부모 핸들 사용.
   */
  bool wait(std::optional<int> timeout_ms = std::nullopt) const;
  /**
   * @brief 스트림을 끊고 진행 중인 수신 콜백이 끝날 때까지 기다린다 — 반환 뒤로 콜백은 없다 (아직 콜백에 넘기지
   * 못한 수신 데이터는 버린다. 콜백 안에서 부르면 기다리지 않는다).
   * @throws RBY1ConnectionError fork 자식에서 부모 핸들 사용.
   */
  void disconnect() const;
  /**
   * @brief 스트림을 끊는다 (진행 중인 콜백은 기다리지 않는다, 넘기지 못한 수신 데이터는 버린다). fork 로 버려진
   * 핸들이면 아무것도 하지 않는다.
   */
  void cancel() const;
  /**
   * @brief 장치가 열려 있는지 (공식 SDK: connect 성공 뒤 True).
   * @return 열려 있으면 True.
   * @throws RBY1ConnectionError fork 자식에서 부모 핸들 사용.
   */
  bool is_opened() const;
  /**
   * @brief 스트림이 끝났는지.
   * @return 끝났으면 True.
   * @throws RBY1ConnectionError fork 자식에서 부모 핸들 사용.
   */
  bool is_done() const;
  /**
   * @brief 수신 콜백 통계.
   * @return {"received": 받은 chunk 수, "delivered": 콜백 호출 수, "dropped": 대기열이 넘쳐 버린 수}. 콜백 없이
   * 열었으면 모두 0.
   */
  std::map<std::string, uint64_t> read_stats() const;

 private:
  std::shared_ptr<Slot> slot_;
};

/**
 * @brief stop / move_* 결과 (Python: ``{"finished": bool, "finish_code": str}``).
 */
struct RBRby1CommandResult {
  bool finished = false;    // 명령 핸들 is_done() (완료 대기 후라 True)
  std::string finish_code;  // 공식 RobotCommandFeedback.FinishCode 이름 ("Ok", "Canceled", "Unknown", ...)
};

/**
 * @brief emergency_stop 결과 (Python: ``{"stopped": bool}``).
 */
struct RBRby1EmergencyStopResult {
  bool stopped = false;  // power_off(".*") 결과
};

/**
 * @brief 관절 하나의 리밋 (get_joint_limits).
 */
struct RBRby1JointLimit {
  std::string name;
  std::array<double, 2> position{};      // [lower, upper] rad
  std::array<double, 2> velocity{};      // [lower, upper] rad/s
  std::array<double, 2> acceleration{};  // [lower, upper] rad/s^2
  double torque = 0;                     // Nm
};

/**
 * @brief get_joint_limits 결과 (Python: ``{joint_name: {"position": [lo, hi], "velocity": [lo, hi],
 * "acceleration": [lo, hi], "torque": t}}``, 공식 dynamics 의 관절 순서).
 */
struct RBRby1JointLimits {
  std::vector<RBRby1JointLimit> joints;
};

/// 로봇 로그 한 줄에서 사람이 읽을 사유만.
RB_SDK_API std::string rby1_extract_log_message(const std::string& raw);
/// 실패한 move/stop/approach/smooth jog 를 muscat/{robot_model}/message 로 알린다 (best-effort, 실패는 stderr).
/// detail 이 비면 로봇 로그에서 사유를 뽑는다.
RB_SDK_API void rby1_publish_move_error(const std::string& robot_model, const std::string& finish_code,
                             const std::string& detail = "");

/// 관절명 → 값 (Python dict, 순서 유지).
/// Cartesian 자세: 컴포넌트("torso"/"right_arm"/"left_arm") → [x_mm, y_mm, z_mm, rx_deg, ry_deg, rz_deg]
/// (Base 기준, R = Rz(rz)·Ry(ry)·Rx(rx) — manipulate tar_values 와 같은 규약). 링크는 SDK 가 정한다
/// (torso→link_torso_5, right_arm→ee_right, left_arm→ee_left). 키가 곧 명령에 넣는 부위 — 없는 부위는 현재 자세 유지.
using RBRby1Cartesians = std::map<std::string, std::vector<double>>;
/// 관절 목표 (move_j / smoothjog_j): 컴포넌트("torso"/"right_arm"/"left_arm"/"head") → 관절값 [deg], 컴포넌트 전체 길이.
using RBRby1JogJoints = std::map<std::string, std::vector<double>>;
/// 부위별 컨트롤러. kind: "position"(기본) / 팔 J "joint_impedance" / 팔 L "cartesian_impedance"·"impedance".
/// torso·head 는 position 만. Python: {"right_arm": "impedance"} 또는 {"right_arm": {"kind": ..., "stiffness": 200}}.
struct RBRby1Controller {
  std::string kind = "position";
  double stiffness = 150.0;          // joint_impedance / cartesian_impedance [Nm/rad]
  double damping = 1.0;              // damping ratio
  double torque = 100.0;             // torque limit [Nm]
  double translation_weight = 1.0;   // impedance
  double rotation_weight = 1.0;      // impedance
};
using RBRby1Controllers = std::map<std::string, RBRby1Controller>;

/**
 * @brief Rainbow Robotics RB-Y1 SDK (공식 rby1-sdk C++ 위의 muscat SDK).
 *
 * 인스턴스는 얇은 핸들이고 로봇 gRPC 연결은 프로세스에 하나다 — 몇 번 생성해도 같은 연결을 쓴다.
 * Python 에서 메서드는 기본 async (gRPC 대기를 C++ worker 스레드에서 GIL 없이), ``sdk.sync.<method>`` 는 동기.
 * 로봇 연결은 connect_robot/disconnect_robot 이다 — RBBaseSDK.connect/disconnect 는 zenoh 원격 peer 등록.
 */
class RB_SDK_API RBRby1SDK : public RBBaseSDK {
 public:
  RBRby1SDK() {}

  /**
   * @brief RB-Y1 gRPC 서버에 연결하고 로봇 model 을 확정한다.
   *
   * 이미 같은 endpoint(기본값 해석 후)·같은 model(생략 시 무관)로 연결돼 있고 채널이 살아 있으면 no-op —
   * 연결과 스트림을 그대로 두고 연결된 model 을 반환한다. 그 밖에는 기존 연결·스트림을 끊고 새로 연결한다.
   * @param endpoint "host:port". None 이면 환경변수 RBY1_HOST(없으면 192.168.30.1) + ":50051".
   * @param model "a" / "m" / "ub". 주면 그 model 이 아닐 때 실패한다. 생략하면 로봇이 알려준 model.
   * @param max_retries 연결 재시도 횟수.
   * @param timeout_ms 시도당 타임아웃(ms).
   * @return 연결된 model 이름 ("a" / "m" / "ub").
   * @throws RBY1ConnectionError 연결 실패 또는 model 불일치.
   */
  static std::string connect_robot(const std::optional<std::string>& endpoint = std::nullopt,
                                   const std::optional<std::string>& model = std::nullopt, int max_retries = 5,
                                   int timeout_ms = 1000);
  /**
   * @brief 로봇 gRPC 연결을 끊는다 (스트림도 모두 멈춘다).
   * @return 연결이 있었으면 true.
   */
  static bool disconnect_robot();
  /**
   * @brief 로봇 gRPC 연결 여부 — 연결된 로봇이 있고 그 gRPC 채널이 살아 있는지 (공식 IsConnected, RPC 없음).
   *
   * 채널 상태는 gRPC 가 마지막으로 관찰한 것이다: 서버가 죽은 뒤 호출이 한 번 실패해야 false 가 되고,
   * 채널이 스스로 재연결하면 다시 true 가 된다 (connect_robot 불필요).
   * @return 연결돼 있으면 true.
   */
  static bool is_robot_connected();
  /**
   * @brief 연결된 로봇 model.
   * @return "a" / "m" / "ub", 미연결이면 None.
   */
  static std::optional<std::string> model();

  /**
   * @brief 장치 전원을 켠다. 켜진 장치는 건드리지 않고 꺼진 장치만 모아 한 번에 켠다 — 전부 켜져 있으면 아무것도 안 보내고 True.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 장치 이름 정규식 (예: ".*" 전체, "^right_arm_.*").
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool power_on(const std::string& robot_model, const std::string& dev_name,
                       FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 장치 전원을 끈다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 장치 이름 정규식 (예: ".*" 전체).
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool power_off(const std::string& robot_model, const std::string& dev_name,
                        FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 장치 전원이 켜져 있는지 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 장치 이름 정규식. 매칭된 장치가 모두 켜져 있어야 True.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 매칭된 장치가 모두 켜져 있으면 True.
   * @throws RBY1Error 매칭 장치 없음 또는 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool is_power_on(const std::string& robot_model, const std::string& dev_name,
                          FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 관절 서보를 켠다. 켜진 관절(is_ready)은 건드리지 않고 꺼진 관절만 모아 한 번에 켠다 — 전부 켜져 있으면 아무것도 안 보내고 True.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 관절 이름 정규식 (예: ".*" 전체, "^torso_.*").
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool servo_on(const std::string& robot_model, const std::string& dev_name,
                       FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 로봇 정보(model, 관절·장치 목록 등)를 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return rby1.RobotInfo (공식 타입).
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static rb::RobotInfo get_robot_info(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief 로봇 상태 스트림을 시작한다 (latest-only).
   *
   * 공식 start_state_update 와 같이 콜백 인자는 1개 또는 2개다: callback(state) 또는
   * callback(state, control_manager_state). 개수는 등록 때 한 번 inspect.signature(callback).parameters 로 센다
   * (bound method 의 self, partial 로 묶인 인자는 빠진다). 그 밖의 개수면 TypeError. 두 값은 같은 스트림 샘플
   * (GetRobotStateStream 응답 하나)에서 온다 — 1개 형도 같은 RPC 이므로 비용 차이는 없다.
   *
   * 콜백은 스트림 전용 스레드에서 한 번에 하나씩 불린다. 콜백이 느리면 그 사이 도착한 상태는 최신 것만 남고
   * 나머지는 버린다 (gRPC 수신은 막히지 않는다). 콜백이 awaitable(코루틴 등)을 돌려주면 등록 시점의 실행 중
   * 이벤트 루프에서 실행하고 끝날 때까지 다음 상태를 넘기지 않는다 (코루틴도 latest-only). 코루틴 함수를
   * 이벤트 루프 밖에서 등록하면 RuntimeError, 그 밖의 콜백이 루프 없이 awaitable 을 돌려주면 에러 로그 후 그 상태를
   * 버린다. 콜백 예외는 stderr 로 출력하고 스트림은 계속된다. 같은 model 로 다시 부르면 이전 스트림을 멈추고
   * 새로 시작한다. 콜백 안에서 stop_state_update 를 불러도 된다.
   *
   * 끊김 복구: 공식 SDK 는 서버가 스트림을 끝내도 알리지 않으므로, max(10/rate, 1)초 동안 상태가 안 오면 다시
   * 구독한다 (stderr 에 끊김·복구 한 줄씩, 재시도 간격은 두 배씩 4배까지, state_update_stats 의 resubscribes).
   * gRPC 연결은 공식 채널이 스스로 다시 맺으므로 로봇이 돌아오면 connect_robot 없이 스트림이 이어진다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param callback callback(state) 또는 callback(state, control_manager_state) — state 는
   * rby1.RobotState_A / _M / _UB, control_manager_state 는 rby1.ControlManagerState (공식 타입).
   * @param rate 요청 수신 주기(Hz).
   * @throws RBY1Error model 불일치. RBY1ConnectionError 미연결. TypeError 콜백 인자 개수가 1·2 가 아님.
   */
  static void start_state_update(const std::string& robot_model, rby1_rt::StateSink callback, double rate);
  /**
   * @brief 상태 스트림을 멈춘다. 진행 중인 동기 콜백이 끝날 때까지 기다리고 (콜백 안에서 부르면 기다리지 않는다),
   * 진행 중인 코루틴 콜백은 취소한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub").
   * @return 동작 중이던 스트림이 있었으면 True.
   */
  static bool stop_state_update(const std::string& robot_model);
  /**
   * @brief 상태 스트림 통계 (멈춘 뒤에도 마지막 값).
   * @param robot_model 로봇 model ("a" / "m" / "ub").
   * @return {"received": 수신 수, "delivered": 콜백 호출 수, "dropped": 콜백 전에 새 상태로 덮여 버린 수,
   * "resubscribes": 끊긴 스트림을 다시 구독한 수}.
   */
  static std::map<std::string, uint64_t> state_update_stats(const std::string& robot_model);

  // ── Task 9: 단순 메서드 (공식 Robot<T> 과 1:1, 부록 A) ─────────────────────────────

  /**
   * @brief 현재 모션 시간 배율(time scale)을 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 현재 time scale (0.0~1.0).
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static double get_time_scale(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 모션 실행 시간 배율을 설정한다. 0.0 은 정지, 1.0 은 최대 속도.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param time_scale 설정할 time scale (0.0~1.0).
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 로봇에 실제 적용된 time scale.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static double set_time_scale(const std::string& robot_model, double time_scale,
                               FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 관절 서보가 켜져 있는지 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 관절 이름 정규식.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 서보가 켜져 있으면 True.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool is_servo_on(const std::string& robot_model, const std::string& dev_name,
                          FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 관절 서보를 끈다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 관절 이름 정규식 (예: ".*" 전체).
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool servo_off(const std::string& robot_model, const std::string& dev_name,
                        FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 장치의 위치 제어 P 게인을 설정한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 장치 이름 정규식.
   * @param p_gain P 게인 (0~65535).
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_position_p_gain(const std::string& robot_model, const std::string& dev_name, uint16_t p_gain,
                                  FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 장치의 위치 제어 I 게인을 설정한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 장치 이름 정규식.
   * @param i_gain I 게인 (0~65535).
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_position_i_gain(const std::string& robot_model, const std::string& dev_name, uint16_t i_gain,
                                  FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 장치의 위치 제어 D 게인을 설정한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 장치 이름 정규식.
   * @param d_gain D 게인 (0~65535).
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_position_d_gain(const std::string& robot_model, const std::string& dev_name, uint16_t d_gain,
                                  FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 장치의 위치 제어 P/I/D 게인을 한 번에 설정한다. PIDGain 객체로 주려면 set_position_pid_gain_object.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 장치 이름 정규식.
   * @param p_gain P 게인 (0~65535).
   * @param i_gain I 게인 (0~65535).
   * @param d_gain D 게인 (0~65535).
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_position_pid_gain(const std::string& robot_model, const std::string& dev_name, uint16_t p_gain,
                                    uint16_t i_gain, uint16_t d_gain, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 장치의 위치 제어 PID 게인을 PIDGain 객체로 설정한다 (공식 SetPositionPIDGain 의 PIDGain 오버로드).
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 장치 이름 정규식.
   * @param pid_gain rby1.PIDGain (공식 타입).
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_position_pid_gain_object(const std::string& robot_model, const std::string& dev_name,
                                           const rb::PIDGain& pid_gain,
                                           FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 몸통(torso) 관절들의 위치 제어 PID 게인을 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 관절별 rby1.PIDGain 목록.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static std::vector<rb::PIDGain> get_torso_position_pid_gains(const std::string& robot_model,
                                                               FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 오른팔 관절들의 위치 제어 PID 게인을 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 관절별 rby1.PIDGain 목록.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static std::vector<rb::PIDGain> get_right_arm_position_pid_gains(const std::string& robot_model,
                                                                   FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 왼팔 관절들의 위치 제어 PID 게인을 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 관절별 rby1.PIDGain 목록.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static std::vector<rb::PIDGain> get_left_arm_position_pid_gains(const std::string& robot_model,
                                                                  FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 머리 관절들의 위치 제어 PID 게인을 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 관절별 rby1.PIDGain 목록.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static std::vector<rb::PIDGain> get_head_position_pid_gains(const std::string& robot_model,
                                                              FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 특정 장치의 위치 제어 PID 게인을 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 장치 이름.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return rby1.PIDGain (공식 타입).
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static rb::PIDGain get_position_pid_gain(const std::string& robot_model, const std::string& dev_name,
                                           FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 관절 브레이크를 건다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 관절 이름 정규식.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool brake_engage(const std::string& robot_model, const std::string& dev_name,
                           FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 관절 브레이크를 푼다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 관절 이름 정규식.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool brake_release(const std::string& robot_model, const std::string& dev_name,
                            FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 장치의 home offset 을 초기화한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param dev_name 장치 이름 정규식.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool home_offset_reset(const std::string& robot_model, const std::string& dev_name,
                                FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 관절의 preset 위치를 설정한다 (PVL 계열 모터만 지원).
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param joint_name 관절 이름.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_preset_position(const std::string& robot_model, const std::string& joint_name,
                                  FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief control manager 를 켠다. 로봇에 명령을 보내기 전에 불러야 한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param unlimited_mode_enabled unlimited 모드 사용 여부.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool enable_control_manager(const std::string& robot_model, bool unlimited_mode_enabled = false,
                                     FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief control manager 를 끈다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool disable_control_manager(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief control manager 의 fault 를 해제한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool reset_fault_control_manager(const std::string& robot_model,
                                          FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 진행 중인 제어(명령)를 취소한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool cancel_control(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 툴 플랜지 출력 전압을 설정한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param name 툴 플랜지 이름 ("right" / "left").
   * @param voltage 출력 전압 [V]. 보통 12 / 24, 0 이면 출력 끔.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_tool_flange_output_voltage(const std::string& robot_model, const std::string& name, int voltage,
                                             FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 툴 플랜지 디지털 출력 한 채널의 상태를 설정한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param name 팔 이름 ("right" / "left").
   * @param channel 디지털 출력 채널 번호.
   * @param state True = ON, False = OFF.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_tool_flange_digital_output(const std::string& robot_model, const std::string& name,
                                             unsigned int channel, bool state,
                                             FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 툴 플랜지 디지털 출력 채널 0/1 의 상태를 동시에 설정한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param name 팔 이름 ("right" / "left").
   * @param state_0 채널 0 상태 (True = ON).
   * @param state_1 채널 1 상태 (True = ON).
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_tool_flange_digital_output_dual(const std::string& robot_model, const std::string& name,
                                                  bool state_0, bool state_1,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 최근 로그를 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param count 가져올 로그 개수.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return rby1.Log 목록 (공식 타입).
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static std::vector<rb::Log> get_last_log(const std::string& robot_model, unsigned int count,
                                           FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief fault 로그 목록을 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return fault 로그 항목 문자열 목록.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static std::vector<std::string> get_fault_log_list(const std::string& robot_model,
                                                     FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief control manager 상태를 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return rby1.ControlManagerState (공식 타입).
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static rb::ControlManagerState get_control_manager_state(const std::string& robot_model,
                                                           FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 오도메트리를 주어진 값으로 초기화한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param angle 새 각도 [rad].
   * @param position 새 위치 [x, y] [m].
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool reset_odometry(const std::string& robot_model, double angle, const Eigen::Vector2d& position,
                             FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 파라미터 목록을 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return (파라미터 이름, 타입) 목록.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static std::vector<std::pair<std::string, int>> get_parameter_list(const std::string& robot_model,
                                                                     FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 로봇 파라미터 값을 설정한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param name 파라미터 이름.
   * @param value 파라미터 값 (문자열).
   * @param write_db DB 에도 기록할지 여부.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 해당 파라미터가 없거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_parameter(const std::string& robot_model, const std::string& name, const std::string& value,
                            bool write_db = true, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 로봇 파라미터 값을 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param name 파라미터 이름.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 파라미터 값 (문자열).
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static std::string get_parameter(const std::string& robot_model, const std::string& name,
                                   FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 파라미터 하나를 공장 기본값으로 되돌린다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param name 파라미터 이름.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool factory_reset_parameter(const std::string& robot_model, const std::string& name,
                                      FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 모든 파라미터를 공장 기본값으로 되돌린다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static void factory_reset_all_parameters(const std::string& robot_model,
                                           FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 파라미터 하나를 기본값으로 되돌린다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param name 파라미터 이름.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool reset_parameter(const std::string& robot_model, const std::string& name,
                              FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 모든 파라미터를 기본값으로 되돌린다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static void reset_all_parameters(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 로봇에 저장된 로봇 모델(URDF) 문자열을 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 로봇 모델 문자열.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static std::string get_robot_model(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 로봇 모델(URDF)을 로봇에 등록한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param name 모델 이름.
   * @param model 모델 데이터 (URDF 문자열).
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool import_robot_model(const std::string& robot_model, const std::string& name, const std::string& model,
                                 FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief LED 색을 설정한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param color rby1.Color (공식 타입, RGB 0~255).
   * @param duration 유지 시간 [s].
   * @param transition_time 전환 시간 [s].
   * @param blinking 깜빡임 여부.
   * @param blinking_freq 깜빡임 주파수 [Hz].
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_led_color(const std::string& robot_model, const rb::Color& color, double duration = 1,
                            double transition_time = 0, bool blinking = false, double blinking_freq = 1,
                            FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 로봇 시스템 시간을 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return (datetime, local_time) — 로봇 타임존의 aware datetime 과 로봇의 로컬 시간 문자열 (공식 Python 바인딩과
   * 같은 형태). 로봇이 타임존을 주지 않으면 datetime 은 UTC.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static RBRby1SystemTime get_system_time(const std::string& robot_model,
                                          FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 로봇 시스템 시간을 설정한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param utc_time 새 시간 (Python datetime.datetime; naive 면 로컬 시간으로 해석).
   * @param time_zone 로봇 타임존 (예: "Asia/Seoul"). None 이면 타임존은 바꾸지 않는다.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_system_time(const std::string& robot_model, const RBRby1Timestamp& utc_time,
                              const std::optional<std::string>& time_zone = std::nullopt,
                              FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 배터리 잔량을 설정한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param level 배터리 잔량 [%] (0.0~100.0).
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_battery_level(const std::string& robot_model, double level,
                                FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 배터리 설정을 바꾼다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param cutoff_voltage 차단 전압 [V].
   * @param fully_charged_voltage 완충 전압 [V].
   * @param coefficients 배터리 계수 4개.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool set_battery_config(const std::string& robot_model, double cutoff_voltage, double fully_charged_voltage,
                                 const std::array<double, 4>& coefficients,
                                 FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 배터리 설정을 기본값으로 되돌린다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool reset_battery_config(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 로봇이 제어 명령을 받을 준비가 될 때까지 기다린다. servo_on 뒤, 명령 전에 부른다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param timeout_ms 타임아웃 [ms].
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 준비됐으면 True, 타임아웃이면 False (예외 아님).
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool wait_for_control_ready(const std::string& robot_model, long timeout_ms,
                                     FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 네트워크 설정을 기본값으로 되돌린다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool reset_network_setting(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 주변 WiFi 네트워크를 검색한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return rby1.WifiNetwork 목록 (공식 타입).
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static std::vector<rb::WifiNetwork> scan_wifi(const std::string& robot_model,
                                                FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief WiFi 네트워크에 연결한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param ssid 네트워크 이름.
   * @param password 비밀번호.
   * @param use_dhcp DHCP 로 IP 를 받을지 여부.
   * @param ip_address 고정 IP 주소 (use_dhcp=False 일 때).
   * @param gateway 게이트웨이 주소.
   * @param dns DNS 서버 목록.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool connect_wifi(const std::string& robot_model, const std::string& ssid, const std::string& password = "",
                           bool use_dhcp = true, const std::string& ip_address = "", const std::string& gateway = "",
                           const std::vector<std::string>& dns = {}, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief WiFi 연결을 끊는다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇이 거부했거나 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool disconnect_wifi(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief WiFi 연결 상태를 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return rby1.WifiStatus (공식 타입). 로봇이 에러 응답을 주면 None.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static std::optional<rb::WifiStatus> get_wifi_status(const std::string& robot_model,
                                                       FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 로봇의 시리얼 장치 목록을 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return rby1.SerialDevice 목록 (공식 타입).
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static std::vector<rb::SerialDevice> get_serial_device_list(const std::string& robot_model,
                                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  // ── Task 10: 모델 의존 반환형 · 핸들 ──────────────────────────────────────────────

  /**
   * @brief 현재 로봇 상태를 한 번 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return rby1.RobotState_A / _M / _UB (연결된 model 의 공식 타입).
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static rby1_rt::RobotStateVar get_state(const std::string& robot_model,
                                          FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 로봇 명령을 보낸다 (수락까지만 — 완료는 핸들의 wait/get 으로 기다린다).
   *
   * 명령 완료가 PyFM step 완료이므로 flow_manager_args 는 핸들의 wait/get 에 넘긴다.
   * 반환된 핸들을 버리면 명령이 취소된다 (공식 핸들 소멸자). await 가 실행 전에 취소되면 명령은 보내지 않는다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param builder rby1.RobotCommandBuilder (공식 타입).
   * @param priority 명령 우선순위 (높을수록 우선).
   * @return RBRby1CommandHandle.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static RBRby1CommandHandle send_command(const std::string& robot_model, RBRby1CommandBuilderRef builder,
                                          int priority = 1);
  /**
   * @brief 명령 스트림을 연다 (한 연결로 명령을 연이어 보낸다).
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param priority 스트림 우선순위 (첫 명령에 실린다).
   * @return RBRby1CommandStream.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static RBRby1CommandStream create_command_stream(const std::string& robot_model, int priority = 1);
  /**
   * @brief 로봇 동역학 모델을 만든다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param urdf_model URDF 내용(경로가 아니다). 비우면 로봇에 저장된 모델(get_robot_model)을 쓴다.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return rby1.dynamics.Robot_24 / _26 / _18 (연결된 model 의 DOF, 공식 타입).
   * @throws RBY1Error 모델 조회·URDF 파싱 실패(관절 수 ≠ DOF 포함). RBY1ConnectionError 미연결.
   */
  static rby1_rt::DynamicsVar get_dynamics(const std::string& robot_model, const std::string& urdf_model = "",
                                           FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 로봇의 시리얼 장치 스트림을 연다 (장치는 반환된 스트림의 connect() 로 연다).
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param device_path 장치 경로 (get_serial_device_list 의 path).
   * @param baudrate 보드레이트.
   * @param bytesize 데이터 비트 수.
   * @param parity 패리티 ('N' / 'E' / 'O').
   * @param stopbits 스톱 비트 수.
   * @param callback callback(data: bytes) — 받은 데이터. 수신 전용 스레드에서 순서대로 불린다. None 이면 받지 않는다.
   * @return RBRby1SerialStream.
   * @throws RBY1Error 호출 실패. RBY1ConnectionError 미연결.
   */
  static RBRby1SerialStream open_serial_stream(const std::string& robot_model, const std::string& device_path,
                                               int baudrate, int bytesize = 8, char parity = 'N', int stopbits = 1,
                                               rby1_rt::SerialSink callback = nullptr);
  /**
   * @brief 로봇의 파일을 내려받는다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param path 로봇 파일 경로 (RBY1_HOME 기준 상대 경로).
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 파일 내용 (bytes).
   * @throws RBY1Error 파일 없음·로봇 에러·gRPC 실패. RBY1ConnectionError 미연결.
   */
  static RBRby1Bytes download_file(const std::string& robot_model, const std::string& path,
                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  // ── Task 11: log 스트림 · control · time sync ─────────────────────────────────────

  /**
   * @brief 로봇 로그 스트림을 시작한다 (유실 최소화 대기열).
   *
   * 콜백은 스트림 전용 스레드에서 받은 순서대로 한 번에 하나씩 불린다. 콜백이 느려도 gRPC 수신은 막히지 않고
   * 1024 batch 까지 쌓이며, 넘치면 가장 오래된 것부터 버린다 (log_stream_stats 의 dropped). 콜백이
   * awaitable(코루틴 등)을 돌려주면 등록 시점의 실행 중 이벤트 루프에서 실행하고 끝날 때까지 다음 batch 를 넘기지
   * 않는다. 코루틴 함수를 이벤트 루프 밖에서 등록하면 RuntimeError. 콜백 예외는 stderr 로 출력하고 스트림은
   * 계속된다. 같은 model 로 다시 부르면 이전 스트림을 멈추고 새로 시작한다. disconnect_robot 은 스트림을 멈춘다.
   * 콜백 안에서 stop_log_stream 을 불러도 된다. 끊김 복구는 start_state_update 와 같다 (max(10/rate, 1)초 동안
   * 수신이 없으면 다시 구독, log_stream_stats 의 resubscribes).
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param callback callback(logs) — logs 는 rby1.Log 목록 (공식 스트림 콜백 1회분).
   * @param rate 요청 수신 주기(Hz).
   * @throws RBY1Error model 불일치. RBY1ConnectionError 미연결.
   */
  static void start_log_stream(const std::string& robot_model, rby1_rt::LogSink callback, double rate);
  /**
   * @brief 로그 스트림을 멈춘다. 진행 중인 동기 콜백이 끝날 때까지 기다리고 (콜백 안에서 부르면 기다리지 않는다),
   * 진행 중인 코루틴 콜백은 취소한다. 아직 콜백에 넘기지 못한 로그는 버린다.
   * @param robot_model 로봇 model ("a" / "m" / "ub").
   * @return 동작 중이던 스트림이 있었으면 True.
   */
  static bool stop_log_stream(const std::string& robot_model);
  /**
   * @brief 로그 스트림 통계 (멈춘 뒤에도 마지막 값).
   * @param robot_model 로봇 model ("a" / "m" / "ub").
   * @return {"received": 수신 batch 수, "delivered": 콜백 호출 수, "dropped": 대기열이 넘쳐 버린 batch 수,
   * "resubscribes": 끊긴 스트림을 다시 구독한 수}.
   */
  static std::map<std::string, uint64_t> log_stream_stats(const std::string& robot_model);
  /**
   * @brief 실시간(UDP) 제어 루프를 돈다 — 콜백이 finish=True 를 돌려줄 때까지 막힌다.
   *
   * 로봇이 보내는 상태 패킷마다 callback(state) 를 부르고 돌려준 입력을 로봇에 보낸다. 콜백은 제어 루프를 도는
   * 스레드에서 불린다 (async: SDK worker 스레드, sync: 호출한 스레드) — 가볍게 유지해야 실시간성이 지켜진다.
   * 콜백 예외는 제어를 끝내고(로봇 RT 명령 취소) 그 예외를 그대로 호출자에게 던진다. async 호출을 기다리던 쪽이
   * 취소되면(Task.cancel, asyncio.wait_for 타임아웃, 루프 종료) 다음 상태 패킷에 콜백 없이 직전 입력(없으면 현재
   * 위치 유지, gain 0)을 finish=True 로 보내 로봇이 제어를 끝낸다 — 이때 flow_manager_args.done() 은 부르지 않는다.
   * sync 는 콜백의 finish 로만 끝난다. 실행 중 async control 은 SDK worker 4개 중 하나를 쓴다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param callback callback(state) -> input — state 는 rby1.Robot_A_ControlState 등, input 은 같은 model 의
   * rby1.Robot_A_ControlInput 등 (공식 타입).
   * @param port 로컬 UDP 포트. 0 이면 OS 가 고른다.
   * @param priority RT 제어 명령 우선순위.
   * @param flow_manager_args Optional PyFM step context. finish=True 로 끝나면 done() 을 호출한다.
   * @return True (finish=True 로 끝남).
   * @throws RBY1Error finish 없이 끝남(UDP bind 실패, 로봇 거부·선점·취소, 연결 끊김) 또는 호출 실패.
   * RBY1ConnectionError 미연결. 콜백이 던진 예외는 그대로.
   */
  static bool control(const std::string& robot_model, rby1_rt::ControlCallback callback, int port = 0,
                      int priority = 1, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 로봇과 시간 동기화를 한 번 한다 (Ping 왕복으로 로봇 시계 오프셋 추정 — 이후 RobotState/Log 의 timestamp
   * 가 로컬 시계 기준으로 보정된다).
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 성공하면 True.
   * @throws RBY1Error 로봇 응답에 시각이 없음 또는 호출 실패. RBY1ConnectionError 미연결.
   */
  static bool sync_time(const std::string& robot_model, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 시간 동기화가 한 번이라도 성공했는지 조회한다.
   * @param robot_model 로봇 model ("a" / "m" / "ub"). 연결된 로봇과 다르면 실패.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return 동기화됐으면 True.
   * @throws RBY1ConnectionError 미연결.
   */
  static bool has_established_time_sync(const std::string& robot_model,
                                        FlowManagerArgsPtr flow_manager_args = nullptr);
  // ── 고수준 동작 ──────────────────────

  /**
   * @brief 모션 정지 — StopCommand(whole body) 를 보내고 끝날 때까지 기다린다.
   *
   * finish_code 가 Ok 가 아니면 예외 대신 그대로 반환하고, muscat/{robot_model}/message 로 ERROR 알림
   * (``RBY1 Move Error: <code>``, 사유는 로봇 마지막 로그)을 보낸다. 정지 명령이라 await 가 취소돼도 명령은
   * 취소하지 않는다 (끝날 때까지 기다리고 done() 만 막는다).
   * @param robot_model 연결된 model ("a" / "m" / "ub").
   * @param priority 명령 우선순위. 진행 중인 명령보다 확실히 우선하려면 높게.
   * @param flow_manager_args Optional PyFM step context. 명령이 끝나면 done() 을 호출한다.
   * @return {"finished": bool, "finish_code": str}.
   * @throws RBY1ConnectionError 미연결. RBY1Error model 불일치·gRPC 실패.
   */
  static RBRby1CommandResult stop(const std::string& robot_model, int priority = 1,
                                  FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 비상 정지 — 모션 정지(priority 10) 후 무조건 전원 차단(power_off ".*"). 물리 EMO 와 별개인 SW 트리거.
   *
   * 정지가 실패해도 stderr 에 로그를 남기고 전원 차단은 반드시 시도한다 (최후 안전장치). 재개하려면 power_on +
   * servo_on + enable_control_manager 가 다시 필요하다. await 가 취소돼도 끝까지 수행한다.
   * @param robot_model 연결된 model.
   * @param flow_manager_args Optional PyFM step context. 끝나면 done() 을 호출한다.
   * @return {"stopped": bool} (power_off 결과).
   * @throws RBY1ConnectionError 미연결. RBY1Error model 불일치·전원 차단 gRPC 실패.
   */
  static RBRby1EmergencyStopResult emergency_stop(const std::string& robot_model,
                                                  FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 관절 이동 1회 — 컴포넌트별 목표 각도(deg) 로 이동하고 끝날 때까지 기다린다.
   *
   * target 의 키가 곧 명령 부위. 컨트롤 매니저는 자동 복구한다. joint_impedance 는 minimum_time 유지 후 Ok.
   * async await 가 취소되면 로봇 명령도 취소한다 (C++: rby1_rt::CancelScope::Enter).
   * @param robot_model 연결된 model.
   * @param target 컴포넌트("torso"/"right_arm"/"left_arm"/"head") → 관절값 [deg], 컴포넌트 전체 길이.
   * @param controllers 부위별 컨트롤러 (없으면 position). 팔: "position"/"joint_impedance". torso·head: "position".
   * @param minimum_time 최소 이동 시간 [s].
   * @param priority 명령 우선순위.
   * @param flow_manager_args Optional PyFM step context. 정지면 로봇을 세우고 예외, 일시정지면 세웠다가 resume 뒤 남은
   *        시간으로 재전송. 끝나면 done(). args["variable"] 이 있으면 done 전에 그 이름의 변수에 끝난 자세 저장
   *        (move_j: 부위별 관절 deg, move_l: reference 기준 pose — target 과 같은 형식).
   * @return {"finished": bool, "finish_code": str}. Ok 가 아니면 알림도 나간다.
   * @throws ValueError 빈 target, 모르는 컴포넌트, 길이 불일치, 유한수 아님, 허용 안 되는 컨트롤러.
   * @throws RBY1ConnectionError 미연결. RBY1Error model 불일치·gRPC 실패·enable 실패·smooth jog 중.
   */
  static RBRby1CommandResult move_j(const std::string& robot_model, const RBRby1JogJoints& target,
                                    const RBRby1Controllers& controllers = {}, double minimum_time = 3.0,
                                    int priority = 1, FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief Cartesian 이동 1회 — 손(ee_right/ee_left)·T5(link_torso_5) 자세로 이동하고 끝날 때까지 기다린다.
   *
   * IK 는 로봇이 푼다. 나머지 규칙은 move_j 와 같다.
   * @param robot_model 연결된 model.
   * @param target 컴포넌트("torso"/"right_arm"/"left_arm") → [x_mm, y_mm, z_mm, rx_deg, ry_deg, rz_deg]
   *        (R = Rz·Ry·Rx). torso 는 Base 기준, 손은 reference 기준.
   * @param reference "base" 또는 "link_torso_5" (손 목표의 기준 — cartesians_from_position(reference) 와 같은 좌표).
   * @param controllers 부위별 컨트롤러. 팔: "position"/"cartesian_impedance"/"impedance". torso: "position".
   * @param minimum_time 최소 이동 시간 [s].
   * @param priority 명령 우선순위.
   * @param flow_manager_args move_j 와 같다.
   * @return {"finished": bool, "finish_code": str}.
   * @throws ValueError 빈 target, 모르는 컴포넌트·키, reference 오류, 유한수 아님, 허용 안 되는 컨트롤러.
   * @throws RBY1ConnectionError 미연결. RBY1Error model 불일치·gRPC 실패·enable 실패·smooth jog 중.
   */
  static RBRby1CommandResult move_l(const std::string& robot_model, const RBRby1Cartesians& target,
                                    const std::string& reference = "base", const RBRby1Controllers& controllers = {},
                                    double minimum_time = 3.0, int priority = 1,
                                    FlowManagerArgsPtr flow_manager_args = nullptr);
  /**
   * @brief 관절 리밋 조회 (로봇 dynamics 모델). move_j 전 목표 검증용.
   * @param robot_model 연결된 model.
   * @param flow_manager_args Optional PyFM step context. 성공하면 done() 을 호출한다.
   * @return {관절명: {"position": [lo, hi] rad, "velocity": [lo, hi] rad/s, "acceleration": [lo, hi] rad/s^2,
   *         "torque": Nm}} (공식 dynamics 관절 순서).
   * @throws RBY1ConnectionError 미연결. RBY1Error model 불일치·gRPC 실패·dynamics 모델 로드 실패.
   */
  static RBRby1JointLimits get_joint_limits(const std::string& robot_model,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Approach J — move_j 와 같은 관절 이동을 시작만 하고 바로 돌아온다 (UI "이 자세로 이동" 용).
   *
   * 완료를 기다리지 않는다 (목표에 닿으면 로봇이 스스로 멈춘다). approach_stop 으로 중단한다. 진행 중 approach 가
   * 있으면 먼저 취소하고 시작한다. 로봇이 거부하면 RBY1Error (사유 포함).
   * 임피던스 컨트롤러는 유지 명령이라 허용하지 않는다 (position 만).
   * @param robot_model 연결된 model.
   * @param target move_j 와 같음.
   * @param controllers 부위별 컨트롤러 — "position" 만.
   * @param minimum_time 최소 이동 시간 [s].
   * @param priority 명령 우선순위.
   * @return True (명령을 보냈다).
   * @throws ValueError move_j 와 같음 + 임피던스 컨트롤러.
   * @throws RBY1ConnectionError 미연결. RBY1Error model 불일치·gRPC 실패·enable 실패·smooth jog 중.
   */
  static bool approach_j(const std::string& robot_model, const RBRby1JogJoints& target,
                         const RBRby1Controllers& controllers = {}, double minimum_time = 3.0, int priority = 1);
  /**
   * @brief Approach L — move_l 과 같은 Cartesian 이동을 시작만 하고 바로 돌아온다. 규칙은 approach_j 와 같다.
   * @param robot_model 연결된 model.
   * @param target move_l 과 같음.
   * @param reference "base" 또는 "link_torso_5".
   * @param controllers 부위별 컨트롤러 — "position" 만.
   * @param minimum_time 최소 이동 시간 [s].
   * @param priority 명령 우선순위.
   * @return True (명령을 보냈다).
   * @throws ValueError move_l 과 같음 + 임피던스 컨트롤러.
   * @throws RBY1ConnectionError 미연결. RBY1Error model 불일치·gRPC 실패·enable 실패·smooth jog 중.
   */
  static bool approach_l(const std::string& robot_model, const RBRby1Cartesians& target,
                         const std::string& reference = "base", const RBRby1Controllers& controllers = {},
                         double minimum_time = 3.0, int priority = 1);
  /**
   * @brief 진행 중인 approach 를 중단한다 (공식 Cancel, 끝날 때까지 최대 1.5s 대기). 없으면 아무것도 안 한다.
   * @param robot_model 연결된 model.
   * @return 중단한 approach 가 있었으면 True.
   */
  static bool approach_stop(const std::string& robot_model);
  /**
   * @brief 관절값 → 손·T5 자세 (FK). gRPC 없이 캐시된 dynamics 모델로 계산한다 (20Hz 상태 콜백용).
   * @param robot_model 연결된 model.
   * @param position 관절값 [rad], state.position 그대로.
   * @param reference "base" (기본) 또는 "link_torso_5" — move_l / smoothjog_l 의 reference 와 같은 기준.
   * @return base: {"torso": pose, "right_arm": pose, "left_arm": pose} — Base 기준 link_torso_5 / ee_right / ee_left.
   *         link_torso_5: {"right_arm": pose, "left_arm": pose} — T5 기준 손 자세 (torso 자신은 항등이라 없음).
   *         pose = [x_mm, y_mm, z_mm, rx_deg, ry_deg, rz_deg] (R = Rz·Ry·Rx).
   * @throws ValueError position 길이가 DOF 와 다름, 모르는 reference. RBY1ConnectionError 미연결. RBY1Error model
   *         불일치·모델 로드 실패.
   */
  static RBRby1Cartesians cartesians_from_position(const std::string& robot_model, const std::vector<double>& position,
                                                   const std::string& reference = "base");

  // ── Smooth jog (버튼 누르는 동안 heartbeat 로 목표를 조금씩 밀어 연속 이동) ──
  /**
   * @brief Smooth L heartbeat — 손(및 T5) Cartesian 목표를 따라 연속 이동한다.
   *
   * 버튼을 누르는 동안 약 20Hz 로 부른다. 세션이 없으면 시작하고(스트림 1개, smooth_status "start"), 호출마다
   * CartesianCommand 1개를 보낸다 (minimum_time 0.15s, hold 0.5s). 250ms 동안 heartbeat 가 없으면 스스로 정지한다.
   * target 의 키가 곧 명령에 넣는 부위. 1회 변화량은 위치 1.5mm·회전 0.35° 이하 (이전 목표 기준, 처음 오는 부위는
   * 현재 FK 기준) — 넘으면 정지 + 예외. 세션 중 L/J·reference 변경도 정지 + 예외.
   * @param robot_model 연결된 model.
   * @param target 컴포넌트("torso"/"right_arm"/"left_arm") → [x_mm, y_mm, z_mm, rx_deg, ry_deg, rz_deg]. 비어 있으면 안 된다.
   * @param reference "base" 또는 "link_torso_5".
   * @return 받아들인 목표 (target 과 같음).
   * @throws ValueError reference·키·길이 오류, 유한수 아님, 빈 target.
   * @throws RBY1ConnectionError 미연결. RBY1Error 변화량 초과·로봇 busy·컨트롤러 거부·gRPC 실패.
   */
  static RBRby1Cartesians smoothjog_l(const std::string& robot_model, const RBRby1Cartesians& target,
                                    const std::string& reference = "base");
  /**
   * @brief Smooth J heartbeat — 관절 목표를 따라 연속 이동한다. 세션·정지 규칙은 smoothjog_l 과 같다.
   *
   * 호출마다 JointPositionCommand 1개 (minimum_time 0.15s, 10°/s, 30°/s²). 1회 변화량은 관절별 0.5° 이하.
   * @param robot_model 연결된 model.
   * @param target 컴포넌트("torso"/"right_arm"/"left_arm"/"head") → 관절값 [deg], 컴포넌트 전체 길이. 비어 있으면 안 된다.
   * @return 받아들인 목표 (target 과 같음).
   * @throws ValueError 키·길이 오류, 유한수 아님, 빈 target.
   * @throws RBY1ConnectionError 미연결. RBY1Error 변화량 초과·로봇 busy·컨트롤러 거부·gRPC 실패.
   */
  static RBRby1JogJoints smoothjog_j(const std::string& robot_model, const RBRby1JogJoints& target);
  /**
   * @brief Smooth jog 정지 (L/J 공용). 스트림 취소 → cancel_control → Idle 대기(최대 1.5s) → smooth_status "stop".
   * @param robot_model 연결된 model.
   * @param reason 로그용 정지 사유.
   * @return 정지한 세션이 있었으면 True.
   */
  static bool smoothjog_stop(const std::string& robot_model, const std::string& reason = "user");
  /**
   * @brief Smooth jog 상태 — "start"(정지 처리 중 포함) 또는 "stop".
   * @param robot_model 연결된 model.
   * @return "start" 또는 "stop".
   */
  static std::string smooth_status(const std::string& robot_model);

 private:
  friend void rby1_publish_move_error(const std::string& robot_model, const std::string& finish_code,
                                      const std::string& detail);
};
