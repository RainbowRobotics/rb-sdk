#pragma once
// RB-Y1 런타임: 프로세스 전역 상태 (연결·스레드·스트림). RBRby1SDK 인스턴스는 얇은 핸들.
#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <stdexcept>
#include <string>
#include <thread>
#include <utility>
#include <variant>
#include <vector>

#include "rby1-sdk/model.h"
#include "rby1-sdk/robot.h"

#include "rb_sdk_api.hpp"

namespace rby1_rt {

// 로봇이 명령을 거부(false)했거나 gRPC 호출이 실패했다.
struct RB_SDK_API Rby1Error : std::runtime_error {
  using std::runtime_error::runtime_error;
};
// connect() 전이거나 연결이 끊겼다.
struct RB_SDK_API Rby1ConnectionError : Rby1Error {
  using Rby1Error::Rby1Error;
};

// async 호출 하나의 취소 범위. await 취소 시 cancel(), 메서드는 명령을 보낸 뒤 set_canceller. 순서 무관.
class CancelScope {
 public:
  void cancel() {
    std::function<void()> c;
    {
      std::lock_guard<std::mutex> lk(mu_);
      cancelled_ = true;
      c = canceller_;
    }
    if (c)
      c();
  }
  // 이미 취소됐으면 곧바로 부른다. 빈 함수 = 해제.
  void set_canceller(std::function<void()> c) {
    bool now = false;
    {
      std::lock_guard<std::mutex> lk(mu_);
      canceller_ = c;
      now = cancelled_ && c;
    }
    if (now)
      c();
  }
  bool cancelled() const {
    std::lock_guard<std::mutex> lk(mu_);
    return cancelled_;
  }

  // 이 스레드의 현재 취소 범위 (없으면 nullptr). move_j/move_l/control 이 쓴다.
  // C++ 에서 취소하려면 scope 를 Enter 한 채 부르고 다른 스레드에서 scope->cancel().
  static const std::shared_ptr<CancelScope>& current() { return tl_current_; }
  class Enter {
   public:
    explicit Enter(std::shared_ptr<CancelScope> s) : prev_(std::exchange(tl_current_, std::move(s))) {}
    ~Enter() { tl_current_ = std::move(prev_); }
    Enter(const Enter&) = delete;
    Enter& operator=(const Enter&) = delete;

   private:
    std::shared_ptr<CancelScope> prev_;
  };

 private:
  mutable std::mutex mu_;
  bool cancelled_ = false;
  std::function<void()> canceller_;
  static inline thread_local std::shared_ptr<CancelScope> tl_current_;
};
using CancelScopePtr = std::shared_ptr<CancelScope>;

// 고정 4스레드 worker pool (async 호출의 gRPC 대기).
class WorkerPool {
 public:
  static constexpr int kWorkers = 4;
  static WorkerPool& instance();
  void set_on_thread_start(std::function<void()> fn);  // 첫 submit 전에만 유효
  void submit(std::function<void()> job);
  // atexit: 시작 안 한 job 은 돌려준다 (파괴는 호출자가 GIL 하에서).
  std::deque<std::function<void()>> shutdown();

 private:
  void ensure_started_locked();
  std::mutex mu_;
  std::condition_variable cv_;
  std::deque<std::function<void()>> q_;
  std::vector<std::thread> threads_;
  std::function<void()> on_thread_start_;
  bool stopping_ = false;
  friend struct ForkHandlers;
};

using RobotA = rb::Robot<rb::y1_model::A>;
using RobotM = rb::Robot<rb::y1_model::M>;
using RobotUB = rb::Robot<rb::y1_model::UB>;
using RobotPtr = std::variant<std::shared_ptr<RobotA>, std::shared_ptr<RobotM>, std::shared_ptr<RobotUB>>;
using RobotStateVar = std::variant<rb::RobotState<rb::y1_model::A>, rb::RobotState<rb::y1_model::M>,
                                   rb::RobotState<rb::y1_model::UB>>;
using DynamicsVar = std::variant<std::shared_ptr<rb::dyn::Robot<rb::y1_model::A::kRobotDOF>>,
                                 std::shared_ptr<rb::dyn::Robot<rb::y1_model::M::kRobotDOF>>,
                                 std::shared_ptr<rb::dyn::Robot<rb::y1_model::UB::kRobotDOF>>>;
// 공식은 unique_ptr — 조작 중에도 살아 있게 shared_ptr.
using CommandHandlerVar = std::variant<std::shared_ptr<rb::RobotCommandHandler<rb::y1_model::A>>,
                                       std::shared_ptr<rb::RobotCommandHandler<rb::y1_model::M>>,
                                       std::shared_ptr<rb::RobotCommandHandler<rb::y1_model::UB>>>;
using CommandStreamVar = std::variant<std::shared_ptr<rb::RobotCommandStreamHandler<rb::y1_model::A>>,
                                      std::shared_ptr<rb::RobotCommandStreamHandler<rb::y1_model::M>>,
                                      std::shared_ptr<rb::RobotCommandStreamHandler<rb::y1_model::UB>>>;
using ControlStateVar = std::variant<rb::ControlState<rb::y1_model::A>, rb::ControlState<rb::y1_model::M>,
                                     rb::ControlState<rb::y1_model::UB>>;
using ControlInputVar = std::variant<rb::ControlInput<rb::y1_model::A>, rb::ControlInput<rb::y1_model::M>,
                                     rb::ControlInput<rb::y1_model::UB>>;
using ControlCallback = std::function<ControlInputVar(const ControlStateVar&)>;
template <typename T>
T model_of(const rb::Robot<T>&);
template <typename T>
rb::ControlInput<T> control_input_of(const rb::ControlState<T>&);

// put 은 막히지 않는다 — 가득 차면 가장 오래된 값을 버린다. capacity 1 = latest-only.
template <typename T>
class BoundedSlot {
 public:
  explicit BoundedSlot(size_t capacity = 1) : capacity_(capacity) {}
  void put(T v) {
    {
      std::lock_guard<std::mutex> lk(mu_);
      if (closed_)
        return;
      if (q_.size() >= capacity_) {
        q_.pop_front();
        ++dropped_;
      }
      q_.push_back(std::move(v));
      ++received_;
    }
    cv_.notify_one();
  }
  // close 되면 nullopt. idle 동안 값이 없으면 nullopt + *idled = true.
  std::optional<T> take(std::optional<std::chrono::milliseconds> idle = std::nullopt, bool* idled = nullptr) {
    std::unique_lock<std::mutex> lk(mu_);
    const auto ready = [this] { return closed_ || !q_.empty(); };
    if (!idle) {
      cv_.wait(lk, ready);
    } else if (!cv_.wait_for(lk, *idle, ready)) {
      *idled = true;
      return std::nullopt;
    }
    if (closed_)
      return std::nullopt;
    std::optional<T> v(std::move(q_.front()));
    q_.pop_front();
    return v;
  }
  void close() {
    {
      std::lock_guard<std::mutex> lk(mu_);
      closed_ = true;
      q_.clear();
    }
    cv_.notify_all();
  }
  // done() 이 참이 되거나 close 될 때까지 대기 (done 을 바꾼 쪽이 notify). close 면 false.
  bool wait_until(const std::function<bool()>& done) {
    std::unique_lock<std::mutex> lk(mu_);
    cv_.wait(lk, [&] { return closed_ || done(); });
    return done();
  }
  void notify() {
    { std::lock_guard<std::mutex> lk(mu_); }
    cv_.notify_all();
  }
  uint64_t received() const {
    std::lock_guard<std::mutex> lk(mu_);
    return received_;
  }
  uint64_t dropped() const {
    std::lock_guard<std::mutex> lk(mu_);
    return dropped_;
  }

 private:
  const size_t capacity_;
  mutable std::mutex mu_;
  std::condition_variable cv_;
  std::deque<T> q_;
  bool closed_ = false;
  uint64_t received_ = 0;
  uint64_t dropped_ = 0;
};

struct StreamStats {
  uint64_t received = 0;
  uint64_t delivered = 0;
  uint64_t dropped = 0;
  uint64_t resubscribes = 0;
};

// 스트림 생존 감시. 공식 reader 는 스트림이 끝나도 알리지 않아 "stale 동안 무수신" 으로 판단하고 재구독한다
// (간격 stale → 4×stale 백오프, 로그는 사건당 1번).
struct StreamLiveness {
  std::string name;
  std::chrono::milliseconds stale;
  // 재구독했으면 true. 이미 멈췄거나 교체됐으면 false.
  std::function<bool(const void* slot_id)> resubscribe;
};

// 스트림 스레드 훅 (바인딩이 tstate 준비/정리를 꽂는다).
struct StreamThreadHooks {
  static void set(std::function<void()> on_start, std::function<void()> on_exit);
  static void on_start();
  static void on_exit();
};

class StreamThread {
 public:
  virtual ~StreamThread() = default;
  virtual void close() = 0;
  virtual void join() = 0;
  virtual StreamStats stats() const = 0;
  virtual const void* slot_id() const = 0;
};

// 전용 스레드 1개: slot.take() → sink(value, slot) 반복. sink 는 이 스레드에서만 불린다.
// stale 은 sink 가 끝난 뒤부터 잰다 (느린 콜백은 끊김이 아니다).
template <typename T>
class StreamWorker final : public StreamThread {
 public:
  using Slot = BoundedSlot<T>;
  using Sink = std::function<void(const T&, const std::shared_ptr<Slot>&)>;

  explicit StreamWorker(Sink sink, size_t capacity = 1, std::optional<StreamLiveness> live = std::nullopt)
      : slot_(std::make_shared<Slot>(capacity)) {
    th_ = std::thread([slot = slot_, delivered = delivered_, resubscribes = resubscribes_, sink = std::move(sink),
                       live = std::move(live)]() mutable {
      StreamThreadHooks::on_start();
      Sink fn = std::move(sink);
      int misses = 0;
      for (;;) {
        bool idled = false;
        std::optional<T> v;
        if (live)
          v = slot->take(live->stale * (1 << std::min(misses, 2)), &idled);
        else
          v = slot->take();
        if (idled) {
          if (misses == 0)
            std::fprintf(stderr, "rby1 %s: no data for %.1fs — resubscribing (retrying with backoff)\n",
                         live->name.c_str(), live->stale.count() / 1000.0);
          if (live->resubscribe(slot.get())) {
            ++misses;
            resubscribes->fetch_add(1, std::memory_order_relaxed);
          }
          continue;
        }
        if (!v)
          break;
        if (misses > 0) {
          std::fprintf(stderr, "rby1 %s: resumed after %d resubscribe(s)\n", live->name.c_str(), misses);
          misses = 0;
        }
        fn(*v, slot);
        delivered->fetch_add(1, std::memory_order_relaxed);
      }
      fn = nullptr;  // exit 훅 전에 해제
      StreamThreadHooks::on_exit();
    });
  }
  StreamWorker(const StreamWorker&) = delete;
  StreamWorker& operator=(const StreamWorker&) = delete;
  ~StreamWorker() override {
    slot_->close();
    if (th_.joinable())
      th_.detach();
  }
  std::shared_ptr<Slot> slot() const { return slot_; }
  void close() override { slot_->close(); }
  // 락 없이. sink 안에서 부르면 detach.
  void join() override {
    if (!th_.joinable())
      return;
    if (th_.get_id() == std::this_thread::get_id())
      th_.detach();  // 자기 join 은 데드락
    else
      th_.join();
  }
  StreamStats stats() const override {
    return {slot_->received(), delivered_->load(std::memory_order_relaxed), slot_->dropped(),
            resubscribes_->load(std::memory_order_relaxed)};
  }
  const void* slot_id() const override { return slot_.get(); }

 private:
  std::shared_ptr<Slot> slot_;
  std::shared_ptr<std::atomic<uint64_t>> delivered_ = std::make_shared<std::atomic<uint64_t>>(0);
  std::shared_ptr<std::atomic<uint64_t>> resubscribes_ = std::make_shared<std::atomic<uint64_t>>(0);
  std::thread th_;
};

// 상태 스트림 한 샘플 (state + control_manager_state).
struct StateSample {
  RobotStateVar state;
  rb::ControlManagerState control_manager_state;
};
using StateWorker = StreamWorker<StateSample>;  // latest-only
using StateSlot = StateWorker::Slot;
using StateSink = StateWorker::Sink;
using LogBatch = std::vector<rb::Log>;
using LogWorker = StreamWorker<LogBatch>;
using LogSink = LogWorker::Sink;
inline constexpr size_t kLogStreamQueue = 1024;
using SerialReader = StreamWorker<std::string>;
using SerialSink = SerialReader::Sink;
inline constexpr size_t kSerialReadQueue = 1024;

class Hub {
 public:
  static Hub& instance();
  // 반환: 연결된 model ("a"/"m"/"ub"). model 을 주면 불일치 시 Rby1ConnectionError.
  std::string connect(const std::string& endpoint, const std::optional<std::string>& model, int max_retries,
                      int timeout_ms);
  bool disconnect();
  std::optional<std::string> model() const;
  std::string endpoint() const;
  bool is_connected() const;
  RobotPtr robot(const std::string& robot_model) const;

  // 스트림은 종류·model 당 1개. 재시작이면 이전 것을 멈춘다. 끊기면 스스로 재구독 (채널 재연결은 gRPC 가).
  enum class StreamKind { State, Log };
  void start_state_update(const std::string& robot_model, double rate, StateSink sink);
  void start_log_stream(const std::string& robot_model, double rate, LogSink sink);
  bool stop_stream(StreamKind kind, const std::string& robot_model);
  void stop_all_streams();
  StreamStats stream_stats(StreamKind kind, const std::string& robot_model) const;

 private:
  struct Stream {
    std::optional<RobotPtr> robot;  // 동작 중일 때만
    std::shared_ptr<StreamThread> worker;
    std::function<void(const RobotPtr&)> begin;
  };
  using StreamKey = std::pair<StreamKind, std::string>;
  StreamLiveness liveness(StreamKind kind, const std::string& robot_model, double rate);
  bool resubscribe(StreamKind kind, const std::string& model, const void* slot_id);
  void start_stream(StreamKind kind, const std::string& robot_model, std::shared_ptr<StreamThread> worker,
                    std::function<void(const RobotPtr&)> begin);
  std::shared_ptr<StreamThread> stop_locked(StreamKind kind, Stream& s);
  std::vector<std::shared_ptr<StreamThread>> close_all_streams();
  std::vector<std::shared_ptr<StreamThread>> disconnect_locked(bool& had);

  // 잠금 순서: connect_mu_ → stream_mu_ → mu_. 락을 쥔 채 GIL·join 을 기다리지 않는다.
  std::mutex connect_mu_;
  mutable std::mutex stream_mu_;
  std::map<StreamKey, Stream> streams_;
  mutable std::mutex mu_;
  std::string endpoint_ = "127.0.0.1:50051";
  std::optional<std::string> model_;
  std::optional<RobotPtr> robot_;
  // fork 자식에서 버릴 HandleSlot 들
  std::map<const void*, std::function<void()>> handles_;
  friend struct ForkHandlers;
  template <typename H>
  friend class HandleSlot;
};

// fork 자식에서 smooth jog·approach 세션을 새로 만든다.
void jog_after_fork_child();

// 공식 핸들(SendCommand / CreateCommandStream / OpenSerialStream 결과)과 그걸 만든 로봇의 소유자. Hub::mu_ 하에서만
// 꺼내고 비운다 — fork 자식은 소멸자 없이 버린다 (버려진 슬롯 조작은 Rby1ConnectionError).
template <typename H>
class HandleSlot {
 public:
  HandleSlot(RobotPtr robot, H h) : robot_(std::move(robot)), h_(std::move(h)) {
    Hub& hub = Hub::instance();
    std::lock_guard<std::mutex> lk(hub.mu_);
    hub.handles_[this] = [this] { abandon_locked(); };
  }
  HandleSlot(const HandleSlot&) = delete;
  HandleSlot& operator=(const HandleSlot&) = delete;
  // 파괴(공식 Cancel + 완료 대기)는 락 밖에서.
  ~HandleSlot() {
    std::optional<RobotPtr> robot;
    std::optional<H> h;  // robot 보다 먼저 파괴
    {
      Hub& hub = Hub::instance();
      std::lock_guard<std::mutex> lk(hub.mu_);
      hub.handles_.erase(this);
      robot.swap(robot_);
      h.swap(h_);
    }
  }
  H get() const {
    std::lock_guard<std::mutex> lk(Hub::instance().mu_);
    return get_locked();
  }
  // 버려졌으면 nullopt (cancel 용)
  std::optional<H> peek() const {
    std::lock_guard<std::mutex> lk(Hub::instance().mu_);
    return h_;
  }
  // 새로 보내는 조작용: 핸들의 연결이 지금 Hub 연결이어야 한다.
  H get_current() const {
    Hub& hub = Hub::instance();
    std::lock_guard<std::mutex> lk(hub.mu_);
    H h = get_locked();
    if (!hub.robot_ || !(*hub.robot_ == *robot_))
      throw Rby1ConnectionError("the robot connection this handle was created on is closed (disconnect_robot / "
                                "connect_robot since)");
    return h;
  }

 private:
  H get_locked() const {
    if (!h_)
      throw Rby1ConnectionError("rby1 handle belongs to the parent process (created before fork) — not usable here");
    return *h_;
  }
  // fork 자식에서만: 소멸자 없이 버린다
  void abandon_locked() {
    if (h_)
      new std::pair<RobotPtr, H>(std::move(*robot_), std::move(*h_));
    robot_.reset();
    h_.reset();
  }

  std::optional<RobotPtr> robot_;
  std::optional<H> h_;
};

// OpenSerialStream 결과 + 수신 스레드. stream 이 먼저 파괴된다 (선언 역순).
struct SerialHandle {
  std::shared_ptr<SerialReader> reader;
  std::shared_ptr<rb::SerialStream> stream;
};

template <typename F>
decltype(auto) visit_robot(const RobotPtr& p, F&& f) {
  return std::visit([&](auto& sp) -> decltype(auto) { return f(sp); }, p);
}

}  // namespace rby1_rt
