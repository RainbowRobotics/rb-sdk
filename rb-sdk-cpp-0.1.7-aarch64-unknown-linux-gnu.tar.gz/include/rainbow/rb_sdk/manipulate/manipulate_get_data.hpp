#pragma once

#include <map>
#include <tuple>
#include <utility>

#include "base.hpp"
#include "rb_sdk_api.hpp"
#include "common_struct_generated.h"
#include "func_config_generated.h"
#include "func_get_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "state_core_generated.h"

using Response_get_core_data_variant = std::optional<std::variant<float, std::vector<float>, std::string>>;
// get_core_function 의 Func_Value union (Val_Number / Val_String / Val_Number_Arr / Val_String_Arr).
// pybind 는 이 순서로 변환을 시도하므로 Python int/float → float, list[int|float] → vector<float>.
using Func_value_variant = std::variant<float, std::string, std::vector<float>, std::vector<std::string>>;
// (func, positional args, keyword args) — get_core_function 의 Func_Call 하나
using Func_call = std::tuple<std::string, std::vector<Func_value_variant>, std::map<std::string, Func_value_variant>>;
// (error message, return) — error 가 비어있지 않으면 그 항목은 실패 (message = core 의 execution_error_msg
// 또는 "RB.<func> failed (execution_result=N)")
using Func_call_result = std::pair<std::string, std::optional<Func_value_variant>>;

class RB_SDK_API RBManipulateGetDataSDK : public RBBaseSDK {
 public:
  RBManipulateGetDataSDK() {}

  static std::string type_name() { return "RBManipulateGetDataSDK"; }

  /**
   * @brief Computes the coordinate a relative move would resolve to.
   *
   * Given @p reference_value as the starting point, computes the absolute
   * target that moving by @p relative_value from it resolves to. Used
   * internally by the move-family functions' relative-move calculation
   * (e.g. @c call_move_j / @c call_move_l).
   *
   * @p relative_value and @p reference_value do not need the same
   * tar_frame: if one is Joint Space (tar_frame -1) and the other isn't,
   * the robot converts one to match the other (forward/inverse kinematics)
   * before combining them, then converts the combined result again if
   * needed to match @p move_type. This conversion can itself fail (e.g. an
   * unreachable target), which surfaces as a nonzero calculated_result.
   *
   * @param robot_model Name of the robot model.
   * @param relative_value Relative offset target and frame information.
   *        tar_values must have exactly 7 elements — this SDK passes it
   *        through unmodified, so callers must pad to 7 themselves (e.g.
   *        with 0 for a 6-axis model's unused ArmAngle slot).
   * @param reference_value Reference target and frame information.
   *        tar_values must resolve to exactly 7 elements after this SDK
   *        truncates it to at most 7 — supplying fewer than 7 will not be
   *        padded and will fail the same way as an oversized/undersized
   *        @p relative_value.
   * @param move_type 0 for the move-J family (joint-space), 1 for the
   *        move-L family (Cartesian-space).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_Get_Relative_ValueT with calculated_result (0 on
   *         success) and calculated_value (the computed absolute target).
   *         If either tar_values doesn't resolve to exactly 7 elements,
   *         the robot rejects the request before any calculation runs:
   *         calculated_result is nonzero and calculated_value is left
   *         unset.
   *
   * @note This function does not throw on calculation failure —
   *       calculated_result nonzero must be checked by the caller (as the
   *       move-family functions do).
   *
   * @throws std::runtime_error If the query itself fails (e.g. no reply).
   */
  IPC::Response_Get_Relative_ValueT get_relative_value(const std::string& robot_model,
                                                       const IPC::MoveInput_TargetT& relative_value,
                                                       const IPC::MoveInput_TargetT& reference_value, int move_type,
                                                       FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Looks up a named runtime variable/system value on the robot.
   *
   * @param robot_model Name of the robot model.
   * @param name Variable name to query.
   *
   * @return The variable's value as a float, a list of floats, or a
   *         string, depending on its reported type; std::nullopt if the
   *         response is invalid or the response's type doesn't match any
   *         of those. This matches the Python original.
   *
   * @throws std::runtime_error If the query itself fails (e.g. no reply).
   */
  Response_get_core_data_variant get_variable(const std::string& robot_model, const std::string& name);

  /**
   * @brief Reads several core variables in a single query.
   *
   * Same as calling @c get_variable once per name, but sends one
   * @c get_core_data_multi query instead of one query per name, so the
   * values also come from the same moment in time.
   *
   * @param robot_model Name of the robot model.
   * @param names Variable names to read.
   *
   * @return A map from variable name to its value (a float, a list of
   *         floats, or a string, depending on its reported type). A name
   *         the robot reports as invalid maps to std::nullopt, and a name
   *         missing from the response is absent from the map.
   *
   * @throws std::runtime_error If the query itself fails. A robot whose
   *         core does not serve @c get_core_data_multi answers nothing,
   *         which surfaces as rb_zenoh::ZenohNoReply; fall back to
   *         @c get_variable per name in that case.
   */
  std::map<std::string, Response_get_core_data_variant> get_variables(const std::string& robot_model,
                                                                      const std::vector<std::string>& names);

  /**
   * @brief Calls a core-side function by name (PyFM @c RB.func(...)).
   *
   * Sends one @c Func_Call in a @c get_core_function query. Positional
   * @p args and keyword @p kwargs are encoded as @c Func_Arg entries
   * (a keyword argument carries its name in @c arg_name).
   *
   * @param robot_model Name of the robot model.
   * @param func Core function name, e.g. @c "sum".
   * @param args Positional arguments: each a float, a string, a list of
   *        floats, or a list of strings.
   * @param kwargs Keyword arguments with the same value types.
   *
   * @return The function's return value (a float, a string, a list of
   *         floats, or a list of strings), or std::nullopt when the core
   *         returns no value.
   *
   * @throws std::runtime_error If the core reports a nonzero
   *         execution_result. The message is the core's
   *         execution_error_msg when it gives one, otherwise the function
   *         name and the result code (-1 unknown function, -2 argument
   *         count/type mismatch, -3 exception inside the function). Also
   *         thrown when the query itself fails (e.g. no reply) or the reply
   *         carries no @c Func_Return.
   */
  std::optional<Func_value_variant> call_function(const std::string& robot_model, const std::string& func,
                                                  const std::vector<Func_value_variant>& args = {},
                                                  const std::map<std::string, Func_value_variant>& kwargs = {});

  /**
   * @brief Calls several core-side functions in one @c get_core_function query.
   *
   * Each entry of @p calls becomes one @c Func_Call item; the core runs them
   * independently and in order. Unlike @c call_function this never throws
   * for a core-reported failure: the failure is returned per item so the
   * caller can raise it at the point where that value is used (PyFM batches
   * every @c RB.func(...) of one expression this way).
   *
   * @param robot_model Name of the robot model.
   * @param calls (func, args, kwargs) per call, same value types as
   *        @c call_function.
   *
   * @return One (error, value) per call, in call order. @c error is empty
   *         on success, otherwise the message @c call_function would have
   *         thrown (the core's execution_error_msg, or the function name
   *         with the result code), and @c value is the return value or
   *         std::nullopt.
   *
   * @throws std::runtime_error If the query itself fails (e.g. no reply).
   */
  std::vector<Func_call_result> call_functions(const std::string& robot_model, const std::vector<Func_call>& calls);

  /**
   * @brief Computes the absolute coordinate a reference target resolves to.
   *
   * Used internally for absolute (non-relative) target resolution, e.g. by
   * @c set_pin_point_or_joint when no reference_target offset is given.
   * @p reference_value's tar_frame does not need to match @p move_type:
   * the robot always converts it (forward/inverse kinematics as needed) to
   * the frame matching @p move_type. This conversion can itself fail (e.g.
   * an unreachable target), which surfaces as a nonzero calculated_result.
   *
   * @param robot_model Name of the robot model.
   * @param reference_value Reference target and frame information.
   *        tar_values must resolve to exactly 7 elements — this SDK
   *        truncates it to at most 7, so supplying fewer than 7 will not
   *        be padded and the request will be rejected.
   * @param move_type 0 for the move-J / pin-joint family (joint-space), 1
   *        for the move-L / pin-point family (Cartesian-space).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_Get_Absolute_ValueT with calculated_result (0 on
   *         success) and calculated_value (the computed absolute target).
   *         If tar_values doesn't resolve to exactly 7 elements, the robot
   *         rejects the request before any calculation runs:
   *         calculated_result is nonzero and calculated_value is left
   *         unset.
   *
   * @note This function does not throw on calculation failure —
   *       calculated_result nonzero must be checked by the caller.
   *
   * @throws std::runtime_error If the query itself fails (e.g. no reply).
   */
  IPC::Response_Get_Absolute_ValueT get_absolute_value(const std::string& robot_model,
                                                       const IPC::MoveInput_TargetT& reference_value, int move_type,
                                                       FlowManagerArgsPtr flow_manager_args = nullptr);
};
