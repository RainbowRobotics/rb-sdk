#pragma once

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <memory>
#include <mutex>
#include <nlohmann/json.hpp>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#include "rb_sdk_api.hpp"

#include "binding/glue/gil_release.hpp"
#include "flow_manager_args.hpp"
#include "zenoh_client.hpp"
#include "zenoh_core.hpp"
#include "zenoh_exception.hpp"

#include "common_struct_generated.h"
#include "host_pcan_generated.h"

#include "mechmind/mechmind_client.hpp"
#include "photoneo/photoneo_client.hpp"
#include "photoneo/exceptions.hpp"
#include "pickit3d/pickit_client.hpp"

/**
 * @brief SDK service family selector used by legacy construction paths.
 */
enum class ServerType { AMR, MANIPULATE };

/**
 * @brief Zenoh congestion-control values used by publish().
 */
enum class CongestionControl : int {
  DROP = 0,
  BLOCK = 1,
  DROP_LATEST = 2,  // same as BLOCK in practice
};

/**
 * @brief Zenoh priority values used by publish().
 */
enum class Priority : int {
  REAL_TIME = 1,
  INTERACTIVE_HIGH = 2,
  INTERACTIVE_LOW = 3,
  DATA_HIGH = 4,
  DATA = 5,
  DATA_LOW = 6,
  BACKGROUND = 7,
};

/**
 * @brief Move-type string constants shared by manipulate program/point helpers.
 */
struct MoveType {
  inline static constexpr std::string_view J = "J";
  inline static constexpr std::string_view L = "L";
  inline static constexpr std::string_view JB = "JB";
  inline static constexpr std::string_view LB = "LB";
  inline static constexpr std::string_view XB = "XB";
};

/**
 * @brief Options for connecting this SDK process as a remote zenoh peer.
 */
struct ConnectOptions {
  /** Bearer token used when registering with the common service. */
  std::string token;
  /** Hostname or IP address of the common service. */
  std::string host;

  /** Optional local zenoh listen port; a free port is chosen when omitted. */
  std::optional<int> zenoh_port;

  /** Peer registration TTL in seconds. */
  int ttl = 5;

  /** Optional heartbeat interval in seconds. Defaults to ttl / 2, with a lower bound of 1s. */
  std::optional<double> heartbeat;
  /** Optional maximum time to wait for the zenoh echo mesh check. */
  std::optional<double> mesh_timeout;

  /** Per-probe timeout for zenoh echo checks. */
  double mesh_probe_timeout = 1.0;
  /** Delay between zenoh echo probes. */
  double mesh_probe_interval = 0.5;
};

/**
 * @brief Owns vendor vision clients keyed by module_name.
 */
template <typename ClientT, typename ConfigT>
class VisionClientRegistry {
 public:
  /**
   * @brief Returns the client currently registered for @p module_name.
   *
   * @return Pointer to the owned client, or nullptr when no client is registered.
   */
  ClientT* get(const std::string& module_name) {
    auto it = clients_.find(module_name);
    return it == clients_.end() ? nullptr : it->second.get();
  }

  /**
   * @brief Replaces the client for @p module_name and connects the new one.
   *
   * If an existing connected client is present for the same module, it is
   * disconnected before the replacement is stored.
   *
   * @return Reference to the connected client owned by this registry.
   *
   * @throws std::exception Propagates errors thrown by the vendor client's
   *         constructor or connect().
   */
  ClientT& connect(const std::string& module_name, const ConfigT& config) {
    auto it = clients_.find(module_name);
    if (it != clients_.end() && it->second->is_connected())
      it->second->disconnect();

    auto client = std::make_unique<ClientT>(config);
    client->connect();
    ClientT& ref = *client;
    clients_[module_name] = std::move(client);
    return ref;
  }

  /**
   * @brief Disconnects all connected clients owned by this registry.
   *
   * Individual disconnect errors are logged and swallowed so SDK cleanup can continue.
   */
  void disconnect_all() {
    for (auto& [module_name, client] : clients_) {
      try {
        if (client && client->is_connected())
          client->disconnect();
      } catch (const std::exception& e) {
        std::cerr << "[VisionClientRegistry] disconnect failed: module=" << module_name << ", err=" << e.what()
                  << std::endl;
      }
    }
  }

 private:
  std::unordered_map<std::string, std::unique_ptr<ClientT>> clients_;
};

/**
 * @brief Common SDK base for zenoh transport, lifecycle, logging, and shared helpers.
 */
class RB_SDK_API RBBaseSDK {
 public:
  /**
   * @brief Returns a process-local singleton base SDK instance.
   */
  static RBBaseSDK& instance();

  RBBaseSDK(const RBBaseSDK&) = delete;
  RBBaseSDK& operator=(const RBBaseSDK&) = delete;

  RBBaseSDK(RBBaseSDK&&) = delete;
  RBBaseSDK& operator=(RBBaseSDK&&) = delete;

 protected:
  RB_SDK_LOCAL static int pid_;

  static std::shared_ptr<rb_zenoh::ZenohClient> zenoh_client_;

  static std::recursive_mutex lock_;

  static std::mutex mutex_;

  RB_SDK_LOCAL static std::optional<std::string> peer_id_;

  RB_SDK_LOCAL static std::optional<std::string> peer_common_url_;

  RB_SDK_LOCAL static std::optional<std::string> peer_token_;

  RB_SDK_LOCAL static std::thread heartbeat_thread_;

  RB_SDK_LOCAL static std::atomic<bool> heartbeat_stop_;

  bool instance_closed_ = false;

  std::string sender = "";

  std::optional<std::string> name;

  std::unordered_set<std::string> zenoh_queryables;

  std::unordered_set<std::string> zenoh_subscribes;

  std::string SERVICE;

  bool IS_DEV = false;

 public:
  /**
   * @brief Creates an SDK instance and ensures the shared zenoh session exists.
   *
   * @param server Legacy service selector. Currently accepted for API
   *        compatibility and not used by the C++ implementation.
   * @param use_directly Legacy construction flag. Currently accepted for API
   *        compatibility and not used by the C++ implementation.
   */
  RBBaseSDK(std::optional<ServerType> server = std::nullopt, bool use_directly = false);

  /**
   * @brief Closes this SDK instance. Virtual so derived SDKs can be deleted through RBBaseSDK*.
   */
  virtual ~RBBaseSDK();

  /**
   * @brief Registers this process as a remote zenoh peer through the common service.
   *
   * If @p options.host resolves to the local machine, no peer is registered
   * and std::nullopt is returned. If a peer is already registered, returns
   * the existing peer id.
   *
   * @param options Remote peer registration and heartbeat options.
   *
   * @return Registered peer id, or std::nullopt when registration is skipped
   *         or the mesh echo check fails.
   *
   * @throws std::runtime_error If local IP/port detection, HTTP
   *         registration, or zenoh reconnection fails.
   */
  std::optional<std::string> connect(const ConnectOptions& options);

  /**
   * @brief Declares a raw zenoh subscriber.
   *
   * @param topic Zenoh key expression to subscribe to.
   * @param callback Callback invoked with raw samples.
   * @param opts Zenoh subscription options.
   *
   * @return Subscriber id that can be passed to zenoh_unsubscribe().
   *
   * @throws std::exception Propagates errors from ZenohClient::declare_subscriber().
   */
  int zenoh_subscribe(const std::string& topic, rb_zenoh::SubCallback callback,
                      rb_zenoh::CppSubscribeOptions opts = {});

  /**
   * @brief Undeclares one subscriber id returned by zenoh_subscribe().
   */
  RB_SDK_LOCAL void zenoh_unsubscribe(int sub_id);

  /**
   * @brief Declares a FlatBuffer-decoding zenoh subscriber.
   *
   * @param topic Zenoh key expression to subscribe to.
   * @param callback Callback invoked with the decoded native table.
   * @param opts Zenoh subscription options.
   *
   * @return Subscriber id, or -1 if declaration fails.
   */
  template <typename FBSType>
  int zenoh_subscribe(
      const std::string& topic,
      std::function<void(const std::string&, std::unique_ptr<typename FBSType::NativeTableType>, const std::string&)>
          callback,
      rb_zenoh::CppSubscribeOptions opts = {}) {
    _gil_release_if_held _g;
    std::lock_guard<std::mutex> guard(mutex_);
    try {
      int sub_id_ = RBBaseSDK::zenoh_client_->declare_subscriber<FBSType>(topic, callback, opts);
      zenoh_subscribes.insert(topic);

      return sub_id_;
    } catch (const std::exception& e) {
      std::cout << "error at zenoh_subscribe()" << std::endl;
      std::cerr << e.what() << '\n';
    }

    // Subscribe failed; -1 means no valid subscriber id.
    return -1;
  }

  /**
   * @brief Declares a zenoh queryable for raw request/reply handling.
   *
   * Duplicate declarations for the same topic on this SDK instance are ignored.
   *
   * @param topic Zenoh key expression to serve.
   * @param handler Query handler invoked by ZenohClient.
   */
  void zenoh_queryable(const std::string& topic, rb_zenoh::QueryHandler handler);

  /**
   * @brief Registers externally declared zenoh resources for cleanup by close().
   */
  void register_zenoh_subscriber(const std::string& topic);
  void register_zenoh_queryable(const std::string& topic);

  /**
   * @brief Unregisters this process from the remote peer mesh and closes its shared zenoh session.
   *
   * @return true when a peer was registered and disconnected; false when no
   *         peer registration was active.
   */
  bool disconnect();

  /**
   * @brief Optional cleanup hook called by close() before shared resources are released.
   */
  virtual void before_close();

  /**
   * @brief Releases this instance's resources and closes the shared session when it is the last SDK.
   */
  void close();

  /**
   * @brief Closes every live SDK instance in the current process.
   */
  static int close_all_for_pid();

  /**
   * @brief Runs a zenoh call and retries it once after reconnecting on transport/no-reply errors.
   *
   * Intended for query-style calls. Transport errors force a reconnect;
   * no-reply errors refresh the current process's shared client without
   * forcing an otherwise healthy session closed.
   */
  template <typename Fn>
  RB_SDK_LOCAL auto _zenoh_call_with_retry(const char* op, Fn&& fn) -> decltype(fn()) {
    try {
      return fn();
    } catch (const rb_zenoh::ZenohTransportError& e) {
      std::cerr << "[" << op << "] zenoh transport error: " << e.what() << " -> reconnect and retry once" << std::endl;
      _refresh_zenoh_client_for_pid(/*force=*/true);
      return fn();
    } catch (const rb_zenoh::ZenohNoReply& e) {
      std::cerr << "[" << op << "] zenoh no-reply: " << e.what() << " -> reconnect and retry once" << std::endl;
      _refresh_zenoh_client_for_pid(/*force=*/false);
      return fn();
    }
  }

  /**
   * @brief Sends a raw zenoh query and returns every raw reply.
   *
   * @param topic Zenoh key expression to query.
   * @param payload Optional raw payload bytes.
   * @param timeout_ms Query timeout in milliseconds.
   * @param target Target selector forwarded to ZenohClient.
   *
   * @return Raw replies returned before timeout.
   *
   * @throws rb_zenoh::ZenohTransportError If the request fails after retry.
   * @throws rb_zenoh::ZenohNoReply If no reply is available after retry.
   */
  std::vector<rb_zenoh::RawReply> query(const std::string& topic, const std::optional<std::vector<uint8_t>>& payload,
                                        int timeout_ms, int target = 0);

  using _gil_release_if_held = rb_sdk::gil_release_if_held;

  /**
   * @brief Sends a raw zenoh query and returns one raw reply.
   *
   * @param topic Zenoh key expression to query.
   * @param payload Optional raw payload bytes.
   * @param timeout_ms Query timeout in milliseconds.
   * @param target Target selector forwarded to ZenohClient.
   *
   * @return Raw reply payload and attachment metadata.
   *
   * @throws rb_zenoh::ZenohTransportError If the request fails after retry.
   * @throws rb_zenoh::ZenohNoReply If no reply is available after retry.
   */
  rb_zenoh::RawReply query_one(const std::string& topic, const std::optional<std::vector<uint8_t>>& payload,
                               int timeout_ms, int target = 0);

  /**
   * @brief Sends a zenoh query and decodes one FlatBuffer reply.
   *
   * @param topic Zenoh key expression to query.
   * @param payload Optional raw payload bytes.
   * @param timeout_ms Query timeout in milliseconds.
   * @param target Target selector forwarded to ZenohClient.
   *
   * @return Decoded native FlatBuffer table.
   */
  template <typename FBSType>
  std::unique_ptr<typename FBSType::NativeTableType> query_one(
      const std::string& topic, const std::optional<std::vector<uint8_t>>& payload = std::nullopt,
      int timeout_ms = 1000, int target = 0) {
    _gil_release_if_held _g;
    return _zenoh_call_with_retry(
        "query_one", [&] { return RBBaseSDK::zenoh_client_->query_one<FBSType>(topic, payload, timeout_ms, target); });
  }

  /**
   * @brief Serializes @p req as a FlatBuffer request and decodes one FlatBuffer reply.
   *
   * @param topic Zenoh key expression to query.
   * @param req Native request table to serialize.
   * @param req_buf_size Initial FlatBuffer builder size.
   * @param timeout_ms Query timeout in milliseconds.
   * @param target Target selector forwarded to ZenohClient.
   *
   * @return Decoded native FlatBuffer table.
   */
  template <typename FBSType, typename ReqT>
  requires rb_zenoh::FlatBufferTClass<ReqT> std::unique_ptr<typename FBSType::NativeTableType> query_one(
      const std::string& topic, const ReqT& req, size_t req_buf_size = 512, int timeout_ms = 1000, int target = 0) {
    _gil_release_if_held _g;
    return _zenoh_call_with_retry("query_one", [&] {
      return RBBaseSDK::zenoh_client_->query_one<FBSType, ReqT>(topic, req, req_buf_size, timeout_ms, target);
    });
  }

  /**
   * @brief Sends a raw zenoh query and returns every raw reply.
   *
   * Same as query(), kept as the "all replies" spelling used by typed
   * overloads.
   */
  std::vector<rb_zenoh::RawReply> query_all(const std::string& topic,
                                            const std::optional<std::vector<uint8_t>>& payload, int timeout_ms,
                                            int target = 0);

  /**
   * @brief Sends a zenoh query and decodes all FlatBuffer replies.
   */
  template <typename FBSType>
  std::vector<std::unique_ptr<typename FBSType::NativeTableType>> query_all(
      const std::string& topic, const std::optional<std::vector<uint8_t>>& payload = std::nullopt,
      int timeout_ms = 1000, int target = 0) {
    return _zenoh_call_with_retry(
        "query_all", [&] { return RBBaseSDK::zenoh_client_->query_all<FBSType>(topic, payload, timeout_ms, target); });
  }

  /**
   * @brief Serializes @p req as a FlatBuffer request and decodes all FlatBuffer replies.
   */
  template <typename FBSType, typename ReqT>
  requires rb_zenoh::FlatBufferTClass<ReqT> std::vector<std::unique_ptr<typename FBSType::NativeTableType>> query_all(
      const std::string& topic, const ReqT& req, size_t req_buf_size = 512, int timeout_ms = 1000, int target = 0) {
    return _zenoh_call_with_retry("query_all", [&] {
      return RBBaseSDK::zenoh_client_->query_all<FBSType, ReqT>(topic, req, req_buf_size, timeout_ms, target);
    });
  }

  /**
   * @brief Publishes raw bytes to a zenoh topic.
   *
   * @param topic Zenoh key expression to publish to.
   * @param payload Raw payload bytes.
   * @param extra_attachment Optional attachment string.
   * @param congestion_control Zenoh congestion-control value.
   * @param priority Zenoh priority value.
   * @param express Whether to publish with express delivery.
   */
  void publish(const std::string& topic, const std::vector<uint8_t>& payload, const std::string& extra_attachment = "",
               int congestion_control = 1 /* zenoh-c: DROP */, int priority = 5, bool express = false);

  /**
   * @brief Serializes a native FlatBuffer object and publishes it to zenoh.
   *
   * @param topic Zenoh key expression to publish to.
   * @param obj Native FlatBuffer table to serialize.
   * @param initial_size Initial FlatBuffer builder size.
   * @param extra_attachment Optional attachment string.
   * @param congestion_control Zenoh congestion-control value.
   * @param priority Zenoh priority value.
   * @param express Whether to publish with express delivery.
   */
  template <typename TObj>
  requires rb_zenoh::FlatBufferTClass<TObj> void publish(const std::string& topic, const TObj& obj,
                                                         size_t initial_size = 512,
                                                         const std::string& extra_attachment = "",
                                                         int congestion_control = 1 /* zenoh-c: DROP */,
                                                         int priority = 5, bool express = false) {
    RBBaseSDK::zenoh_client_->publish(topic, obj, initial_size, extra_attachment, congestion_control, priority,
                                      express);
  }

  /**
   * @brief Receives and decodes one FlatBuffer sample from @p topic.
   *
   * @param topic Zenoh key expression to receive from.
   *
   * @return Decoded native FlatBuffer table.
   */
  template <typename FBSType>
  typename FBSType::NativeTableType receive_one(const std::string& topic) {
    _gil_release_if_held _g;
    return RBBaseSDK::zenoh_client_->receive_one<FBSType>(topic);
  }

  /**
   * @brief Receives one raw queued sample from @p topic.
   *
   * @param topic Zenoh key expression to receive from.
   * @param timeout_ms Receive timeout in milliseconds.
   * @param self_sender_id Sender id to ignore when filtering self-originated samples.
   *
   * @return Raw queued sample.
   */
  rb_zenoh::QueuedSample receive_one(const std::string& topic, int timeout_ms = 1000,
                                     const std::string& self_sender_id = "");

  /**
   * @brief Emits a program log entry on the shared muscat log topic.
   *
   * @param content Log message content.
   * @param robot_model Name of the robot model associated with the log.
   * @param level Log level: "INFO", "WARNING", "ERROR", "USER", "DEBUG", or "GENERAL".
   * @param disable_db Kept for parity with the Python SDK; currently ignored.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done after publishing the log.
   */
  void log(const std::string& content, const std::string& robot_model,
           const std::string& level /* INFO|WARNING|ERROR|USER|DEBUG|GENERAL */, bool disable_db = false,
           FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Raises on non-zero return_value when called from a PyFM step.
   *
   * If @p flow_manager_args is omitted, this helper ignores return_value,
   * matching the Python SDK's direct-call behavior.
   *
   * @param func_name Name used in the generated error message.
   * @param obj_payload Response object to inspect. Types without a
   *        return_value field pass through.
   * @param flow_manager_args Optional PyFM step context.
   *
   * @throws std::runtime_error If @p flow_manager_args is provided and
   *         obj_payload.return_value is non-zero.
   */
  template <typename T>
  void manipulate_return_value(const std::string& func_name, const T& obj_payload,
                               FlowManagerArgsPtr flow_manager_args = nullptr) {
    if constexpr (requires(const T& t) { t.return_value; }) {
      if (flow_manager_args && obj_payload.return_value != 0) {
        std::string error_msg = "[" + func_name + "] return value is " + std::to_string(obj_payload.return_value);

        std::cerr << error_msg << std::endl;
        throw std::runtime_error(error_msg);
      }
    }
  }

  /**
   * @brief Validates an optional response payload and optionally completes the PyFM step.
   *
   * @param obj_payload Optional response payload.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done after validation succeeds.
   *
   * @return The contained payload value.
   *
   * @throws std::runtime_error If @p obj_payload is empty, or if the payload
   *         has a non-zero return_value field.
   */
  template <typename T>
  T validate_single_return_value(const std::optional<T>& obj_payload, FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!obj_payload)
      throw std::runtime_error("validate_single_return value got no payload");

    if constexpr (requires(const T& t) { t.return_value; }) {
      if (obj_payload.value().return_value != 0)
        throw std::runtime_error("return value is not 0: " + std::to_string(obj_payload.value().return_value));
    }

    if (flow_manager_args)
      flow_manager_args->done();

    return obj_payload.value();
  }

  /**
   * @brief Opens a CAN channel through the host_pcan service.
   *
   * @param channel CAN channel name.
   * @param bitrate Nominal bitrate.
   * @param fd Whether to use CAN-FD.
   * @param data_bitrate CAN-FD data phase bitrate.
   * @param receive_own_messages Whether transmitted frames should be looped back.
   * @param interface CAN interface backend, defaults to "pcan".
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done on success and an unsuccessful response raises.
   *
   * @return IPC::ResponseCANConnectT returned by the host service.
   *
   * @throws std::runtime_error If no response is received, or if
   *         @p flow_manager_args is provided and the response reports failure.
   */
  IPC::ResponseCANConnectT connect_can(const std::string& channel, uint32_t bitrate, bool fd = false,
                                       uint32_t data_bitrate = 0, bool receive_own_messages = false,
                                       const std::string& interface = "pcan",
                                       FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Closes a CAN channel through the host_pcan service.
   *
   * @param channel CAN channel name.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done on success and an unsuccessful response raises.
   *
   * @return IPC::ResponseCANDisconnectT returned by the host service.
   *
   * @throws std::runtime_error If no response is received, or if
   *         @p flow_manager_args is provided and the response reports failure.
   */
  IPC::ResponseCANDisconnectT disconnect_can(const std::string& channel,
                                             FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Transmits one CAN/CAN-FD frame through the host_pcan service.
   *
   * @param channel CAN channel name.
   * @param arbitration_id CAN arbitration id.
   * @param data Frame payload bytes.
   * @param dlc Data length code.
   * @param is_extended_id Whether @p arbitration_id is an extended id.
   * @param is_remote_frame Whether the frame is a remote frame.
   * @param is_fd Whether the frame is CAN-FD.
   * @param bitrate_switch Whether CAN-FD bitrate switching is enabled.
   * @param is_error_frame Whether the frame is an error frame.
   * @param error_state_indicator CAN-FD error-state indicator flag.
   * @param timestamp Optional frame timestamp.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done on success and an unsuccessful response raises.
   *
   * @return IPC::ResponseCANTransmitT returned by the host service.
   *
   * @throws std::runtime_error If no response is received, or if
   *         @p flow_manager_args is provided and the response reports failure.
   */
  IPC::ResponseCANTransmitT transmit_can(const std::string& channel, uint32_t arbitration_id,
                                         const std::vector<uint8_t>& data = {}, uint8_t dlc = 0,
                                         bool is_extended_id = false, bool is_remote_frame = false, bool is_fd = false,
                                         bool bitrate_switch = false, bool is_error_frame = false,
                                         bool error_state_indicator = false, double timestamp = 0.0,
                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  /** Vendor Mech-Mind clients keyed by PyFM module/task id. */
  VisionClientRegistry<mechmind::MechMindClient, mechmind::MechMindConfig> mechmind_clients_;
  /** Vendor Photoneo clients keyed by PyFM module/task id. */
  VisionClientRegistry<photoneo::PhotoneoClient, photoneo::PhotoneoConfig> photoneo_clients_;
  /** Vendor Pickit clients keyed by PyFM module/task id. */
  VisionClientRegistry<pickit3d::PickitClient, pickit3d::PickitConfig> pickit_clients_;

 private:
  RB_SDK_LOCAL void _connect(const std::optional<std::vector<std::pair<std::string, std::string>>>& pairs = std::nullopt,
                const std::optional<std::string>& sender = std::nullopt, const int max_attempts = 8,
                const float initial_delay_s = 0.5, const float max_delay_s = 3.0);

  RB_SDK_LOCAL void _zenoh_unsubscribe_mine();

  RB_SDK_LOCAL void _zenoh_unqueryable_mine();

  std::shared_ptr<rb_zenoh::ZenohClient> _refresh_zenoh_client_for_pid(bool force = false);

  RB_SDK_LOCAL void _reconnect_shared_zenoh_for_remote_peer(int listen_port);

  RB_SDK_LOCAL void heartbeat_loop(const std::string& peer_id, int ttl, double interval_sec);

  RB_SDK_LOCAL bool _wait_for_zenoh_echo(const std::string& req_keyexpr, const std::string& res_keyexpr,
                            std::optional<double> timeout, double probe_timeout, double interval);
};
