#pragma once

#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <algorithm>
#include <any>
#include <atomic>
#include <condition_variable>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>
#include <memory>
#include <mutex>
#include <nlohmann/json.hpp>
#include <optional>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <typeinfo>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "rb_sdk_api.hpp"

#include "binding/glue/gil_release.hpp"
#include "flow_manager_args.hpp"
#include "zenoh_client.hpp"
#include "zenoh_core.hpp"
#include "zenoh_exception.hpp"  // rb_zenoh::ZenohNoReply / ZenohTransportError (query 재시도에서 사용)

#include "common_struct_generated.h"  // IPC::MoveInput_{Target,Speed,Type}T
#include "host_pcan_generated.h"      // IPC::Request/ResponseCAN* (connect_can/disconnect_can/transmit_can)
#include "program_generated.h"        // muscat::RB_Program_LogT (log() 에서 사용, 모든 도메인 공용)

// lib/Vision 벤더 프로토콜 클라이언트 (CMakeLists.txt RB_VISION_SOURCES 로 rb_sdk 타겟에 이미 링크됨).
// RBBaseSDK 를 상속받는 모든 SDK 클래스(manipulate, 차후 amr 등)가 VisionClientRegistry 를
// 통해 module_name 별로 여러 비전 서버에 동시 접속할 수 있도록 여기서 타입만 끌어온다.
#include "mechmind/mechmind_client.hpp"
#include "photoneo/photoneo_client.hpp"
// photoneo_client.hpp 는 (mechmind/pickit3d client 헤더와 달리) exceptions.hpp 를 스스로 include
// 하지 않는다 - photoneo::PhotoneoError 등을 catch 하려면 명시적으로 필요하다.
#include "photoneo/exceptions.hpp"
#include "pickit3d/pickit_client.hpp"

enum class ServerType { AMR, MANIPULATE };

enum class HttpMethod { GET, POST, PUT, DELETE };

using HttpHeaders = std::map<std::string, std::string>;

enum class CongestionControl : int {
  DROP = 0,
  BLOCK = 1,
  DROP_LATEST = 2,  // same as BLOCK in practice
};

enum class Priority : int {
  REAL_TIME = 1,
  INTERACTIVE_HIGH = 2,
  INTERACTIVE_LOW = 3,
  DATA_HIGH = 4,
  DATA = 5,
  DATA_LOW = 6,
  BACKGROUND = 7,
};

struct MoveType {
  inline static constexpr std::string_view J = "J";
  inline static constexpr std::string_view L = "L";
  inline static constexpr std::string_view JB = "JB";
  inline static constexpr std::string_view LB = "LB";
  inline static constexpr std::string_view XB = "XB";
};

struct ConnectOptions {
  std::string token;
  std::string host;

  std::optional<int> zenoh_port;

  int ttl = 5;

  std::optional<double> heartbeat;
  std::optional<double> mesh_timeout;

  double mesh_probe_timeout = 1.0;
  double mesh_probe_interval = 0.5;
};

inline std::string get_env(const std::string& name, const std::string& default_value) {
  if (const char* value = std::getenv(name.c_str())) {
    return value;
  }
  return default_value;
}

inline bool getenv_bool(const char* name, bool default_value = false) {
  if (const char* p = std::getenv(name)) {
    std::string s = p;
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return std::tolower(c); });
    return s == "true";
  }
  return default_value;
}

// module_name(PFM 의 task_id) 별로 독립된 벤더 비전 클라이언트를 소유/관리한다.
// 같은 module_name 으로 다시 connect() 하면 기존 연결을 정리하고 새로 만든다.
template <typename ClientT, typename ConfigT>
class VisionClientRegistry {
 public:
  ClientT* get(const std::string& module_name) {
    auto it = clients_.find(module_name);
    return it == clients_.end() ? nullptr : it->second.get();
  }

  ClientT& connect(const std::string& module_name, const ConfigT& config) {
    auto it = clients_.find(module_name);
    if (it != clients_.end() && it->second->is_connected())
      it->second->disconnect();

    auto client = std::make_unique<ClientT>(config);
    client->connect();
    ClientT& ref = *client;
    clients_[module_name] = std::move(client);
    return ref;
  }

  void disconnect_all() {
    for (auto& [module_name, client] : clients_) {
      try {
        if (client && client->is_connected())
          client->disconnect();
      } catch (const std::exception& e) {
        std::cerr << "[VisionClientRegistry] disconnect failed: module=" << module_name << ", err=" << e.what()
                  << std::endl;
      }
    }
  }

 private:
  std::unordered_map<std::string, std::unique_ptr<ClientT>> clients_;
};

// 비-템플릿 메서드와 내부 helper 구현은 base.cpp 로 분리되어 librb_sdk.so 안에 컴파일된다.
// 헤더에는 선언과, 소비자 TU 에서 인스턴스화되어야 하는 얇은 템플릿(zenoh_client_ 로 위임)만 남는다.
class RB_SDK_API RBBaseSDK {
 public:
  static RBBaseSDK& instance();

  // copy 방지
  RBBaseSDK(const RBBaseSDK&) = delete;
  RBBaseSDK& operator=(const RBBaseSDK&) = delete;

  // move 방지
  RBBaseSDK(RBBaseSDK&&) = delete;
  RBBaseSDK& operator=(RBBaseSDK&&) = delete;

 protected:
  RB_SDK_LOCAL inline static int pid_ = 0;

  inline static std::shared_ptr<rb_zenoh::ZenohClient> zenoh_client_;

  inline static std::recursive_mutex lock_;

  inline static std::mutex mutex_;

  RB_SDK_LOCAL inline static std::optional<std::string> peer_id_;

  RB_SDK_LOCAL inline static std::optional<std::string> peer_common_url_;

  RB_SDK_LOCAL inline static std::optional<std::string> peer_token_;

  RB_SDK_LOCAL inline static std::thread heartbeat_thread_;

  RB_SDK_LOCAL inline static std::atomic<bool> heartbeat_stop_{false};

  // 인스턴스 단위 중복 close 가드.
  bool instance_closed_ = false;

  // SDK 인스턴스 참조 카운트(base.py _total_ref_counts[pid] 대응, 0 이 될 때만 공유 세션 close)는
  // base.cpp 익명 namespace 의 acquire_sdk_ref() / release_sdk_ref() 로 옮겼다.

  std::string sender = "";

  std::optional<std::string> name;

  std::unordered_set<std::string> zenoh_queryables;

  std::unordered_set<std::string> zenoh_subscribes;

  std::string SERVICE = get_env("SERVICE", "unknown");

  bool IS_DEV = getenv_bool("IS_DEV");

  RBBaseSDK(std::optional<ServerType> server = std::nullopt, bool use_directly = false);

  // 외부 삭제 방지. base.py __del__ 대응 — disconnect() 아니라 close().
  // virtual: before_close() 가 가상함수라 클래스에 처음 vtable 이 생겼다 — 가상함수가 하나라도
  // 있으면 소멸자도 가상이어야 한다는 표준 관례를 따른다(RBBaseSDK* 로 delete 되는 경우 안전).
  virtual ~RBBaseSDK();

 public:
  std::optional<std::string> connect(const ConnectOptions& options);

  int zenoh_subscribe(const std::string& topic, rb_zenoh::SubCallback callback,
                      rb_zenoh::CppSubscribeOptions opts = {});

  // zenoh_subscribe 로 받은 subscriber id 하나만 해제한다 (공유 세션은 건드리지 않음).
  // protected 인 zenoh_client_ 를 감싸, .so 내부의 non-member helper 도 개별 구독을 정리할 수 있게 한다.
  RB_SDK_LOCAL void zenoh_unsubscribe(int sub_id);

  template <typename FBSType>
  int zenoh_subscribe(
      const std::string& topic,
      std::function<void(const std::string&, std::unique_ptr<typename FBSType::NativeTableType>, const std::string&)>
          callback,
      rb_zenoh::CppSubscribeOptions opts = {}) {
    _gil_release_if_held _g;
    std::lock_guard<std::mutex> guard(mutex_);
    try {
      int sub_id_ = RBBaseSDK::zenoh_client_->declare_subscriber<FBSType>(topic, callback, opts);
      zenoh_subscribes.insert(topic);

      return sub_id_;
    } catch (const std::exception& e) {
      std::cout << "error at zenoh_subscribe()" << std::endl;
      std::cerr << e.what() << '\n';
    }

    // 구독 실패. 유효한 subscriber id 가 없음을 -1 로 알린다
    // (_FlowManagerState::subs_id 기본값과 동일).
    return -1;
  }

  void zenoh_queryable(const std::string& topic, rb_zenoh::QueryHandler handler);

  void disconnect();

  // base.py RBBaseSDK._cleanup_resources() 의 `getattr(self, "before_close", None)` 동적 훅 대응.
  // 빈 기본 구현(optional hook) — 서브클래스가 정리할 자원이 있으면 override 한다
  // (예: RBProgramSDK::before_close(), 각자 close() 를 부르는 자기 소멸자와 함께).
  //
  // 주의: 이 가상함수는 close() 가 자기 소멸자(예: ~RBProgramSDK())에서 불릴 때만 override 로
  // 디스패치된다. ~RBBaseSDK() 자신의 소멸자 본문에서 close() 가 불리는 시점엔 이미 vtable 이
  // RBBaseSDK 로 되돌아가 있어(C++ 표준상 파생 클래스가 이미 부분 소멸된 뒤 그쪽 가상함수를
  // 부르는 걸 막기 위함) before_close() 가 항상 이 빈 기본 구현으로 떨어진다 — 그래서
  // before_close() 를 override 하는 서브클래스는 반드시 자기 소멸자에서 close() 를 명시적으로
  // 불러야 한다(멱등이라 그 뒤 ~RBBaseSDK() 가 또 불러도 안전).
  virtual void before_close();

  // base.py RBBaseSDK.close() 대응: 중복 가드 → 참조 카운트 감소 →
  // (peer 붙어있으면 disconnect) → 자기 리소스 정리 → 마지막 SDK일 때만
  // 공유 세션 close. zenoh_client_ 는 프로세스 공유라 무조건 닫으면 다른
  // SDK 의 구독/queryable 까지 끊긴다.
  void close();

  // base.py _wrap_with_safe_handler 의 zenoh 재시도 대응(축약판): query 계열이 ZenohNoReply /
  // ZenohTransportError 로 실패하면 세션을 재확인/재연결하고 딱 한 번 다시 시도한다. Transport
  // 오류는 세션 자체가 깨진 것으로 보고 강제 재연결한다(base.py force_reconnect 와 동일).
  template <typename Fn>
  RB_SDK_LOCAL auto _zenoh_call_with_retry(const char* op, Fn&& fn) -> decltype(fn()) {
    try {
      return fn();
    } catch (const rb_zenoh::ZenohTransportError& e) {
      std::cerr << "[" << op << "] zenoh transport error: " << e.what() << " -> reconnect and retry once" << std::endl;
      _refresh_zenoh_client_for_pid(/*force=*/true);
      return fn();
    } catch (const rb_zenoh::ZenohNoReply& e) {
      std::cerr << "[" << op << "] zenoh no-reply: " << e.what() << " -> reconnect and retry once" << std::endl;
      _refresh_zenoh_client_for_pid(/*force=*/false);
      return fn();
    }
  }

  std::vector<rb_zenoh::RawReply> query(const std::string& topic, const std::optional<std::vector<uint8_t>>& payload,
                                        int timeout_ms, int target = 0);

  // zenoh 왕복(query_one/receive_one)은 응답이 올 때까지 C++ 레벨에서 블로킹한다.
  // Python 진입 시 GIL 을 쥔 채 기다리면 다른 zenoh 콜백과 서로 물리므로 실제로 GIL 을
  // 들고 있을 때만 놓는다. pybind 의존은 binding/glue/gil_release.hpp 안에 RB_SDK_WITH_PYTHON 로
  // 격리돼 있고, 순수 C++ 빌드에서는 no-op 이다.
  using _gil_release_if_held = rb_sdk::gil_release_if_held;

  rb_zenoh::RawReply query_one(const std::string& topic, const std::optional<std::vector<uint8_t>>& payload,
                               int timeout_ms, int target = 0);

  template <typename FBSType>
  std::unique_ptr<typename FBSType::NativeTableType> query_one(
      const std::string& topic, const std::optional<std::vector<uint8_t>>& payload = std::nullopt,
      int timeout_ms = 1000, int target = 0) {
    _gil_release_if_held _g;
    return _zenoh_call_with_retry(
        "query_one", [&] { return RBBaseSDK::zenoh_client_->query_one<FBSType>(topic, payload, timeout_ms, target); });
  }

  template <typename FBSType, typename ReqT>
  requires rb_zenoh::FlatBufferTClass<ReqT> std::unique_ptr<typename FBSType::NativeTableType> query_one(
      const std::string& topic, const ReqT& req, size_t req_buf_size = 512, int timeout_ms = 1000, int target = 0) {
    _gil_release_if_held _g;
    return _zenoh_call_with_retry("query_one", [&] {
      return RBBaseSDK::zenoh_client_->query_one<FBSType, ReqT>(topic, req, req_buf_size, timeout_ms, target);
    });
  }

  std::vector<rb_zenoh::RawReply> query_all(const std::string& topic,
                                            const std::optional<std::vector<uint8_t>>& payload, int timeout_ms,
                                            int target = 0);

  template <typename FBSType>
  std::vector<std::unique_ptr<typename FBSType::NativeTableType>> query_all(
      const std::string& topic, const std::optional<std::vector<uint8_t>>& payload = std::nullopt,
      int timeout_ms = 1000, int target = 0) {
    return _zenoh_call_with_retry(
        "query_all", [&] { return RBBaseSDK::zenoh_client_->query_all<FBSType>(topic, payload, timeout_ms, target); });
  }

  template <typename FBSType, typename ReqT>
  requires rb_zenoh::FlatBufferTClass<ReqT> std::vector<std::unique_ptr<typename FBSType::NativeTableType>> query_all(
      const std::string& topic, const ReqT& req, size_t req_buf_size = 512, int timeout_ms = 1000, int target = 0) {
    return _zenoh_call_with_retry("query_all", [&] {
      return RBBaseSDK::zenoh_client_->query_all<FBSType, ReqT>(topic, req, req_buf_size, timeout_ms, target);
    });
  }

  void publish(const std::string& topic, const std::vector<uint8_t>& payload, const std::string& extra_attachment = "",
               int congestion_control = 1 /* zenoh-c: DROP */, int priority = 5, bool express = false);

  template <typename TObj>
  requires rb_zenoh::FlatBufferTClass<TObj> void publish(const std::string& topic, const TObj& obj,
                                                         size_t initial_size = 512,
                                                         const std::string& extra_attachment = "",
                                                         int congestion_control = 1 /* zenoh-c: DROP */,
                                                         int priority = 5, bool express = false) {
    RBBaseSDK::zenoh_client_->publish(topic, obj, initial_size, extra_attachment, congestion_control, priority,
                                      express);
  }

  template <typename FBSType>
  typename FBSType::NativeTableType receive_one(const std::string& topic) {
    _gil_release_if_held _g;
    return RBBaseSDK::zenoh_client_->receive_one<FBSType>(topic);
  }

  // Python base.py::RBBaseSDK.log() 대응. program_sdk 뿐 아니라 이 클래스를 상속하는 모든 SDK
  // (RBManipulateSDK 포함)가 공용으로 쓴다 — muscat/program/log 토픽은 도메인과 무관하게 동일.
  // program_sdk 마이그레이션(rb_program_sdk.hpp) 때 처음 필요해져서 여기로 포팅했다.
  void log(const std::string& content, const std::string& robot_model,
           const std::string& level /* INFO|WARNING|ERROR|USER|DEBUG|GENERAL */, bool disable_db = false,
           FlowManagerArgsPtr flow_manager_args = nullptr);

  // base.py RBBaseSDK.manipulate_return_value 대응: PyFM 실행 중(flow_manager_args 존재)일 때만
  // return_value != 0 을 에러로 간주해 예외를 던진다. 직접 호출(flow_manager_args 없음)에서는
  // Python 과 동일하게 return_value 를 무시한다. done() 은 호출부에서 별도로 부른다(Python 과 동일).
  // return_value 필드가 없는 응답 타입은 Python 의 hasattr 체크처럼 조용히 통과시킨다.
  template <typename T>
  void manipulate_return_value(const std::string& func_name, const T& obj_payload,
                               FlowManagerArgsPtr flow_manager_args = nullptr) {
    if constexpr (requires(const T& t) { t.return_value; }) {
      if (flow_manager_args && obj_payload.return_value != 0) {
        std::string error_msg = "[" + func_name + "] return value is " + std::to_string(obj_payload.return_value);

        std::cerr << error_msg << std::endl;
        throw std::runtime_error(error_msg);
      }
    }
  }

  template <typename T>
  T validate_single_return_value(const std::optional<T>& obj_payload, FlowManagerArgsPtr flow_manager_args = nullptr) {
    if (!obj_payload)
      throw std::runtime_error("validate_single_return value got no payload");

    if constexpr (requires(const T& t) { t.return_value; }) {
      if (obj_payload.value().return_value != 0)
        throw std::runtime_error("return value is not 0: " + std::to_string(obj_payload.value().return_value));
    }

    if (flow_manager_args)
      flow_manager_args->done();

    return obj_payload.value();
  }

  // ---------------------------------------------------------------------
  // CAN (host_pcan 서비스) — base.py RBBaseSDK.connect_can/disconnect_can/transmit_can 대응.
  // muscat/can/* 토픽은 도메인과 무관하므로 log() 처럼 base 에 둔다. flow_manager_args 가 있으면
  // 응답 success 여부로 done() / 예외를 가른다(Python 원본과 동일).
  // ---------------------------------------------------------------------

  IPC::ResponseCANConnectT connect_can(const std::string& channel, uint32_t bitrate, bool fd = false,
                                       uint32_t data_bitrate = 0, bool receive_own_messages = false,
                                       const std::string& interface = "pcan",
                                       FlowManagerArgsPtr flow_manager_args = nullptr);

  IPC::ResponseCANDisconnectT disconnect_can(const std::string& channel,
                                             FlowManagerArgsPtr flow_manager_args = nullptr);

  IPC::ResponseCANTransmitT transmit_can(const std::string& channel, uint32_t arbitration_id,
                                         const std::vector<uint8_t>& data = {}, uint8_t dlc = 0,
                                         bool is_extended_id = false, bool is_remote_frame = false, bool is_fd = false,
                                         bool bitrate_switch = false, bool is_error_frame = false,
                                         bool error_state_indicator = false, double timestamp = 0.0,
                                         FlowManagerArgsPtr flow_manager_args = nullptr);

  // ---------------------------------------------------------------------
  // lib/Vision 벤더 프로토콜 클라이언트. RBBaseSDK 를 상속받는 SDK 클래스는
  // (manipulate 뿐 아니라 차후 amr 등도) module_name 별로 여러 비전 서버에
  // 동시 접속할 수 있다 - PFM 이 Task(module_name) 마다 독립된 비전 연결을
  // 요구하기 때문에 인스턴스를 하나만 두지 않고 registry 로 관리한다.
  // ---------------------------------------------------------------------

  VisionClientRegistry<mechmind::MechMindClient, mechmind::MechMindConfig> mechmind_clients_;
  VisionClientRegistry<photoneo::PhotoneoClient, photoneo::PhotoneoConfig> photoneo_clients_;
  VisionClientRegistry<pickit3d::PickitClient, pickit3d::PickitConfig> pickit_clients_;

 private:
  RB_SDK_LOCAL void _connect(const std::optional<std::vector<std::pair<std::string, std::string>>>& pairs = std::nullopt,
                const std::optional<std::string>& sender = std::nullopt, const int max_attempts = 8,
                const float initial_delay_s = 0.5, const float max_delay_s = 3.0);

  RB_SDK_LOCAL void _zenoh_unsubscribe_mine();

  RB_SDK_LOCAL void _zenoh_unqueryable_mine();

  std::shared_ptr<rb_zenoh::ZenohClient> _refresh_zenoh_client_for_pid(bool force = false);

  RB_SDK_LOCAL void _reconnect_shared_zenoh_for_remote_peer(int listen_port);

  RB_SDK_LOCAL void heartbeat_loop(const std::string& peer_id, int ttl, double interval_sec);

  RB_SDK_LOCAL bool _wait_for_zenoh_echo(const std::string& req_keyexpr, const std::string& res_keyexpr,
                            std::optional<double> timeout, double probe_timeout, double interval);
};
