#pragma once

// plugin.py -> rb_plugin.hpp. 순수 C++ core — pybind11 을 전혀 모른다.
//
// RBPluginCall 은 "플러그인 프로세스"(플러그인 개발자의 main.py, 또는 C++ 플러그인 실행파일)
// 안에서 도는 헬퍼다. 플러그인 UI(브라우저) 와 pub/sub/serve/call 하기 위해 플러그인
// Socket.IO 게이트웨이(scripts/backend/runtime/plugin_gateway.py, 기본 http://127.0.0.1:10000)
// 에 접속한다. PluginProgramContext(로봇 executor <-> 플러그인, zenoh) 와는 다른 축이다.
//
// transport: socket.io-client-cpp(sioclient) 3.1.0 을 rb_sioclient static lib 로 편입해 쓴다
// (EIO=4, WebSocket). PluginProgramContext 가 rb_zenoh::ZenohClient(이미 링크됨) 에 얹힌 것과
// 달리 여기는 새 transport 가 필요해서 sioclient 를 추가했다.
//
// pimpl: sio::client / sio::socket 등 sioclient 타입은 Impl(rb_plugin.cpp) 안에만 있고 이
// 배포 헤더에는 새어나오지 않는다. RBPluginCall 은 자기 동작(핸들러 설치 / 연결 / 이벤트 처리)
// 을 private RB_SDK_LOCAL 메서드로 직접 소유하고, Impl 은 순수 데이터 홀더다(plugin.py 의
// 인스턴스 필드에 해당). private 헬퍼는 이름 `_` 접두사 + RB_SDK_LOCAL 로 .dynsym 에서도 뺀다.
//
// 3계층 (plugin_program_context 와 동일 구조):
//   1. 이 파일 (순수 C++)   — C++ 플러그인이 include 해서 nlohmann::json + std::function 로 직접 사용
//   2. binding/plugin_call_binding.hpp — py::object <-> nlohmann::json + 데코레이터/asyncio 표면
//   3. rb_sdk.rb_sdk_cpp.RBPluginCall  — 위 바인딩. plugin.py 와 1:1 (순수 Python plugin.py 는 그대로 잔존)
//
// 싱글턴: plugin.py 의 `_instances[(pid, plugin_id)]` 와 동일. get_instance() 가 프로세스 전역
// (pid 포함 — fork 후 자식은 새 인스턴스) 레지스트리에서 plugin_id 별 단일 객체를 돌려주며,
// 레지스트리는 인스턴스를 프로세스 수명 내내 leak 한다(plugin.py class dict 와 동일 수명; sioclient
// 3.1.0 은 handshake 진행 중 파괴되면 crash 하므로 종료는 OS 에 맡긴다). 인터프리터 종료 시
// 콜백이 죽은 Python 을 건드리지 않도록 shutdown_all() 을 바인딩이 atexit 로 부른다.

#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

#include <nlohmann/json_fwd.hpp>

#include "rb_sdk_api.hpp"

namespace rb_plugin {

class PluginRouter;

// plugin.py::RBPluginGatewayError. 게이트웨이 call/emit 실패 시 던진다.
class RB_SDK_API RBPluginGatewayError : public std::runtime_error {
 public:
  explicit RBPluginGatewayError(const std::string& what) : std::runtime_error(what) {}
};

// plugin.py::PluginRouteError. serve 핸들러(특히 PluginRouter.on 라우트)가 이 예외를
// 던지면 게이트웨이엔 {"error": message, "code": code} 로 응답한다 — 성공/그 외 예외와
// 구분해 외부 응답 status 로 그대로 나간다.
class RB_SDK_API PluginRouteError : public std::runtime_error {
 public:
  PluginRouteError(int code, const std::string& message)
      : std::runtime_error(message), code_(code), message_(message) {}

  int code() const noexcept { return code_; }

  const std::string& message() const noexcept { return message_; }

 private:
  int code_;
  std::string message_;
};

// subscribe() 가 반환하는 구독 핸들. 전역 유니크 토큰을 감싼 값 타입 — 복사 가능하고
// RAII 가 아니다(소멸해도 구독은 유지된다). RBPluginCall::unsubscribe(topic, sub) 로
// 명시적으로 해제한다. plugin.py 에서 구독 콜백 함수를 다시 넘기던 자리에 해당.
// 토큰 값 자체는 RBPluginCall 인스턴스 없이는 의미 없다 — 그래서 token() 을 열어둔다(바인딩용).
class RB_SDK_API Subscription {
 public:
  Subscription() noexcept = default;

  explicit Subscription(std::uint64_t token) noexcept : token_(token) {}

  std::uint64_t token() const noexcept { return token_; }

  bool valid() const noexcept { return token_ != 0; }

  explicit operator bool() const noexcept { return token_ != 0; }

 private:
  std::uint64_t token_ = 0;
};

class RB_SDK_API RBPluginCall {
 public:
  // (topic, payload). topic 은 이미 scoped 된 값(게이트웨이가 echo 한 그대로).
  using SubCallback = std::function<void(const std::string& topic, const nlohmann::json& payload)>;
  // payload -> reply. PluginRouteError 를 던지면 게이트웨이엔 {error, code} 로, 그 외
  // std::exception 은 {error: what(), code: 500} 으로 응답한다(plugin.py _on_serve_call 와 1:1).
  using ServeHandler = std::function<nlohmann::json(const nlohmann::json& payload)>;

  // plugin.py::_resolve_plugin_id — 명시값 > RB_PLUGIN_ID > PLUGIN_ID, strip("/"). 비면 예외.
  static std::string resolve_plugin_id(const std::optional<std::string>& plugin_id);

  // (getpid(), plugin_id) 키 프로세스 전역 싱글턴. plugin_id 는 이미 resolve/strip 된 값이어야.
  static std::shared_ptr<RBPluginCall> get_instance(const std::string& plugin_id);

  // 인터프리터 종료 전 콜백(py::object 캡처)을 놓아준다. 바인딩이 atexit 로 부른다.
  static void shutdown_all();

  ~RBPluginCall();
  RBPluginCall(const RBPluginCall&) = delete;
  RBPluginCall& operator=(const RBPluginCall&) = delete;

  const std::string& plugin_id() const { return plugin_id_; }

  // plugin.py::_scoped. "/" 로 시작하면 절대(prefix 무시), 아니면 "{plugin_id}/{key}" (중복 방지).
  std::string scoped(const std::string& key) const;

  // socket.io 네임스페이스가 연결돼 있는지 (plugin.py self._client.connected).
  bool connected() const;

  // plugin.py::publish. 미연결이면 조용히 버린다.
  void publish(const std::string& topic, const nlohmann::json& payload);

  // plugin.py::subscribe. 해당 topic 의 첫 구독이고 연결돼 있으면 "sub" emit.
  // 반환한 Subscription 핸들을 보관했다가 unsubscribe(topic, sub) 로 해제한다.
  [[nodiscard]] Subscription subscribe(const std::string& topic, SubCallback cb);

  // plugin.py::unsubscribe 와 1:1 — 인자 둘 다 선택. sub 를 주면 그 구독 하나만,
  // 안 주면(무효 핸들) topic 단위 / 전체.
  //   unsubscribe()                 → 전체 해제
  //   unsubscribe("ui/event")       → 그 topic 의 모든 구독 해제
  //   unsubscribe(std::nullopt, s)  → 핸들 s 하나만 해제
  //   unsubscribe("ui/event", s)    → s 가 그 topic 의 구독일 때만 해제
  // 비게 된 topic 마다 "unsub" emit.
  void unsubscribe(const std::optional<std::string>& topic = std::nullopt, const Subscription& sub = Subscription{});
  // plugin.py::unsubscribe_topic (= unsubscribe 별칭). topic 의 모든 구독 해제 — callback 인자 없는 버전.
  void unsubscribe_topic(const std::string& topic);

  // plugin.py::serve 의 register(). keyexpr 당 1개(교체). 연결돼 있으면 "serve_register" emit.
  void serve(const std::string& keyexpr, ServeHandler handler);
  // plugin.py::unserve. keyexpr 지정 시 그것만, 생략 시 전체. 항목마다 "serve_unregister" emit.
  void unserve(const std::optional<std::string>& keyexpr = std::nullopt);
  // plugin.py::undeclare_queryable (= unserve 별칭).
  void undeclare_queryable(const std::optional<std::string>& keyexpr = std::nullopt);

  // plugin.py::call 의 action 경로. ack 를 timeout_sec 까지 기다려 첫 인자를 반환(없으면 null).
  // 미연결이면 RBPluginGatewayError.
  nlohmann::json call(const std::string& keyexpr, const nlohmann::json& payload, double timeout_sec);

  // plugin.py::RBPluginCall.router — MuscatRouter 어휘로 외부 endpoint 를 선언하는 헬퍼.
  // 인스턴스당 1개(생성자에서 생성). C++ 플러그인은 이걸 직접 쓴다.
  PluginRouter& router();
  // 바인딩 전용 — 파이썬 wrapper PyObject 를 dedup 하려면 shared_ptr 로 넘겨야 한다.
  const std::shared_ptr<PluginRouter>& router_ptr() const;

 private:
  explicit RBPluginCall(std::string plugin_id);

  // plugin.py __init__ 의 흐름을 그대로 나눈 내부 단계. Impl(pimpl) 을 통해 sioclient 를 만진다.
  // 전부 RB_SDK_LOCAL — class 는 RB_SDK_API 라도 이 심볼들은 STV_HIDDEN → 배포 .so 의 .dynsym 에 안 뜬다.
  RB_SDK_LOCAL void _install_handlers();  // sio 이벤트("msg"/"serve_call") + 재연결 리스너 바인딩
  RB_SDK_LOCAL void _on_connect();        // (재)연결 시 현재 구독/queryable 재등록 (plugin.py::_on_connect)
  RB_SDK_LOCAL void _on_msg(const nlohmann::json& data);         // "msg" 수신 -> 구독 콜백 디스패치
  RB_SDK_LOCAL void _on_serve_call(const nlohmann::json& data);  // "serve_call" 수신 -> 핸들러 -> "serve_reply"
  RB_SDK_LOCAL void _emit(const std::string& event, const nlohmann::json& payload);  // 미연결이면 no-op

  struct Impl;
  std::unique_ptr<Impl> impl_;
  std::string plugin_id_;
  std::shared_ptr<PluginRouter> router_;  // 생성자에서 채운다 (plugin.py self.router)
};

// 바인딩(plugin_call_binding.hpp)이 PluginRouter 의 데코레이터 2단계에 접근하는 창구.
// 정의는 바인딩 쪽에 있고 여기선 friend 대상 이름만 연다 — 코어 헤더가 pybind 를 모른 채로.
struct PluginRouterBindingAccess;

// plugin.py::PluginRouter 와 1:1. plugin_id prefix 는 RBPluginCall 이 붙이므로 여기선 path 만
// 다룬다. 공개 API 는 plugin.py 와 동일하게 on()/subscribe()/emit() 뿐이다 — C++ 플러그인은
// 이것만 쓴다. 데코레이터 2단계(검증/등록 분리)는 파이썬 바인딩 전용이라 private.
class RB_SDK_API PluginRouter {
 public:
  // route 핸들러: (payload, meta) -> reply. transport 게이트를 통과한 호출만 들어온다.
  // PluginRouteError 를 던지면 그 code 로 외부 응답 status 가 나간다.
  using RouteHandler =
      std::function<nlohmann::json(const nlohmann::json& payload, const nlohmann::json& meta)>;
  // event 핸들러: payload. transport 게이트를 통과한 호출만.
  using EventHandler = std::function<void(const nlohmann::json& payload)>;

  explicit PluginRouter(RBPluginCall& call);
  PluginRouter(const PluginRouter&) = delete;
  PluginRouter& operator=(const PluginRouter&) = delete;

  // plugin.py::PluginRouter.on — path "/" strip + 중복 검사 + explicit_routes 검증 후
  // {plugin_id}/{path} queryable 로 등록. 빈/중복 path, 알 수 없는 transport 는
  // std::invalid_argument (바인딩에서 ValueError).
  void on(const std::string& path, RouteHandler handler,
          const std::optional<std::vector<std::string>>& explicit_routes = std::nullopt);
  // plugin.py::PluginRouter.subscribe — {plugin_id}/{topic} room 구독.
  void subscribe(const std::string& topic, EventHandler handler,
                 const std::optional<std::vector<std::string>>& explicit_events = std::nullopt);
  // plugin.py::PluginRouter.emit — __muscat__/emit 로 pub. 외부는 common/plugin/{id}/{topic} 구독.
  // publish/call 과 마찬가지로 payload 는 항상 명시한다 (없으면 nlohmann::json(nullptr)).
  void emit(const std::string& topic, const nlohmann::json& payload);

 private:
  friend struct PluginRouterBindingAccess;

  // 바인딩 데코레이터용 2단계 — on()/subscribe() 가 데코레이터를 돌려주므로 검증은 즉시
  // (reserve_*), 핸들러 등록은 데코레이터 적용 시점에 (attach_*). 공개 on()/subscribe() 는
  // 이 둘을 이어서 한 번에 부른다.
  std::string reserve_route(const std::string& path,
                            const std::optional<std::vector<std::string>>& explicit_routes);
  void attach_route(const std::string& key, RouteHandler handler);
  std::string reserve_subscription(const std::string& topic,
                                   const std::optional<std::vector<std::string>>& explicit_events);
  void attach_subscription(const std::string& key, EventHandler handler);

  // plugin.py::PluginRouter._allowed — 비었으면 nullopt(전부 허용). trim/lower 후 알 수 없는
  // transport 있으면 std::invalid_argument.
  static std::optional<std::vector<std::string>> allowed_transports(
      const std::optional<std::vector<std::string>>& explicit_list);

  RBPluginCall& call_;
  // key -> transport 게이트(nullopt = 전부). plugin.py self._routes/_subscriptions 겸 _allowed
  // 결과 보관. reserve_* 가 채우고 attach_* 가 읽는다.
  std::unordered_map<std::string, std::optional<std::vector<std::string>>> route_gates_;
  std::unordered_map<std::string, std::optional<std::vector<std::string>>> sub_gates_;
};

}  // namespace rb_plugin
