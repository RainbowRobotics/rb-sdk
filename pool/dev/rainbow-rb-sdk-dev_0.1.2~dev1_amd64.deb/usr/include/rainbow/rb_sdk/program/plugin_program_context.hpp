#pragma once

// plugin_context.py -> plugin_program_context.hpp. 순수 C++ core — pybind11 을 전혀 모른다.
//
// 클래스 선언만 배포한다. 구현(zenoh 토픽 등록, control/execute 핸들러, executor state 캐시)은
// plugin_program_context.cpp 로 분리되어 librb_sdk.so 안에 컴파일된다.
//
// PluginProgramContext 는 "플러그인 프로세스"(플러그인 개발자의 main.py, 또는 C++ 플러그인
// 실행파일) 안에서 도는 헬퍼다. RBProgramSDK(로봇→플러그인)와 반대 방향으로, 플러그인이
// executor 에게 done/pause/stop 을 알리고 프로그램 변수를 조회/설정한다.
//
// 3계층:
//   1. 이 파일 (순수 C++)      — C++ 플러그인이 헤더 include 해서 nlohmann::json + std::function 로 직접 사용
//   2. binding/plugin_program_context_binding.hpp — py::dict <-> nlohmann::json 변환해서 rb_sdk_cpp 로 노출
//   3. program_sdk/plugin_context.py — 위 바인딩을 asyncio(@on_execute / async start) 로 감싼 wrapper
//
// transport 는 nlohmann::json 직렬화 + rb_zenoh::ZenohClient(순수 C++).
//
// C++ 플러그인 main.cpp 예 (plugin_main_example.py 의 C++ 판):
//
//     #include "plugin_program_context.hpp"
//     int main() {
//       rb_plugin::PluginProgramContext ctx("my-plugin");
//       ctx.set_execute_handler([&](const nlohmann::json& args) {
//         std::string msg = args.value("message", "");
//         for (int i = 0; i < 10; ++i) {
//           ctx.check_stop();                       // stop 이면 PluginStopped throw
//           std::this_thread::sleep_for(std::chrono::milliseconds(100));
//         }
//         nlohmann::json counter = ctx.get_variable("counter");
//         ctx.set_variable("result", "done: " + msg);
//         ctx.done();
//       });
//       ctx.start();                                // subscriber+queryable 등록, 블로킹 안 함
//       std::promise<void>().get_future().wait();   // run forever
//     }
//
// core 가 execute 요청마다 detach 스레드를 띄워 핸들러를 돌리므로, 핸들러는 그냥 blocking 코드로
// 쓰면 된다. 핸들러가 던지면(PluginStopped 포함) core 가 executor 에 stop 을 통지한다.

#include <atomic>
#include <chrono>
#include <functional>
#include <map>
#include <mutex>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

#include <flatbuffers/flatbuffers.h>
#include <nlohmann/json.hpp>

#include "rb_sdk_api.hpp"

#include "program_generated.h"  // muscat::Response_Get_Executor_State{,T}
#include "zenoh_client.hpp"     // rb_zenoh::ZenohClient (순수 C++)

namespace rb_plugin {

using nlohmann::json;

// "실행 중"으로 취급하는 executor 상태 / "정지"로 취급하는 상태 (plugin_context.py 와 동일).
inline bool is_active_state(const std::string& s) {
  return s == "running" || s == "waiting" || s == "paused" || s == "post_start";
}
inline bool is_stop_state(const std::string& s) {
  return s == "stopped" || s == "error";
}

// check_stop() 이 stop 감지 시 던진다. Python wrapper 는 이걸 asyncio.CancelledError 로 번역한다.
struct RB_SDK_API PluginStopped : std::runtime_error {
  PluginStopped() : std::runtime_error("program stopped") {}
};

class RB_SDK_API PluginProgramContext {
 public:
  using ExecuteHandler = std::function<void(const json& args)>;
  using StateChangeHandler = std::function<void(const std::string& robot_model, const std::string& state)>;
  // 블로킹 정리(undeclare/join)를 감싸 실행하는 러너. 바인딩이 [](fn){ py::gil_scoped_release; fn(); }
  // 를 넣어준다 — 정리는 Python dealloc(=GIL 보유) 에서 불리는데, join 을 GIL 쥔 채 하면 GIL 이
  // 필요한 exec_thread_/zenoh 콜백과 데드락. C++ 플러그인은 안 넣으면 그냥 직접 실행.
  using BlockingRunner = std::function<void(const std::function<void()>&)>;

  explicit PluginProgramContext(std::string plugin_id);

  PluginProgramContext(const PluginProgramContext&) = delete;
  PluginProgramContext& operator=(const PluginProgramContext&) = delete;

  ~PluginProgramContext();

  void set_execute_handler(ExecuteHandler h);
  void set_state_change_handler(StateChangeHandler h);
  void set_blocking_runner(BlockingRunner r);

  // 정리: 1) stopping_ 로 진행 중 execute 핸들러에게 "그만" 신호. 2) 콜백 끊기(undeclare).
  // 3) exec_thread_ join. idempotent — 바인딩 start() 의 finally 와 ~PluginProgramContext 양쪽에서 불린다.
  void shutdown();

  // 파괴가 시작됐는지 (바인딩 execute 브리지가 무한 대기 방지용으로 폴링).
  bool stopping() const;

  const std::string& plugin_id() const;
  const std::string& control_topic() const;

  // ── execute lifecycle ─────────────────────────────────────────────────────
  // on_execute 처리 시작/끝. Python wrapper 의 _run() 이 감싸며 호출한다.
  void begin_execution(std::optional<std::string> robot_model);
  void end_execution();
  bool in_execute() const;
  std::optional<std::string> exec_robot_model() const;

  // ── 흐름 제어 / 변수 (blocking zenoh query) ────────────────────────────────
  // Step 실행 중 경로: control queryable. done/pause/stop/get_variable/set_variable.
  json send_control(const std::string& action, const json& extra = json::object());

  // send_control 단축 (Python 의 await ctx.done()/pause()/stop() 대응).
  json done();
  json pause();
  json stop();

  // Step 실행 밖 경로: 상시 executor 변수 엔드포인트 (저수준).
  json query_variable_endpoint(const std::string& action, const std::string& name,
                               const std::optional<std::string>& robot_model,
                               const std::optional<std::string>& plugin_id, const json& value = json());

  // ── 변수 조회/설정 (라우팅 포함 — Python wrapper 와 C++ plugin 이 공유) ─────
  // Step 중이면 control topic(자기 프로그램 즉시), 밖이면 상시 endpoint. plugin_context.py 와 동일.
  json get_variable(const std::string& name, const std::optional<std::string>& robot_model = std::nullopt,
                    const std::optional<std::string>& plugin_id = std::nullopt);

  void set_variable(const std::string& name, const json& value);

  // ── 상태 조회 (cheap, 캐시 읽기) ───────────────────────────────────────────
  bool is_stopped(const std::optional<std::string>& robot_model = std::nullopt) const;
  bool is_paused(const std::optional<std::string>& robot_model = std::nullopt) const;
  std::optional<std::string> executor_state_for(const std::string& robot_model) const;
  std::map<std::string, std::string> executor_states() const;

  // C++ plugin 용 blocking check_stop. Python wrapper 는 자기 async 버전을 쓴다(이건 안 씀).
  void check_stop(const std::optional<std::string>& robot_model = std::nullopt);

  // ── start: subscriber + queryable 등록. 블로킹하지 않는다 ──────────────────
  void start();

  bool started() const;

  // 테스트 훅: zenoh 없이 상태 캐시 로직만 검증할 때 executor state 바이트를 직접 주입한다.
  void feed_executor_state_bytes(const std::vector<uint8_t>& payload);

  // 테스트 훅: 위와 같지만 진짜 별도 네이티브 스레드에서 on_executor_state_ 를 태운다.
  void feed_executor_state_bytes_from_native_thread(const std::vector<uint8_t>& payload);

  // 테스트 훅: zenoh queryable 없이 on_execute_ 경로(진짜 exec_thread_ 스폰 포함)를 탄다.
  void feed_execute_request_for_test(const json& args);

 private:
  std::runtime_error error_(const std::string& m) const;
  void require_started() const;

  // payload(json) -> 직렬화 -> query_one -> reply bytes -> json (Python 의 ["dict_payload"] 등가).
  json query_json_(const std::string& topic, const json& payload, int timeout_ms);

  // robot_model 미지정 + on_execute 안이면 자기 step 모델만. 없으면 전체. (plugin_context.py::_model_states)
  std::map<std::string, std::string> model_states_locked_(const std::optional<std::string>& robot_model) const;

  // muscat/executor/state 수신 -> robot model 별 대표 상태 갱신. main task 우선, active 우선.
  void on_executor_state_(const std::vector<uint8_t>& payload);

  // execute 요청 수신 -> 즉시 {"ok":"started"} 반환, 핸들러는 detach 스레드에서.
  void on_execute_(const std::optional<std::vector<uint8_t>>& payload, const rb_zenoh::ReplyFn& reply_fn);

  void safe_notify_(const std::string& action);

  const std::string plugin_id_;
  const std::string execute_topic_;
  const std::string control_topic_;

  ExecuteHandler execute_handler_;
  StateChangeHandler state_change_handler_;
  BlockingRunner blocking_runner_;

  std::shared_ptr<rb_zenoh::ZenohClient> zenoh_;
  int sub_id_ = -1;
  int queryable_id_ = -1;
  std::atomic<bool> started_{false};
  std::atomic<bool> stopping_{false};  // ~PluginProgramContext 진입 신호
  std::thread exec_thread_;             // 진행 중 execute 핸들러 스레드 (~PluginProgramContext 에서 join)
  std::atomic<bool> exec_running_{false};  // exec_thread_ 안에서 핸들러가 실제 실행 중인지

  mutable std::mutex mu_;
  std::map<std::string, std::string> executor_states_;
  std::set<std::string> exec_seen_active_;
  bool in_execute_ = false;
  std::optional<std::string> exec_robot_model_;
};

}  // namespace rb_plugin
