#pragma once

// program.py -> rb_program_sdk.hpp 1차 포팅 초안 (draft). RBProgramSDK 본체.
//
// rb_manipulate_sdk.hpp 와 파일 역할이 다르다: manipulate 는 최상위 애그리게이터 파일
// (rb_sdk/manipulate.py::RBManipulateSDK) 이 11개의 독립된 하위 SDK 클래스(RBManipulateMoveSDK,
// RBManipulateIOSDK, ...)를 멤버로 묶는 구조라 rb_manipulate_sdk.hpp 도 그 형태(멤버 목록)를
// 그대로 옮겼다. program 쪽은 그런 최상위 애그리게이터가 없다 — rb_sdk/ 최상위에 manipulate.py/
// amr.py/rby1.py 는 있어도 program.py 는 없고, program_sdk/program.py 의 RBProgramSDK 하나가
// 그 자체로 최종 SDK 다(program_interface.py 는 클래스가 아니라 RBProgramSDK.interface() 가
// 내부적으로 쓰는 free function 모음). 그래서 이 파일이 곧 RBProgramSDK 본체를 직접 정의한다
// (예전 초안에서는 program_program.hpp 에 클래스를 두고 이 파일은 include 만 했는데, 묶을 대상이
// 없어 순수 pass-through 였으므로 통합했다).

//
// 아직 결정/검증되지 않은 부분:
//  - plugin_execute 의 control queryable 은 base.hpp::zenoh_queryable() 이 declare_queryable() 의
//    int id 를 버리고 topic 만 기록해서(undeclare 불가) 그대로 못 썼다. RBBaseSDK::zenoh_client_
//    (protected 멤버)를 직접 호출해 id 를 붙잡아 undeclare_queryable(id) 까지 짝을 맞췄다.
//  - get_digital_input 의 Python `except ZenohNoReply: return None` 대응: rb_zenoh::ZenohClient
//    C++ core 도 이제 no-reply/error reply 를 전용 예외 타입으로 던진다. 따라서 Python 원본과
//    동일하게 통신 실패만 좁게 잡고, 실제 로컬 오류는 밖으로 흘린다.
//  - call_event_tree 의 trees: list[Step] 은 rb_flow_manager.step.Step (Python 런타임 클래스)이라
//    C++ 쪽 대응 타입이 없다. py::object/py::list 로 그대로 받아 .attr("execute") 를 호출한다.
//  - plugin_execute 의 **user_args 는 py::kwargs 로 받아 payload dict 로 그대로 합친다.
//  - make_script ADVANCED 모드는 Python 원본이 `exec(code, globals, locals)` 를 쓴다. 이 SDK
//    자체가 pybind11 확장이라 인터프리터 안에서 돌므로 별도 C++ 인터프리터가 필요한 게 아니다.
//    스크립트 env(variables/var/update_variable/get_var/done/pause/stop/resume/check_stop/
//    rb_log) 조립은 glue(PyFlowManagerArgsAdapter::run_advanced_script)가 flow_manager_args
//    로 하고, compile/exec + 제한된 __builtins__ 는 flow_manager_args.ctx.run_advanced_script
//    (rb_flow_manager) 로 넘긴다 (rb_flow_manager -> rb_sdk 단방향 의존이라 glue 에서
//    make_builtins_allow_most 를 import 하지 않으려는 것). 스크립트의 rb_log 는 make_script 가
//    넘기는 ProgramLogFn = 이 SDK 자신의 RBBaseSDK::log (base.hpp).
//  - _plugin_execute_locks 는 Python 원본이 "클래스 레벨 dict + lazy lock 초기화"라는 이중 체크
//    락킹을 썼는데, 이는 Python 특유의 초기화 순서 문제를 우회하기 위한 것이었다. C++ 로는 이런
//    문제가 없으므로 magic-static std::mutex 로 단순화했다 — plugin_id 별로 동시 실행을 막는다는
//    관찰 가능한 동작은 동일하다.
//
// plugin_context.py / plugin_main_example.py 는 포팅 대상에서 제외했다: PluginProgramContext 는
// "로봇이 플러그인을 호출하는" RBProgramSDK 와 반대 방향으로, 플러그인 개발자가 자기 프로세스의
// main.py 에서 `from rainbow.rb_sdk import PluginProgramContext` 로 직접 import 해 쓰는 순수 Python
// 헬퍼다. RBProgramSDK 바인딩 모듈(pybind11 확장, C++ 프로세스 내부에서 도는 쪽)에 넣을 이유가
// 없고 manipulate_sdk 마이그레이션에도 이런 역방향 클래스를 포팅한 선례가 없다.
//
// 바인딩: scripts/backend/gen_rb_sdk_binding.py 가 litgen(실제 C++ 파서)으로 cpp/manipulate/*.hpp
// 를 스캔해 binding.cpp 를 완전 자동 생성하는 구조로 재작성돼 있다(커밋 d37155bb). 지금 디스크의
// binding.cpp 는 그 이전(수동 bind_manipulate/bind_base 분리) 버전이 남아있어 stale 하다 — 최근
// SDK 헤더 변경 이후로 make backend.sdk-pybind 가 재실행되지 않은 것으로 보인다. 이 상황에서
// program 전용 program_binding.hpp 를 손으로 새로 만드는 건 곧 사라질 옛 구조를 따라가는 셈이라,
// 대신 gen_rb_sdk_binding.py 자체가 cpp/program/*.hpp 도 스캔하도록 확장했다 — 나중에 실제로
// make backend.sdk-pybind 를 돌리면(flatc 산출물 + litgen 필요, 이 환경엔 없어 여기선 실행 못 함)
// RBProgramSDK 도 자동으로 바인딩에 포함된다.
// litgen 은 RBBaseSDK(zenoh/템플릿 많아 파싱 불가)를 못 읽으므로, log() 처럼 상속만 받고 재선언
// 안 한 메서드는 바인딩에서 빠진다 — rb_manipulate_sdk.hpp::connect() 와 동일한 이유로 log() 를
// 한 줄 forward 로 재선언해뒀다(아래 log()).
// docstring: DOC()/docstrings.h 매크로는 litgen 이전 구조의 흔적이라 새 파이프라인에서는 안 쓰인다
// — litgen 이 각 메서드 바로 위 Doxygen(/** ... */, @param/@return/@throws/@note) 주석을 그대로
// 파이썬 docstring 으로 박아 넣는다. 이 파일의 public 메서드들에 최신 manipulate_move.hpp 와 같은
// 스타일로 Doxygen 주석을 달아뒀다.

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <functional>
#include <iostream>
#include <memory>
#include <mutex>
#include <optional>
#include <sstream>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include <nlohmann/json.hpp>  // user_select 의 content 직렬화

#include "base.hpp"
#include "flow_manager_args.hpp"
#include "func_get_generated.h"  // IPC::Request_Get_Digital_Input{,T} (get_digital_input() 에서 사용)
#include "binding/glue/gil_release.hpp"
#include "program_generated.h"

#include "interface_payload_schema.hpp"
#include "program_interface.hpp"
#include "rpc_manager.h"  // RpcManagerRegistry(아래) 가 RpcManager/RpcLogCallback 을 직접 쓴다.
#include "common/value_validation.hpp"

#include "rb_sdk_api.hpp"

// module_name(PFM 의 task_id) 별로 독립된 RpcManager 를 소유/관리한다. python 원본
// (program_sdk/program.py, program_sdk/program_interface.py, program_sdk/__init__.py)에서도
// client_modules.RpcManager 는 program 도메인 전용이었고 manipulate/amr 등 다른 도메인은 쓰지
// 않는다 - base.hpp::VisionClientRegistry(mechmind/photoneo/pickit, manipulate 뿐 아니라 다른
// 도메인도 재사용) 와 달리 이건 RBBaseSDK 공용으로 올릴 근거가 없어 RBProgramSDK 전용으로 둔다.
// VisionClientRegistry 와 달리 RpcManager 는 connect()/is_connected() 개념이 없다 - 내부적으로
// (module, ip:port) 조합마다 세션을 lazy 하게 만들어 관리한다(get_or_create_session, rpc_manager.h).
// module_name 별로 별도 인스턴스를 두는 이유는 세션 재사용이 아니라 로그 콜백에 module_name
// 접두사를 붙이기 위함이다(Python 원본 RBProgramSDK._get_rpc 의 동작 그대로 - 아래 get_rpc 참고).
class RB_SDK_API RpcManagerRegistry {
 public:
  RpcManager* get(const std::string& module_name) {
    auto it = managers_.find(module_name);
    return it == managers_.end() ? nullptr : it->second.get();
  }

  RpcManager& get_or_create(const std::string& module_name, RpcLogCallback log_cb = nullptr);

  void disconnect_all();

 private:
  std::unordered_map<std::string, std::unique_ptr<RpcManager>> managers_;
};

// wait() 의 digital_input 조건 (base_schema.py::DigitalInputConditionSchema).
// dict <-> 이 struct 변환은 binding/glue/program_wait_caster.hpp 의 type_caster 가 한다.
struct ProgramDigitalInputCondition {
  std::vector<int> signal;
  std::string logical_operator = "AND";  // "AND" | "OR"
};

class RB_SDK_API RBProgramSDK : public RBBaseSDK {
 public:
  RBProgramSDK();

  // before_close() 는 RBBaseSDK::close() 가 자기 자신의 소멸자에서 불릴 때만 가상 디스패치로
  // override 가 걸린다(base.hpp::before_close() 주석 참고) — 그래서 close() 를 직접 부르는
  // 소멸자를 여기 따로 선언해야 rpc_managers_(base.hpp) 의 RpcManager 들이 실제로 정리된다.
  ~RBProgramSDK() override;

  static std::string type_name() { return "RBProgramSDK"; }

  // RpcManager 워커 스레드의 로그를 rb_log 로 흘려보내는 sink. get_rpc() 가 만드는
  // RpcLogCallback 이 이걸 부른다 — 캐시된 RpcManager 가 호출보다 오래 살고 워커
  // 스레드에서 불리므로, Python 객체(rb_log)를 잡는 건 프로세스 전역 sink 쪽이어야
  // 한다(fm 파생 아님). binding/glue/rpc_log_sink.hpp::install_rpc_log_sink() 가
  // pybind 경계에서 1회 설치. 미설치 시 get_rpc 는 stderr 로 폴백.
  using RpcLogSink = std::function<void(LogType type, const std::string& module_name, const std::string& message)>;

  static void set_rpc_log_sink(RpcLogSink sink) { rpc_log_sink_ = std::move(sink); }

  // Re-declare the inherited log() here so litgen (which never parses the
  // zenoh/template-heavy RBBaseSDK base header) sees it and binds it directly
  // -- same pattern as RBManipulateSDK::connect() in rb_manipulate_sdk.hpp.
  /**
   * Emits a program log entry.
   *
   * @param content Log message content.
   * @param robot_model Name of the robot model this log entry is associated with.
   * @param level Log level ("INFO", "WARNING", "ERROR", "USER", "DEBUG", or "GENERAL").
   * @param disable_db Unused (kept for parity with the Python original, which also
   *        never reads this parameter).
   * @param flow_manager_args Optional PyFM step context. If provided, the step is
   *        marked done immediately after the log entry is published.
   */
  void log(const std::string& content, const std::string& robot_model, const std::string& level,
           bool disable_db = false, FlowManagerArgsPtr flow_manager_args = nullptr) {
    RBBaseSDK::log(content, robot_model, level, disable_db, flow_manager_args);
  }

  /**
   * Returns the RpcManager registered for @p module_name in this SDK's own
   * RpcManagerRegistry (rpc_managers_, defined above this class), creating
   * one (with a log callback bridged to rb_log) on first use.
   *
   * Public (not `_`-prefixed) so it's individually bindable, mirroring
   * manipulate_vision.hpp::execute_mechmind_connect(): rb_program_interface's
   * execute_* free functions (program_interface.hpp) take an RpcManager&
   * directly, so a Python caller wanting to call them standalone (instead of
   * through interface()) needs a way to obtain that reference first.
   *
   * @param module_name PFM task id used as the RpcManager cache key.
   * @return The RpcManager instance for @p module_name, owned by rpc_managers_.
   */
  RpcManager& get_rpc(const std::string& module_name);

  // ---------------------------------------------------------------------
  // 변수 / 스크립트
  // ---------------------------------------------------------------------

  /**
   * Initializes local task variables from their configured init values.
   *
   * @param variables List of variable definition dicts, each carrying an
   *        "init_value" key, in the same order as the task's declared variables.
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything — if omitted, returns immediately without
   *        touching @p variables. When provided, each variable is applied
   *        via @p flow_manager_args's local variable updater and the step
   *        is marked done afterwards.
   */
  void set_variables(const nlohmann::json& variables, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Runs a program script step, in either GENERAL or ADVANCED mode.
   *
   * In GENERAL mode, @p flow_manager_args's "general_contents" argument is
   * evaluated as a single expression against the step's context (assignments
   * are reflected into state). In ADVANCED mode, @p contents is compiled and
   * executed as an arbitrary python script with `variables`/`var`,
   * `update_variable`/`update_var`, `get_var`, `done`, `pause`, `stop`,
   * `resume`, `check_stop`, and `rb_log` injected into its globals (the bridge
   * builds that env from @p flow_manager_args; compile/exec runs on the PyFM
   * side in ctx.run_advanced_script). `rb_log` is this SDK's own log
   * (RBBaseSDK::log), called as `rb_log(content, robot_model, level)`.
   *
   * @param mode "GENERAL" or "ADVANCED".
   * @param contents ADVANCED-mode script source. Required when @p mode is
   *        "ADVANCED".
   * @param flow_manager_args PyFM step context. Required; the step is marked
   *        done when the script finishes (or immediately raises, in ADVANCED
   *        mode, since the step is still marked done before the exception
   *        propagates).
   *
   * @throws std::runtime_error If GENERAL mode is missing
   *         "general_contents", or ADVANCED mode is missing @p contents.
   */
  void make_script(const std::string& mode /* GENERAL|ADVANCED */, std::optional<std::string> contents,
                   FlowManagerArgsPtr flow_manager_args = nullptr);

  // ---------------------------------------------------------------------
  // wait 계열
  // ---------------------------------------------------------------------

  /**
   * Blocks the calling thread for @p second seconds, polling for stop/pause
   * requests every 1/50s. Time spent blocked inside a pause is excluded from
   * the wait duration.
   *
   * @param second Seconds to wait. Must be greater than 0 when
   *        @p flow_manager_args is not provided (a standalone caller has no
   *        other way to be notified that the wait was skipped).
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done once the wait elapses (or immediately, if
   *        @p second <= 0).
   *
   * @throws std::runtime_error If @p second <= 0 and @p flow_manager_args is
   *         not provided.
   */
  void simple_wait(double second, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Pauses every running program process on this robot.
   *
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step's own execution context is paused too, after the broadcast
   *        pause request.
   */
  void all_pause(FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Stops every running program process on this robot.
   *
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done after the broadcast stop request.
   */
  void all_stop(FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Publishes a program dialog alarm.
   *
   * @param title Dialog title. Falls back to "No Title" when empty.
   * @param content Dialog content.
   * @param robot_model Name of the robot model.
   * @param flow_manager_args Optional PyFM step context. If provided, the
   *        step is marked done immediately after the alarm is published.
   */
  void alarm(const std::string& title, const std::string& content, const std::string& robot_model,
             FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Raises an alarm and/or halts execution, depending on @p option.
   *
   * @param robot_model Name of the robot model.
   * @param option "ALARM" (publish an alarm dialog), "HALT" (stop the step's
   *        context), "FOLDER_HALT" (break out of the enclosing folder), or
   *        "SUB_PROGRAM_HALT" (halt the enclosing sub task).
   * @param save_log If true, also emits a USER-level log entry with
   *        @p content (or @p title if @p content is None).
   * @param is_only_at_ui If true and the step is not running from a UI
   *        execution, the step is marked done and this call is a no-op.
   * @param pause_option "ALL" (pause every process) or "CURRENT" (pause only
   *        this context). Only consulted when @p option resolves to a pause.
   * @param title Alarm dialog title (used when @p option is "ALARM", and as
   *        the log fallback content when @p save_log is set and @p content
   *        is None).
   * @param content Alarm dialog / log content.
   * @param flow_manager_args PyFM step context. Required; the step is marked
   *        done after the alarm/halt/pause sequence completes.
   */
  void alarm_or_halt(const std::string& robot_model, const std::string& option, bool save_log, bool is_only_at_ui,
                     const std::string& pause_option, const nlohmann::json& title, const nlohmann::json& content,
                     FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Reports the current values of @p variables for debugging, then pauses.
   *
   * Compares each variable's raw (pre-evaluation) string against its
   * evaluated JSON value; numeric values/lists are rounded to 3 decimals for
   * display, and unchanged variables are reported as "Undefined".
   *
   * @param robot_model Name of the robot model.
   * @param option "DIALOG" (publish a single alarm dialog listing every
   *        variable) or "LOG" (emit one USER-level log entry per variable).
   * @param is_only_at_ui If true and the step is not running from a UI
   *        execution, the step is marked done and this call is a no-op.
   * @param variables Evaluated current variable values, in the same order as
   *        @p flow_manager_args's raw "variables" list.
   * @param log_content Optional extra USER-level log entry (any value; non-str
   *        is JSON-encoded) appended after the per-variable LOG entries.
   * @param pause_option "ALL" (pause every process) or "CURRENT" (pause only
   *        this context).
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything; the step is marked done after pausing.
   */
  void debug_variables(const std::string& robot_model, const std::string& option, bool is_only_at_ui,
                       const nlohmann::json& variables, const nlohmann::json& log_content,
                       const std::string& pause_option, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Publishes a "user input" prompt dialog and pauses the step until the
   * operator supplies a value (resumed out-of-band via the program
   * service's change_user_input_value endpoint).
   *
   * Mirrors program.py::RBProgramSDK.user_input: the dialog content is
   * `"{raw var_selection arg} ({resolved var_selection})"` — the raw name
   * comes from `flow_manager_args.args["var_selection"]` (pre-substitution)
   * and the resolved value from the @p var_selection parameter.
   *
   * @param robot_model Name of the robot model.
   * @param var_form Input widget kind: "STRING" (default), "NUMERIC",
   *        "BOOLEAN", "LIST", "DICTIONARY", or "VAR". Only used to tag the
   *        alarm title (`USER_INPUT_{var_form}`).
   * @param var_selection Resolved value of the target variable. PyFM evaluates
   *        the step's `var_selection` expression before the call, so this can
   *        arrive as any Python type (int/float/list/dict, ...), not only str —
   *        it is stringified here, mirroring the Python original's f-string.
   * @param flow_manager_args PyFM step context. When provided, the step's
   *        context is paused, checked for stop, and marked done.
   */
  void user_input(const std::string& robot_model, const nlohmann::json& var_selection, const std::string& var_form,
                  FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Publishes a "user select" prompt dialog and pauses the step until the
   * operator picks one of @p content (resumed out-of-band via the program
   * service's set_user_select_value endpoint).
   *
   * Mirrors program.py::RBProgramSDK.user_select: the dialog content is
   * `json.dumps([var_name, timeout, disconn_timeout, content])`.
   *
   * @param robot_model Name of the robot model.
   * @param ask_ment Prompt text, used to tag the alarm title
   *        (`USER_SELECT_{ask_ment}`).
   * @param var_name Name of the variable that will receive the choice.
   * @param content Selectable option strings.
   * @param timeout Seconds before the select auto-resolves.
   * @param disconn_timeout Behavior label when the operator UI disconnects.
   * @param flow_manager_args PyFM step context. When provided, the step's
   *        context is paused, checked for stop, and marked done.
   *
   * @note ask_ment/var_name/content/timeout/disconn_timeout arrive as values
   *       PyFM produced by evaluating the step's args, so their runtime types
   *       are not fixed (e.g. a `"60"` arg resolves to int 60, `"0"` to int 0).
   *       They are taken as py::object and normalized to the expected C++ type
   *       here before the (unchanged) nlohmann serialization, so a NUMERIC /
   *       other-typed variable no longer trips the pybind11 argument check.
   */
  void user_select(const std::string& robot_model, const nlohmann::json& ask_ment, const nlohmann::json& var_name,
                   const nlohmann::json& content, const nlohmann::json& timeout, const nlohmann::json& disconn_timeout,
                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Queries the digital input state of @p robot_model.
   *
   * @param robot_model Name of the robot model.
   * @return The digital input list, or std::nullopt if the robot has no
   *         `{robot_model}/get_digital_input` zenoh queryable (e.g. not
   *         connected / not running).
   */
  std::optional<std::vector<int8_t>> get_digital_input(const std::string& robot_model);

  // ---------------------------------------------------------------------
  // Interface (MC/XGT/Modbus/Socket)
  // ---------------------------------------------------------------------
  //
  // 개별 프로토콜 호출(execute_modbus_read 등)은 여기 RBProgramSDK 에 thin wrapper 로 올리지 않는다 -
  // program_interface.hpp::rb_program_interface::execute_* free function 이 이미 RpcResult(대부분)/
  // bool(execute_socket_connect)을 그대로 반환하므로, binding/program_binding.hpp 가 그 free
  // function 들을 module 레벨 함수로 직접 바인딩해서 개별 호출을 지원한다 - get_rpc(module_name) 을
  // 먼저 호출해 RpcManager& 를 얻은 뒤 그 free function 들에 넘기는 게 python 쪽 사용 패턴이다
  // (vision.hpp::execute_mechmind_connect 가 client 포인터를 반환하고 이후 호출들이 그 포인터를
  // 받는 것과 유사하되, 여기서는 "연결"이 아니라 registry 조회이므로 get_rpc() 가 그 역할).
  // interface() 자신은 그대로 (rpc 변수 하나로) free function 을 직접 호출한다.

  /**
   * Dispatches a protocol interface call (Modbus/MC/XGT/socket) via the
   * native RpcManager cached for this step's task id (rpc_managers_).
   *
   * @param option "MODBUS_CLIENT", "MC_PROTOCOL", "XGT_PROTOCOL", or
   *        "SOCKET_INTERFACE".
   * @param data Protocol payload generated from program.fbs. Must contain a
   *        non-empty "server_ip" and a "type" of "READ"/"WRITE" (plus
   *        "CONNECT" for SOCKET_INTERFACE).
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything — if omitted, returns immediately without
   *        dispatching to any protocol. When provided, it's forwarded to
   *        the underlying execute_* call and the step is marked done after
   *        dispatch.
   *
   * @throws std::runtime_error If @p option or @p data["type"] is
   *         unsupported for the given @p option.
   */
  void interface(const std::string& option, muscat::InterfacePayloadUnion data,
                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Blocks until the requested wait condition is satisfied (or times out),
   * polling for stop requests every 10ms.
   *
   * @param robot_model Name of the robot model (used for DIGITAL_INPUT
   *        polling).
   * @param wait_type "TIME" (delegates to simple_wait()), "HOLDING" (wait
   *        while the condition holds), or "EXIT" (wait until the condition
   *        becomes true / the digital input matches).
   * @param mode "GENERAL" (evaluate @p flow_manager_args's "condition"
   *        expression) or "DIGITAL_INPUT" (poll get_digital_input() against
   *        @p digital_input's expected signal pattern).
   * @param second Wait duration in seconds, used only when @p wait_type is
   *        "TIME".
   * @param digital_input Digital input condition dict ("signal" list and
   *        optional "logical_operator", "AND" by default). Required when
   *        @p mode is "DIGITAL_INPUT".
   * @param time_out Optional timeout in seconds; the wait loop breaks once
   *        elapsed time reaches this value, regardless of whether the
   *        condition was satisfied.
   * @param flow_manager_args Optional PyFM step context. Required for this
   *        call to do anything — if omitted, returns immediately without
   *        waiting (despite the default of py::none(), calling this
   *        standalone is a no-op). The step is marked done once the wait
   *        loop exits.
   */
  void wait(const std::string& robot_model, const std::string& wait_type, const std::string& mode,
            std::optional<double> second, std::optional<ProgramDigitalInputCondition> digital_input,
            std::optional<double> time_out, FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * Changes the running program and immediately starts it (program.py::change_program).
   *
   * Sends a Request_Change_Program to the "muscat/change/program" queryable
   * and waits (up to 20s — the handler can take several seconds) for a
   * ResponseProgramExecution. Either @p program_id or @p program_name must
   * be given.
   *
   * @param program_id Target program id (mutually optional with @p program_name).
   * @param program_name Target program name.
   * @param flow_manager_args PyFM step context. Required — raises if omitted.
   *        The step is marked done once the change is accepted.
   *
   * @throws std::runtime_error If @p flow_manager_args is omitted, if
   *         neither @p program_id nor @p program_name is given, or if the
   *         change/start request gets no (usable) reply.
   */
  void change_program(std::optional<std::string> program_id, std::optional<std::string> program_name,
                      FlowManagerArgsPtr flow_manager_args = nullptr);

  // ---------------------------------------------------------------------
  // Event tree / plugin
  // ---------------------------------------------------------------------
  //
  // call_event_tree 는 rb_flow_manager.step.Step (Python 런타임 클래스) 리스트를 직접
  // 받아야 해서 이 순수 C++ 헤더에 없다 — binding/glue/event_tree.hpp::call_event_tree
  // 자유함수로 옮겼다.

  /**
   * Sends an execute request to a plugin process and waits until it reports
   * completion (or stop). Concurrent calls for the same @p plugin_id are
   * serialized so their control queryables don't collide.
   *
   * @param plugin_id Target plugin id; the request is sent to
   *        "muscat/plugin/{plugin_id}/execute" and control messages are
   *        exchanged over "muscat/plugin/{plugin_id}/control".
   * @param user_args Execute request JSON object (Python 바인딩은 `**kwargs` 를 여기로 모아 넘긴다).
   * @param flow_manager_args PyFM step context. Required; the step is marked
   *        done once the plugin reports "done" (directly, or by exiting its
   *        control loop after "stop").
   *
   * @throws std::runtime_error If @p flow_manager_args is not provided, or
   *         if the plugin is not running/responding to the execute request.
   */
  void plugin_execute(const std::string& plugin_id, FlowManagerArgsPtr flow_manager_args = nullptr,
                      const nlohmann::json& user_args = nlohmann::json::object());

 private:
  RB_SDK_LOCAL void _plugin_execute_locked(const std::string& plugin_id, const FlowManagerArgsPtr& flow_manager_args,
                              const nlohmann::json& user_args);

 public:
  /**
   * Disconnects every RpcManager module cached in rpc_managers_ before the
   * SDK instance is closed.
   */
  void before_close() override;

 private:
  // program 도메인 전용 (RpcManagerRegistry 주석 참고) - VisionClientRegistry 처럼 RBBaseSDK 공용으로
  // 두지 않고 RBProgramSDK 가 직접 소유한다.
  RpcManagerRegistry rpc_managers_;

  inline static RpcLogSink rpc_log_sink_ = nullptr;
};
