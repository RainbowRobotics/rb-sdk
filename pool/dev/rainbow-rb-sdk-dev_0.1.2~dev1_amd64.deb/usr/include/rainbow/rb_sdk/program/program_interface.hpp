#pragma once

// program_interface.py -> program_interface.hpp 1차 포팅 초안 (draft).
//
// manipulate_vision.hpp 구조 참고: manipulate_vision.py 는 이미 Python 단계에서 벤더 클라이언트
// 호출을 "연결 확인 -> call_fn 호출/예외처리 -> 실패 시 resolve_interface_flow -> 성공 시 ctx
// 변수 반영 -> done()" 공통 wrapper(_run_mechmind_read_call / _run_mechmind_write_call /
// _run_photoneo_client_call)로 묶어뒀고, vision.hpp 는 그 구조를 그대로 C++ 로 옮겼다.
//
// program_interface.py 는 반대로 이 tail 부분(resolve_interface_flow 판정 + 변수 반영 + done())을
// 8개 execute_* 함수에 그대로 복붙해뒀다. 다만 vision 과 달리 여기서는 벤더가 3개(MechMind/
// Photoneo/Pickit)로 갈려 성공 판정 로직이 제각각인 것과 달리, client_modules.pyi 를 보면
// RpcResult.success 가 Modbus/MC/XGT/Socket(recv/send) 전부 균일하다(connect_sock 만 예외적으로
// bool 을 직접 리턴). 그래서 vision.hpp 처럼 벤더별로 wrapper 를 나누지 않고 공통 tail 하나
// (_finish_protocol_call)로 합쳤다.
//
// return_variable_name(4개 read 함수 공통)은 이 파일에서 직접 조회하지 않는다 — PyFM 의 변수 치환이
// "결과를 어디에 쓸지" 지정하는 이 필드까지 값 내용만 보고 덮어써버릴 수 있어서
// (flow_manager_args.hpp::raw_data_field 주석 참고), 호출부인 RBProgramSDK::interface() 가 dict->struct
// 캐스팅 직후 원본(raw) 값으로 payload.return_variable_name 을 미리 덮어쓰고, require() 로 뽑아낸 값을
// 이 파일의 explicit return_variable_name 파라미터로 그대로 넘겨준다.
//
// rpc 파라미터: lib/Client_Module/rb_comm_source/rpc_manager.cpp 가 native C++ 소스로 rb_sdk 에
// 직접 추가되면서(CMakeLists.txt add_subdirectory), 예전에 여기 있던 client_modules.hpp
// (py::module_::import("rb_sdk.program_sdk.client_modules") 브리지, 이 아키텍처용 prebuilt .so 가
// 없으면 기능을 죽이던 fallback)를 걷어내고 rb_program_sdk.hpp::RpcManagerRegistry 가 들고 있는
// 실제 RpcManager& 를 그대로 받는다. vision 벤더 클라이언트(mechmind/photoneo/pickit)는 manipulate
// 뿐 아니라 다른 도메인도 재사용할 근거가 있어 base.hpp::VisionClientRegistry 로 공용화됐지만,
// client_modules.RpcManager 는 python 원본(program_sdk/*)에서도 program 도메인 전용이었어서
// RpcManagerRegistry 는 base.hpp 가 아니라 RBProgramSDK 가 직접 소유한다(rb_program_sdk.hpp 참고).
// McDeviceType/McFrameType/... 등 enum 리졸버도 rb_client_modules::attr(...) 대신 rpc_manager.h 가
// transitively 끌어오는 네이티브 enum(mc_types.h/xgt_types.h/modbus_types.h)을 직접 반환한다.
//
// Boundary contract (intentional): PyFM 이 dict 로 넘기는 RBProgramSDK::interface() 는 지금도
// dict->struct(muscat::Interface*PayloadT) 캐스팅과
// require()/resolve_option_of() 를 거쳐 "필수인데 없음"을 검증한 뒤, 이 파일의 explicit 파라미터로
// 풀어서 넘긴다 — vision.hpp::execute_mechmind_trigger_and_get_poses 와 동일한 스타일로, 이 파일의
// execute_* 함수들은 struct/dict 를 직접 받지 않고 개별 타입 있는 파라미터만 받는다(pybind11/향후
// 다른 언어 바인딩에서도 시그니처만 보고 계약을 알 수 있게). WRITE payload 는 순수 C++ DTO
// rb_payload::WriteRegisterValues 로 받는다 — bool 거부/혼합·중첩 리스트 평탄화는
// interface_payload_caster.hpp 의 type_caster 가 하고, 여기 _validate_payload_field 는
// 범위/길이/allowed 만 본다.
//
// flow_manager_args(FlowManagerArgsPtr, nullptr 면 단독 호출): 이 파일은 pybind 에 의존하지
// 않는다. PyFM step context 는 flow_manager_args.hpp 의 FlowManagerArgs/FlowManagerContext
// 가상 브릿지로 직접 만진다(flow_manager_args->done(), ->context().update_local_variables(...) 등;
// 구현체는 pybind 경계 binding/glue/flow_manager_caster.hpp). 실패 처리 정책은
// flow_manager_args.hpp::resolve_interface_flow 하나를 공유한다. 블로킹 rpc 왕복 동안의 GIL
// 해제는 binding/glue/gil_release.hpp 의 rb_sdk::gil_release_if_held (바인딩이 훅 주입, 순수 C++ 은 no-op).
//

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

#include "flow_manager_args.hpp"
#include "binding/glue/gil_release.hpp"
#include "interface_payload_schema.hpp"
#include "rpc_manager.h"
#include "rb_sdk_api.hpp"

#include "common/value_validation.hpp"

namespace rb_program_interface {
// ---------------------------------------------------------------------------
// execute_* (program_interface.py 모듈 전역 함수 대응)
// ---------------------------------------------------------------------------

/**
 * @brief Reads Modbus holding or input registers.
 *
 * @p function_code selects the register type: 3 reads holding registers
 * (READ_HOLDING), 4 reads input registers (READ_INPUT).
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip Modbus server IP address.
 * @param server_port Modbus server port.
 * @param function_code 3 (READ_HOLDING) or 4 (READ_INPUT).
 * @param register_addr Starting register address to read from.
 * @param number_of_read Number of registers to read.
 * @param return_variable_name PyFM variable name that will receive the
 *        read registers (@c RpcResult::regs).
 * @param resolve_option How to handle a failed read — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param timeout_sec Read timeout in seconds. Defaults to 1.0.
 * @param flow_manager_args Optional PyFM step context. @p
 *        return_variable_name is written into its context and
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the read failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call (success flag plus the read
 *         registers in @c regs).
 *
 * @throws std::runtime_error If @p function_code is not 3 or 4; and,
 *         under "STOP", if the read fails.
 */
RB_SDK_API RpcResult execute_modbus_read(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                     int server_port, int function_code, int register_addr, int number_of_read,
                                     const std::string& return_variable_name,
                                     const std::string& resolve_option = "SKIP", double timeout_sec = 1.0,
                                     FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

/**
 * @brief Writes Modbus holding registers.
 *
 * @p function_code selects the write mode: 6 writes a single register
 * (WRITE_SINGLE_REG), 16 writes multiple registers (WRITE_MULTI_REGS).
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip Modbus server IP address.
 * @param server_port Modbus server port.
 * @param function_code 6 (WRITE_SINGLE_REG) or 16 (WRITE_MULTI_REGS).
 * @param register_addr Starting register address to write to.
 * @param payload_field List of register values to write (1-40 entries,
 *        each in [0, 65535]).
 * @param resolve_option How to handle a failed write — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param timeout_sec Write timeout in seconds. Defaults to 1.0.
 * @param flow_manager_args Optional PyFM step context.
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the write failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call.
 *
 * @throws std::runtime_error If @p function_code is not 6 or 16, or
 *         @p payload_field is missing/out of range; and, under "STOP",
 *         if the write fails.
 */
RB_SDK_API RpcResult execute_modbus_write(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                      int server_port, int function_code, int register_addr,
                                      const std::optional<rb_payload::WriteRegisterValues>& payload_field,
                                      const std::string& resolve_option = "SKIP", double timeout_sec = 1.0,
                                      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

/**
 * @brief Reads MC (Mitsubishi) protocol device values.
 *
 * @p function_code selects the command: 1 reads bit devices (read_bit),
 * 2 reads word devices (read_word). @p address_type and @p protocol
 * resolve the target McDeviceType and McFrameType respectively. The
 * result is always taken from @c RpcResult::data_word — unlike the
 * Python original's `data_word or data_bit` fallback, a bit read does
 * not fall back to @c data_bit (matches the current C++ behavior).
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip MC server IP address.
 * @param server_port MC server port.
 * @param register_addr Starting device address to read from.
 * @param address_type Device type: "1"/"D", "2"/"M", "3"/"X", or "4"/"Y".
 * @param protocol MC frame type: "1"/"MC_1E" or "2"/"MC_3E".
 * @param function_code 1 (read_bit) or 2 (read_word).
 * @param number_of_read Number of devices to read.
 * @param return_variable_name PyFM variable name that will receive the
 *        read values (@c RpcResult::data_word).
 * @param resolve_option How to handle a failed read — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param flow_manager_args Optional PyFM step context. @p
 *        return_variable_name is written into its context and
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the read failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call (success flag plus the read
 *         values in @c data_word).
 *
 * @throws std::runtime_error If @p function_code is not 1 or 2, or
 *         @p address_type/@p protocol cannot be resolved; and, under
 *         "STOP", if the read fails.
 */
RB_SDK_API RpcResult execute_mc_read(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                 int server_port, int register_addr, const std::string& address_type,
                                 const std::string& protocol, int function_code, int number_of_read,
                                 const std::string& return_variable_name, const std::string& resolve_option = "SKIP",
                                 FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

/**
 * @brief Writes MC (Mitsubishi) protocol device values.
 *
 * @p function_code selects the command: 3 writes bit devices (write_bit,
 * @p payload_field values restricted to 0/1), 4 writes word devices
 * (write_word, @p payload_field values restricted to
 * [-32768, 32767]). @p address_type also determines which native buffer
 * the payload is sent through: "1"/"D" (word device) uses write_word,
 * "2"/"3"/"4" or "M"/"X"/"Y" (bit devices) use write_bit.
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip MC server IP address.
 * @param server_port MC server port.
 * @param register_addr Starting device address to write to.
 * @param address_type Device type: "1"/"D", "2"/"M", "3"/"X", or "4"/"Y".
 * @param protocol MC frame type: "1"/"MC_1E" or "2"/"MC_3E".
 * @param function_code 3 (write_bit) or 4 (write_word).
 * @param payload_field List of values to write (1-40 entries), range
 *        depends on @p function_code as described above.
 * @param resolve_option How to handle a failed write — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param flow_manager_args Optional PyFM step context.
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the write failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call.
 *
 * @throws std::runtime_error If @p function_code is not 3 or 4, @p
 *         address_type/@p protocol cannot be resolved, or @p
 *         payload_field is missing/out of range; and, under "STOP", if
 *         the write fails.
 */
RB_SDK_API RpcResult execute_mc_write(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                  int server_port, int register_addr, const std::string& address_type,
                                  const std::string& protocol, int function_code,
                                  const std::optional<rb_payload::WriteRegisterValues>& payload_field,
                                  const std::string& resolve_option = "SKIP",
                                  FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

/**
 * @brief Reads XGT (LS Electric) protocol device values.
 *
 * Only @p function_code 1 (read_byte) is currently supported. @p
 * cpu_type and @p device_type resolve the target XgtCPUinfo and
 * XgtDeviceType respectively.
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip XGT server IP address.
 * @param server_port XGT server port.
 * @param register_addr Starting device address to read from.
 * @param cpu_type CPU type: "XGK", "XGI", "XBC", "XEC", or "NONE".
 * @param device_type Device type; only "DB" is currently supported.
 * @param function_code Must be 1 (read_byte).
 * @param number_of_read Number of devices to read.
 * @param return_variable_name PyFM variable name that will receive the
 *        read values (@c RpcResult::data_word_xgt).
 * @param resolve_option How to handle a failed read — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param flow_manager_args Optional PyFM step context. @p
 *        return_variable_name is written into its context and
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the read failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call (success flag plus the read
 *         values in @c data_word_xgt).
 *
 * @throws std::runtime_error If @p function_code is not 1, or @p
 *         cpu_type/@p device_type cannot be resolved; and, under
 *         "STOP", if the read fails.
 */
RB_SDK_API RpcResult execute_xgt_read(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                  int server_port, int register_addr, const std::string& cpu_type,
                                  const std::string& device_type, int function_code, int number_of_read,
                                  const std::string& return_variable_name, const std::string& resolve_option = "SKIP",
                                  FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

/**
 * @brief Writes XGT (LS Electric) protocol device values.
 *
 * Only @p function_code 3 (write_byte) is currently supported. @p
 * cpu_type and @p device_type resolve the target XgtCPUinfo and
 * XgtDeviceType respectively.
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip XGT server IP address.
 * @param server_port XGT server port.
 * @param register_addr Starting device address to write to.
 * @param cpu_type CPU type: "XGK", "XGI", "XBC", "XEC", or "NONE".
 * @param device_type Device type; only "DB" is currently supported.
 * @param function_code Must be 3 (write_byte).
 * @param payload_field List of values to write (1-40 entries, each in
 *        [-32768, 32767]).
 * @param resolve_option How to handle a failed write — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param flow_manager_args Optional PyFM step context.
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the write failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call.
 *
 * @throws std::runtime_error If @p function_code is not 3, @p
 *         cpu_type/@p device_type cannot be resolved, or @p
 *         payload_field is missing/out of range; and, under "STOP", if
 *         the write fails.
 */
RB_SDK_API RpcResult execute_xgt_write(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                   int server_port, int register_addr, const std::string& cpu_type,
                                   const std::string& device_type, int function_code,
                                   const std::optional<rb_payload::WriteRegisterValues>& payload_field,
                                   const std::string& resolve_option = "SKIP",
                                   FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

/**
 * @brief Receives data over a socket connection.
 *
 * @p function_code selects how the received payload is decoded before
 * being stored: 1 keeps it as the raw byte list, 2 decodes it as a
 * UTF-8 string.
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip Socket server IP address.
 * @param server_port Socket server port.
 * @param function_code 1 (raw bytes) or 2 (UTF-8 string).
 * @param return_variable_name PyFM variable name that will receive the
 *        decoded payload.
 * @param resolve_option How to handle a failed receive — "SKIP"
 *        continues without effect, "STOP" raises immediately, "ASK"
 *        fires @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param timeout_sec Receive timeout in seconds. Defaults to 1.0.
 * @param flow_manager_args Optional PyFM step context. @p
 *        return_variable_name is written into its context and
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the receive failed, which
 *        raises instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call (success flag plus the raw
 *         payload in @c payload).
 *
 * @throws std::runtime_error If @p function_code is not 1 or 2, or the
 *         payload cannot be decoded as UTF-8; and, under "STOP", if the
 *         receive fails.
 */
RB_SDK_API RpcResult execute_socket_read(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                     int server_port, int function_code, const std::string& return_variable_name,
                                     const std::string& resolve_option = "SKIP", double timeout_sec = 1.0,
                                     FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

/**
 * @brief Sends data over a socket connection.
 *
 * @p function_code selects how @p payload is encoded before sending: 3
 * (BYTES) splits @p payload on the delimiter read from
 * `flow_manager_args.args["data"]["split"]` and parses each token as an
 * integer byte value; 4 (ASCII) encodes @p payload directly as ASCII
 * bytes.
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip Socket server IP address.
 * @param server_port Socket server port.
 * @param function_code 3 (BYTES, delimiter-split) or 4 (ASCII).
 * @param payload String payload to send; interpretation depends on
 *        @p function_code as described above.
 * @param resolve_option How to handle a failed send — "SKIP" continues
 *        without effect, "STOP" raises immediately, "ASK" fires
 *        @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param flow_manager_args Optional PyFM step context, required when
 *        @p function_code is 3 to look up the split delimiter.
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the send failed, which raises
 *        instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return RpcResult from the native call.
 *
 * @throws std::runtime_error If @p function_code is not 3 or 4, the
 *         BYTES split delimiter is missing, or @p payload cannot be
 *         parsed/encoded; and, under "STOP", if the send fails.
 */
RB_SDK_API RpcResult execute_socket_write(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                      int server_port, int function_code, const std::string& payload,
                                      const std::string& resolve_option = "SKIP",
                                      FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

/**
 * @brief Opens a socket connection and registers the session under @p
 *        module_name.
 *
 * Only creates the session (@c connect_sock()); it does not wait for a
 * response, so unlike the other execute_* calls in this file the GIL is
 * not released while the call runs.
 *
 * @param rpc RpcManager handle for the target connection, obtained via
 *        RBProgramSDK::get_rpc(module_name).
 * @param module_name PyFM task id identifying the calling step/task.
 * @param server_ip Socket server IP address.
 * @param server_port Socket server port.
 * @param resolve_option How to handle a failed connect — "SKIP"
 *        continues without effect, "STOP" raises immediately, "ASK"
 *        fires @p alarm_fn and pauses the PyFM context (requires
 *        @p flow_manager_args). Defaults to "SKIP".
 * @param flow_manager_args Optional PyFM step context.
 *        `flow_manager_args.done()` is called on completion (unless
 *        @p resolve_option is "STOP" and the connect failed, which
 *        raises instead).
 * @param alarm_fn Optional (title, content) callback used only when
 *        @p resolve_option is "ASK".
 *
 * @return true if the connection was established; false otherwise.
 *
 * @throws std::runtime_error Under "STOP", if the connect fails.
 */
RB_SDK_API bool execute_socket_connect(RpcManager& rpc, const std::string& module_name, const std::string& server_ip,
                                   int server_port, const std::string& resolve_option = "SKIP",
                                   FlowManagerArgsPtr flow_manager_args = nullptr, AlarmFn alarm_fn = nullptr);

}  // namespace rb_program_interface
