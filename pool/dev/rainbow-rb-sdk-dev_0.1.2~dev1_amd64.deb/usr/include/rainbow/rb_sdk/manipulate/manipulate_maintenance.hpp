#pragma once

#include "base.hpp"
#include "rb_sdk_api.hpp"
#include "common_struct_generated.h"
#include "func_config_generated.h"
#include "func_move_generated.h"
#include "func_return_generated.h"
#include "func_servo_generated.h"
#include "state_core_generated.h"

class RB_SDK_API RBManipulateMaintenanceSDK : public RBBaseSDK {
 public:
  RBManipulateMaintenanceSDK() {}

  static std::string type_name() { return "RBManipulateMaintenanceSDK"; }

  /**
   * @brief Requests the cobot to log/broadcast a joint board's info.
   *
   * This does not return the joint info through the SDK call itself — the
   * robot only reports success/failure here. The actual info is logged and
   * broadcast as a general message on the robot side (visible on the
   * teach-pendant/UI, not returned to this caller). Also powers the robot
   * on if it isn't already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         joint info payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_infos(std::string& robot_model, int board_no,
                                           FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's brake state.
   *
   * If @p brake_optioin is 1 (Open, Hard) or 2 (Weak), this powers the
   * robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to control. A negative value
   *        applies to every joint board.
   * @param brake_optioin Brake option: 0 (Close), 1 (Open, Hard), 2 (Weak),
   *        or 3 (Close only). (Parameter name matches the underlying wire
   *        field's spelling, including its typo.)
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_brake(std::string& robot_model, int board_no, int brake_optioin,
                                            FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to zero a joint board's encoder.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to zero. A negative value applies
   *        to every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_encoder_zero(std::string& robot_model, int board_no,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to run a joint board's current-sensor calibration procedure.
   *
   * This is a multi-stage physical calibration, not an instant reset:
   * cycles the brake and runs DQ-axis alignment (3 tries), DQ save (2
   * tries), and current nulling (2 tries), with real delays between steps.
   * Takes on the order of several seconds per joint. Powers the robot on
   * first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to calibrate. A negative value
   *        applies to every joint board (multiplying the total time).
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_sensor_reset(std::string& robot_model, int board_no,
                                                   FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's current-loop gains.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param pgain Proportional gain of the current control loop.
   * @param igain Integral gain of the current control loop.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_gain_cur(std::string& robot_model, int board_no, int pgain, int igain,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's position-loop gains.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param pgain Proportional gain of the position control loop.
   * @param igain Integral gain of the position control loop.
   * @param dgain Derivative gain of the position control loop.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_gain_pos(std::string& robot_model, int board_no, int pgain, int igain, int dgain,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to log/broadcast a joint board's current-loop gains.
   *
   * Counterpart to @c set_joint_gain_cur, but this does not return the
   * gain values through the SDK call — the robot only reports
   * success/failure here. The actual gains are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         gain payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_gain_cur(std::string& robot_model, int board_no,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to log/broadcast a joint board's position-loop gains.
   *
   * Counterpart to @c set_joint_gain_pos, but this does not return the
   * gain values through the SDK call — the robot only reports
   * success/failure here. The actual gains are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         gain payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_gain_pos(std::string& robot_model, int board_no,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to change a joint board's board-number assignment.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param channel_no Channel the joint board is on.
   * @param board_no Current joint board number. A negative value applies
   *        to every joint board.
   * @param target_no New board number to assign.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT call_joint_bno_change(std::string& robot_model, int channel_no, int board_no, int target_no,
                                                 FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's big-error/input-error pulse thresholds.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param bigerr Big-error pulse threshold.
   * @param inputerr Input-error pulse threshold.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_big_input(std::string& robot_model, int board_no, int bigerr, int inputerr,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to log/broadcast a joint board's big-error/input-error pulse thresholds.
   *
   * Counterpart to @c set_joint_big_input, but this does not return the
   * threshold values through the SDK call — the robot only reports
   * success/failure here. The actual values are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         threshold payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_big_input(std::string& robot_model, int board_no,
                                               FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to set a joint board's jam/overcurrent error thresholds.
   *
   * Powers the robot on first if it isn't already powered.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to configure. A negative value
   *        applies to every joint board.
   * @param jam_current Jam-error current limit, in mA.
   * @param jam_time Jam-error duration threshold, in units of 0.1s.
   * @param ovr_current Overcurrent-error current limit, in mA.
   * @param ovr_time Overcurrent-error duration threshold, in units of 0.1s
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing the request result.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT set_joint_jam_over(std::string& robot_model, int board_no, int jam_current, int jam_time,
                                              int ovr_current, int ovr_time,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);

  /**
   * @brief Requests the cobot to log/broadcast a joint board's jam/overcurrent error thresholds.
   *
   * Counterpart to @c set_joint_jam_over, but this does not return the
   * threshold values through the SDK call — the robot only reports
   * success/failure here. The actual values are logged and broadcast as a
   * general message on the robot side (visible on the teach-pendant/UI,
   * not returned to this caller). Also powers the robot on if it isn't
   * already.
   *
   * @param robot_model Name of the robot model.
   * @param board_no Joint board number to query. A negative value queries
   *        every joint board.
   * @param flow_manager_args Optional PyFM step context. If provided,
   *        completion is reported to the flow manager immediately
   *        (synchronous) once the result is received.
   *
   * @return IPC::Response_FunctionsT containing only success/failure — no
   *         threshold payload.
   *
   * @throws std::runtime_error If the query fails, @p board_no is out of
   *         range, or the result cannot be retrieved.
   */
  IPC::Response_FunctionsT pop_joint_jam_over(std::string& robot_model, int board_no,
                                              FlowManagerArgsPtr flow_manager_args = nullptr);
};
