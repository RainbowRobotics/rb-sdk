#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "rb_zenoh::rb_zenoh" for configuration "Release"
set_property(TARGET rb_zenoh::rb_zenoh APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(rb_zenoh::rb_zenoh PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/librb_zenoh.so.0.11.12"
  IMPORTED_SONAME_RELEASE "librb_zenoh.so.0.11.12"
  )

list(APPEND _IMPORT_CHECK_TARGETS rb_zenoh::rb_zenoh )
list(APPEND _IMPORT_CHECK_FILES_FOR_rb_zenoh::rb_zenoh "${_IMPORT_PREFIX}/lib/librb_zenoh.so.0.11.12" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
